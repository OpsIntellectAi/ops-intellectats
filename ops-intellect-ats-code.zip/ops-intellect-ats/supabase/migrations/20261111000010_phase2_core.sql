-- 0010 · Phase 2: core screens.
-- Adds the few columns the screens need, two read-only list views (RLS still applies:
-- they run as the person asking), and server-side actions for things that must be
-- checked or done in one step (add applicant, bulk upload, answer review, DSP invite,
-- user levels, new client, emergency stop).

-- ---------- columns ----------
alter table public.job_roles add column scheduling_link text
  check (scheduling_link is null or scheduling_link ~ '^https://[^\s]{4,300}$');
alter table public.applications add column booked_call_at timestamptz;
-- AI call results (filled by the voice webhook): full transcript, short overview, extracted facts.
alter table public.calls add column transcript text, add column summary text, add column facts jsonb;
alter table public.profiles add column invited_by uuid references public.profiles(id) on delete set null;
alter table public.client_settings add column dashboard_widgets text[] not null
  default array['kpis', 'funnel', 'calls_per_day', 'contact_health', 'onboarding', 'sources', 'days_in_stage', 'call_outcomes'];
alter table public.client_settings add column go_live_checklist jsonb not null default '{}'::jsonb;


-- Admins see the people they invited even before a Super Admin gives them a client.
create policy profiles_select_invited on public.profiles for select to authenticated
  using (invited_by = auth.uid() and public.can('users.manage'));

-- Non-secret settings the Edge Functions read (for example the allowed website addresses).
-- No policies: only the service role inside Edge Functions can read it.
create table public.app_config (
  key text primary key check (key ~ '^[a-z_]{2,60}$'),
  value text not null,
  updated_at timestamptz not null default now()
);
alter table public.app_config enable row level security;
revoke all on public.app_config from anon, authenticated;

-- ---------- helpers ----------
create or replace function public.normalize_us_phone(p text)
returns text
language sql
immutable
set search_path = ''
as $$
  select case
    when d ~ '^[2-9][0-9]{2}[2-9][0-9]{6}$' then '+1' || d
    when d ~ '^1[2-9][0-9]{2}[2-9][0-9]{6}$' then '+' || d
    else null
  end
  from (select regexp_replace(coalesce(p, ''), '[^0-9]', '', 'g') as d) x;
$$;
grant execute on function public.normalize_us_phone(text) to authenticated, service_role;
revoke execute on function public.normalize_us_phone(text) from public, anon;

-- Create any missing onboarding step rows for an application (status "Not started").
create or replace function private.ensure_onboarding_steps(p_application uuid)
returns void
language sql
security definer
set search_path = ''
as $$
  insert into public.onboarding_steps (application_id, client_id, step_def_id, status)
  select a.id, a.client_id, d.id, 'Not started'
  from public.applications a
  join public.onboarding_step_defs d on d.client_id = a.client_id
  where a.id = p_application
  on conflict (application_id, step_def_id) do nothing;
$$;

create or replace function private.applications_create_steps()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.stage in ('pre_onboarding', 'onboarding', 'hired') and (tg_op = 'INSERT' or new.stage is distinct from old.stage) then
    perform private.ensure_onboarding_steps(new.id);
  end if;
  return new;
end;
$$;

create trigger applications_create_steps after insert or update of stage on public.applications
  for each row execute function private.applications_create_steps();

-- Creating blank steps is not worth an activity-log row; real status changes are.
create or replace function private.audit_onboarding_step()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  step text;
begin
  if tg_op = 'INSERT' and new.status = 'Not started' then
    return new;
  end if;
  select d.name into step from public.onboarding_step_defs d where d.id = new.step_def_id;
  if tg_op = 'INSERT' or new.status is distinct from old.status or new.note is distinct from old.note then
    perform private.write_audit('Onboarding step', new.client_id, 'application', new.application_id::text, step,
      case when tg_op = 'UPDATE' then old.status end, new.status);
  end if;
  return new;
end;
$$;

-- ---------- list views (RLS of the underlying tables applies to the caller) ----------
create view public.application_rows with (security_invoker = true) as
select
  a.id, a.client_id, a.candidate_id, a.station_id, a.job_role_id, a.stage, a.owner_id, a.source,
  a.applied_at, a.stage_changed_at, a.not_interested_reason, a.not_interested_until, a.rejection_reason,
  a.booked_call_at,
  c.full_name, c.phone_e164, c.email, c.city, c.zip, c.time_zone, c.opted_out_at, c.is_landline, c.lives_in_nyc,
  m.last_out_at, m.last_in_at, coalesce(m.out_count, 0) as out_count, coalesce(m.in_count, 0) as in_count,
  m.last_body,
  (select mm.topics from public.messages mm
     where mm.application_id = a.id and mm.direction = 'inbound' order by mm.created_at desc limit 1) as last_topics,
  coalesce(k.ai_calls, 0) as ai_calls,
  coalesce(k.completed_ai_calls, 0) as completed_ai_calls,
  k.last_call_at, k.last_call_outcome,
  coalesce(k.unreviewed_calls, 0) as unreviewed_calls,
  (select count(*) from public.call_answers x join public.calls y on y.id = x.call_id
     where y.application_id = a.id and x.result = 'needs_review' and x.reviewed_at is null) as answers_to_review,
  coalesce(o.steps_total, 0) as steps_total,
  coalesce(o.steps_done, 0) as steps_done,
  coalesce(o.required_left, 0) as required_left,
  o.last_step_change
from public.applications a
join public.candidates c on c.id = a.candidate_id
left join lateral (
  select
    max(mx.created_at) filter (where mx.direction = 'outbound') as last_out_at,
    max(mx.created_at) filter (where mx.direction = 'inbound') as last_in_at,
    count(*) filter (where mx.direction = 'outbound') as out_count,
    count(*) filter (where mx.direction = 'inbound') as in_count,
    (array_agg(mx.body order by mx.created_at desc))[1] as last_body
  from public.messages mx where mx.application_id = a.id
) m on true
left join lateral (
  select
    count(*) filter (where cl.via = 'ai') as ai_calls,
    count(*) filter (where cl.via = 'ai' and cl.outcome = 'completed') as completed_ai_calls,
    max(coalesce(cl.started_at, cl.created_at)) as last_call_at,
    (array_agg(cl.outcome order by coalesce(cl.started_at, cl.created_at) desc))[1] as last_call_outcome,
    count(*) filter (where cl.via = 'ai' and cl.outcome = 'completed'
      and not exists (select 1 from public.call_reviews r where r.call_id = cl.id)) as unreviewed_calls
  from public.calls cl where cl.application_id = a.id
) k on true
left join lateral (
  select
    count(*) as steps_total,
    count(*) filter (where s.status = any (d.done_statuses) or s.status = 'Waived') as steps_done,
    count(*) filter (where d.required and not (s.status = any (d.done_statuses) or s.status = 'Waived')) as required_left,
    max(s.changed_at) as last_step_change
  from public.onboarding_steps s join public.onboarding_step_defs d on d.id = s.step_def_id
  where s.application_id = a.id
) o on true;

create view public.call_rows with (security_invoker = true) as
select
  cl.id, cl.client_id, cl.application_id, cl.provider, cl.direction, cl.via, cl.outcome, cl.duration_seconds,
  cl.recording_path, cl.script_version_id, cl.attempt_number, cl.placed_by, cl.started_at, cl.ended_at, cl.created_at,
  a.job_role_id, a.station_id, a.owner_id, a.stage,
  c.full_name, c.phone_e164,
  (select count(*) from public.call_answers x where x.call_id = cl.id and x.result = 'needs_review' and x.reviewed_at is null) as answers_to_review,
  (select r.verdict from public.call_reviews r where r.call_id = cl.id order by r.created_at desc limit 1) as review_verdict,
  (select r.reason from public.call_reviews r where r.call_id = cl.id order by r.created_at desc limit 1) as review_reason
from public.calls cl
join public.applications a on a.id = cl.application_id
join public.candidates c on c.id = a.candidate_id;

revoke all on public.application_rows, public.call_rows from anon;
grant select on public.application_rows, public.call_rows to authenticated;

-- ---------- people in a client (names and levels only) ----------
create or replace function public.client_team(p_client uuid)
returns table (user_id uuid, full_name text, role public.app_role, station_ids uuid[])
language sql
stable
security definer
set search_path = ''
as $$
  select p.id, p.full_name, p.role, u.station_ids
  from public.user_client_access u
  join public.profiles p on p.id = u.user_id
  where u.client_id = p_client and p.status = 'active' and public.has_client_access(p_client)
  order by p.full_name;
$$;

-- Super Admin only: how many other clients this person (same phone) applied to.
create or replace function public.applied_elsewhere(p_candidate uuid)
returns integer
language sql
stable
security definer
set search_path = ''
as $$
  select case when public.is_super_admin() then (
    select count(*)::integer from public.candidates o
    join public.candidates c on c.phone_e164 = o.phone_e164 and o.client_id <> c.client_id
    where c.id = p_candidate
  ) end;
$$;

-- ---------- add one applicant ----------
create or replace function public.add_applicant(
  p_client uuid,
  p_station uuid,
  p_job_role uuid,
  p_full_name text,
  p_phone text,
  p_email text default null,
  p_city text default null,
  p_zip text default null,
  p_source text default 'Direct',
  p_owner uuid default null,
  p_consent_sms boolean default false,
  p_consent_ai boolean default false,
  p_consent_recording boolean default false
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_phone text := public.normalize_us_phone(p_phone);
  v_email text := nullif(lower(trim(coalesce(p_email, ''))), '');
  v_zip text := nullif(trim(coalesce(p_zip, '')), '');
  v_name text := trim(regexp_replace(coalesce(p_full_name, ''), '\s+', ' ', 'g'));
  v_cand uuid;
  v_app uuid;
  v_owner uuid;
  v_role public.app_role := public.auth_user_role();
  t public.consent_type;
begin
  if not public.can('candidates.act') or not public.has_client_access(p_client) or not public.has_station_access(p_station) then
    raise exception 'Your access level cannot add applicants here' using errcode = 'insufficient_privilege';
  end if;
  if not exists (select 1 from public.job_roles j where j.id = p_job_role and j.station_id = p_station and j.client_id = p_client) then
    raise exception 'That job role is not at this station' using errcode = 'check_violation';
  end if;
  if length(v_name) < 2 or length(v_name) > 120 then
    raise exception 'Full name is required' using errcode = 'check_violation';
  end if;
  if v_phone is null then
    raise exception 'Phone is not a valid US mobile number' using errcode = 'check_violation';
  end if;
  if v_email is not null and v_email !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' then
    raise exception 'Email is not valid' using errcode = 'check_violation';
  end if;
  if v_zip is not null and v_zip !~ '^[0-9]{5}$' then
    raise exception 'ZIP must be 5 digits' using errcode = 'check_violation';
  end if;

  -- Same phone in the same client: block and point to the existing person.
  select c.id into v_cand from public.candidates c where c.client_id = p_client and c.phone_e164 = v_phone;
  if v_cand is not null then
    select a.id into v_app from public.applications a where a.candidate_id = v_cand order by a.created_at desc limit 1;
    return jsonb_build_object(
      'status', 'duplicate',
      'candidate_id', v_cand,
      'application_id', v_app,
      'visible', public.candidate_visible(v_cand),
      'name', case when public.candidate_visible(v_cand) then (select full_name from public.candidates where id = v_cand) end
    );
  end if;

  if v_role = 'csr' then
    v_owner := auth.uid();
  elsif p_owner is not null then
    if not exists (select 1 from public.user_client_access u join public.profiles p on p.id = u.user_id
                   where u.user_id = p_owner and u.client_id = p_client and p.role in ('csr', 'supervisor', 'admin', 'super_admin')) then
      raise exception 'That person cannot own candidates in this client' using errcode = 'check_violation';
    end if;
    v_owner := p_owner;
  end if;

  insert into public.candidates (client_id, full_name, phone_e164, email, city, zip)
  values (p_client, v_name, v_phone, v_email, nullif(trim(coalesce(p_city, '')), ''), v_zip)
  returning id into v_cand;

  insert into public.applications (client_id, candidate_id, station_id, job_role_id, owner_id, source)
  values (p_client, v_cand, p_station, p_job_role, v_owner, left(coalesce(nullif(trim(p_source), ''), 'Direct'), 40))
  returning id into v_app;

  foreach t in array array['sms', 'ai_call', 'recording']::public.consent_type[] loop
    if (t = 'sms' and p_consent_sms) or (t = 'ai_call' and p_consent_ai) or (t = 'recording' and p_consent_recording) then
      insert into public.consents (candidate_id, client_id, consent_type, wording_version, source, ip)
      values (v_cand, p_client, t, 'v1-2026-11', 'Recorded by recruiter when adding the applicant',
              private.safe_inet(private.req_header('x-forwarded-for')));
    end if;
  end loop;

  return jsonb_build_object('status', 'added', 'candidate_id', v_cand, 'application_id', v_app);
end;
$$;

-- ---------- bulk upload (preview with p_dry_run = true, then import) ----------
create or replace function public.import_applicants(
  p_client uuid,
  p_station uuid,
  p_job_role uuid,
  p_rows jsonb,
  p_dry_run boolean default true,
  p_consent_sms boolean default false,
  p_consent_ai boolean default false,
  p_consent_recording boolean default false
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  r jsonb;
  i integer := 0;
  v_role_name text;
  v_phone text;
  v_name text;
  v_seen text[] := '{}';
  v_skipped jsonb := '[]'::jsonb;
  v_ready integer := 0;
  v_added integer := 0;
  v_res jsonb;
  v_file_role text;
begin
  if not public.can('candidates.act') or not public.has_client_access(p_client) or not public.has_station_access(p_station) then
    raise exception 'Your access level cannot upload applicants here' using errcode = 'insufficient_privilege';
  end if;
  select j.name into v_role_name from public.job_roles j where j.id = p_job_role and j.station_id = p_station and j.client_id = p_client;
  if v_role_name is null then
    raise exception 'That job role is not at this station' using errcode = 'check_violation';
  end if;
  if jsonb_typeof(p_rows) <> 'array' or jsonb_array_length(p_rows) = 0 then
    raise exception 'The file has no rows' using errcode = 'check_violation';
  end if;
  if jsonb_array_length(p_rows) > 2000 then
    raise exception 'Upload at most 2,000 rows at a time' using errcode = 'check_violation';
  end if;

  for r in select * from jsonb_array_elements(p_rows) loop
    i := i + 1;
    v_name := trim(regexp_replace(coalesce(r ->> 'full_name', ''), '\s+', ' ', 'g'));
    v_phone := public.normalize_us_phone(r ->> 'phone');
    v_file_role := nullif(trim(coalesce(r ->> 'job_role', '')), '');
    if length(v_name) < 2 then
      v_skipped := v_skipped || jsonb_build_object('row', i, 'name', v_name, 'reason', 'Full Name is missing');
    elsif v_phone is null then
      v_skipped := v_skipped || jsonb_build_object('row', i, 'name', v_name, 'reason', 'Phone is missing or not a valid US number');
    elsif v_file_role is not null and lower(v_file_role) <> lower(v_role_name) then
      v_skipped := v_skipped || jsonb_build_object('row', i, 'name', v_name, 'reason', 'Different job role (' || v_file_role || ')');
    elsif v_phone = any (v_seen) then
      v_skipped := v_skipped || jsonb_build_object('row', i, 'name', v_name, 'reason', 'Same phone twice in this file');
    elsif exists (select 1 from public.candidates c where c.client_id = p_client and c.phone_e164 = v_phone) then
      v_skipped := v_skipped || jsonb_build_object('row', i, 'name', v_name, 'reason', 'Already a candidate in this client');
    else
      v_seen := v_seen || v_phone;
      v_ready := v_ready + 1;
      if not p_dry_run then
        begin
          v_res := public.add_applicant(p_client, p_station, p_job_role, v_name, v_phone, r ->> 'email', r ->> 'city', r ->> 'zip',
            coalesce(nullif(r ->> 'source', ''), 'Bulk upload'), null, p_consent_sms, p_consent_ai, p_consent_recording);
          if v_res ->> 'status' = 'added' then
            v_added := v_added + 1;
          end if;
        exception when check_violation then
          v_skipped := v_skipped || jsonb_build_object('row', i, 'name', v_name, 'reason', sqlerrm);
          v_ready := v_ready - 1;
        end;
      end if;
    end if;
  end loop;

  if not p_dry_run then
    perform private.write_audit('Bulk upload', p_client, 'job_role', p_job_role::text, v_role_name,
      null, v_added || ' added, ' || jsonb_array_length(v_skipped) || ' skipped', v_added > 30,
      case when v_added > 30 then 'Bulk action over 30 candidates' end);
  end if;

  return jsonb_build_object('ready', v_ready, 'added', v_added, 'skipped', v_skipped, 'dry_run', p_dry_run);
end;
$$;

-- ---------- reviews ----------
create or replace function public.review_answer(p_answer uuid, p_result public.answer_result)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v public.call_answers;
begin
  select * into v from public.call_answers where id = p_answer;
  if v.id is null or not public.can('calls.review') or not public.call_visible(v.call_id) then
    raise exception 'You cannot review this answer' using errcode = 'insufficient_privilege';
  end if;
  if p_result not in ('yes', 'no') then
    raise exception 'Choose Yes or No' using errcode = 'check_violation';
  end if;
  update public.call_answers set result = p_result, reviewed_by = auth.uid(), reviewed_at = now() where id = p_answer;
  perform private.write_audit('Answer reviewed', v.client_id, 'call', v.call_id::text, v.question_text, v.result::text, p_result::text);
end;
$$;

-- ---------- DSP invite (sent by hand in the portal, then marked here) ----------
create or replace function public.mark_dsp_invite_sent(p_application uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  a public.applications;
begin
  select * into a from public.applications where id = p_application;
  if a.id is null or not public.can('onboarding.update') or not public.application_visible(a.client_id, a.station_id, a.owner_id) then
    raise exception 'You cannot update this candidate' using errcode = 'insufficient_privilege';
  end if;
  if a.stage not in ('shortlisted', 'pre_onboarding', 'onboarding') then
    raise exception 'Only shortlisted or pre-onboarding candidates get a DSP invite' using errcode = 'check_violation';
  end if;
  perform private.ensure_onboarding_steps(a.id);
  update public.onboarding_steps s set status = 'Invited'
  from public.onboarding_step_defs d
  where d.id = s.step_def_id and d.key = 'dsp_invite' and s.application_id = a.id and s.status = 'Not started';
  if a.stage <> 'onboarding' then
    update public.applications set stage = 'onboarding' where id = a.id;
  end if;
end;
$$;

-- ---------- user levels and status ----------
create or replace function public.set_user_role(p_user uuid, p_role public.app_role, p_status public.user_status)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  t public.profiles;
  me_super boolean := public.is_super_admin();
begin
  select * into t from public.profiles where id = p_user;
  if t.id is null or not public.can('users.manage') then
    raise exception 'You cannot change this user' using errcode = 'insufficient_privilege';
  end if;
  if p_user = auth.uid() then
    raise exception 'You cannot change your own level' using errcode = 'insufficient_privilege';
  end if;
  if not me_super then
    if t.role in ('admin', 'super_admin') or p_role in ('admin', 'super_admin') then
      raise exception 'Only a Super Admin can create or change Admins' using errcode = 'insufficient_privilege';
    end if;
    if not (t.invited_by = auth.uid() or public.shares_client_with(p_user)) then
      raise exception 'You cannot change this user' using errcode = 'insufficient_privilege';
    end if;
  end if;
  if p_role = 'super_admin' and t.role <> 'super_admin'
     and (select count(*) from public.profiles where role = 'super_admin' and status = 'active') >= 3 then
    raise exception 'There can be at most 3 Super Admins' using errcode = 'check_violation';
  end if;
  update public.profiles set role = p_role, status = p_status where id = p_user;
end;
$$;

-- ---------- new client with sensible defaults (Super Admin) ----------
create or replace function private.seed_client_defaults(p_client uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.onboarding_step_defs (client_id, key, name, phase, owner_label, statuses, done_statuses, bad_statuses, guidance, required, sort_order)
  select p_client, d.key, d.name, d.phase, d.owner_label, d.statuses, d.done_statuses, d.bad_statuses, d.guidance, d.required, d.sort_order
  from (values
    ('licence', 'Driver''s licence verification', 'Pre-hire', 'CSR', array['Not started','Pending','Verified','Failed','Waived'], array['Verified'], array['Failed'], '{}'::jsonb, true, 1),
    ('dsp_invite', 'DSP Portal invitation', 'Pre-hire', 'CSR', array['Not started','Invited','Account created','Associate Settings done','Waived'], array['Associate Settings done'], array[]::text[], '{"Invited":"The invite is sent by hand in the Amazon DSP portal, then marked here."}'::jsonb, true, 2),
    ('offer', 'Offer letter', 'Pre-hire', 'CSR', array['Not started','Sent','Signed','Declined','Waived'], array['Signed'], array['Declined'], '{}'::jsonb, true, 3),
    ('handbook', 'Handbook', 'Pre-hire', 'CSR', array['Not started','Sent','Acknowledged','Waived'], array['Acknowledged'], array[]::text[], '{}'::jsonb, true, 4),
    ('background', 'Background check', 'Screening', 'Ops', array['Not started','Draft / Pending','Report Review','Meets Requirements','Adverse','Waived'], array['Meets Requirements'], array['Adverse'], '{"Report Review":"Report Review cannot be expedited.","Adverse":"Adverse results go to the client. Do not explain the result to the candidate yourself."}'::jsonb, true, 5),
    ('drug_test', 'Drug test', 'Screening', 'Ops', array['Not started','Ordered','Collected','Negative','Negative Dilute','Positive','Waived'], array['Negative'], array['Positive'], '{"Collected":"Collected is not a result. Wait for the lab.","Negative Dilute":"Negative Dilute is its own status. Follow the client''s retest policy.","Positive":"Positive results go to the client."}'::jsonb, true, 6),
    ('payroll', 'Payroll profile', 'Paperwork', 'Ops', array['Not started','Sent','Completed','Waived'], array['Completed'], array[]::text[], '{}'::jsonb, true, 7),
    ('wotc', 'WOTC', 'Paperwork', 'Ops', array['Not started','Sent','Completed','Waived'], array['Completed'], array[]::text[], '{}'::jsonb, false, 8),
    ('i9', 'I-9', 'Paperwork', 'Ops', array['Not started','Section 1 done','Verified','Waived'], array['Verified'], array[]::text[], '{}'::jsonb, true, 9),
    ('ready_email', 'Ready for Training email', 'Training', 'CSR', array['Not started','Sent','Waived'], array['Sent'], array[]::text[], '{}'::jsonb, true, 10),
    ('training_1', 'Training Day 1', 'Training', 'Station', array['Not started','Booked','Pass','No-show','Fail','Waived'], array['Pass'], array['No-show','Fail'], '{}'::jsonb, true, 11),
    ('training_2', 'Training Day 2', 'Training', 'Station', array['Not started','Booked','Pass','No-show','Fail','Waived'], array['Pass'], array['No-show','Fail'], '{}'::jsonb, true, 12),
    ('active', 'Active / client notified', 'Done', 'CSR', array['Not started','Notified','Waived'], array['Notified'], array[]::text[], '{}'::jsonb, true, 13)
  ) as d(key, name, phase, owner_label, statuses, done_statuses, bad_statuses, guidance, required, sort_order)
  on conflict (client_id, key) do nothing;

  insert into public.message_templates (client_id, name, body, stages, is_scheduling_link)
  select p_client, t.name, t.body, t.stages::public.app_stage[], t.link
  from (values
    ('Free for an AI call?', 'Hi [first name], if you are free we can do a quick AI call for the [role] role at [client]. Reply YES and we will call you now.', array['interview'], true),
    ('AI call scheduling link', 'Hi [first name], book your short AI interview for the [role] role here: [link]', array['interview'], true),
    ('Ask for email', 'Hi [first name], please text us an email address you have never used with Amazon, so we can send your onboarding invitation.', array['interview','shortlisted','pre_onboarding'], false),
    ('Background check', 'Hi [first name], your background check link is in your email. Please finish it today; it takes about 10 minutes.', array['onboarding'], false)
  ) as t(name, body, stages, link)
  on conflict (client_id, name) do nothing;

  insert into public.step_messages (client_id, trigger_key, label, body, enabled)
  select p_client, s.k, s.label, s.body, s.enabled
  from (values
    ('first_text', 'First text', 'Hi [first name], thanks for applying for [role] at [client]! Book your short AI interview here: [link]. Reply STOP to opt out.', true),
    ('follow_up_day2', 'Follow-up · day 2', 'Hi [first name], just checking in about the [role] role at [client]. Book a time that suits you: [link]', true),
    ('follow_up_day5', 'Final text · day 5', 'Hi [first name], last reminder about the [role] role at [client]. If you are still interested, book here: [link]', true),
    ('stage:shortlisted', 'Shortlisted', 'Great news [first name]! You passed the interview for [role] at [client]. Reply with your email so we can start onboarding.', true),
    ('step:dsp_invite:Associate Settings done', 'DSP Portal passed', 'You are all set on the DSP Portal, [first name]. Next: your offer letter and background check.', true),
    ('step:offer:Sent', 'Offer sent', 'Hi [first name], your offer letter for [role] at [client] is in your email. Please sign it today.', true),
    ('step:background:Draft / Pending', 'Background check started', 'Hi [first name], your background check has started. Watch your email for the link.', true),
    ('step:drug_test:Ordered', 'Drug test ordered', 'Hi [first name], your drug test is ordered. Go to the collection site within 24 hours with photo ID.', true),
    ('step:drug_test:Negative', 'Drug test passed', 'Hi [first name], your drug test came back clear. Next: training.', true),
    ('step:training_1:Booked', 'Training booked', 'Hi [first name], your training day is booked. We will text you the details.', true),
    ('stage:hired', 'Hired', 'Congratulations [first name], you are hired at [client]!', true)
  ) as s(k, label, body, enabled)
  on conflict (client_id, trigger_key) do nothing;

  insert into public.call_reminders (client_id, minutes_before, body, enabled)
  select p_client, r.m, r.body, r.enabled
  from (values
    (300, 'Hi [first name], reminder: your AI interview for [role] at [client] is today at [time]. Reply C to change the time.', false),
    (120, 'Hi [first name], your AI interview for [role] at [client] is at [time] today, about 8 minutes. Reply C to change the time.', true),
    (15, 'Hi [first name], your AI interview starts at [time], in 15 minutes. Keep your phone close.', true)
  ) as r(m, body, enabled)
  on conflict (client_id, minutes_before) do nothing;

  insert into public.alert_rules (client_id, rule_key, label, threshold, channel)
  select p_client, r.k, r.label, r.t, r.ch::public.alert_channel
  from (values
    ('answer_rate', 'Answer rate on AI calls today drops below (%)', 70, 'text_email'),
    ('unreviewed_calls', 'AI calls not reviewed for 24 hours reach', 5, 'text_email'),
    ('shortlisted_no_reply', 'Shortlisted with no reply for 2+ days reach', 3, 'email'),
    ('onboarding_stuck', 'People stuck in onboarding over 24 h reach', 3, 'email'),
    ('behind_target', 'Hiring falls behind target pace by', 2, 'email')
  ) as r(k, label, t, ch)
  on conflict (client_id, rule_key) do nothing;
end;
$$;

-- Existing clients get the new automatic texts (first text, follow-ups, more steps).
do $$
declare c uuid;
begin
  for c in select id from public.clients loop
    perform private.seed_client_defaults(c);
  end loop;
end $$;

create or replace function public.create_client(
  p_name text,
  p_slug text,
  p_time_zone text,
  p_station_code text,
  p_station_name text,
  p_station_address text default null
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_client uuid;
begin
  if not public.can('platform.admin') then
    raise exception 'Only a Super Admin can add a client' using errcode = 'insufficient_privilege';
  end if;
  if p_time_zone not in (select name from pg_catalog.pg_timezone_names) then
    raise exception 'Unknown time zone' using errcode = 'check_violation';
  end if;
  insert into public.clients (name, slug) values (trim(p_name), lower(trim(p_slug))) returning id into v_client;
  insert into public.client_settings (client_id, time_zone) values (v_client, p_time_zone);
  insert into public.stations (client_id, code, name, address, time_zone)
  values (v_client, upper(trim(p_station_code)), trim(p_station_name), nullif(trim(coalesce(p_station_address, '')), ''), p_time_zone);
  perform private.seed_client_defaults(v_client);
  return v_client;
end;
$$;

-- ---------- emergency stop (Admin and Super Admin) ----------
create or replace function public.set_emergency_stop(p_on boolean)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.can('settings.edit') then
    raise exception 'Only Admins can use the emergency stop' using errcode = 'insufficient_privilege';
  end if;
  update public.feature_flags set enabled = p_on, updated_by = auth.uid() where key = 'emergency_stop';
  perform private.write_audit(case when p_on then 'Emergency stop ON' else 'Emergency stop OFF' end, null, 'setting', 'emergency_stop',
    'Emergency stop', (not p_on)::text, p_on::text, true, 'Emergency stop changed');
end;
$$;

-- ---------- record exports and downloads in the activity log ----------
create or replace function public.log_action(p_action text, p_client uuid, p_label text, p_rows integer default null)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if public.auth_user_role() is null then
    raise exception 'Not signed in' using errcode = 'insufficient_privilege';
  end if;
  if p_action not in ('CSV exported', 'Candidate file downloaded', 'Transcript downloaded', 'Activity log exported', 'Training pack downloaded', 'Bulk assign') then
    raise exception 'Unknown action' using errcode = 'check_violation';
  end if;
  if p_client is not null and not public.has_client_access(p_client) then
    raise exception 'No access to this client' using errcode = 'insufficient_privilege';
  end if;
  perform private.write_audit(p_action, p_client, 'export', null, left(p_label, 200), null,
    case when p_rows is not null then p_rows || ' rows' end, coalesce(p_rows, 0) > 30,
    case when coalesce(p_rows, 0) > 30 then 'Large export' end);
end;
$$;

-- ---------- automatic texts waiting for the sending window ----------
create or replace function public.queued_job_count(p_client uuid)
returns integer
language sql
stable
security definer
set search_path = ''
as $$
  select case when public.has_client_access(p_client) then (
    select count(*)::integer from public.job_queue j
    where j.client_id = p_client and j.status = 'queued' and j.kind in ('send_sms', 'follow_up', 'call_reminder')
  ) end;
$$;

-- ---------- grants ----------
do $$
declare f text;
begin
  foreach f in array array[
    'public.client_team(uuid)',
    'public.applied_elsewhere(uuid)',
    'public.add_applicant(uuid, uuid, uuid, text, text, text, text, text, text, uuid, boolean, boolean, boolean)',
    'public.import_applicants(uuid, uuid, uuid, jsonb, boolean, boolean, boolean, boolean)',
    'public.review_answer(uuid, public.answer_result)',
    'public.mark_dsp_invite_sent(uuid)',
    'public.set_user_role(uuid, public.app_role, public.user_status)',
    'public.create_client(text, text, text, text, text, text)',
    'public.set_emergency_stop(boolean)',
    'public.log_action(text, uuid, text, integer)',
    'public.queued_job_count(uuid)'
  ] loop
    execute format('revoke execute on function %s from public, anon', f);
    execute format('grant execute on function %s to authenticated, service_role', f);
  end loop;
end $$;
