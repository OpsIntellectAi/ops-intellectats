-- 0004 · Reports, alerts, views, devices, activity log, queues, bugs, assistant, compliance

create table public.alert_rules (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  rule_key text not null check (rule_key in ('answer_rate', 'unreviewed_calls', 'shortlisted_no_reply', 'onboarding_stuck', 'behind_target')),
  label text not null,
  threshold numeric not null check (threshold >= 0),
  channel public.alert_channel not null default 'email',
  enabled boolean not null default true,
  updated_at timestamptz not null default now(),
  unique (client_id, rule_key)
);

create table public.alert_log (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  rule_id uuid references public.alert_rules(id) on delete set null,
  message text not null,
  sent_to text not null,
  channel public.alert_channel not null,
  is_test boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.hiring_targets (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  job_role_id uuid not null,
  hires integer not null check (hires > 0),
  from_date date not null,
  by_date date not null,
  created_by uuid references public.profiles(id) on delete set null,
  updated_at timestamptz not null default now(),
  foreign key (job_role_id, client_id) references public.job_roles(id, client_id) on delete cascade,
  unique (client_id, job_role_id),
  check (by_date > from_date)
);

create table public.saved_views (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  owner_id uuid not null references public.profiles(id) on delete cascade,
  name text not null check (length(trim(name)) between 2 and 60),
  filters jsonb not null default '{}'::jsonb,
  shared boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  device_key text not null check (device_key ~ '^[0-9a-f-]{36}$'),
  label text not null default 'Unknown device',
  user_agent text,
  first_ip inet,
  last_ip inet,
  last_location text,
  first_seen_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  trusted boolean not null default false,
  blocked boolean not null default false,
  blocked_by uuid references public.profiles(id),
  blocked_at timestamptz,
  unique (user_id, device_key)
);

-- Append-only. No role (not even the service role) can update or delete a row: see 0007.
create table public.audit_log (
  id bigint generated always as identity primary key,
  occurred_at timestamptz not null default now(),
  actor_id uuid,
  actor_role public.app_role,
  client_id uuid,
  action text not null,
  target_type text,
  target_id text,
  target_label text,
  before_value text,
  after_value text,
  device_key text,
  ip inet,
  user_agent text,
  flagged boolean not null default false,
  flag_reason text
);

create table public.idempotency_keys (
  key text primary key,
  source text not null,
  created_at timestamptz not null default now()
);

create table public.job_queue (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references public.clients(id) on delete cascade,
  kind text not null check (kind in ('send_sms', 'ai_call', 'call_reminder', 'follow_up', 'alert_check', 'weekly_report', 'retention')),
  payload jsonb not null default '{}'::jsonb,
  run_at timestamptz not null,
  status public.job_status not null default 'queued',
  attempts integer not null default 0,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.bug_reports (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references public.clients(id) on delete set null,
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  priority public.bug_priority not null default 'p2',
  title text not null check (length(trim(title)) between 3 and 140),
  description text not null default '',
  page text,
  status text not null default 'open' check (status in ('open', 'in_progress', 'fixed', 'wont_fix')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.ai_assistant_log (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  client_id uuid references public.clients(id) on delete set null,
  question text not null,
  answer text,
  tools_used jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);

create table public.aedt_notices (
  id uuid primary key default gen_random_uuid(),
  candidate_id uuid not null,
  client_id uuid not null,
  sent_at timestamptz not null,
  method text not null check (method in ('sms', 'email')),
  asked_for_person boolean not null default false,
  created_at timestamptz not null default now(),
  foreign key (candidate_id, client_id) references public.candidates(id, client_id) on delete cascade
);

-- Fixed-window rate limit counters. Written only through hit_rate_limit() by Edge Functions.
create table public.rate_limits (
  key text not null,
  window_start timestamptz not null,
  count integer not null default 0,
  primary key (key, window_start)
);

create trigger alert_rules_updated_at before update on public.alert_rules for each row execute function public.set_updated_at();
create trigger hiring_targets_updated_at before update on public.hiring_targets for each row execute function public.set_updated_at();
create trigger job_queue_updated_at before update on public.job_queue for each row execute function public.set_updated_at();
create trigger bug_reports_updated_at before update on public.bug_reports for each row execute function public.set_updated_at();

create index audit_log_client_time_idx on public.audit_log(client_id, occurred_at desc);
create index audit_log_actor_idx on public.audit_log(actor_id, occurred_at desc);
create index job_queue_due_idx on public.job_queue(status, run_at);
create index devices_user_idx on public.devices(user_id);
create index saved_views_client_idx on public.saved_views(client_id);
