-- 0008 · Reference data that every environment needs (not demo data):
-- the permission matrix and the feature switches.

insert into public.role_permissions (role, permission)
select r::public.app_role, p
from (values
  -- See candidates, calls, messages, dashboard of their scope
  ('view',               array['csr','supervisor','admin','super_admin','ops','station_manager','dsp_manager','viewer']),
  -- AI call / phone candidates, move stages, add or upload applicants
  ('candidates.act',     array['csr','supervisor','admin','super_admin']),
  -- Text candidates (single, bulk, reminders)
  ('messages.send',      array['csr','supervisor','admin','super_admin','ops']),
  -- Update onboarding steps, mark DSP invite sent, move to Onboarding/Hired
  ('onboarding.update',  array['csr','supervisor','admin','super_admin','ops','station_manager']),
  -- Review AI calls and unclear answers
  ('calls.review',       array['csr','supervisor','admin','super_admin']),
  -- Team board, AI insights, reports (view)
  ('reports.view',       array['supervisor','admin','super_admin','station_manager','dsp_manager','viewer']),
  -- AI recruitment assistant (answers limited to own scope)
  ('assistant.use',      array['csr','supervisor','admin','super_admin','ops','station_manager','dsp_manager','viewer']),
  -- Assign candidates to CSRs
  ('candidates.assign',  array['supervisor','admin','super_admin']),
  -- Activity log (Supervisor: own team)
  ('audit.view',         array['supervisor','admin','super_admin']),
  -- All users' activity, devices, export log
  ('audit.view_all',     array['admin','super_admin']),
  -- Add/edit message templates
  ('templates.edit',     array['supervisor','admin','super_admin']),
  -- Customize dashboard, automatic messages, client info, emergency stop
  ('settings.edit',      array['admin','super_admin']),
  -- Weekly client report, alert rules, hiring targets, AI training pack
  ('reports.manage',     array['admin','super_admin']),
  -- Add users and set levels below Admin
  ('users.manage',       array['admin','super_admin']),
  -- Create Admins/Super Admins, client setup, AI script, add client, feature switches,
  -- give client access, block device
  ('platform.admin',     array['super_admin'])
) as m(p, roles), unnest(m.roles) as r;

insert into public.feature_flags (key, label, description) values
  ('my_day', 'My day screen per role', 'CSRs open to their next 10 actions; Supervisors see each CSR''s load and what is overdue.'),
  ('alerts', 'Alerts on the numbers', 'Text or email Supervisors when a number crosses a line.'),
  ('review_quality', 'Review quality score', 'How often reviewers flag the AI and why, and which script question to fix.'),
  ('saved_views', 'Saved views and filters', 'One-click candidate lists, private or shared with the team.'),
  ('weekly_report', 'Weekly client report', 'Emailed to the client contact every Monday at 8:00 AM ET.'),
  ('self_service', 'Candidate self-service link', 'Candidates reschedule, upload their licence and see their checklist.'),
  ('bulk_actions', 'Bulk actions from any list', 'Text everyone, retry AI calls at the best time, or reassign.'),
  ('hiring_targets', 'Hiring targets per client', 'Target hires by a date, with an on-pace line.'),
  ('phone_layout', 'Phone layout for Supervisors', 'My day, Today, reviews and stats fit a phone screen.'),
  ('step_texts', 'Automatic text at every step', 'Shortlisted, DSP Portal, drug test and more, each with its own switch.'),
  ('ai_assistant', 'AI recruitment assistant', 'Ask questions about your own candidates in plain English.'),
  ('emergency_stop', 'Emergency stop', 'When ON, every automated text, reminder, AI call and bulk send is paused.')
on conflict (key) do nothing;

-- Emergency stop starts OFF (switch is "enabled" = stop active).
update public.feature_flags set enabled = false where key = 'emergency_stop';

-- Private storage buckets. Files are opened only through signed URLs (<= 10 minutes)
-- created by Edge Functions; there are deliberately no storage policies for users.
insert into storage.buckets (id, name, public)
values ('recordings', 'recordings', false), ('licences', 'licences', false), ('documents', 'documents', false)
on conflict (id) do update set public = false;
