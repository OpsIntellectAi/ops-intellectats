-- 0013 · Keep the pg_net extension out of the public API schema (Supabase security advisor).
-- Its functions live in the "net" schema either way; the scheduler job keeps working.
do $$
begin
  if exists (select 1 from pg_extension e join pg_namespace n on n.oid = e.extnamespace
             where e.extname = 'pg_net' and n.nspname = 'public') then
    drop extension pg_net;
    create extension pg_net with schema extensions;
  end if;
end $$;
