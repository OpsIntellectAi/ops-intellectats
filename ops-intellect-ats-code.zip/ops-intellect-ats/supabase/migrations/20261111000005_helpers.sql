-- 0005 · Access helper functions used by every RLS policy and every Edge Function.
-- All are SECURITY DEFINER with an empty search_path, so they read the access tables
-- without being blocked by RLS and cannot be hijacked by objects in other schemas.

create schema if not exists private;
revoke all on schema private from public;
grant usage on schema private to authenticated, service_role;

-- Request header sent by PostgREST (device key, IP, user agent) for the activity log.
create or replace function private.req_header(p_name text)
returns text
language sql
stable
set search_path = ''
as $$
  select nullif(coalesce(current_setting('request.headers', true), '{}')::json ->> lower(p_name), '');
$$;

-- A session is valid for 12 hours after sign-in, whatever the refresh token says.
create or replace function private.session_ok()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when auth.uid() is null then false
    when nullif(auth.jwt() ->> 'session_id', '') is null then false
    else exists (
      select 1 from auth.sessions s
      where s.id = (auth.jwt() ->> 'session_id')::uuid
        and s.user_id = auth.uid()
        and s.created_at > now() - interval '12 hours'
    )
  end;
$$;

-- The caller's role, or NULL when they must see nothing:
-- not signed in, account not active, session older than 12 h,
-- or an Admin / Super Admin who has not passed MFA (aal2) in this session.
create or replace function public.auth_user_role()
returns public.app_role
language sql
stable
security definer
set search_path = ''
as $$
  select p.role
  from public.profiles p
  where p.id = auth.uid()
    and p.status = 'active'
    and private.session_ok()
    and (p.role not in ('admin', 'super_admin') or coalesce(auth.jwt() ->> 'aal', 'aal1') = 'aal2');
$$;

create or replace function public.is_super_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce(public.auth_user_role() = 'super_admin', false);
$$;

create or replace function public.can(p_permission text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.role_permissions rp
    where rp.role = public.auth_user_role() and rp.permission = p_permission
  );
$$;

create or replace function public.has_client_access(p_client uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when public.auth_user_role() is null then false
    when public.auth_user_role() = 'super_admin' then exists (select 1 from public.clients c where c.id = p_client)
    else exists (
      select 1 from public.user_client_access u
      where u.user_id = auth.uid() and u.client_id = p_client
    )
  end;
$$;

-- Station Managers need an explicit station list; everyone else with client access
-- and no list sees every station of that client.
create or replace function public.has_station_access(p_station uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when public.auth_user_role() is null then false
    when public.auth_user_role() = 'super_admin' then exists (select 1 from public.stations s where s.id = p_station)
    else exists (
      select 1
      from public.stations s
      join public.user_client_access u on u.client_id = s.client_id and u.user_id = auth.uid()
      where s.id = p_station
        and (
          (u.station_ids is null and public.auth_user_role() <> 'station_manager')
          or p_station = any (u.station_ids)
        )
    )
  end;
$$;

-- Supervisor scope: themselves plus their CSRs.
create or replace function public.my_team_ids()
returns uuid[]
language sql
stable
security definer
set search_path = ''
as $$
  select array_append(coalesce(array_agg(t.csr_id), '{}'), auth.uid())
  from public.teams t
  where t.supervisor_id = auth.uid();
$$;

-- The single rule for "can this user see this application?"
create or replace function public.application_visible(p_client uuid, p_station uuid, p_owner uuid)
returns boolean
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  r public.app_role := public.auth_user_role();
begin
  if r is null then
    return false;
  elsif r = 'super_admin' then
    return true;
  elsif r = 'csr' then
    return p_owner = auth.uid() and public.has_station_access(p_station);
  elsif r = 'supervisor' then
    return p_owner = any (public.my_team_ids()) and public.has_station_access(p_station);
  else
    -- admin, ops, station_manager, dsp_manager, viewer: by client (and station list when set)
    return public.has_client_access(p_client) and public.has_station_access(p_station);
  end if;
end;
$$;

create or replace function public.app_id_visible(p_application uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce((
    select public.application_visible(a.client_id, a.station_id, a.owner_id)
    from public.applications a where a.id = p_application
  ), false);
$$;

create or replace function public.call_visible(p_call uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce((select public.app_id_visible(c.application_id) from public.calls c where c.id = p_call), false);
$$;

create or replace function public.candidate_visible(p_candidate uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.applications a
    where a.candidate_id = p_candidate
      and public.application_visible(a.client_id, a.station_id, a.owner_id)
  );
$$;

-- True when the signed-in user and p_user both have access to at least one same client.
create or replace function public.shares_client_with(p_user uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select public.auth_user_role() is not null and exists (
    select 1 from public.user_client_access mine
    join public.user_client_access theirs on theirs.client_id = mine.client_id
    where mine.user_id = auth.uid() and theirs.user_id = p_user
  );
$$;

-- What the signed-in user may do; used by the web app (UI hints) and Edge Functions.
create or replace function public.my_access()
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select jsonb_build_object(
    'user_id', p.id,
    'full_name', p.full_name,
    'email', p.email,
    'role', p.role,
    'status', p.status,
    'session_ok', private.session_ok(),
    'mfa_required', p.role in ('admin', 'super_admin'),
    'mfa_ok', p.role not in ('admin', 'super_admin') or coalesce(auth.jwt() ->> 'aal', 'aal1') = 'aal2',
    'effective_role', public.auth_user_role(),
    'permissions', coalesce((
      select jsonb_agg(rp.permission order by rp.permission)
      from public.role_permissions rp where rp.role = public.auth_user_role()
    ), '[]'::jsonb)
  )
  from public.profiles p
  where p.id = auth.uid();
$$;

-- Fixed-window rate limit. Returns true when the call is allowed.
-- Only Edge Functions (service role) may call it.
create or replace function public.hit_rate_limit(p_key text, p_limit integer, p_window_seconds integer)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  w timestamptz := to_timestamp(floor(extract(epoch from now()) / p_window_seconds) * p_window_seconds);
  n integer;
begin
  if p_limit < 1 or p_window_seconds < 1 then
    raise exception 'invalid rate limit';
  end if;
  insert into public.rate_limits as rl (key, window_start, count)
  values (p_key, w, 1)
  on conflict (key, window_start) do update set count = rl.count + 1
  returning count into n;
  delete from public.rate_limits where window_start < now() - interval '1 day';
  return n <= p_limit;
end;
$$;

revoke execute on function public.hit_rate_limit(text, integer, integer) from public, anon, authenticated;
grant execute on function public.hit_rate_limit(text, integer, integer) to service_role;
revoke execute on function private.session_ok() from public, anon;
grant execute on function private.session_ok() to authenticated, service_role;
