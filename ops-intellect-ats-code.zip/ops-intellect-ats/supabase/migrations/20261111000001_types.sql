-- 0001 · Extensions and shared types
-- Ops Intellect ATS. Every later migration depends on these types.

create extension if not exists pgcrypto with schema extensions;

create type public.app_role as enum (
  'csr',
  'supervisor',
  'admin',
  'super_admin',
  'ops',
  'station_manager',
  'dsp_manager',
  'viewer'
);

create type public.user_status as enum ('pending', 'active', 'disabled');

create type public.app_stage as enum (
  'interview',
  'shortlisted',
  'pre_onboarding',
  'onboarding',
  'hired',
  'not_interested',
  'rejected'
);

create type public.message_direction as enum ('inbound', 'outbound');
create type public.call_direction as enum ('inbound', 'outbound');
create type public.call_via as enum ('ai', 'csr');
create type public.call_outcome as enum ('queued', 'in_progress', 'completed', 'voicemail', 'no_answer', 'busy', 'failed', 'dropped');
create type public.answer_result as enum ('yes', 'no', 'needs_review', 'recorded', 'info');
create type public.review_verdict as enum ('looks_right', 'flagged');
create type public.consent_type as enum ('sms', 'ai_call', 'recording');
create type public.bug_priority as enum ('p0', 'p1', 'p2');
create type public.job_status as enum ('queued', 'running', 'done', 'failed', 'cancelled');
create type public.alert_channel as enum ('text', 'email', 'text_email');

-- Shared trigger: keep updated_at current.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;
