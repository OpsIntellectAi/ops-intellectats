-- 0012 · Phase 4 + 5: AI insights data, training pack, alerts, weekly client report,
-- data retention, candidate export / delete on request, and the every-minute scheduler.

-- ---------- AI insights (runs as the caller: RLS limits it to their own scope) ----------
create or replace function public.insights_data(p_client uuid, p_job_role uuid default null, p_days integer default 30)
returns jsonb
language plpgsql
stable
security invoker
set search_path = ''
as $$
declare
  v_from timestamptz := now() - make_interval(days => greatest(1, least(p_days, 365)));
  v_tz text := coalesce((select time_zone from public.client_settings where client_id = p_client), 'America/New_York');
  v jsonb;
begin
  if not public.can('reports.view') or not public.has_client_access(p_client) then
    raise exception 'Your access level cannot see AI insights' using errcode = 'insufficient_privilege';
  end if;
  with apps as (
    select * from public.application_rows a
    where a.client_id = p_client and (p_job_role is null or a.job_role_id = p_job_role) and a.applied_at >= v_from
  ),
  calls as (
    select k.* from public.call_rows k
    where k.client_id = p_client and (p_job_role is null or k.job_role_id = p_job_role)
      and k.via = 'ai' and coalesce(k.started_at, k.created_at) >= v_from
  ),
  answers as (
    select x.question_key, x.question_text, x.result
    from public.call_answers x join calls k on k.id = x.call_id
  )
  select jsonb_build_object(
    'funnel', jsonb_build_object(
      'applied', (select count(*) from apps),
      'ai_called', (select count(*) from apps where ai_calls > 0),
      'interviewed', (select count(*) from apps where completed_ai_calls > 0),
      'shortlisted', (select count(*) from apps where stage in ('shortlisted', 'pre_onboarding', 'onboarding', 'hired')),
      'onboarding', (select count(*) from apps where stage in ('onboarding', 'hired')),
      'hired', (select count(*) from apps where stage = 'hired'),
      'no_response', (select count(*) from apps where no_response_at is not null),
      'opted_out', (select count(*) from apps where opted_out_at is not null),
      'not_interested', (select count(*) from apps where stage = 'not_interested'),
      'rejected', (select count(*) from apps where stage = 'rejected')),
    'questions', coalesce((select jsonb_agg(q order by q.no_or_unclear desc) from (
      select question_key as key, max(question_text) as text, count(*) as asked,
             count(*) filter (where result = 'no') as no,
             count(*) filter (where result = 'needs_review') as unclear,
             count(*) filter (where result in ('no', 'needs_review')) as no_or_unclear
      from answers group by question_key) q), '[]'::jsonb),
    'by_hour', coalesce((select jsonb_agg(h order by h.hour) from (
      select extract(hour from coalesce(started_at, created_at) at time zone v_tz)::integer as hour,
             count(*) as calls, count(*) filter (where outcome = 'completed') as answered
      from calls group by 1) h), '[]'::jsonb),
    'outcomes', coalesce((select jsonb_object_agg(outcome, n) from (select outcome::text, count(*) as n from calls group by 1) o), '{}'::jsonb),
    'stalls', coalesce((select jsonb_agg(s order by s.stuck desc) from (
      select d.name as step, count(*) as stuck
      from public.onboarding_steps st
      join public.onboarding_step_defs d on d.id = st.step_def_id
      join apps a on a.id = st.application_id
      where a.stage = 'onboarding' and not (st.status = any (d.done_statuses) or st.status = 'Waived')
        and st.changed_at < now() - interval '48 hours'
      group by d.name) s), '[]'::jsonb),
    'days', p_days,
    'time_zone', v_tz
  ) into v;
  return v;
end;
$$;

-- ---------- AI training pack (Admin and up): names removed ----------
create or replace function public.training_pack(p_client uuid, p_job_role uuid default null, p_days integer default 90)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v jsonb;
begin
  if not public.can('reports.manage') or not public.has_client_access(p_client) then
    raise exception 'Only Admins can download the AI training pack' using errcode = 'insufficient_privilege';
  end if;
  select jsonb_build_object(
    'generated_at', now(),
    'client_ref', md5(p_client::text),
    'instructions', coalesce((select jsonb_agg(jsonb_build_object(
        'job_role', j.name, 'version', v.version, 'published_at', v.published_at, 'note', v.note,
        'questions', v.question_tree, 'rules', v.global_rules) order by j.name, v.version)
      from public.script_versions v join public.scripts s on s.id = v.script_id join public.job_roles j on j.id = s.job_role_id
      where v.client_id = p_client and (p_job_role is null or s.job_role_id = p_job_role) and v.published_at is not null), '[]'::jsonb),
    'calls', coalesce((select jsonb_agg(jsonb_build_object(
        'call_ref', left(md5(k.id::text), 12),
        'script_version', (select v.version from public.script_versions v where v.id = k.script_version_id),
        'outcome', k.outcome, 'duration_seconds', k.duration_seconds,
        -- Names removed: full name, first name and phone are replaced.
        'transcript', regexp_replace(regexp_replace(replace(coalesce(k.transcript, ''), c.full_name, 'Candidate'),
                        '\m' || split_part(c.full_name, ' ', 1) || '\M', 'Candidate', 'g'), '\+?1?\d{10}', '[phone]', 'g'),
        'answers', (select coalesce(jsonb_agg(jsonb_build_object('key', x.question_key, 'question', x.question_text,
                       'heard', replace(coalesce(x.heard_text, ''), split_part(c.full_name, ' ', 1), 'Candidate'),
                       'result', x.result, 'reviewed', x.reviewed_at is not null) order by x.at_seconds), '[]'::jsonb)
                    from public.call_answers x where x.call_id = k.id),
        'review', (select jsonb_build_object('verdict', r.verdict, 'reason', r.reason, 'question', r.question_key, 'note', r.note)
                   from public.call_reviews r where r.call_id = k.id order by r.created_at desc limit 1)
      ) order by k.created_at)
      from public.calls k
      join public.applications a on a.id = k.application_id
      join public.candidates c on c.id = a.candidate_id
      where k.client_id = p_client and k.via = 'ai' and k.outcome = 'completed'
        and (p_job_role is null or a.job_role_id = p_job_role)
        and k.created_at >= now() - make_interval(days => greatest(1, least(p_days, 730)))), '[]'::jsonb)
  ) into v;
  perform private.write_audit('Training pack downloaded', p_client, 'export', null, 'AI training pack', null,
    jsonb_array_length(v -> 'calls') || ' calls');
  return v;
end;
$$;

-- ---------- alerts (every 15 minutes, from the scheduler) ----------
create or replace function private.alert_metric(p_client uuid, p_rule text, p_now timestamptz)
returns numeric
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_tz text := coalesce((select time_zone from public.client_settings where client_id = p_client), 'America/New_York');
  n numeric;
  t record;
begin
  if p_rule = 'answer_rate' then
    -- Only meaningful after at least 5 AI calls today.
    select case when count(*) >= 5 then round(100.0 * count(*) filter (where outcome = 'completed') / count(*)) end into n
    from public.calls where client_id = p_client and via = 'ai'
      and (coalesce(started_at, created_at) at time zone v_tz)::date = (p_now at time zone v_tz)::date
      and outcome not in ('queued', 'in_progress');
  elsif p_rule = 'unreviewed_calls' then
    select count(*) into n from public.calls k
    where k.client_id = p_client and k.via = 'ai' and k.outcome = 'completed' and k.ended_at < p_now - interval '24 hours'
      and not exists (select 1 from public.call_reviews r where r.call_id = k.id);
  elsif p_rule = 'shortlisted_no_reply' then
    select count(*) into n from public.applications a
    where a.client_id = p_client and a.stage = 'shortlisted' and a.stage_changed_at < p_now - interval '2 days'
      and not exists (select 1 from public.messages m where m.application_id = a.id and m.direction = 'inbound'
                      and m.created_at >= a.stage_changed_at);
  elsif p_rule = 'onboarding_stuck' then
    select count(*) into n from public.applications a
    where a.client_id = p_client and a.stage = 'onboarding'
      and coalesce((select max(s.changed_at) from public.onboarding_steps s where s.application_id = a.id), a.stage_changed_at)
          < p_now - interval '24 hours';
  elsif p_rule = 'behind_target' then
    select * into t from public.hiring_targets h where h.client_id = p_client and h.by_date >= p_now::date
    order by h.by_date limit 1;
    if t.id is null then return null; end if;
    select greatest(0, round(t.hires * least(1.0, (p_now::date - t.from_date)::numeric / greatest(1, t.by_date - t.from_date)))
           - count(*)) into n
    from public.applications a
    where a.client_id = p_client and a.stage = 'hired' and a.stage_changed_at >= t.from_date
      and a.job_role_id = t.job_role_id;
  end if;
  return n;
end;
$$;

create or replace function public.evaluate_alerts(p_now timestamptz default now())
returns table (client_id uuid, message text, channel public.alert_channel, phones text[], emails text[])
language plpgsql
security definer
set search_path = ''
as $$
declare
  r record;
  v numeric;
  v_msg text;
  v_hit boolean;
  v_phones text[];
  v_emails text[];
begin
  for r in
    select ar.*, cl.name as client_name from public.alert_rules ar join public.clients cl on cl.id = ar.client_id
    where ar.enabled
  loop
    v := private.alert_metric(r.client_id, r.rule_key, p_now);
    continue when v is null;
    v_hit := case when r.rule_key = 'answer_rate' then v < r.threshold else v >= r.threshold end;
    continue when not v_hit;
    -- The same alert at most once every 6 hours.
    continue when exists (select 1 from public.alert_log l where l.rule_id = r.id and not l.is_test
                          and l.created_at > p_now - interval '6 hours');
    v_msg := r.client_name || ': ' || case r.rule_key
      when 'answer_rate' then 'AI call answer rate today is ' || v || '% (alert below ' || r.threshold || '%)'
      when 'unreviewed_calls' then v || ' AI calls not reviewed for 24 hours'
      when 'shortlisted_no_reply' then v || ' shortlisted candidates with no reply for 2+ days'
      when 'onboarding_stuck' then v || ' people stuck in onboarding over 24 h'
      else 'hiring is ' || v || ' behind target pace' end;
    select coalesce(array_agg(distinct p.phone_e164) filter (where p.phone_e164 is not null), '{}'),
           coalesce(array_agg(distinct p.email) filter (where p.email is not null), '{}')
      into v_phones, v_emails
    from public.profiles p
    join public.user_client_access u on u.user_id = p.id and u.client_id = r.client_id
    where p.role = 'supervisor' and p.status = 'active';
    insert into public.alert_log (client_id, rule_id, message, sent_to, channel)
    values (r.client_id, r.id, v_msg,
            coalesce(nullif(array_to_string(v_emails || v_phones, ', '), ''), 'no supervisor on this client'), r.channel);
    client_id := r.client_id; message := v_msg; channel := r.channel; phones := v_phones; emails := v_emails;
    return next;
  end loop;
end;
$$;

-- "Test send" from Reports & alerts: logged as a test, sent only to the person clicking.
create or replace function public.test_alert(p_rule uuid)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  r record;
  v numeric;
  v_msg text;
begin
  select ar.*, cl.name as client_name into r from public.alert_rules ar join public.clients cl on cl.id = ar.client_id where ar.id = p_rule;
  if r.id is null or not public.can('reports.manage') or not public.has_client_access(r.client_id) then
    raise exception 'Only Admins can test alerts' using errcode = 'insufficient_privilege';
  end if;
  v := private.alert_metric(r.client_id, r.rule_key, now());
  v_msg := 'TEST · ' || r.client_name || ' · ' || r.label || ' ' || r.threshold || ' · now: ' || coalesce(v::text, 'not enough data');
  insert into public.alert_log (client_id, rule_id, message, sent_to, channel, is_test)
  values (r.client_id, r.id, v_msg, (select coalesce(email, 'you') from public.profiles where id = auth.uid()), r.channel, true);
  return v_msg;
end;
$$;

-- ---------- weekly client report (Monday 8:00 AM ET). No candidate names. ----------
create or replace function private.weekly_report_html(p_client uuid, p_now timestamptz default now())
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  c record;
  f timestamptz := p_now - interval '7 days';
  kp record;
  stages text;
  target text;
  drop_q text;
begin
  select cl.name, cs.contact_name, cs.contact_email into c
  from public.clients cl left join public.client_settings cs on cs.client_id = cl.id where cl.id = p_client;
  select
    count(*) filter (where a.applied_at >= f) as applied,
    (select count(*) from public.calls k where k.client_id = p_client and k.via = 'ai' and k.created_at >= f) as ai_calls,
    (select count(*) from public.calls k where k.client_id = p_client and k.via = 'ai' and k.outcome = 'completed' and k.created_at >= f) as interviews,
    count(*) filter (where a.stage in ('shortlisted', 'pre_onboarding', 'onboarding', 'hired') and a.stage_changed_at >= f) as shortlisted,
    count(*) filter (where a.stage = 'hired' and a.stage_changed_at >= f) as hired,
    count(*) filter (where a.stage = 'onboarding') as in_onboarding
    into kp
  from public.applications a where a.client_id = p_client;
  select string_agg('<tr><td>' || initcap(replace(s.stage::text, '_', ' ')) || '</td><td align="right">' || s.n || '</td></tr>', '' order by s.stage)
    into stages
  from (select stage, count(*) as n from public.applications where client_id = p_client group by stage) s;
  select h.hires || ' hires by ' || to_char(h.by_date, 'Mon DD') || ': ' ||
         (select count(*) from public.applications a where a.client_id = p_client and a.stage = 'hired' and a.stage_changed_at >= h.from_date)
         || ' so far' into target
  from public.hiring_targets h where h.client_id = p_client and h.by_date >= p_now::date order by h.by_date limit 1;
  select x.question_text || ' (' || count(*) || ' No or unclear)' into drop_q
  from public.call_answers x join public.calls k on k.id = x.call_id
  where k.client_id = p_client and k.created_at >= f and x.result in ('no', 'needs_review')
  group by x.question_text order by count(*) desc limit 1;
  return jsonb_build_object(
    'client_id', p_client,
    'to', c.contact_email,
    'subject', 'Weekly hiring report · ' || c.name || ' · week to ' || to_char(p_now at time zone 'America/New_York', 'Mon DD'),
    'html',
      '<div style="font-family:Inter,Arial,sans-serif;color:#1d1d1b">' ||
      '<h2 style="font-family:Georgia,serif;color:#1E5A4E">' || replace(replace(c.name, '<', ''), '>', '') || ' · weekly hiring report</h2>' ||
      '<p>Hi ' || coalesce(replace(replace(c.contact_name, '<', ''), '>', ''), 'there') || ', here is last week at a glance.</p>' ||
      '<table cellpadding="6" style="border-collapse:collapse">' ||
      '<tr><td>New applicants</td><td align="right"><b>' || kp.applied || '</b></td></tr>' ||
      '<tr><td>AI calls / interviews done</td><td align="right"><b>' || kp.ai_calls || ' / ' || kp.interviews || '</b></td></tr>' ||
      '<tr><td>Shortlisted</td><td align="right"><b>' || kp.shortlisted || '</b></td></tr>' ||
      '<tr><td>Hired</td><td align="right"><b>' || kp.hired || '</b></td></tr>' ||
      '<tr><td>In onboarding now</td><td align="right"><b>' || kp.in_onboarding || '</b></td></tr></table>' ||
      '<h3>Pipeline today</h3><table cellpadding="4">' || coalesce(stages, '') || '</table>' ||
      '<h3>Target</h3><p>' || coalesce(target, 'No hiring target set.') || '</p>' ||
      '<h3>Top drop-off question</h3><p>' || coalesce(replace(replace(drop_q, '<', ''), '>', ''), 'None this week.') || '</p>' ||
      '<h3>Next week</h3><p>We keep texting new applicants at 8 AM their time, follow up on everyone shortlisted, ' ||
      'and push onboarding steps that are waiting.</p>' ||
      '<p style="color:#666;font-size:12px">Sent by Ops Intellect ATS. This report contains no candidate names.</p></div>');
end;
$$;

create or replace function public.weekly_reports()
returns setof jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select private.weekly_report_html(c.id) from public.clients c;
$$;

create or replace function public.weekly_report_preview(p_client uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if not public.can('reports.view') or not public.has_client_access(p_client) then
    raise exception 'No access to this report' using errcode = 'insufficient_privilege';
  end if;
  return private.weekly_report_html(p_client);
end;
$$;

create or replace function public.log_weekly_report(p_client uuid, p_status text)
returns void
language sql
security definer
set search_path = ''
as $$
  insert into public.alert_log (client_id, message, sent_to, channel)
  select p_client, 'Weekly client report (' || left(p_status, 20) || ')', coalesce(cs.contact_email, 'no contact email'), 'email'
  from public.client_settings cs where cs.client_id = p_client;
$$;

-- ---------- data retention (daily, 3 AM ET) ----------
create or replace function public.run_retention(p_now timestamptz default now())
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_paths text[];
  v_apps integer := 0;
  v_cands integer := 0;
  r record;
begin
  -- Recordings older than the client's limit: remove the file reference (the scheduler deletes the files).
  with due as (
    select k.id, k.recording_path from public.calls k
    join public.client_settings cs on cs.client_id = k.client_id
    where k.recording_path is not null
      and coalesce(k.ended_at, k.created_at) < p_now - make_interval(days => cs.recording_retention_days)
    for update of k
  ), cleared as (
    update public.calls k set recording_path = null from due where due.id = k.id returning due.recording_path as old_path
  )
  select coalesce(array_agg(old_path), '{}') into v_paths from cleared;

  -- Rejected candidates older than the client's limit.
  for r in
    select a.id, a.client_id, a.candidate_id from public.applications a
    join public.client_settings cs on cs.client_id = a.client_id
    where a.stage = 'rejected' and a.stage_changed_at < p_now - make_interval(months => cs.rejected_retention_months)
  loop
    delete from public.applications where id = r.id;
    v_apps := v_apps + 1;
    if not exists (select 1 from public.applications where candidate_id = r.candidate_id) then
      delete from public.candidates where id = r.candidate_id;
      v_cands := v_cands + 1;
    end if;
  end loop;

  if coalesce(array_length(v_paths, 1), 0) + v_apps > 0 then
    perform private.write_audit('Retention clean-up', null, 'retention', null, 'Scheduled data retention', null,
      coalesce(array_length(v_paths, 1), 0) || ' recordings, ' || v_apps || ' rejected applications, ' || v_cands || ' candidates deleted');
  end if;
  return jsonb_build_object('recording_paths', to_jsonb(v_paths), 'applications', v_apps, 'candidates', v_cands);
end;
$$;

-- ---------- candidate data: export and delete on request (Admin and up) ----------
create or replace function public.export_candidate(p_candidate uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  c record;
  v jsonb;
begin
  select * into c from public.candidates where id = p_candidate;
  if c.id is null or not public.can('users.manage') or not public.has_client_access(c.client_id) then
    raise exception 'Only Admins of this client can export a candidate''s data' using errcode = 'insufficient_privilege';
  end if;
  select jsonb_build_object(
    'exported_at', now(),
    'candidate', jsonb_build_object('full_name', c.full_name, 'phone', c.phone_e164, 'email', c.email, 'city', c.city, 'zip', c.zip,
                                    'opted_out_at', c.opted_out_at, 'licence_on_file', c.licence_number_enc is not null),
    'consents', (select coalesce(jsonb_agg(jsonb_build_object('type', k.consent_type, 'wording', k.wording_version, 'source', k.source,
                   'given_at', k.given_at, 'revoked_at', k.revoked_at)), '[]') from public.consents k where k.candidate_id = c.id),
    'applications', (select coalesce(jsonb_agg(jsonb_build_object(
        'stage', a.stage, 'applied_at', a.applied_at, 'source', a.source,
        'messages', (select coalesce(jsonb_agg(jsonb_build_object('at', m.created_at, 'direction', m.direction, 'body', m.body) order by m.created_at), '[]')
                     from public.messages m where m.application_id = a.id),
        'calls', (select coalesce(jsonb_agg(jsonb_build_object('at', k.created_at, 'via', k.via, 'outcome', k.outcome, 'transcript', k.transcript,
                     'answers', (select coalesce(jsonb_agg(jsonb_build_object('question', x.question_text, 'heard', x.heard_text, 'result', x.result)), '[]')
                                 from public.call_answers x where x.call_id = k.id)) order by k.created_at), '[]')
                  from public.calls k where k.application_id = a.id),
        'onboarding', (select coalesce(jsonb_agg(jsonb_build_object('step', d.name, 'status', s.status, 'at', s.changed_at)), '[]')
                       from public.onboarding_steps s join public.onboarding_step_defs d on d.id = s.step_def_id where s.application_id = a.id)
      )), '[]') from public.applications a where a.candidate_id = c.id)
  ) into v;
  perform private.write_audit('Candidate data exported', c.client_id, 'candidate', c.id::text, c.full_name, null, 'export on request', true,
    'Personal data export');
  return v;
end;
$$;

create or replace function public.delete_candidate(p_candidate uuid, p_reason text)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  c record;
  v_paths text[];
  v_apps uuid[];
begin
  select * into c from public.candidates where id = p_candidate;
  if c.id is null or not public.can('users.manage') or not public.has_client_access(c.client_id) then
    raise exception 'Only Admins of this client can delete a candidate' using errcode = 'insufficient_privilege';
  end if;
  if length(trim(coalesce(p_reason, ''))) < 4 then
    raise exception 'A reason is required' using errcode = 'check_violation';
  end if;
  select coalesce(array_agg(k.recording_path) filter (where k.recording_path is not null), '{}'), coalesce(array_agg(distinct a.id), '{}')
    into v_paths, v_apps
  from public.applications a left join public.calls k on k.application_id = a.id
  where a.candidate_id = c.id;
  -- The activity log keeps who deleted whom and why, but not the person's details.
  perform private.write_audit('Candidate deleted on request', c.client_id, 'candidate', c.id::text,
    'Candidate ' || left(md5(c.id::text), 8), null, left(trim(p_reason), 300), true, 'Personal data deleted');
  delete from public.candidates where id = c.id;
  return jsonb_build_object('recording_paths', to_jsonb(v_paths),
    'licence_prefixes', (select coalesce(jsonb_agg(c.client_id::text || '/' || x::text), '[]') from unnest(v_apps) x));
end;
$$;

-- ---------- AI assistant log (written by the assistant function) ----------
create or replace function public.log_assistant(p_user uuid, p_client uuid, p_question text, p_answer text, p_tools jsonb)
returns void
language sql
security definer
set search_path = ''
as $$
  insert into public.ai_assistant_log (user_id, client_id, question, answer, tools_used)
  values (p_user, p_client, left(p_question, 2000), left(p_answer, 8000), coalesce(p_tools, '[]'::jsonb));
$$;

-- ---------- grants ----------
revoke execute on function public.insights_data(uuid, uuid, integer) from public, anon;
grant execute on function public.insights_data(uuid, uuid, integer) to authenticated;
do $$
declare f text;
begin
  foreach f in array array[
    'public.training_pack(uuid, uuid, integer)', 'public.test_alert(uuid)', 'public.weekly_report_preview(uuid)',
    'public.export_candidate(uuid)', 'public.delete_candidate(uuid, text)'
  ] loop
    execute format('revoke execute on function %s from public, anon', f);
    execute format('grant execute on function %s to authenticated, service_role', f);
  end loop;
  foreach f in array array[
    'public.evaluate_alerts(timestamptz)', 'public.weekly_reports()', 'public.log_weekly_report(uuid, text)',
    'public.run_retention(timestamptz)', 'public.log_assistant(uuid, uuid, text, text, jsonb)'
  ] loop
    execute format('revoke execute on function %s from public, anon, authenticated', f);
    execute format('grant execute on function %s to service_role', f);
  end loop;
end $$;

-- ---------- scheduler: every minute through pg_cron + pg_net (hosted Supabase) ----------
insert into public.app_config (key, value) values ('cron_secret', encode(extensions.gen_random_bytes(32), 'hex'))
on conflict (key) do nothing;

do $$
begin
  if exists (select 1 from pg_available_extensions where name = 'pg_cron')
     and exists (select 1 from pg_available_extensions where name = 'pg_net') then
    create extension if not exists pg_cron;
    create extension if not exists pg_net;
    perform cron.unschedule(jobid) from cron.job where jobname = 'ops-intellect-scheduler';
    perform cron.schedule('ops-intellect-scheduler', '* * * * *', $job$
      select net.http_post(
        url := (select value from public.app_config where key = 'functions_url') || '/scheduler',
        headers := jsonb_build_object('content-type', 'application/json',
                                      'x-cron-secret', (select value from public.app_config where key = 'cron_secret')),
        body := '{}'::jsonb,
        timeout_milliseconds := 55000)
      where exists (select 1 from public.app_config where key = 'functions_url');
    $job$);
  end if;
end $$;
