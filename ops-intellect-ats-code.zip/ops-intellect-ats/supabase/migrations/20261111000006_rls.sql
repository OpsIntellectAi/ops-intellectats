-- 0006 · Row Level Security: ON for every table, deny by default.
-- A table with no policy for an action means nobody (except the service role
-- inside Edge Functions) can do that action.

do $$
declare t text;
begin
  foreach t in array array[
    'clients', 'client_settings', 'stations', 'job_roles', 'profiles', 'user_client_access', 'teams',
    'role_permissions', 'feature_flags', 'candidates', 'applications', 'stage_history', 'consents',
    'messages', 'scripts', 'script_versions', 'calls', 'call_answers', 'call_reviews',
    'onboarding_step_defs', 'onboarding_steps', 'message_templates', 'step_messages', 'call_reminders',
    'alert_rules', 'alert_log', 'hiring_targets', 'saved_views', 'devices', 'audit_log',
    'idempotency_keys', 'job_queue', 'bug_reports', 'ai_assistant_log', 'aedt_notices', 'rate_limits'
  ] loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;

-- ---------- clients and setup ----------
create policy clients_select on public.clients for select to authenticated
  using (public.has_client_access(id));
create policy clients_insert on public.clients for insert to authenticated
  with check (public.can('platform.admin'));
create policy clients_update on public.clients for update to authenticated
  using (public.can('platform.admin')) with check (public.can('platform.admin'));

create policy client_settings_select on public.client_settings for select to authenticated
  using (public.has_client_access(client_id));
create policy client_settings_insert on public.client_settings for insert to authenticated
  with check (public.can('platform.admin'));
create policy client_settings_update on public.client_settings for update to authenticated
  using (public.can('settings.edit') and public.has_client_access(client_id))
  with check (public.can('settings.edit') and public.has_client_access(client_id));

create policy stations_select on public.stations for select to authenticated
  using (public.has_station_access(id));
create policy stations_write on public.stations for all to authenticated
  using (public.can('platform.admin')) with check (public.can('platform.admin'));

create policy job_roles_select on public.job_roles for select to authenticated
  using (public.has_station_access(station_id));
create policy job_roles_write on public.job_roles for all to authenticated
  using (public.can('platform.admin')) with check (public.can('platform.admin'));

-- ---------- people and access ----------
-- Everyone can read their own profile (needed for the MFA step, even before aal2).
create policy profiles_select_self on public.profiles for select to authenticated
  using (id = auth.uid());
-- Others: people who share at least one client with you (CSR names on candidates, etc.).
create policy profiles_select_colleagues on public.profiles for select to authenticated
  using (public.is_super_admin() or public.shares_client_with(id));
-- Role and status changes go through an Edge Function (users.manage); no direct updates.

create policy uca_select on public.user_client_access for select to authenticated
  using (user_id = auth.uid() or (public.can('users.manage') and public.has_client_access(client_id)));
create policy uca_write on public.user_client_access for all to authenticated
  using (public.can('platform.admin')) with check (public.can('platform.admin'));

create policy teams_select on public.teams for select to authenticated
  using (
    public.auth_user_role() is not null
    and (supervisor_id = auth.uid() or csr_id = auth.uid() or public.can('users.manage'))
  );
create policy teams_write on public.teams for all to authenticated
  using (public.can('users.manage')) with check (public.can('users.manage'));

create policy role_permissions_select on public.role_permissions for select to authenticated
  using (true);

create policy feature_flags_select on public.feature_flags for select to authenticated
  using (public.auth_user_role() is not null);
create policy feature_flags_update on public.feature_flags for update to authenticated
  using (public.can('platform.admin')) with check (public.can('platform.admin'));

-- ---------- candidates and applications ----------
create policy candidates_select on public.candidates for select to authenticated
  using (public.has_client_access(client_id) and public.candidate_visible(id));
create policy candidates_insert on public.candidates for insert to authenticated
  with check (public.can('candidates.act') and public.has_client_access(client_id));
create policy candidates_update on public.candidates for update to authenticated
  using (public.can('candidates.act') and public.candidate_visible(id))
  with check (public.can('candidates.act') and public.has_client_access(client_id));

create policy applications_select on public.applications for select to authenticated
  using (public.application_visible(client_id, station_id, owner_id));
create policy applications_insert on public.applications for insert to authenticated
  with check (
    public.can('candidates.act')
    and public.has_client_access(client_id)
    and public.has_station_access(station_id)
  );
create policy applications_update on public.applications for update to authenticated
  using (
    (public.can('candidates.act') or public.can('onboarding.update'))
    and public.application_visible(client_id, station_id, owner_id)
  )
  with check (
    (public.can('candidates.act') or public.can('onboarding.update'))
    and public.has_client_access(client_id)
    and public.has_station_access(station_id)
  );

create policy stage_history_select on public.stage_history for select to authenticated
  using (public.app_id_visible(application_id));

create policy consents_select on public.consents for select to authenticated
  using (public.candidate_visible(candidate_id));
create policy consents_insert on public.consents for insert to authenticated
  with check (public.can('candidates.act') and public.has_client_access(client_id));

-- Messages and calls are written only by Edge Functions (Twilio / voice provider).
create policy messages_select on public.messages for select to authenticated
  using (public.app_id_visible(application_id));

create policy calls_select on public.calls for select to authenticated
  using (public.app_id_visible(application_id));

create policy call_answers_select on public.call_answers for select to authenticated
  using (public.call_visible(call_id));

create policy call_reviews_select on public.call_reviews for select to authenticated
  using (public.call_visible(call_id));
create policy call_reviews_insert on public.call_reviews for insert to authenticated
  with check (public.can('calls.review') and reviewer_id = auth.uid() and public.call_visible(call_id));

-- ---------- scripts and onboarding ----------
create policy scripts_select on public.scripts for select to authenticated
  using (public.has_client_access(client_id));
create policy scripts_write on public.scripts for all to authenticated
  using (public.can('platform.admin')) with check (public.can('platform.admin'));

create policy script_versions_select on public.script_versions for select to authenticated
  using (public.has_client_access(client_id));
create policy script_versions_write on public.script_versions for all to authenticated
  using (public.can('platform.admin')) with check (public.can('platform.admin'));

create policy onboarding_step_defs_select on public.onboarding_step_defs for select to authenticated
  using (public.has_client_access(client_id));
create policy onboarding_step_defs_write on public.onboarding_step_defs for all to authenticated
  using (public.can('platform.admin')) with check (public.can('platform.admin'));

create policy onboarding_steps_select on public.onboarding_steps for select to authenticated
  using (public.app_id_visible(application_id));
create policy onboarding_steps_insert on public.onboarding_steps for insert to authenticated
  with check (public.can('onboarding.update') and public.app_id_visible(application_id));
create policy onboarding_steps_update on public.onboarding_steps for update to authenticated
  using (public.can('onboarding.update') and public.app_id_visible(application_id))
  with check (public.can('onboarding.update') and public.app_id_visible(application_id));

-- ---------- messaging settings ----------
create policy message_templates_select on public.message_templates for select to authenticated
  using (public.has_client_access(client_id));
create policy message_templates_write on public.message_templates for all to authenticated
  using (public.can('templates.edit') and public.has_client_access(client_id))
  with check (public.can('templates.edit') and public.has_client_access(client_id));

create policy step_messages_select on public.step_messages for select to authenticated
  using (public.has_client_access(client_id));
create policy step_messages_write on public.step_messages for all to authenticated
  using (public.can('settings.edit') and public.has_client_access(client_id))
  with check (public.can('settings.edit') and public.has_client_access(client_id));

create policy call_reminders_select on public.call_reminders for select to authenticated
  using (public.has_client_access(client_id));
create policy call_reminders_write on public.call_reminders for all to authenticated
  using (public.can('settings.edit') and public.has_client_access(client_id))
  with check (public.can('settings.edit') and public.has_client_access(client_id));

-- ---------- reports, alerts, targets ----------
create policy alert_rules_select on public.alert_rules for select to authenticated
  using (public.can('reports.view') and public.has_client_access(client_id));
create policy alert_rules_write on public.alert_rules for all to authenticated
  using (public.can('reports.manage') and public.has_client_access(client_id))
  with check (public.can('reports.manage') and public.has_client_access(client_id));

create policy alert_log_select on public.alert_log for select to authenticated
  using (public.can('reports.view') and public.has_client_access(client_id));

create policy hiring_targets_select on public.hiring_targets for select to authenticated
  using (public.can('reports.view') and public.has_client_access(client_id));
create policy hiring_targets_write on public.hiring_targets for all to authenticated
  using (public.can('reports.manage') and public.has_client_access(client_id))
  with check (public.can('reports.manage') and public.has_client_access(client_id));

create policy saved_views_select on public.saved_views for select to authenticated
  using (public.has_client_access(client_id) and (owner_id = auth.uid() or shared));
create policy saved_views_insert on public.saved_views for insert to authenticated
  with check (owner_id = auth.uid() and public.has_client_access(client_id));
create policy saved_views_update on public.saved_views for update to authenticated
  using (owner_id = auth.uid() and public.has_client_access(client_id))
  with check (owner_id = auth.uid() and public.has_client_access(client_id));
create policy saved_views_delete on public.saved_views for delete to authenticated
  using (public.has_client_access(client_id) and (owner_id = auth.uid() or public.is_super_admin()));

-- ---------- devices and activity ----------
create policy devices_select on public.devices for select to authenticated
  using (
    (user_id = auth.uid() and public.auth_user_role() is not null)
    or public.is_super_admin()
    or (public.can('audit.view_all') and public.shares_client_with(user_id))
  );
create policy devices_update on public.devices for update to authenticated
  using (public.can('platform.admin')) with check (public.can('platform.admin'));

-- Super Admin: everything. Admin: their clients. Supervisor: their own team's actions.
create policy audit_log_select on public.audit_log for select to authenticated
  using (
    public.is_super_admin()
    or (public.can('audit.view_all') and client_id is not null and public.has_client_access(client_id))
    or (public.can('audit.view') and actor_id = any (public.my_team_ids())
        and (client_id is null or public.has_client_access(client_id)))
  );

create policy bug_reports_insert on public.bug_reports for insert to authenticated
  with check (reporter_id = auth.uid() and public.auth_user_role() is not null
              and (client_id is null or public.has_client_access(client_id)));
create policy bug_reports_select on public.bug_reports for select to authenticated
  using ((reporter_id = auth.uid() and public.auth_user_role() is not null) or public.can('audit.view_all'));

create policy ai_assistant_log_select on public.ai_assistant_log for select to authenticated
  using ((user_id = auth.uid() and public.auth_user_role() is not null) or public.is_super_admin());

create policy aedt_notices_select on public.aedt_notices for select to authenticated
  using (public.candidate_visible(candidate_id));

-- idempotency_keys, job_queue, rate_limits: no policies at all → service role only.

-- The anon role never needs table access. Remove the default grants as a second wall.
revoke all on all tables in schema public from anon;
revoke all on all sequences in schema public from anon;
alter default privileges in schema public revoke all on tables from anon;
alter default privileges in schema public revoke all on sequences from anon;

-- Append-only activity log: nobody gets UPDATE/DELETE/TRUNCATE (trigger in 0007 is the second wall).
revoke update, delete, truncate on public.audit_log from authenticated, service_role;
revoke insert on public.audit_log from authenticated;
