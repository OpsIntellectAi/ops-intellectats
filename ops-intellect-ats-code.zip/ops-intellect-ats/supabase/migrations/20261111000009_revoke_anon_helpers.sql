-- 0009 · Anonymous visitors cannot call the access-helper functions at all.
-- (Found by the Supabase security advisor on staging.) Signed-in users still need
-- EXECUTE because RLS policies call these helpers as the signed-in user; each helper
-- only ever answers about the caller's own access.

do $$
declare f text;
begin
  foreach f in array array[
    'public.auth_user_role()',
    'public.is_super_admin()',
    'public.can(text)',
    'public.has_client_access(uuid)',
    'public.has_station_access(uuid)',
    'public.my_team_ids()',
    'public.application_visible(uuid, uuid, uuid)',
    'public.app_id_visible(uuid)',
    'public.call_visible(uuid)',
    'public.candidate_visible(uuid)',
    'public.shares_client_with(uuid)',
    'public.my_access()'
  ] loop
    execute format('revoke execute on function %s from public, anon', f);
    execute format('grant execute on function %s to authenticated, service_role', f);
  end loop;
end $$;

-- New functions in public are not executable by anon unless granted explicitly.
alter default privileges in schema public revoke execute on functions from public, anon;
