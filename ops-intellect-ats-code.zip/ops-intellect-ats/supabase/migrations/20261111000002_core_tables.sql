-- 0002 · Platform, clients, stations, job roles, users and access

create table public.clients (
  id uuid primary key default gen_random_uuid(),
  name text not null unique check (length(trim(name)) between 2 and 120),
  slug text not null unique check (slug ~ '^[a-z0-9-]{2,60}$'),
  is_live boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.client_settings (
  client_id uuid primary key references public.clients(id) on delete cascade,
  time_zone text not null default 'America/New_York',
  twilio_messaging_service_sid text check (twilio_messaging_service_sid is null or twilio_messaging_service_sid ~ '^MG[0-9a-f]{32}$'),
  a2p_campaign_status text not null default 'not_started' check (a2p_campaign_status in ('not_started', 'pending', 'approved', 'rejected')),
  auto_text_time time not null default '08:00',
  -- Quiet hours: no texts between quiet_start and quiet_end (candidate local time).
  -- The sending window may never be wider than 8:00 AM – 9:00 PM.
  quiet_start time not null default '20:00',
  quiet_end time not null default '08:00',
  recording_retention_days integer not null default 90 check (recording_retention_days between 1 and 3650),
  rejected_retention_months integer not null default 12 check (rejected_retention_months between 1 and 120),
  contact_name text,
  contact_email text check (contact_email is null or contact_email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  contact_phone text,
  auto_shortlist boolean not null default false,
  aedt_enabled boolean not null default false,
  aedt_bias_audit_date date,
  max_ai_attempts_per_day integer not null default 2 check (max_ai_attempts_per_day between 1 and 5),
  max_ai_attempts_total integer not null default 4 check (max_ai_attempts_total between 1 and 10),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint quiet_hours_within_limits check (quiet_end >= time '08:00' and quiet_start <= time '21:00' and quiet_start > quiet_end)
);

create table public.stations (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  code text not null check (code ~ '^[A-Z0-9-]{2,12}$'),
  name text not null,
  address text,
  time_zone text not null default 'America/New_York',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (client_id, code),
  unique (id, client_id)
);

create table public.job_roles (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  station_id uuid not null,
  name text not null,
  pay_text text,
  min_age integer check (min_age between 16 and 30),
  days_per_week text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (station_id, client_id) references public.stations(id, client_id) on delete cascade,
  unique (station_id, name),
  unique (id, client_id)
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text not null,
  role public.app_role not null default 'viewer',
  status public.user_status not null default 'pending',
  phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Which clients a user may open. station_ids = null means every station of that client
-- (except for Station Managers, who must have an explicit list).
create table public.user_client_access (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  client_id uuid not null references public.clients(id) on delete cascade,
  station_ids uuid[],
  granted_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  unique (user_id, client_id)
);

-- Supervisor → CSR. A CSR has one supervisor.
create table public.teams (
  id uuid primary key default gen_random_uuid(),
  supervisor_id uuid not null references public.profiles(id) on delete cascade,
  csr_id uuid not null unique references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  check (supervisor_id <> csr_id)
);

-- The permission matrix (section 4 of the build prompt). Read by can().
create table public.role_permissions (
  role public.app_role not null,
  permission text not null,
  primary key (role, permission)
);

-- Company-wide feature switches. Only Super Admin can change them.
create table public.feature_flags (
  key text primary key check (key ~ '^[a-z_]{2,40}$'),
  label text not null,
  description text not null default '',
  enabled boolean not null default true,
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

create trigger clients_updated_at before update on public.clients for each row execute function public.set_updated_at();
create trigger client_settings_updated_at before update on public.client_settings for each row execute function public.set_updated_at();
create trigger stations_updated_at before update on public.stations for each row execute function public.set_updated_at();
create trigger job_roles_updated_at before update on public.job_roles for each row execute function public.set_updated_at();
create trigger profiles_updated_at before update on public.profiles for each row execute function public.set_updated_at();
create trigger feature_flags_updated_at before update on public.feature_flags for each row execute function public.set_updated_at();

create index user_client_access_user_idx on public.user_client_access(user_id);
create index stations_client_idx on public.stations(client_id);
create index job_roles_client_idx on public.job_roles(client_id);
