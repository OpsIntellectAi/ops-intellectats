-- 0011 · Phase 3: texting and calls.
-- Texts: every text goes through public.queue_text(), which waits for the candidate's
-- sending window and is then sent by the scheduler (Edge Function) through Twilio.
-- Calls: public.ai_call_check() decides whether an AI call may start; results come back
-- through public.record_call_result(), which saves answers and plans retries.
-- All functions here are for the service role (Edge Functions), unless stated otherwise.

-- ---------- columns ----------
alter table public.applications
  add column said_yes_at timestamptz,
  add column first_text_at timestamptz,
  add column cadence_step smallint not null default 0 check (cadence_step between 0 and 3),
  add column no_response_at timestamptz,
  add column manual_call_needed boolean not null default false,
  add column reschedule_requested_at timestamptz,
  add column self_token text not null default encode(extensions.gen_random_bytes(18), 'hex');
create unique index applications_self_token_key on public.applications (self_token);

alter table public.profiles
  add column phone_e164 text check (phone_e164 is null or phone_e164 ~ '^\+[1-9][0-9]{7,14}$');

alter table public.client_settings
  add column best_call_start time not null default '10:00',
  add column best_call_end time not null default '18:00',
  add constraint client_settings_best_call_window check (best_call_start < best_call_end);

create index job_queue_app_idx on public.job_queue ((payload ->> 'application_id')) where status = 'queued';

-- ---------- staging allow-list of test phones ----------
create table public.test_phones (
  phone_e164 text primary key check (phone_e164 ~ '^\+[1-9][0-9]{7,14}$'),
  label text not null default '',
  added_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
alter table public.test_phones enable row level security;
create policy test_phones_select on public.test_phones for select to authenticated
  using (public.can('platform.admin'));
create policy test_phones_write on public.test_phones for all to authenticated
  using (public.can('platform.admin')) with check (public.can('platform.admin'));
revoke all on public.test_phones from anon;

-- Anything other than 'production' keeps the allow-list on.
insert into public.app_config (key, value) values ('environment', 'staging') on conflict (key) do nothing;

-- ---------- time helpers ----------
create or replace function public.candidate_tz(p_application uuid)
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce(c.time_zone, s.time_zone, cs.time_zone, 'America/New_York')
  from public.applications a
  join public.candidates c on c.id = a.candidate_id
  join public.stations s on s.id = a.station_id
  left join public.client_settings cs on cs.client_id = a.client_id
  where a.id = p_application;
$$;

-- First moment at or after p_from that is inside the sending window (local time p_tz).
create or replace function public.next_send_time(p_tz text, p_quiet_start time, p_quiet_end time, p_from timestamptz)
returns timestamptz
language plpgsql
immutable
set search_path = ''
as $$
declare
  l timestamp := p_from at time zone p_tz;
  t time := l::time;
begin
  if t >= p_quiet_end and t < p_quiet_start then
    return p_from;
  elsif t < p_quiet_end then
    return (date_trunc('day', l) + p_quiet_end) at time zone p_tz;
  else
    return (date_trunc('day', l) + interval '1 day' + p_quiet_end) at time zone p_tz;
  end if;
end;
$$;

-- When the first text goes: at the client's set time (candidate local), or right away if
-- that time already passed today and we are still inside the sending window.
create or replace function public.first_text_due(p_tz text, p_auto time, p_quiet_start time, p_quiet_end time, p_applied timestamptz)
returns timestamptz
language plpgsql
immutable
set search_path = ''
as $$
declare
  l timestamp := p_applied at time zone p_tz;
  at_time timestamptz := (date_trunc('day', l) + p_auto) at time zone p_tz;
begin
  if p_applied <= at_time then
    return public.next_send_time(p_tz, p_quiet_start, p_quiet_end, at_time);
  end if;
  return public.next_send_time(p_tz, p_quiet_start, p_quiet_end, p_applied);
end;
$$;

-- Next moment inside the client's best answer window, at least p_after from now.
create or replace function public.next_call_time(p_tz text, p_start time, p_end time, p_from timestamptz)
returns timestamptz
language plpgsql
immutable
set search_path = ''
as $$
declare
  l timestamp := p_from at time zone p_tz;
  t time := l::time;
begin
  if t >= p_start and t < p_end then
    return p_from;
  elsif t < p_start then
    return (date_trunc('day', l) + p_start) at time zone p_tz;
  else
    return (date_trunc('day', l) + interval '1 day' + p_start) at time zone p_tz;
  end if;
end;
$$;

-- ---------- message text ----------
create or replace function public.site_url()
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce(nullif(split_part((select value from public.app_config where key = 'allowed_origins'), ',', 1), ''),
                  'https://ops-intellect-staging.vercel.app');
$$;

create or replace function public.self_service_link(p_application uuid)
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select public.site_url() || '/s/' || a.self_token from public.applications a where a.id = p_application;
$$;

create or replace function public.fill_template(p_body text, p_application uuid, p_time timestamptz default null)
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select replace(replace(replace(replace(replace(replace(p_body,
    '[first name]', split_part(c.full_name, ' ', 1)),
    '[role]', j.name),
    '[client]', cl.name),
    '[link]', coalesce(j.scheduling_link, public.self_service_link(a.id))),
    '[self-service link]', public.self_service_link(a.id)),
    '[time]', coalesce(to_char(p_time at time zone public.candidate_tz(a.id), 'FMHH12:MI AM'), ''))
  from public.applications a
  join public.candidates c on c.id = a.candidate_id
  join public.job_roles j on j.id = a.job_role_id
  join public.clients cl on cl.id = a.client_id
  where a.id = p_application;
$$;

create or replace function public.has_active_consent(p_candidate uuid, p_type public.consent_type)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.consents k
    where k.candidate_id = p_candidate and k.consent_type = p_type and k.revoked_at is null
  );
$$;

-- ---------- queue one text ----------
-- Returns {message_id, run_at} or {skipped: reason}. Never sends inside quiet hours.
create or replace function public.queue_text(
  p_application uuid,
  p_body text,
  p_automatic boolean,
  p_sent_by uuid default null,
  p_not_before timestamptz default null,
  p_fill_time timestamptz default null
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  a record;
  v_body text;
  v_run timestamptz;
  v_msg uuid;
begin
  select ap.id, ap.client_id, ap.candidate_id, ap.not_interested_until, ap.stage,
         c.opted_out_at, c.is_landline,
         coalesce(cs.quiet_start, '20:00') as qs, coalesce(cs.quiet_end, '08:00') as qe
    into a
  from public.applications ap
  join public.candidates c on c.id = ap.candidate_id
  left join public.client_settings cs on cs.client_id = ap.client_id
  where ap.id = p_application;
  if a.id is null then
    return jsonb_build_object('skipped', 'not_found');
  end if;
  if a.opted_out_at is not null then
    return jsonb_build_object('skipped', 'opted_out');
  end if;
  if a.is_landline then
    return jsonb_build_object('skipped', 'landline');
  end if;
  if not public.has_active_consent(a.candidate_id, 'sms') then
    return jsonb_build_object('skipped', 'no_sms_consent');
  end if;
  if p_automatic and a.not_interested_until is not null and a.not_interested_until > current_date then
    return jsonb_build_object('skipped', 'paused_not_interested');
  end if;
  v_body := left(public.fill_template(p_body, p_application, p_fill_time), 640);
  if v_body is null or length(trim(v_body)) < 2 then
    return jsonb_build_object('skipped', 'empty');
  end if;
  v_run := public.next_send_time(public.candidate_tz(p_application), a.qs, a.qe, greatest(now(), coalesce(p_not_before, now())));
  insert into public.messages (application_id, client_id, direction, body, status, sent_by, is_automatic)
  values (p_application, a.client_id, 'outbound', v_body, 'queued', p_sent_by, p_automatic)
  returning id into v_msg;
  insert into public.job_queue (client_id, kind, payload, run_at)
  values (a.client_id, 'send_sms',
          jsonb_build_object('message_id', v_msg, 'application_id', p_application, 'automatic', p_automatic), v_run);
  return jsonb_build_object('message_id', v_msg, 'run_at', v_run);
end;
$$;

-- Queue the client's automatic text for a trigger key, if it exists and is on.
create or replace function private.queue_step_text(p_application uuid, p_key text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_body text;
begin
  select sm.body into v_body
  from public.step_messages sm
  join public.applications a on a.client_id = sm.client_id
  where a.id = p_application and sm.trigger_key = p_key and sm.enabled;
  if v_body is not null then
    perform public.queue_text(p_application, v_body, true, null);
  end if;
end;
$$;

-- ---------- automatic texts on stage and step changes ----------
create or replace function private.stage_step_text()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.stage is distinct from old.stage then
    perform private.queue_step_text(new.id, 'stage:' || new.stage::text);
  end if;
  return new;
end;
$$;

create trigger applications_stage_text after update of stage on public.applications
  for each row execute function private.stage_step_text();

create or replace function private.onboarding_step_text()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_key text;
begin
  if tg_op = 'UPDATE' and new.status is not distinct from old.status then
    return new;
  end if;
  select d.key into v_key from public.onboarding_step_defs d where d.id = new.step_def_id;
  if v_key is not null and new.status <> 'Not started' then
    perform private.queue_step_text(new.application_id, 'step:' || v_key || ':' || new.status);
  end if;
  return new;
end;
$$;

create trigger onboarding_steps_text after insert or update of status on public.onboarding_steps
  for each row execute function private.onboarding_step_text();

-- ---------- reminders before a booked AI call ----------
create or replace function private.plan_booking_jobs()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  r record;
begin
  if new.booked_call_at is not distinct from old.booked_call_at then
    return new;
  end if;
  update public.job_queue set status = 'cancelled', updated_at = now()
  where status = 'queued' and kind in ('call_reminder', 'ai_call')
    and payload ->> 'application_id' = new.id::text and coalesce(payload ->> 'booked', 'false') = 'true';
  if new.booked_call_at is null or new.booked_call_at <= now() then
    return new;
  end if;
  new.reschedule_requested_at := null;
  for r in select * from public.call_reminders cr where cr.client_id = new.client_id and cr.enabled loop
    -- Skip any reminder whose time has already passed.
    if new.booked_call_at - make_interval(mins => r.minutes_before) > now() then
      insert into public.job_queue (client_id, kind, payload, run_at)
      values (new.client_id, 'call_reminder',
              jsonb_build_object('application_id', new.id, 'reminder_id', r.id, 'booked', true,
                                 'booked_at', new.booked_call_at, 'automatic', true),
              new.booked_call_at - make_interval(mins => r.minutes_before));
    end if;
  end loop;
  insert into public.job_queue (client_id, kind, payload, run_at)
  values (new.client_id, 'ai_call', jsonb_build_object('application_id', new.id, 'booked', true, 'automatic', true),
          new.booked_call_at);
  return new;
end;
$$;

create trigger applications_booking_jobs before update of booked_call_at on public.applications
  for each row execute function private.plan_booking_jobs();

-- ---------- no-reply cadence and first text (run by the scheduler every few minutes) ----------
create or replace function public.run_cadence(p_now timestamptz default now())
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  r record;
  n_first integer := 0;
  n_day2 integer := 0;
  n_day5 integer := 0;
  n_none integer := 0;
  v_body text;
begin
  if coalesce((select enabled from public.feature_flags where key = 'emergency_stop'), false) then
    return jsonb_build_object('skipped', 'emergency_stop');
  end if;

  -- First text, at the client's set time in the candidate's local time.
  for r in
    select a.id, a.client_id, a.applied_at, public.candidate_tz(a.id) as tz,
           cs.auto_text_time, cs.quiet_start, cs.quiet_end
    from public.applications a
    join public.candidates c on c.id = a.candidate_id
    join public.client_settings cs on cs.client_id = a.client_id
    where a.stage = 'interview' and a.first_text_at is null and c.opted_out_at is null
      and a.applied_at > p_now - interval '3 days'
      and not exists (select 1 from public.messages m where m.application_id = a.id and m.direction = 'outbound')
  loop
    if p_now >= public.first_text_due(r.tz, r.auto_text_time, r.quiet_start, r.quiet_end, r.applied_at) then
      select sm.body into v_body from public.step_messages sm
      where sm.client_id = r.client_id and sm.trigger_key = 'first_text' and sm.enabled;
      if v_body is not null and (public.queue_text(r.id, v_body, true) ->> 'message_id') is not null then
        update public.applications set first_text_at = p_now, cadence_step = 0 where id = r.id;
        n_first := n_first + 1;
      end if;
    end if;
  end loop;

  -- Day 2 follow-up, Day 5 final text, Day 7 "No response". Any reply stops this.
  for r in
    select a.id, a.client_id, a.cadence_step, a.first_text_at
    from public.applications a
    join public.candidates c on c.id = a.candidate_id
    where a.stage = 'interview' and a.first_text_at is not null and a.cadence_step < 3
      and a.no_response_at is null and c.opted_out_at is null
      and not exists (select 1 from public.messages m
                      where m.application_id = a.id and m.direction = 'inbound' and m.created_at >= a.first_text_at)
  loop
    if r.cadence_step = 0 and p_now >= r.first_text_at + interval '2 days' then
      perform private.queue_step_text(r.id, 'follow_up_day2');
      update public.applications set cadence_step = 1 where id = r.id;
      n_day2 := n_day2 + 1;
    elsif r.cadence_step = 1 and p_now >= r.first_text_at + interval '5 days' then
      perform private.queue_step_text(r.id, 'follow_up_day5');
      update public.applications set cadence_step = 2 where id = r.id;
      n_day5 := n_day5 + 1;
    elsif r.cadence_step = 2 and p_now >= r.first_text_at + interval '7 days' then
      update public.applications set cadence_step = 3, no_response_at = p_now where id = r.id;
      -- Stop AI calls: cancel planned calls and retries.
      update public.job_queue set status = 'cancelled', updated_at = now()
      where status = 'queued' and kind = 'ai_call' and payload ->> 'application_id' = r.id::text;
      perform private.write_audit('Marked No response', r.client_id, 'application', r.id::text, null, null, 'No reply after 7 days');
      n_none := n_none + 1;
    end if;
  end loop;

  return jsonb_build_object('first', n_first, 'day2', n_day2, 'day5', n_day5, 'no_response', n_none);
end;
$$;

-- ---------- inbound texts ----------
create or replace function public.message_topics(p_body text)
returns text[]
language sql
immutable
set search_path = ''
as $$
  select array_remove(array[
    case when upper(trim(p_body)) in ('YES', 'Y', 'YES!', 'YEAH', 'YEP', 'SURE', 'OK', 'OKAY') then 'said_yes' end,
    case when p_body ~* '[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}' then 'shared_email' end,
    case when p_body ~* 'background' then 'background_check' end,
    case when p_body ~* 'drug|urine|collection site' then 'drug_test' end,
    case when p_body ~* 'offer' then 'offer_letter' end,
    case when upper(trim(p_body)) = 'C' or p_body ~* 'reschedul|another time|different time' then 'reschedule' end
  ], null);
$$;

create or replace function public.process_inbound_sms(p_from text, p_body text, p_sid text)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_app record;
  v_kw text := upper(regexp_replace(trim(coalesce(p_body, '')), '[^A-Za-z]', '', 'g'));
  v_topics text[] := public.message_topics(coalesce(p_body, ''));
  v_email text;
  v_reply text;
  v_msg uuid;
begin
  -- The application this person most recently heard from us about.
  select a.id, a.client_id, a.candidate_id into v_app
  from public.applications a
  join public.candidates c on c.id = a.candidate_id
  where c.phone_e164 = p_from
  order by (select max(m.created_at) from public.messages m where m.application_id = a.id) desc nulls last,
           a.applied_at desc
  limit 1;
  if v_app.id is null then
    return jsonb_build_object('unknown', true);
  end if;

  if v_kw in ('STOP', 'STOPALL', 'UNSUBSCRIBE', 'CANCEL', 'END', 'QUIT', 'REVOKE', 'OPTOUT') then
    v_topics := array['opted_out'];
  end if;

  insert into public.messages (application_id, client_id, direction, body, status, twilio_sid, topics)
  values (v_app.id, v_app.client_id, 'inbound', left(coalesce(p_body, ''), 1600), 'received', p_sid, v_topics)
  on conflict (twilio_sid) do nothing
  returning id into v_msg;
  if v_msg is null then
    return jsonb_build_object('duplicate', true);
  end if;

  if 'opted_out' = any (v_topics) then
    -- Opt out of every client that has this phone: no texts and no AI calls. Twilio sends
    -- the one standard confirmation itself.
    update public.candidates set opted_out_at = now() where phone_e164 = p_from and opted_out_at is null;
    update public.consents k set revoked_at = now()
    from public.candidates c
    where c.id = k.candidate_id and c.phone_e164 = p_from and k.consent_type = 'sms' and k.revoked_at is null;
    update public.job_queue j set status = 'cancelled', updated_at = now()
    from public.applications a join public.candidates c on c.id = a.candidate_id
    where c.phone_e164 = p_from and j.status = 'queued' and j.kind in ('send_sms', 'call_reminder', 'ai_call', 'follow_up')
      and j.payload ->> 'application_id' = a.id::text;
    update public.messages m set status = 'cancelled'
    from public.applications a join public.candidates c on c.id = a.candidate_id
    where c.phone_e164 = p_from and m.application_id = a.id and m.status = 'queued';
    perform private.write_audit('Opted out (STOP)', v_app.client_id, 'application', v_app.id::text, null, null, 'STOP');
    return jsonb_build_object('application_id', v_app.id, 'opted_out', true);
  end if;

  if v_kw in ('START', 'UNSTOP') then
    update public.candidates set opted_out_at = null where phone_e164 = p_from;
    insert into public.consents (candidate_id, client_id, consent_type, wording_version, source)
    select c.id, c.client_id, 'sms', 'start-keyword', 'Texted START' from public.candidates c where c.phone_e164 = p_from;
    perform private.write_audit('Opted back in (START)', v_app.client_id, 'application', v_app.id::text, null, null, 'START');
    return jsonb_build_object('application_id', v_app.id, 'opted_in', true);
  end if;

  if v_kw in ('HELP', 'INFO') then
    select cl.name || ' recruiting: questions? Call ' || coalesce(cs.contact_phone, 'us') ||
           coalesce(' or email ' || cs.contact_email, '') || '. Reply STOP to opt out.'
      into v_reply
    from public.clients cl left join public.client_settings cs on cs.client_id = cl.id
    where cl.id = v_app.client_id;
    return jsonb_build_object('application_id', v_app.id, 'reply', v_reply);
  end if;

  -- Any reply reopens the candidate and stops the no-reply cadence.
  update public.applications
     set no_response_at = null,
         cadence_step = 3,
         said_yes_at = case when 'said_yes' = any (v_topics) then now() else said_yes_at end,
         reschedule_requested_at = case when 'reschedule' = any (v_topics) then now() else reschedule_requested_at end
   where id = v_app.id;

  if 'shared_email' = any (v_topics) then
    v_email := lower(substring(p_body from '([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})'));
    update public.candidates set email = v_email where id = v_app.candidate_id and email is null;
  end if;

  if 'reschedule' = any (v_topics) then
    v_reply := public.fill_template('No problem, [first name]. Pick a new time here: [self-service link]', v_app.id);
  end if;

  return jsonb_build_object('application_id', v_app.id, 'topics', v_topics, 'reply', v_reply);
end;
$$;

-- Status callbacks from Twilio only move a message forward.
create or replace function public.update_message_status(p_sid text, p_status text, p_error text default null)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  rank_new integer := case p_status when 'queued' then 1 when 'accepted' then 1 when 'sending' then 2 when 'sent' then 3
                         when 'delivered' then 4 when 'undelivered' then 4 when 'failed' then 4 else 0 end;
begin
  if rank_new = 0 then
    return;
  end if;
  update public.messages set status = p_status, error_code = coalesce(p_error, error_code)
  where twilio_sid = p_sid
    and (case status when 'queued' then 1 when 'accepted' then 1 when 'sending' then 2 when 'sent' then 3
           when 'delivered' then 4 when 'undelivered' then 4 when 'failed' then 4 else 0 end) < rank_new;
end;
$$;

-- ---------- job queue ----------
create or replace function public.claim_jobs(p_limit integer default 25, p_kinds text[] default null)
returns setof public.job_queue
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_stop boolean := coalesce((select enabled from public.feature_flags where key = 'emergency_stop'), false);
begin
  -- Jobs stuck in "running" (a crashed run) go back to the queue.
  update public.job_queue set status = 'queued', updated_at = now()
  where status = 'running' and updated_at < now() - interval '10 minutes';

  return query
  update public.job_queue j set status = 'running', attempts = j.attempts + 1, updated_at = now()
  where j.id in (
    select q.id from public.job_queue q
    where q.status = 'queued' and q.run_at <= now()
      and (p_kinds is null or q.kind = any (p_kinds))
      -- Emergency stop: automated work waits; one-off texts by a person still go.
      and not (v_stop and coalesce((q.payload ->> 'automatic')::boolean, true))
    order by q.run_at
    limit least(greatest(p_limit, 1), 200)
    for update skip locked
  )
  returning j.*;
end;
$$;

create or replace function public.finish_job(p_id uuid, p_ok boolean, p_error text default null, p_retry_at timestamptz default null)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  update public.job_queue
     set status = case when p_ok then 'done'::public.job_status
                       when p_retry_at is not null and attempts < 5 then 'queued'::public.job_status
                       else 'failed'::public.job_status end,
         run_at = coalesce(p_retry_at, run_at),
         last_error = left(p_error, 500),
         updated_at = now()
   where id = p_id;
end;
$$;

-- Everything the scheduler needs to send one queued text.
create or replace function public.sms_to_send(p_message uuid)
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select jsonb_build_object(
    'message_id', m.id, 'status', m.status, 'body', m.body, 'is_automatic', m.is_automatic,
    'to', c.phone_e164, 'opted_out', c.opted_out_at is not null,
    'client_id', m.client_id, 'client_live', cl.is_live,
    'messaging_service_sid', cs.twilio_messaging_service_sid, 'a2p_status', cs.a2p_campaign_status,
    'environment', coalesce((select value from public.app_config where key = 'environment'), 'staging'),
    'allow_listed', exists (select 1 from public.test_phones t where t.phone_e164 = c.phone_e164))
  from public.messages m
  join public.applications a on a.id = m.application_id
  join public.candidates c on c.id = a.candidate_id
  join public.clients cl on cl.id = m.client_id
  left join public.client_settings cs on cs.client_id = m.client_id
  where m.id = p_message;
$$;

create or replace function public.mark_message_sent(p_message uuid, p_status text, p_sid text default null, p_error text default null)
returns void
language sql
security definer
set search_path = ''
as $$
  update public.messages set status = p_status, twilio_sid = coalesce(p_sid, twilio_sid), error_code = p_error
  where id = p_message;
$$;

-- ---------- webhook idempotency ----------
create or replace function public.claim_idempotency(p_key text, p_source text)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  v text;
begin
  insert into public.idempotency_keys (key, source) values (left(p_key, 300), p_source)
  on conflict (key) do nothing
  returning key into v;
  return v is not null;
end;
$$;

-- ---------- AI calls ----------
-- Null when an AI call may start; otherwise the reason (shown on the disabled button).
create or replace function public.ai_call_check(p_application uuid, p_automatic boolean default false)
returns text
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  a record;
  v_today integer;
  v_total integer;
begin
  select ap.id, ap.client_id, ap.candidate_id, ap.stage, ap.job_role_id, ap.no_response_at, ap.not_interested_until,
         c.opted_out_at, c.lives_in_nyc, coalesce(cs.aedt_enabled, false) as aedt,
         coalesce(cs.max_ai_attempts_per_day, 2) as per_day, coalesce(cs.max_ai_attempts_total, 4) as total,
         public.candidate_tz(ap.id) as tz
    into a
  from public.applications ap
  join public.candidates c on c.id = ap.candidate_id
  left join public.client_settings cs on cs.client_id = ap.client_id
  where ap.id = p_application;
  if a.id is null then return 'Candidate not found'; end if;
  if a.opted_out_at is not null then return 'Opted out (STOP)'; end if;
  if not public.has_active_consent(a.candidate_id, 'ai_call') then return 'No AI-call consent on file'; end if;
  if a.stage <> 'interview' then return 'AI interviews are for the Interview stage'; end if;
  if p_automatic and coalesce((select enabled from public.feature_flags where key = 'emergency_stop'), false) then
    return 'Emergency stop is on';
  end if;
  if p_automatic and a.no_response_at is not null then return 'Marked No response'; end if;
  if a.not_interested_until is not null and a.not_interested_until > current_date then return 'Not interested for now'; end if;
  if not exists (select 1 from public.scripts s where s.job_role_id = a.job_role_id and s.current_version_id is not null) then
    return 'No published AI script for this job role';
  end if;
  if exists (select 1 from public.calls k where k.application_id = a.id and k.outcome in ('queued', 'in_progress')
             and k.created_at > now() - interval '30 minutes') then
    return 'A call is already in progress';
  end if;
  if a.lives_in_nyc and a.aedt and not exists (
    select 1 from public.aedt_notices n where n.candidate_id = a.candidate_id
      and n.sent_at <= now() - interval '14 days' and not n.asked_for_person) then
    return 'NYC: AI-use notice must go out 10 business days before an AI interview';
  end if;
  select count(*) filter (where (coalesce(k.started_at, k.created_at) at time zone a.tz)::date = (now() at time zone a.tz)::date),
         count(*)
    into v_today, v_total
  from public.calls k where k.application_id = a.id and k.via = 'ai';
  if v_total >= a.total then return 'All AI call attempts used; call them yourself'; end if;
  if v_today >= a.per_day then return 'Daily AI call attempts used; next try tomorrow'; end if;
  return null;
end;
$$;

-- Signed-in users can ask why the button is off (only for candidates they can see).
create or replace function public.ai_call_reason(p_application uuid)
returns text
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if not public.app_id_visible(p_application) then
    return 'No access';
  end if;
  return public.ai_call_check(p_application, false);
end;
$$;

-- Creates the call row pinned to the current script version. Returns call + script data.
create or replace function public.create_call(p_application uuid, p_via public.call_via, p_provider text, p_placed_by uuid default null)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  a record;
  v_version uuid;
  v_tree jsonb;
  v_rules jsonb;
  v_attempt integer;
  v_call uuid;
begin
  select ap.id, ap.client_id, ap.job_role_id, c.full_name, c.phone_e164, j.name as role_name, cl.name as client_name,
         j.pay_text, s.address
    into a
  from public.applications ap
  join public.candidates c on c.id = ap.candidate_id
  join public.job_roles j on j.id = ap.job_role_id
  join public.stations s on s.id = ap.station_id
  join public.clients cl on cl.id = ap.client_id
  where ap.id = p_application;
  if a.id is null then
    raise exception 'Candidate not found' using errcode = 'no_data_found';
  end if;
  select sc.current_version_id, v.question_tree, v.global_rules into v_version, v_tree, v_rules
  from public.scripts sc join public.script_versions v on v.id = sc.current_version_id
  where sc.job_role_id = a.job_role_id;
  select count(*) + 1 into v_attempt from public.calls k where k.application_id = p_application and k.via = p_via;
  insert into public.calls (application_id, client_id, provider, direction, via, outcome, script_version_id,
                            attempt_number, placed_by, started_at)
  values (p_application, a.client_id, p_provider, 'outbound', p_via, 'queued',
          case when p_via = 'ai' then v_version end, v_attempt, p_placed_by, now())
  returning id into v_call;
  perform private.write_audit(case when p_via = 'ai' then 'AI call started' else 'Phone call started' end,
    a.client_id, 'application', p_application::text, a.full_name, null, 'attempt ' || v_attempt);
  return jsonb_build_object(
    'call_id', v_call, 'attempt', v_attempt, 'to', a.phone_e164, 'first_name', split_part(a.full_name, ' ', 1),
    'role', a.role_name, 'client', a.client_name, 'pay', a.pay_text, 'address', a.address,
    'script_version_id', v_version, 'questions', coalesce(v_tree, '[]'::jsonb), 'rules', coalesce(v_rules, '[]'::jsonb));
end;
$$;

create or replace function public.set_provider_call_id(p_call uuid, p_provider_call_id text, p_outcome public.call_outcome default 'in_progress')
returns void
language sql
security definer
set search_path = ''
as $$
  update public.calls set provider_call_id = p_provider_call_id, outcome = p_outcome where id = p_call;
$$;

-- Saves the result of a call. Answers: [{key, text, heard, result, at}]. Plans retries.
create or replace function public.record_call_result(
  p_call uuid,
  p_outcome public.call_outcome,
  p_duration integer default null,
  p_transcript text default null,
  p_answers jsonb default '[]'::jsonb,
  p_recording_path text default null,
  p_summary text default null,
  p_facts jsonb default null
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  k record;
  s record;
  v_today integer;
  v_total integer;
  v_next timestamptz;
  v_retry boolean := false;
  v_body text;
  v_short boolean := false;
begin
  select cl.*, a.candidate_id, a.stage, c.lives_in_nyc into k
  from public.calls cl
  join public.applications a on a.id = cl.application_id
  join public.candidates c on c.id = a.candidate_id
  where cl.id = p_call;
  if k.id is null then
    raise exception 'Call not found' using errcode = 'no_data_found';
  end if;
  -- A call that already has a final result is never processed twice.
  if k.outcome not in ('queued', 'in_progress') then
    return jsonb_build_object('duplicate', true);
  end if;

  update public.calls
     set outcome = p_outcome, duration_seconds = p_duration, transcript = left(p_transcript, 100000),
         recording_path = p_recording_path, summary = left(p_summary, 4000), facts = p_facts, ended_at = now()
   where id = p_call;

  if p_outcome = 'completed' then
    -- Voicemail-safe: answers only for a real, completed conversation.
    insert into public.call_answers (call_id, client_id, question_key, question_text, heard_text, result, at_seconds)
    select p_call, k.client_id, left(x ->> 'key', 40), left(coalesce(x ->> 'text', x ->> 'key'), 400),
           left(x ->> 'heard', 1000),
           case when x ->> 'result' in ('yes', 'no', 'needs_review', 'recorded', 'info')
                then (x ->> 'result')::public.answer_result else 'needs_review'::public.answer_result end,
           nullif(x ->> 'at', '')::integer
    from jsonb_array_elements(coalesce(p_answers, '[]'::jsonb)) x
    where coalesce(x ->> 'key', '') <> '';
    update public.applications set booked_call_at = null where id = k.application_id and booked_call_at <= now();

    -- Optional auto-shortlist: only when every yes/no answer is Yes, never on an unclear
    -- answer, and never for NYC residents unless the client switched on AEDT compliance.
    select cs.auto_shortlist, cs.aedt_enabled into s from public.client_settings cs where cs.client_id = k.client_id;
    if coalesce(s.auto_shortlist, false) and k.via = 'ai' and k.stage = 'interview'
       and (not k.lives_in_nyc or coalesce(s.aedt_enabled, false))
       and exists (select 1 from public.call_answers x where x.call_id = p_call and x.result = 'yes')
       and not exists (select 1 from public.call_answers x where x.call_id = p_call and x.result in ('no', 'needs_review')) then
      update public.applications set stage = 'shortlisted' where id = k.application_id;
      v_short := true;
    end if;
  elsif p_outcome = 'voicemail' then
    -- Hang up, save nothing, text the scheduling link instead.
    select mt.body into v_body from public.message_templates mt
    where mt.client_id = k.client_id and mt.is_scheduling_link and mt.body like '%[link]%' order by mt.name limit 1;
    perform public.queue_text(k.application_id,
      coalesce(v_body, 'Hi [first name], sorry we missed you. Book your short AI interview for [role] here: [link]'), true);
  end if;

  if k.via = 'ai' and p_outcome in ('voicemail', 'no_answer', 'busy', 'failed', 'dropped') then
    select coalesce(cs.max_ai_attempts_per_day, 2) as per_day, coalesce(cs.max_ai_attempts_total, 4) as total,
           coalesce(cs.best_call_start, '10:00') as bs, coalesce(cs.best_call_end, '18:00') as be,
           public.candidate_tz(k.application_id) as tz
      into s
    from public.client_settings cs where cs.client_id = k.client_id;
    select count(*) filter (where (coalesce(c2.started_at, c2.created_at) at time zone s.tz)::date = (now() at time zone s.tz)::date),
           count(*)
      into v_today, v_total
    from public.calls c2 where c2.application_id = k.application_id and c2.via = 'ai';
    if v_total < s.total then
      if v_today < s.per_day then
        v_next := public.next_call_time(s.tz, s.bs, s.be, now() + interval '2 hours');
      else
        v_next := public.next_call_time(s.tz, s.bs, s.be, ((date_trunc('day', now() at time zone s.tz) + interval '1 day') at time zone s.tz));
      end if;
      insert into public.job_queue (client_id, kind, payload, run_at)
      values (k.client_id, 'ai_call', jsonb_build_object('application_id', k.application_id, 'retry', true, 'automatic', true), v_next);
      v_retry := true;
    else
      update public.applications set manual_call_needed = true where id = k.application_id;
      perform private.write_audit('AI call attempts used up', k.client_id, 'application', k.application_id::text, null, null,
        'Manual call needed', true, 'Call this candidate yourself');
    end if;
  end if;

  perform private.write_audit('Call ended', k.client_id, 'application', k.application_id::text, null, null, p_outcome::text);
  return jsonb_build_object('call_id', p_call, 'retry_at', v_next, 'retry', v_retry, 'auto_shortlisted', v_short);
end;
$$;

create or replace function public.call_by_provider_id(p_provider_call_id text)
returns uuid
language sql
stable
security definer
set search_path = ''
as $$
  select id from public.calls where provider_call_id = p_provider_call_id;
$$;

-- ---------- grants: service role only, except the two "why" helpers ----------
do $$
declare f text;
begin
  foreach f in array array[
    'public.candidate_tz(uuid)',
    'public.next_send_time(text, time, time, timestamptz)',
    'public.first_text_due(text, time, time, time, timestamptz)',
    'public.next_call_time(text, time, time, timestamptz)',
    'public.site_url()',
    'public.self_service_link(uuid)',
    'public.fill_template(text, uuid, timestamptz)',
    'public.has_active_consent(uuid, public.consent_type)',
    'public.queue_text(uuid, text, boolean, uuid, timestamptz, timestamptz)',
    'public.run_cadence(timestamptz)',
    'public.message_topics(text)',
    'public.process_inbound_sms(text, text, text)',
    'public.update_message_status(text, text, text)',
    'public.claim_jobs(integer, text[])',
    'public.finish_job(uuid, boolean, text, timestamptz)',
    'public.sms_to_send(uuid)',
    'public.mark_message_sent(uuid, text, text, text)',
    'public.claim_idempotency(text, text)',
    'public.ai_call_check(uuid, boolean)',
    'public.create_call(uuid, public.call_via, text, uuid)',
    'public.set_provider_call_id(uuid, text, public.call_outcome)',
    'public.record_call_result(uuid, public.call_outcome, integer, text, jsonb, text, text, jsonb)',
    'public.call_by_provider_id(text)'
  ] loop
    execute format('revoke execute on function %s from public, anon, authenticated', f);
    execute format('grant execute on function %s to service_role', f);
  end loop;
end $$;

revoke execute on function public.ai_call_reason(uuid) from public, anon;
grant execute on function public.ai_call_reason(uuid) to authenticated, service_role;

-- The list view gains the new columns (security_invoker keeps RLS of the caller).
create or replace view public.application_rows with (security_invoker = true) as
select
  a.id, a.client_id, a.candidate_id, a.station_id, a.job_role_id, a.stage, a.owner_id, a.source,
  a.applied_at, a.stage_changed_at, a.not_interested_reason, a.not_interested_until, a.rejection_reason,
  a.booked_call_at,
  c.full_name, c.phone_e164, c.email, c.city, c.zip, c.time_zone, c.opted_out_at, c.is_landline, c.lives_in_nyc,
  m.last_out_at, m.last_in_at, coalesce(m.out_count, 0) as out_count, coalesce(m.in_count, 0) as in_count,
  m.last_body,
  (select mm.topics from public.messages mm
     where mm.application_id = a.id and mm.direction = 'inbound' order by mm.created_at desc limit 1) as last_topics,
  coalesce(k.ai_calls, 0) as ai_calls,
  coalesce(k.completed_ai_calls, 0) as completed_ai_calls,
  k.last_call_at, k.last_call_outcome,
  coalesce(k.unreviewed_calls, 0) as unreviewed_calls,
  (select count(*) from public.call_answers x join public.calls y on y.id = x.call_id
     where y.application_id = a.id and x.result = 'needs_review' and x.reviewed_at is null) as answers_to_review,
  coalesce(o.steps_total, 0) as steps_total,
  coalesce(o.steps_done, 0) as steps_done,
  coalesce(o.required_left, 0) as required_left,
  o.last_step_change,
  a.said_yes_at, a.no_response_at, a.manual_call_needed, a.reschedule_requested_at, a.cadence_step
from public.applications a
join public.candidates c on c.id = a.candidate_id
left join lateral (
  select
    max(mx.created_at) filter (where mx.direction = 'outbound') as last_out_at,
    max(mx.created_at) filter (where mx.direction = 'inbound') as last_in_at,
    count(*) filter (where mx.direction = 'outbound') as out_count,
    count(*) filter (where mx.direction = 'inbound') as in_count,
    (array_agg(mx.body order by mx.created_at desc))[1] as last_body
  from public.messages mx where mx.application_id = a.id
) m on true
left join lateral (
  select
    count(*) filter (where cl.via = 'ai') as ai_calls,
    count(*) filter (where cl.via = 'ai' and cl.outcome = 'completed') as completed_ai_calls,
    max(coalesce(cl.started_at, cl.created_at)) as last_call_at,
    (array_agg(cl.outcome order by coalesce(cl.started_at, cl.created_at) desc))[1] as last_call_outcome,
    count(*) filter (where cl.via = 'ai' and cl.outcome = 'completed'
      and not exists (select 1 from public.call_reviews r where r.call_id = cl.id)) as unreviewed_calls
  from public.calls cl where cl.application_id = a.id
) k on true
left join lateral (
  select
    count(*) as steps_total,
    count(*) filter (where s.status = any (d.done_statuses) or s.status = 'Waived') as steps_done,
    count(*) filter (where d.required and not (s.status = any (d.done_statuses) or s.status = 'Waived')) as required_left,
    max(s.changed_at) as last_step_change
  from public.onboarding_steps s join public.onboarding_step_defs d on d.id = s.step_def_id
  where s.application_id = a.id
) o on true;

revoke all on public.application_rows from anon;
grant select on public.application_rows to authenticated;
