-- 0003 · Candidates, applications, messages, calls, scripts, onboarding, templates
-- Every client-owned table carries client_id. Composite foreign keys (id, client_id)
-- make it impossible to attach a row to a parent that belongs to another client.

alter table public.job_roles add constraint job_roles_id_station_key unique (id, station_id);

create table public.candidates (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  full_name text not null check (length(trim(full_name)) between 2 and 120),
  phone_e164 text not null check (phone_e164 ~ '^\+[1-9][0-9]{7,14}$'),
  email text check (email is null or email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  city text,
  zip text check (zip is null or zip ~ '^[0-9]{5}$'),
  time_zone text,
  -- AES-256-GCM ciphertext written only by Edge Functions ("v1:<base64 iv+ciphertext>").
  licence_number_enc text check (licence_number_enc is null or licence_number_enc like 'v1:%'),
  date_of_birth_enc text check (date_of_birth_enc is null or date_of_birth_enc like 'v1:%'),
  is_landline boolean not null default false,
  lives_in_nyc boolean not null default false,
  opted_out_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  -- Same phone in the same client is blocked; another client is allowed.
  unique (client_id, phone_e164),
  unique (id, client_id)
);

create table public.applications (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  candidate_id uuid not null,
  station_id uuid not null,
  job_role_id uuid not null,
  stage public.app_stage not null default 'interview',
  owner_id uuid references public.profiles(id) on delete set null,
  source text not null default 'Direct',
  applied_at timestamptz not null default now(),
  stage_changed_at timestamptz not null default now(),
  not_interested_reason text,
  not_interested_until date,
  rejection_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (candidate_id, client_id) references public.candidates(id, client_id) on delete cascade,
  foreign key (station_id, client_id) references public.stations(id, client_id),
  foreign key (job_role_id, station_id) references public.job_roles(id, station_id),
  unique (candidate_id, job_role_id),
  unique (id, client_id)
);

create table public.stage_history (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null,
  client_id uuid not null,
  from_stage public.app_stage,
  to_stage public.app_stage not null,
  changed_by uuid references public.profiles(id) on delete set null,
  note text,
  changed_at timestamptz not null default now(),
  foreign key (application_id, client_id) references public.applications(id, client_id) on delete cascade
);

create table public.consents (
  id uuid primary key default gen_random_uuid(),
  candidate_id uuid not null,
  client_id uuid not null,
  consent_type public.consent_type not null,
  wording_version text not null,
  source text not null,
  ip inet,
  given_at timestamptz not null default now(),
  revoked_at timestamptz,
  foreign key (candidate_id, client_id) references public.candidates(id, client_id) on delete cascade
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null,
  client_id uuid not null,
  direction public.message_direction not null,
  body text not null,
  status text not null default 'queued',
  twilio_sid text unique,
  error_code text,
  topics text[] not null default '{}',
  sent_by uuid references public.profiles(id) on delete set null,
  is_automatic boolean not null default false,
  created_at timestamptz not null default now(),
  foreign key (application_id, client_id) references public.applications(id, client_id) on delete cascade
);

create table public.scripts (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  job_role_id uuid not null unique,
  name text not null,
  current_version_id uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (job_role_id, client_id) references public.job_roles(id, client_id) on delete cascade,
  unique (id, client_id)
);

create table public.script_versions (
  id uuid primary key default gen_random_uuid(),
  script_id uuid not null,
  client_id uuid not null,
  version integer not null check (version > 0),
  question_tree jsonb not null default '[]'::jsonb,
  global_rules jsonb not null default '[]'::jsonb,
  note text,
  published_by uuid references public.profiles(id) on delete set null,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  foreign key (script_id, client_id) references public.scripts(id, client_id) on delete cascade,
  unique (script_id, version),
  unique (id, client_id)
);

alter table public.scripts
  add constraint scripts_current_version_fk foreign key (current_version_id) references public.script_versions(id) on delete set null;

create table public.calls (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null,
  client_id uuid not null,
  provider text not null check (provider in ('vapi', 'retell', 'twilio')),
  direction public.call_direction not null default 'outbound',
  via public.call_via not null,
  outcome public.call_outcome not null default 'queued',
  duration_seconds integer check (duration_seconds is null or duration_seconds >= 0),
  recording_path text,
  script_version_id uuid,
  provider_call_id text unique,
  attempt_number integer not null default 1 check (attempt_number > 0),
  placed_by uuid references public.profiles(id) on delete set null,
  started_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz not null default now(),
  foreign key (application_id, client_id) references public.applications(id, client_id) on delete cascade,
  foreign key (script_version_id, client_id) references public.script_versions(id, client_id),
  unique (id, client_id)
);

create table public.call_answers (
  id uuid primary key default gen_random_uuid(),
  call_id uuid not null,
  client_id uuid not null,
  question_key text not null,
  question_text text not null,
  heard_text text,
  result public.answer_result not null,
  at_seconds integer check (at_seconds is null or at_seconds >= 0),
  reviewed_by uuid references public.profiles(id) on delete set null,
  reviewed_at timestamptz,
  foreign key (call_id, client_id) references public.calls(id, client_id) on delete cascade
);

create table public.call_reviews (
  id uuid primary key default gen_random_uuid(),
  call_id uuid not null,
  client_id uuid not null,
  verdict public.review_verdict not null,
  reason text,
  question_key text,
  note text,
  reviewer_id uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  foreign key (call_id, client_id) references public.calls(id, client_id) on delete cascade,
  check (verdict = 'looks_right' or reason is not null)
);

create table public.onboarding_step_defs (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  key text not null check (key ~ '^[a-z0-9_]{2,40}$'),
  name text not null,
  phase text not null,
  owner_label text not null default 'CSR',
  statuses text[] not null,
  done_statuses text[] not null,
  bad_statuses text[] not null default '{}',
  guidance jsonb not null default '{}'::jsonb,
  required boolean not null default true,
  sort_order integer not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (client_id, key),
  unique (id, client_id),
  check (done_statuses <@ statuses and bad_statuses <@ statuses)
);

create table public.onboarding_steps (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null,
  client_id uuid not null,
  step_def_id uuid not null,
  status text not null default 'Not started',
  note text,
  waived_reason text,
  changed_by uuid references public.profiles(id) on delete set null,
  changed_at timestamptz not null default now(),
  foreign key (application_id, client_id) references public.applications(id, client_id) on delete cascade,
  foreign key (step_def_id, client_id) references public.onboarding_step_defs(id, client_id) on delete cascade,
  unique (application_id, step_def_id),
  check (status <> 'Waived' or (waived_reason is not null and length(trim(waived_reason)) > 3))
);

create table public.message_templates (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  name text not null check (length(trim(name)) between 2 and 60),
  body text not null check (length(body) between 2 and 640),
  stages public.app_stage[] not null check (cardinality(stages) > 0),
  is_scheduling_link boolean not null default false,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (client_id, name)
);

create table public.step_messages (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  trigger_key text not null,
  label text not null,
  body text not null check (length(body) between 2 and 640),
  enabled boolean not null default true,
  updated_at timestamptz not null default now(),
  unique (client_id, trigger_key)
);

create table public.call_reminders (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  minutes_before integer not null check (minutes_before between 5 and 1440),
  body text not null check (length(body) between 2 and 640),
  enabled boolean not null default true,
  updated_at timestamptz not null default now(),
  unique (client_id, minutes_before)
);

create trigger candidates_updated_at before update on public.candidates for each row execute function public.set_updated_at();
create trigger applications_updated_at before update on public.applications for each row execute function public.set_updated_at();
create trigger scripts_updated_at before update on public.scripts for each row execute function public.set_updated_at();
create trigger onboarding_step_defs_updated_at before update on public.onboarding_step_defs for each row execute function public.set_updated_at();
create trigger message_templates_updated_at before update on public.message_templates for each row execute function public.set_updated_at();
create trigger step_messages_updated_at before update on public.step_messages for each row execute function public.set_updated_at();
create trigger call_reminders_updated_at before update on public.call_reminders for each row execute function public.set_updated_at();

create index applications_client_role_stage_idx on public.applications(client_id, job_role_id, stage);
create index applications_owner_idx on public.applications(owner_id);
create index applications_station_idx on public.applications(station_id);
create index applications_candidate_idx on public.applications(candidate_id);
create index messages_application_idx on public.messages(application_id, created_at);
create index calls_application_idx on public.calls(application_id, created_at);
create index call_answers_call_idx on public.call_answers(call_id);
create index call_reviews_call_idx on public.call_reviews(call_id);
create index onboarding_steps_application_idx on public.onboarding_steps(application_id);
create index stage_history_application_idx on public.stage_history(application_id);
create index consents_candidate_idx on public.consents(candidate_id);
