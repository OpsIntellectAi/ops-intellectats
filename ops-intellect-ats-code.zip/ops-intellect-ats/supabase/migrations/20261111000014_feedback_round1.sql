-- Feedback round 1 (staging):
--   * any 10-digit phone format is accepted (spaces, dashes, dots, brackets, +1)
--   * Super Admin feature toggles per client (enforced in the database where it matters)
--   * reason templates for Reject / Not interested
--   * job role facts used by the standard AI script (training location, shift, schedule)
--   * bulk AI calls (queued, spaced out, inside the calling window)
--   * live alert status for My day
--   * realtime for new texts and calls
--   * last-message details on application_rows, overview on call_rows

-- ---------- phones: digits only, 10 digits (or 11 starting with 1) ----------
create or replace function public.normalize_us_phone(p text)
returns text
language sql
immutable
set search_path = ''
as $$
  select case
    when d ~ '^[0-9]{10}$' then '+1' || d
    when d ~ '^1[0-9]{10}$' then '+' || d
    else null
  end
  from (select regexp_replace(coalesce(p, ''), '[^0-9]', '', 'g') as d) x;
$$;

-- ---------- client settings: toggles and reason templates ----------
alter table public.client_settings
  add column features jsonb not null default '{}'::jsonb check (jsonb_typeof(features) = 'object'),
  add column reject_reasons text[] not null default array[
    'Under 21 or no valid driver licence',
    'Not authorized to work in the US',
    'Not comfortable with the pay',
    'Not comfortable with the schedule or weekends',
    'Lives too far / no way to commute',
    'Failed background check',
    'Failed drug test',
    'No-show for interview or training',
    'Duplicate application'
  ],
  add column not_interested_reasons text[] not null default array[
    'Found another job',
    'Pay too low',
    'Schedule does not work',
    'Location too far',
    'Not ready to start yet',
    'Did not reply after several tries',
    'Wants a different role'
  ];

alter table public.client_settings
  add constraint reject_reasons_size check (cardinality(reject_reasons) <= 30),
  add constraint not_interested_reasons_size check (cardinality(not_interested_reasons) <= 30);

-- The list of toggles. Missing key = ON.
create or replace function public.feature_keys()
returns text[]
language sql
immutable
set search_path = ''
as $$
  select array['auto_texts', 'follow_ups', 'booking_reminders', 'ai_calls', 'bulk_ai_calls', 'phone_calls',
               'bulk_texts', 'ai_overview', 'ai_assistant', 'alerts', 'weekly_report', 'self_service',
               'message_popups', 'csv_export', 'bulk_upload'];
$$;

create or replace function private.feature_on(p_client uuid, p_key text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce((select (cs.features ->> p_key)::boolean from public.client_settings cs where cs.client_id = p_client), true);
$$;

-- Same check for signed-in users (only for clients they can open).
create or replace function public.feature_on(p_client uuid, p_key text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select public.has_client_access(p_client) and private.feature_on(p_client, p_key);
$$;
grant execute on function public.feature_on(uuid, text) to authenticated, service_role;
revoke execute on function public.feature_on(uuid, text) from public, anon;
grant execute on function public.feature_keys() to authenticated, service_role;

-- Only a Super Admin changes toggles (any update path).
create or replace function private.guard_features()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  k text;
begin
  if new.features is distinct from old.features then
    if coalesce(auth.role(), '') <> 'service_role' and not public.can('platform.admin') then
      raise exception 'Only a Super Admin can change feature toggles' using errcode = 'insufficient_privilege';
    end if;
    for k in select jsonb_object_keys(new.features) loop
      if not k = any (public.feature_keys()) or jsonb_typeof(new.features -> k) <> 'boolean' then
        raise exception 'Unknown feature toggle %', k using errcode = 'check_violation';
      end if;
    end loop;
    perform private.write_audit('Feature toggles changed', new.client_id, 'client', new.client_id::text, null,
      old.features::text, new.features::text);
  end if;
  return new;
end;
$$;
create trigger client_settings_guard_features before update of features on public.client_settings
  for each row execute function private.guard_features();

create or replace function public.set_feature(p_client uuid, p_key text, p_on boolean)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v jsonb;
begin
  if not public.can('platform.admin') then
    raise exception 'Only a Super Admin can change feature toggles' using errcode = 'insufficient_privilege';
  end if;
  if not p_key = any (public.feature_keys()) then
    raise exception 'Unknown feature toggle %', p_key using errcode = 'check_violation';
  end if;
  update public.client_settings set features = features || jsonb_build_object(p_key, p_on)
  where client_id = p_client returning features into v;
  if v is null then
    raise exception 'Client not found' using errcode = 'no_data_found';
  end if;
  return v;
end;
$$;
grant execute on function public.set_feature(uuid, text, boolean) to authenticated;
revoke execute on function public.set_feature(uuid, text, boolean) from public, anon;

-- ---------- job role facts for the standard AI script ----------
alter table public.job_roles
  add column training_location text check (training_location is null or length(training_location) <= 200),
  add column shift_text text check (shift_text is null or length(shift_text) <= 200),
  add column schedule_text text check (schedule_text is null or length(schedule_text) <= 200);

-- ---------- toggles enforced in the database ----------
create or replace function private.queue_step_text(p_application uuid, p_key text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_body text;
  v_client uuid;
begin
  select sm.body, a.client_id into v_body, v_client
  from public.step_messages sm
  join public.applications a on a.client_id = sm.client_id
  where a.id = p_application and sm.trigger_key = p_key and sm.enabled;
  if v_body is null then
    return;
  end if;
  if not private.feature_on(v_client, case when p_key like 'follow_up%' then 'follow_ups' else 'auto_texts' end) then
    return;
  end if;
  perform public.queue_text(p_application, v_body, true, null);
end;
$$;

create or replace function public.run_cadence(p_now timestamptz default now())
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  r record;
  n_first integer := 0;
  n_day2 integer := 0;
  n_day5 integer := 0;
  n_none integer := 0;
  v_body text;
begin
  if coalesce((select enabled from public.feature_flags where key = 'emergency_stop'), false) then
    return jsonb_build_object('skipped', 'emergency_stop');
  end if;

  -- First text, at the client's set time in the candidate's local time.
  for r in
    select a.id, a.client_id, a.applied_at, public.candidate_tz(a.id) as tz,
           cs.auto_text_time, cs.quiet_start, cs.quiet_end
    from public.applications a
    join public.candidates c on c.id = a.candidate_id
    join public.client_settings cs on cs.client_id = a.client_id
    where a.stage = 'interview' and a.first_text_at is null and c.opted_out_at is null
      and a.applied_at > p_now - interval '3 days'
      and private.feature_on(a.client_id, 'auto_texts')
      and not exists (select 1 from public.messages m where m.application_id = a.id and m.direction = 'outbound')
  loop
    if p_now >= public.first_text_due(r.tz, r.auto_text_time, r.quiet_start, r.quiet_end, r.applied_at) then
      select sm.body into v_body from public.step_messages sm
      where sm.client_id = r.client_id and sm.trigger_key = 'first_text' and sm.enabled;
      if v_body is not null and (public.queue_text(r.id, v_body, true) ->> 'message_id') is not null then
        update public.applications set first_text_at = p_now, cadence_step = 0 where id = r.id;
        n_first := n_first + 1;
      end if;
    end if;
  end loop;

  -- Day 2 follow-up, Day 5 final text, Day 7 "No response". Any reply stops this.
  for r in
    select a.id, a.client_id, a.cadence_step, a.first_text_at
    from public.applications a
    join public.candidates c on c.id = a.candidate_id
    where a.stage = 'interview' and a.first_text_at is not null and a.cadence_step < 3
      and a.no_response_at is null and c.opted_out_at is null
      and private.feature_on(a.client_id, 'follow_ups')
      and not exists (select 1 from public.messages m
                      where m.application_id = a.id and m.direction = 'inbound' and m.created_at >= a.first_text_at)
  loop
    if r.cadence_step = 0 and p_now >= r.first_text_at + interval '2 days' then
      perform private.queue_step_text(r.id, 'follow_up_day2');
      update public.applications set cadence_step = 1 where id = r.id;
      n_day2 := n_day2 + 1;
    elsif r.cadence_step = 1 and p_now >= r.first_text_at + interval '5 days' then
      perform private.queue_step_text(r.id, 'follow_up_day5');
      update public.applications set cadence_step = 2 where id = r.id;
      n_day5 := n_day5 + 1;
    elsif r.cadence_step = 2 and p_now >= r.first_text_at + interval '7 days' then
      update public.applications set cadence_step = 3, no_response_at = p_now where id = r.id;
      update public.job_queue set status = 'cancelled', updated_at = now()
      where status = 'queued' and kind = 'ai_call' and payload ->> 'application_id' = r.id::text;
      perform private.write_audit('Marked No response', r.client_id, 'application', r.id::text, null, null, 'No reply after 7 days');
      n_none := n_none + 1;
    end if;
  end loop;

  return jsonb_build_object('first', n_first, 'day2', n_day2, 'day5', n_day5, 'no_response', n_none);
end;
$$;

create or replace function private.plan_booking_jobs()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  r record;
begin
  if new.booked_call_at is not distinct from old.booked_call_at then
    return new;
  end if;
  update public.job_queue set status = 'cancelled', updated_at = now()
  where status = 'queued' and kind in ('call_reminder', 'ai_call')
    and payload ->> 'application_id' = new.id::text and coalesce(payload ->> 'booked', 'false') = 'true';
  if new.booked_call_at is null or new.booked_call_at <= now() then
    return new;
  end if;
  new.reschedule_requested_at := null;
  if private.feature_on(new.client_id, 'booking_reminders') then
    for r in select * from public.call_reminders cr where cr.client_id = new.client_id and cr.enabled loop
      if new.booked_call_at - make_interval(mins => r.minutes_before) > now() then
        insert into public.job_queue (client_id, kind, payload, run_at)
        values (new.client_id, 'call_reminder',
                jsonb_build_object('application_id', new.id, 'reminder_id', r.id, 'booked', true,
                                   'booked_at', new.booked_call_at, 'automatic', true),
                new.booked_call_at - make_interval(mins => r.minutes_before));
      end if;
    end loop;
  end if;
  insert into public.job_queue (client_id, kind, payload, run_at)
  values (new.client_id, 'ai_call', jsonb_build_object('application_id', new.id, 'booked', true, 'automatic', true),
          new.booked_call_at);
  return new;
end;
$$;

create or replace function public.ai_call_check(p_application uuid, p_automatic boolean default false)
returns text
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  a record;
  v_today integer;
  v_total integer;
begin
  select ap.id, ap.client_id, ap.candidate_id, ap.stage, ap.job_role_id, ap.no_response_at, ap.not_interested_until,
         c.opted_out_at, c.lives_in_nyc, coalesce(cs.aedt_enabled, false) as aedt,
         coalesce(cs.max_ai_attempts_per_day, 2) as per_day, coalesce(cs.max_ai_attempts_total, 4) as total,
         public.candidate_tz(ap.id) as tz
    into a
  from public.applications ap
  join public.candidates c on c.id = ap.candidate_id
  left join public.client_settings cs on cs.client_id = ap.client_id
  where ap.id = p_application;
  if a.id is null then return 'Candidate not found'; end if;
  if not private.feature_on(a.client_id, 'ai_calls') then return 'AI calls are turned off for this client'; end if;
  if a.opted_out_at is not null then return 'Opted out (STOP)'; end if;
  if not public.has_active_consent(a.candidate_id, 'ai_call') then return 'No AI-call consent on file'; end if;
  if a.stage <> 'interview' then return 'AI interviews are for the Interview stage'; end if;
  if p_automatic and coalesce((select enabled from public.feature_flags where key = 'emergency_stop'), false) then
    return 'Emergency stop is on';
  end if;
  if p_automatic and a.no_response_at is not null then return 'Marked No response'; end if;
  if a.not_interested_until is not null and a.not_interested_until > current_date then return 'Not interested for now'; end if;
  if not exists (select 1 from public.scripts s where s.job_role_id = a.job_role_id and s.current_version_id is not null) then
    return 'No published AI script for this job role';
  end if;
  if exists (select 1 from public.calls k where k.application_id = a.id and k.outcome in ('queued', 'in_progress')
             and k.created_at > now() - interval '30 minutes') then
    return 'A call is already in progress';
  end if;
  if a.lives_in_nyc and a.aedt and not exists (
    select 1 from public.aedt_notices n where n.candidate_id = a.candidate_id
      and n.sent_at <= now() - interval '14 days' and not n.asked_for_person) then
    return 'NYC: AI-use notice must go out 10 business days before an AI interview';
  end if;
  select count(*) filter (where (coalesce(k.started_at, k.created_at) at time zone a.tz)::date = (now() at time zone a.tz)::date),
         count(*)
    into v_today, v_total
  from public.calls k where k.application_id = a.id and k.via = 'ai';
  if v_total >= a.total then return 'All AI call attempts used; call them yourself'; end if;
  if v_today >= a.per_day then return 'Daily AI call attempts used; next try tomorrow'; end if;
  return null;
end;
$$;

create or replace function public.evaluate_alerts(p_now timestamptz default now())
returns table (client_id uuid, message text, channel public.alert_channel, phones text[], emails text[])
language plpgsql
security definer
set search_path = ''
as $$
declare
  r record;
  v numeric;
  v_msg text;
  v_hit boolean;
  v_phones text[];
  v_emails text[];
begin
  for r in
    select ar.*, cl.name as client_name from public.alert_rules ar join public.clients cl on cl.id = ar.client_id
    where ar.enabled and private.feature_on(ar.client_id, 'alerts')
  loop
    v := private.alert_metric(r.client_id, r.rule_key, p_now);
    continue when v is null;
    v_hit := case when r.rule_key = 'answer_rate' then v < r.threshold else v >= r.threshold end;
    continue when not v_hit;
    continue when exists (select 1 from public.alert_log l where l.rule_id = r.id and not l.is_test
                          and l.created_at > p_now - interval '6 hours');
    v_msg := r.client_name || ': ' || case r.rule_key
      when 'answer_rate' then 'AI call answer rate today is ' || v || '% (alert below ' || r.threshold || '%)'
      when 'unreviewed_calls' then v || ' AI calls not reviewed for 24 hours'
      when 'shortlisted_no_reply' then v || ' shortlisted candidates with no reply for 2+ days'
      when 'onboarding_stuck' then v || ' people stuck in onboarding over 24 h'
      else 'hiring is ' || v || ' behind target pace' end;
    select coalesce(array_agg(distinct p.phone_e164) filter (where p.phone_e164 is not null), '{}'),
           coalesce(array_agg(distinct p.email) filter (where p.email is not null), '{}')
      into v_phones, v_emails
    from public.profiles p
    join public.user_client_access u on u.user_id = p.id and u.client_id = r.client_id
    where p.role = 'supervisor' and p.status = 'active';
    insert into public.alert_log (client_id, rule_id, message, sent_to, channel)
    values (r.client_id, r.id, v_msg,
            coalesce(nullif(array_to_string(v_emails || v_phones, ', '), ''), 'no supervisor on this client'), r.channel);
    client_id := r.client_id; message := v_msg; channel := r.channel; phones := v_phones; emails := v_emails;
    return next;
  end loop;
end;
$$;

create or replace function public.weekly_reports()
returns setof jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select private.weekly_report_html(c.id) from public.clients c where private.feature_on(c.id, 'weekly_report');
$$;

-- ---------- live alert status for My day ----------
-- Every enabled rule that is over its line right now, who it goes to, and when it was last sent.
create or replace function public.alert_status(p_client uuid)
returns table (rule_id uuid, rule_key text, label text, threshold numeric, current_value numeric,
               channel public.alert_channel, recipients text, last_sent_at timestamptz)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  r record;
  v numeric;
begin
  if not public.has_client_access(p_client) or not public.can('view') then
    raise exception 'No access to this client' using errcode = 'insufficient_privilege';
  end if;
  if not private.feature_on(p_client, 'alerts') then
    return;
  end if;
  for r in select * from public.alert_rules ar where ar.client_id = p_client and ar.enabled order by ar.rule_key loop
    v := private.alert_metric(p_client, r.rule_key, now());
    continue when v is null;
    continue when not (case when r.rule_key = 'answer_rate' then v < r.threshold else v >= r.threshold end);
    rule_id := r.id; rule_key := r.rule_key; label := r.label; threshold := r.threshold; current_value := v;
    channel := r.channel;
    select coalesce(nullif(string_agg(distinct p.full_name, ', '), ''), 'no Supervisor on this client') into recipients
    from public.profiles p
    join public.user_client_access u on u.user_id = p.id and u.client_id = p_client
    where p.role = 'supervisor' and p.status = 'active';
    select max(l.created_at) into last_sent_at from public.alert_log l where l.rule_id = r.id and not l.is_test;
    return next;
  end loop;
end;
$$;
grant execute on function public.alert_status(uuid) to authenticated;
revoke execute on function public.alert_status(uuid) from public, anon;

-- ---------- bulk AI calls ----------
-- Queues one AI call per eligible candidate, spaced 30 s apart, inside the client's calling
-- window (candidate local time). Skipped candidates come back with the reason.
create or replace function public.queue_ai_calls(p_applications uuid[])
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_id uuid;
  a record;
  v_reason text;
  v_skipped jsonb := '[]'::jsonb;
  v_queued integer := 0;
  v_client uuid;
  v_at timestamptz;
begin
  if not public.can('candidates.act') then
    raise exception 'Your access level cannot start AI calls' using errcode = 'insufficient_privilege';
  end if;
  if p_applications is null or cardinality(p_applications) = 0 then
    raise exception 'Choose at least one candidate' using errcode = 'check_violation';
  end if;
  if cardinality(p_applications) > 500 then
    raise exception 'At most 500 AI calls at a time' using errcode = 'check_violation';
  end if;
  foreach v_id in array p_applications loop
    if not public.app_id_visible(v_id) then
      v_skipped := v_skipped || jsonb_build_object('id', v_id, 'name', null, 'reason', 'Not in your scope');
      continue;
    end if;
    select ap.id, ap.client_id, c.full_name, public.candidate_tz(ap.id) as tz,
           coalesce(cs.best_call_start, '10:00') as bs, coalesce(cs.best_call_end, '18:00') as be
      into a
    from public.applications ap
    join public.candidates c on c.id = ap.candidate_id
    left join public.client_settings cs on cs.client_id = ap.client_id
    where ap.id = v_id;
    if v_client is null then
      v_client := a.client_id;
    elsif v_client <> a.client_id then
      raise exception 'All candidates must be in the same client' using errcode = 'check_violation';
    end if;
    if not private.feature_on(a.client_id, 'bulk_ai_calls') then
      raise exception 'Bulk AI calls are turned off for this client' using errcode = 'check_violation';
    end if;
    v_reason := public.ai_call_check(v_id, false);
    if v_reason is null and exists (select 1 from public.job_queue j where j.status = 'queued' and j.kind = 'ai_call'
                                    and j.payload ->> 'application_id' = v_id::text) then
      v_reason := 'An AI call is already queued';
    end if;
    if v_reason is not null then
      v_skipped := v_skipped || jsonb_build_object('id', v_id, 'name', a.full_name, 'reason', v_reason);
      continue;
    end if;
    v_at := public.next_call_time(a.tz, a.bs, a.be, now()) + make_interval(secs => v_queued * 30);
    insert into public.job_queue (client_id, kind, payload, run_at)
    values (a.client_id, 'ai_call', jsonb_build_object('application_id', v_id, 'bulk', true, 'requested_by', auth.uid()), v_at);
    v_queued := v_queued + 1;
  end loop;
  if v_client is not null then
    perform private.write_audit('Bulk AI calls queued', v_client, 'client', v_client::text, null, null,
      v_queued || ' queued, ' || jsonb_array_length(v_skipped) || ' skipped', v_queued > 30,
      case when v_queued > 30 then 'Bulk action over 30 candidates' end);
  end if;
  return jsonb_build_object('queued', v_queued, 'skipped', v_skipped);
end;
$$;
grant execute on function public.queue_ai_calls(uuid[]) to authenticated;
revoke execute on function public.queue_ai_calls(uuid[]) from public, anon;

-- Queued AI calls per application (for the "Queued" chip in the candidate list).
create or replace function public.queued_ai_calls(p_client uuid)
returns table (application_id uuid, run_at timestamptz)
language sql
stable
security definer
set search_path = ''
as $$
  select (j.payload ->> 'application_id')::uuid, min(j.run_at)
  from public.job_queue j
  where j.client_id = p_client and j.kind = 'ai_call' and j.status = 'queued'
    and public.has_client_access(p_client)
    and public.app_id_visible((j.payload ->> 'application_id')::uuid)
  group by 1;
$$;
grant execute on function public.queued_ai_calls(uuid) to authenticated;
revoke execute on function public.queued_ai_calls(uuid) from public, anon;

-- ---------- views: last message details, call overview ----------
-- New columns are added at the end, so the view is replaced in place (nothing dropped).
create or replace view public.application_rows with (security_invoker = true) as
select
  a.id, a.client_id, a.candidate_id, a.station_id, a.job_role_id, a.stage, a.owner_id, a.source,
  a.applied_at, a.stage_changed_at, a.not_interested_reason, a.not_interested_until, a.rejection_reason,
  a.booked_call_at,
  c.full_name, c.phone_e164, c.email, c.city, c.zip, c.time_zone, c.opted_out_at, c.is_landline, c.lives_in_nyc,
  m.last_out_at, m.last_in_at, coalesce(m.out_count, 0) as out_count, coalesce(m.in_count, 0) as in_count,
  m.last_body,
  (select mm.topics from public.messages mm
     where mm.application_id = a.id and mm.direction = 'inbound' order by mm.created_at desc limit 1) as last_topics,
  coalesce(k.ai_calls, 0) as ai_calls,
  coalesce(k.completed_ai_calls, 0) as completed_ai_calls,
  k.last_call_at, k.last_call_outcome,
  coalesce(k.unreviewed_calls, 0) as unreviewed_calls,
  (select count(*) from public.call_answers x join public.calls y on y.id = x.call_id
     where y.application_id = a.id and x.result = 'needs_review' and x.reviewed_at is null) as answers_to_review,
  coalesce(o.steps_total, 0) as steps_total,
  coalesce(o.steps_done, 0) as steps_done,
  coalesce(o.required_left, 0) as required_left,
  o.last_step_change,
  a.said_yes_at, a.no_response_at, a.manual_call_needed, a.reschedule_requested_at, a.cadence_step,
  m.last_direction, m.last_status, m.last_is_automatic, m.last_at,
  k.last_call_via, k.last_call_summary
from public.applications a
join public.candidates c on c.id = a.candidate_id
left join lateral (
  select
    max(mx.created_at) filter (where mx.direction = 'outbound') as last_out_at,
    max(mx.created_at) filter (where mx.direction = 'inbound') as last_in_at,
    count(*) filter (where mx.direction = 'outbound') as out_count,
    count(*) filter (where mx.direction = 'inbound') as in_count,
    (array_agg(mx.body order by mx.created_at desc))[1] as last_body,
    (array_agg(mx.direction order by mx.created_at desc))[1] as last_direction,
    (array_agg(mx.status order by mx.created_at desc))[1] as last_status,
    (array_agg(mx.is_automatic order by mx.created_at desc))[1] as last_is_automatic,
    max(mx.created_at) as last_at
  from public.messages mx where mx.application_id = a.id
) m on true
left join lateral (
  select
    count(*) filter (where cl.via = 'ai') as ai_calls,
    count(*) filter (where cl.via = 'ai' and cl.outcome = 'completed') as completed_ai_calls,
    max(coalesce(cl.started_at, cl.created_at)) as last_call_at,
    (array_agg(cl.outcome order by coalesce(cl.started_at, cl.created_at) desc))[1] as last_call_outcome,
    (array_agg(cl.via order by coalesce(cl.started_at, cl.created_at) desc))[1] as last_call_via,
    (array_agg(cl.summary order by coalesce(cl.started_at, cl.created_at) desc))[1] as last_call_summary,
    count(*) filter (where cl.via = 'ai' and cl.outcome = 'completed'
      and not exists (select 1 from public.call_reviews r where r.call_id = cl.id)) as unreviewed_calls
  from public.calls cl where cl.application_id = a.id
) k on true
left join lateral (
  select
    count(*) as steps_total,
    count(*) filter (where s.status = any (d.done_statuses) or s.status = 'Waived') as steps_done,
    count(*) filter (where d.required and not (s.status = any (d.done_statuses) or s.status = 'Waived')) as required_left,
    max(s.changed_at) as last_step_change
  from public.onboarding_steps s join public.onboarding_step_defs d on d.id = s.step_def_id
  where s.application_id = a.id
) o on true;

revoke all on public.application_rows from anon;
grant select on public.application_rows to authenticated;

create or replace view public.call_rows with (security_invoker = true) as
select
  cl.id, cl.client_id, cl.application_id, cl.provider, cl.direction, cl.via, cl.outcome, cl.duration_seconds,
  cl.recording_path, cl.script_version_id, cl.attempt_number, cl.placed_by, cl.started_at, cl.ended_at, cl.created_at,
  a.job_role_id, a.station_id, a.owner_id, a.stage,
  c.full_name, c.phone_e164,
  (select count(*) from public.call_answers x where x.call_id = cl.id and x.result = 'needs_review' and x.reviewed_at is null) as answers_to_review,
  (select r.verdict from public.call_reviews r where r.call_id = cl.id order by r.created_at desc limit 1) as review_verdict,
  (select r.reason from public.call_reviews r where r.call_id = cl.id order by r.created_at desc limit 1) as review_reason,
  cl.summary
from public.calls cl
join public.applications a on a.id = cl.application_id
join public.candidates c on c.id = a.candidate_id;
revoke all on public.call_rows from anon;
grant select on public.call_rows to authenticated;

-- ---------- realtime: new texts and call results reach open screens at once (RLS still applies) ----------
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'messages') then
      alter publication supabase_realtime add table public.messages;
    end if;
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and tablename = 'calls') then
      alter publication supabase_realtime add table public.calls;
    end if;
  end if;
end;
$$;

-- ---------- create_call: also hands over the job facts that fill the standard script ----------
create or replace function public.create_call(p_application uuid, p_via public.call_via, p_provider text, p_placed_by uuid default null)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  a record;
  v_version uuid;
  v_tree jsonb;
  v_rules jsonb;
  v_attempt integer;
  v_call uuid;
begin
  select ap.id, ap.client_id, ap.job_role_id, c.full_name, c.phone_e164, j.name as role_name, cl.name as client_name,
         j.pay_text, s.address, j.training_location, j.shift_text, coalesce(j.schedule_text, j.days_per_week) as schedule_text,
         j.min_age
    into a
  from public.applications ap
  join public.candidates c on c.id = ap.candidate_id
  join public.job_roles j on j.id = ap.job_role_id
  join public.stations s on s.id = ap.station_id
  join public.clients cl on cl.id = ap.client_id
  where ap.id = p_application;
  if a.id is null then
    raise exception 'Candidate not found' using errcode = 'no_data_found';
  end if;
  select sc.current_version_id, v.question_tree, v.global_rules into v_version, v_tree, v_rules
  from public.scripts sc join public.script_versions v on v.id = sc.current_version_id
  where sc.job_role_id = a.job_role_id;
  select count(*) + 1 into v_attempt from public.calls k where k.application_id = p_application and k.via = p_via;
  insert into public.calls (application_id, client_id, provider, direction, via, outcome, script_version_id,
                            attempt_number, placed_by, started_at)
  values (p_application, a.client_id, p_provider, 'outbound', p_via, 'queued',
          case when p_via = 'ai' then v_version end, v_attempt, p_placed_by, now())
  returning id into v_call;
  perform private.write_audit(case when p_via = 'ai' then 'AI call started' else 'Phone call started' end,
    a.client_id, 'application', p_application::text, a.full_name, null, 'attempt ' || v_attempt);
  return jsonb_build_object(
    'call_id', v_call, 'attempt', v_attempt, 'to', a.phone_e164, 'first_name', split_part(a.full_name, ' ', 1),
    'role', a.role_name, 'client', a.client_name, 'pay', a.pay_text, 'address', a.address,
    'training_location', a.training_location, 'shift_text', a.shift_text, 'schedule_text', a.schedule_text,
    'min_age', a.min_age,
    'script_version_id', v_version, 'questions', coalesce(v_tree, '[]'::jsonb), 'rules', coalesce(v_rules, '[]'::jsonb));
end;
$$;
