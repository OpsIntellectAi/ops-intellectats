-- 0015 · Faster access checks.
-- Every RLS check calls auth_user_role(), which looks up the sign-in session and parses the
-- login token. One candidates list made hundreds of those calls (287 ms for 8 rows on staging).
-- The answer cannot change inside one request, so it is now worked out once per request
-- (per transaction) and reused. The cache is keyed by the full login claims and the
-- transaction start time, and is local to the transaction, so it never leaks between requests
-- or between users. The rules themselves are unchanged.

create or replace function public.auth_user_role()
returns public.app_role
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  k text := coalesce(current_setting('request.jwt.claims', true), '') || '|' || now()::text;
  c text := coalesce(current_setting('oi.auth_role_cache', true), '');
  sep int := strpos(c, chr(31));
  r public.app_role;
begin
  if sep > 0 and left(c, sep - 1) = k then
    return nullif(substr(c, sep + 1), '')::public.app_role;
  end if;

  select p.role into r
  from public.profiles p
  where p.id = auth.uid()
    and p.status = 'active'
    and private.session_ok()
    and (p.role not in ('admin', 'super_admin') or coalesce(auth.jwt() ->> 'aal', 'aal1') = 'aal2');

  perform set_config('oi.auth_role_cache', k || chr(31) || coalesce(r::text, ''), true);
  return r;
end;
$$;

-- A role or status change takes effect in the same request too (tests and admin screens).
create or replace function private.clear_role_cache()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform set_config('oi.auth_role_cache', '', true);
  return null;
end;
$$;

drop trigger if exists clear_role_cache on public.profiles;
create trigger clear_role_cache
after insert or update of role, status or delete on public.profiles
for each statement execute function private.clear_role_cache();

-- Policies: wrap checks that do not depend on the row in (select …) so Postgres runs them
-- once per query instead of once per row (Supabase lint "auth_rls_initplan"). Same rules.
alter policy ai_assistant_log_select on public.ai_assistant_log
  using (((user_id = (select auth.uid())) and ((select public.auth_user_role()) is not null)) or (select public.is_super_admin()));
alter policy bug_reports_insert on public.bug_reports
  with check ((reporter_id = (select auth.uid())) and ((select public.auth_user_role()) is not null) and ((client_id is null) or public.has_client_access(client_id)));
alter policy bug_reports_select on public.bug_reports
  using (((reporter_id = (select auth.uid())) and ((select public.auth_user_role()) is not null)) or (select public.can('audit.view_all')));
alter policy call_reviews_insert on public.call_reviews
  with check ((select public.can('calls.review')) and (reviewer_id = (select auth.uid())) and public.call_visible(call_id));
alter policy devices_select on public.devices
  using (((user_id = (select auth.uid())) and ((select public.auth_user_role()) is not null)) or (select public.is_super_admin()) or ((select public.can('audit.view_all')) and public.shares_client_with(user_id)));
alter policy profiles_select_invited on public.profiles
  using ((invited_by = (select auth.uid())) and (select public.can('users.manage')));
alter policy profiles_select_self on public.profiles
  using (id = (select auth.uid()));
alter policy saved_views_delete on public.saved_views
  using (public.has_client_access(client_id) and ((owner_id = (select auth.uid())) or (select public.is_super_admin())));
alter policy saved_views_insert on public.saved_views
  with check ((owner_id = (select auth.uid())) and public.has_client_access(client_id));
alter policy saved_views_select on public.saved_views
  using (public.has_client_access(client_id) and ((owner_id = (select auth.uid())) or shared));
alter policy saved_views_update on public.saved_views
  using ((owner_id = (select auth.uid())) and public.has_client_access(client_id))
  with check ((owner_id = (select auth.uid())) and public.has_client_access(client_id));
alter policy teams_select on public.teams
  using (((select public.auth_user_role()) is not null) and ((supervisor_id = (select auth.uid())) or (csr_id = (select auth.uid())) or (select public.can('users.manage'))));
alter policy uca_select on public.user_client_access
  using ((user_id = (select auth.uid())) or ((select public.can('users.manage')) and public.has_client_access(client_id)));
