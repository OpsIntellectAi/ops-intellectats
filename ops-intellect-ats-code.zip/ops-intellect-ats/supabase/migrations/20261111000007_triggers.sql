-- 0007 · Triggers: append-only activity log, automatic audit rows, stage rules, new users

-- ---------- activity log writer ----------
create or replace function private.safe_inet(p text)
returns inet
language plpgsql
immutable
set search_path = ''
as $$
begin
  return trim(split_part(p, ',', 1))::inet;
exception when others then
  return null;
end;
$$;

create or replace function private.write_audit(
  p_action text,
  p_client uuid,
  p_target_type text,
  p_target_id text,
  p_target_label text,
  p_before text,
  p_after text,
  p_flagged boolean default false,
  p_flag_reason text default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.audit_log (
    actor_id, actor_role, client_id, action, target_type, target_id, target_label,
    before_value, after_value, device_key, ip, user_agent, flagged, flag_reason
  )
  values (
    auth.uid(),
    (select p.role from public.profiles p where p.id = auth.uid()),
    p_client, p_action, p_target_type, p_target_id, p_target_label,
    left(p_before, 2000), left(p_after, 2000),
    private.req_header('x-device-id'),
    private.safe_inet(private.req_header('x-forwarded-for')),
    left(private.req_header('user-agent'), 400),
    p_flagged, p_flag_reason
  );
end;
$$;

-- The activity log can never be changed or deleted, by anyone.
create or replace function private.block_audit_change()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  raise exception 'audit_log is append-only: % is not allowed', tg_op
    using errcode = 'insufficient_privilege';
end;
$$;

create trigger audit_log_no_update before update or delete on public.audit_log
  for each row execute function private.block_audit_change();
create trigger audit_log_no_truncate before truncate on public.audit_log
  for each statement execute function private.block_audit_change();

-- Generic audit for settings-type tables: records the whole row before → after.
create or replace function private.audit_row_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_client uuid;
  v_id text;
begin
  if tg_op = 'DELETE' then
    v_client := case when to_jsonb(old) ? 'client_id' then (to_jsonb(old) ->> 'client_id')::uuid end;
    v_id := coalesce(to_jsonb(old) ->> 'id', to_jsonb(old) ->> 'key', to_jsonb(old) ->> 'client_id');
    perform private.write_audit(tg_table_name || ' deleted', v_client, tg_table_name, v_id, null, to_jsonb(old)::text, null);
    return old;
  end if;
  v_client := case when to_jsonb(new) ? 'client_id' then (to_jsonb(new) ->> 'client_id')::uuid end;
  if tg_table_name = 'clients' then
    v_client := new.id;
  end if;
  v_id := coalesce(to_jsonb(new) ->> 'id', to_jsonb(new) ->> 'key', to_jsonb(new) ->> 'client_id');
  if tg_op = 'INSERT' then
    perform private.write_audit(tg_table_name || ' added', v_client, tg_table_name, v_id, null, null, to_jsonb(new)::text);
  elsif to_jsonb(new) - 'updated_at' is distinct from to_jsonb(old) - 'updated_at' then
    perform private.write_audit(tg_table_name || ' changed', v_client, tg_table_name, v_id, null, to_jsonb(old)::text, to_jsonb(new)::text);
  end if;
  return new;
end;
$$;

do $$
declare t text;
begin
  foreach t in array array[
    'clients', 'client_settings', 'stations', 'job_roles', 'feature_flags', 'teams',
    'message_templates', 'step_messages', 'call_reminders', 'alert_rules', 'hiring_targets',
    'onboarding_step_defs', 'scripts', 'script_versions', 'devices'
  ] loop
    execute format(
      'create trigger %I after insert or update or delete on public.%I for each row execute function private.audit_row_change()',
      t || '_audit', t
    );
  end loop;
end $$;

-- ---------- access changes ----------
create or replace function private.audit_access_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  r record;
  who text;
begin
  r := case when tg_op = 'DELETE' then old else new end;
  select coalesce(nullif(p.full_name, ''), p.email) into who from public.profiles p where p.id = r.user_id;
  perform private.write_audit(
    case tg_op when 'INSERT' then 'Client access given' when 'DELETE' then 'Client access removed' else 'Client access changed' end,
    r.client_id, 'user', r.user_id::text, who,
    case when tg_op <> 'INSERT' then coalesce(array_to_string(old.station_ids, ','), 'all stations') end,
    case when tg_op <> 'DELETE' then coalesce(array_to_string(new.station_ids, ','), 'all stations') end
  );
  return r;
end;
$$;

create trigger user_client_access_audit after insert or update or delete on public.user_client_access
  for each row execute function private.audit_access_change();

create or replace function private.audit_profile_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.role is distinct from old.role then
    perform private.write_audit('User level changed', null, 'user', new.id::text, new.full_name, old.role::text, new.role::text,
      new.role in ('admin', 'super_admin'), case when new.role in ('admin', 'super_admin') then 'Admin-level access granted' end);
  end if;
  if new.status is distinct from old.status then
    perform private.write_audit('User status changed', null, 'user', new.id::text, new.full_name, old.status::text, new.status::text);
  end if;
  return new;
end;
$$;

create trigger profiles_audit after update on public.profiles
  for each row execute function private.audit_profile_change();

-- ---------- stages ----------
create or replace function private.check_stage_rules()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  missing text;
begin
  -- Field-level rules for people (the service role / Edge Functions have auth.uid() = null).
  if auth.uid() is not null then
    if new.client_id <> old.client_id or new.candidate_id <> old.candidate_id
       or new.station_id <> old.station_id or new.job_role_id <> old.job_role_id then
      raise exception 'Client, candidate, station and job role cannot be changed' using errcode = 'insufficient_privilege';
    end if;
    if new.owner_id is distinct from old.owner_id and not public.can('candidates.assign') then
      raise exception 'Your access level cannot assign candidates' using errcode = 'insufficient_privilege';
    end if;
    if new.stage is distinct from old.stage and not public.can('candidates.act')
       and not (public.can('onboarding.update') and new.stage in ('onboarding', 'hired')) then
      raise exception 'Your access level cannot move candidates to this stage' using errcode = 'insufficient_privilege';
    end if;
  end if;

  if new.stage is distinct from old.stage then
    new.stage_changed_at := now();

    -- Shortlist needs a completed interview and no answer still waiting for a person.
    if new.stage = 'shortlisted' and old.stage = 'interview' then
      if not exists (
        select 1 from public.calls c
        where c.application_id = new.id and c.outcome = 'completed' and c.via = 'ai'
      ) then
        raise exception 'Cannot shortlist: no completed AI interview' using errcode = 'check_violation';
      end if;
      if exists (
        select 1 from public.call_answers a
        join public.calls c on c.id = a.call_id
        where c.application_id = new.id and a.result = 'needs_review' and a.reviewed_at is null
      ) then
        raise exception 'Cannot shortlist: an answer still needs review' using errcode = 'check_violation';
      end if;
    end if;

    -- Hired only when every required onboarding step is done (or waived with a reason).
    if new.stage = 'hired' then
      select string_agg(d.name, ', ' order by d.sort_order) into missing
      from public.onboarding_step_defs d
      left join public.onboarding_steps s on s.step_def_id = d.id and s.application_id = new.id
      where d.client_id = new.client_id and d.required
        and (s.id is null or not (s.status = any (d.done_statuses) or s.status = 'Waived'));
      if missing is not null then
        raise exception 'Cannot mark hired: required steps not done: %', missing using errcode = 'check_violation';
      end if;
    end if;

    if new.stage = 'not_interested' and new.not_interested_reason is null then
      raise exception 'A reason is required for Not interested' using errcode = 'check_violation';
    end if;
  end if;
  return new;
end;
$$;

create trigger applications_stage_rules before update on public.applications
  for each row execute function private.check_stage_rules();

create or replace function private.record_stage_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  who text;
begin
  select c.full_name into who from public.candidates c where c.id = new.candidate_id;
  if tg_op = 'INSERT' then
    insert into public.stage_history (application_id, client_id, from_stage, to_stage, changed_by, note)
    values (new.id, new.client_id, null, new.stage, auth.uid(), 'Applied · ' || new.source);
    perform private.write_audit('Applicant added', new.client_id, 'application', new.id::text, who, null, new.stage::text);
  else
    if new.stage is distinct from old.stage then
      insert into public.stage_history (application_id, client_id, from_stage, to_stage, changed_by)
      values (new.id, new.client_id, old.stage, new.stage, auth.uid());
      perform private.write_audit('Stage changed', new.client_id, 'application', new.id::text, who, old.stage::text, new.stage::text);
    end if;
    if new.owner_id is distinct from old.owner_id then
      perform private.write_audit('Candidate assigned', new.client_id, 'application', new.id::text, who,
        coalesce(old.owner_id::text, 'nobody'), coalesce(new.owner_id::text, 'nobody'));
    end if;
  end if;
  return new;
end;
$$;

create trigger applications_history after insert or update on public.applications
  for each row execute function private.record_stage_change();

create or replace function private.audit_onboarding_step()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  step text;
begin
  select d.name into step from public.onboarding_step_defs d where d.id = new.step_def_id;
  if tg_op = 'INSERT' or new.status is distinct from old.status or new.note is distinct from old.note then
    perform private.write_audit('Onboarding step', new.client_id, 'application', new.application_id::text, step,
      case when tg_op = 'UPDATE' then old.status end, new.status);
  end if;
  return new;
end;
$$;

create or replace function private.stamp_onboarding_step()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.changed_at := now();
  new.changed_by := coalesce(auth.uid(), new.changed_by);
  return new;
end;
$$;

create trigger onboarding_steps_stamp before insert or update on public.onboarding_steps
  for each row execute function private.stamp_onboarding_step();
create trigger onboarding_steps_audit after insert or update on public.onboarding_steps
  for each row execute function private.audit_onboarding_step();

-- ---------- new sign-ups start with no access ----------
create or replace function private.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, email, full_name, role, status)
  values (
    new.id,
    lower(new.email),
    coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name', ''),
    'viewer',
    'pending'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function private.handle_new_user();
