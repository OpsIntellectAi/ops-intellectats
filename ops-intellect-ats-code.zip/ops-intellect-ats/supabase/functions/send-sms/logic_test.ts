import { assertEquals } from '../_shared/testing.ts';
import { bulkCheck, SendSmsBody, uniqueIds } from './logic.ts';
import { smsGate, type SmsRow } from '../_shared/dispatch.ts';

Deno.test('bulk over 30 needs confirmation and is flagged', () => {
  assertEquals(bulkCheck(30, false), { ok: true, flagged: false });
  assertEquals(bulkCheck(31, false), { ok: false, flagged: true });
  assertEquals(bulkCheck(31, true), { ok: true, flagged: true });
});

Deno.test('input validation', () => {
  assertEquals(SendSmsBody.safeParse({ applicationIds: [], body: 'hi there' }).success, false);
  assertEquals(SendSmsBody.safeParse({ applicationIds: [crypto.randomUUID()], body: 'x' }).success, false);
  assertEquals(SendSmsBody.safeParse({ applicationIds: ['not-a-uuid'], body: 'hello' }).success, false);
  assertEquals(SendSmsBody.safeParse({ applicationIds: [crypto.randomUUID()], body: 'a'.repeat(641) }).success, false);
  assertEquals(SendSmsBody.safeParse({ applicationIds: [crypto.randomUUID()], body: 'Hello there' }).success, true);
});

Deno.test('duplicate ids count once', () => {
  const a = crypto.randomUUID();
  assertEquals(uniqueIds([a, a.toUpperCase()]).length, 1);
});

const base: SmsRow = {
  message_id: 'm', status: 'queued', body: 'hi', is_automatic: false, to: '+12025550101', opted_out: false,
  client_id: 'c', client_live: false, messaging_service_sid: null, a2p_status: 'not_started',
  environment: 'staging', allow_listed: true,
};

Deno.test('staging only texts allow-listed phones', () => {
  assertEquals(smsGate({ ...base, allow_listed: false }, true).status, 'blocked_not_allowlisted');
  assertEquals(smsGate(base, true).send, true);
});

Deno.test('production needs an approved A2P campaign', () => {
  assertEquals(smsGate({ ...base, environment: 'production', allow_listed: false }, true).status, 'blocked_a2p');
  assertEquals(smsGate({ ...base, environment: 'production', a2p_status: 'approved' }, true).send, true);
});

Deno.test('production: automatic texts wait until the client is live', () => {
  const prod = { ...base, environment: 'production', a2p_status: 'approved', is_automatic: true };
  assertEquals(smsGate(prod, true).status, 'blocked_not_live');
  assertEquals(smsGate({ ...prod, client_live: true }, true).send, true);
});

Deno.test('opted out, already sent, and test mode', () => {
  assertEquals(smsGate({ ...base, opted_out: true }, true).status, 'cancelled');
  assertEquals(smsGate({ ...base, status: 'sent' }, true).send, false);
  assertEquals(smsGate(base, false).status, 'test_sent');
});
