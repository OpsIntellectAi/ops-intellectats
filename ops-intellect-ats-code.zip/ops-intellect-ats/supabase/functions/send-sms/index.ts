/**
 * POST /functions/v1/send-sms   { applicationIds, body, confirmBulk? }
 * One-off and bulk texts by a person. Checks: signed in, "messages.send", every candidate
 * visible to the caller (RLS), rate limits, bulk confirmation over 30. Each text waits for
 * the candidate's sending window; texts already inside it go out right away.
 */
import { writeAudit } from '../_shared/audit.ts';
import { requireAuth, requirePermission } from '../_shared/auth.ts';
import { dispatchDue } from '../_shared/dispatch.ts';
import { handleBrowserRequest } from '../_shared/handler.ts';
import { HttpError, json } from '../_shared/http.ts';
import { enforceRateLimit } from '../_shared/rate-limit.ts';
import { parseBody } from '../_shared/validate.ts';
import { bulkCheck, SendSmsBody, uniqueIds } from './logic.ts';
import { requireFeature } from '../_shared/features.ts';

Deno.serve((req) =>
  handleBrowserRequest(req, async (cors) => {
    const body = await parseBody(req, SendSmsBody);
    const ctx = await requireAuth(req);
    requirePermission(ctx, 'messages.send');
    const ids = uniqueIds(body.applicationIds);
    const bulk = bulkCheck(ids.length, body.confirmBulk);
    if (!bulk.ok) throw new HttpError(409, 'confirm_bulk', `Please confirm sending to ${ids.length} people.`);
    await enforceRateLimit(ctx.admin, 'sendText', 'user', ctx.userId);
    if (ids.length > 1) await enforceRateLimit(ctx.admin, 'bulkAction', 'user', ctx.userId);

    // Only candidates the caller can see (RLS applies to ctx.user).
    const { data: visible, error } = await ctx.user.from('applications').select('id, client_id').in('id', ids);
    if (error) throw new Error('lookup failed');
    if ((visible ?? []).length !== ids.length) throw new HttpError(403, 'forbidden', 'Some of these candidates are not yours to text.');
    const clients = [...new Set((visible ?? []).map((v) => v.client_id as string))];
    if (clients.length !== 1) throw new HttpError(400, 'one_client', 'Text one client at a time.');
    await enforceRateLimit(ctx.admin, 'sendText', 'client', clients[0]!);
    if (ids.length > 1) await requireFeature(ctx.admin, clients[0]!, 'bulk_texts');

    let queued = 0;
    const skipped: { id: string; reason: string }[] = [];
    for (const id of ids) {
      const { data, error: qErr } = await ctx.admin.rpc('queue_text', {
        p_application: id,
        p_body: body.body,
        p_automatic: false,
        p_sent_by: ctx.userId,
      });
      if (qErr) throw new Error('queue failed');
      const r = data as { message_id?: string; skipped?: string };
      if (r.message_id) queued++;
      else skipped.push({ id, reason: r.skipped ?? 'skipped' });
    }

    await writeAudit(ctx.admin, req, { userId: ctx.userId, role: ctx.access.role, deviceKey: ctx.deviceKey }, {
      action: ids.length > 1 ? 'Bulk text' : 'Text sent',
      clientId: clients[0],
      targetType: 'application',
      targetId: ids.length === 1 ? ids[0] : null,
      after: `${queued} queued, ${skipped.length} skipped`,
      flagged: bulk.flagged,
      flagReason: bulk.flagged ? `Bulk text to ${ids.length} people` : null,
    });

    const sent = await dispatchDue(ctx.admin, Math.min(queued, 50));
    return json({ queued, skipped, sentNow: sent.sent }, 200, cors);
  })
);
