import { z } from 'zod';

export const SendSmsBody = z.object({
  applicationIds: z.array(z.string().uuid()).min(1).max(500),
  body: z.string().trim().min(2, 'Write a message').max(640, 'Keep texts under 640 characters'),
  confirmBulk: z.boolean().optional(),
});
export type SendSmsBody = z.infer<typeof SendSmsBody>;

/** Bulk sends over 30 people need an explicit confirmation and are flagged in the log. */
export function bulkCheck(n: number, confirmed: boolean | undefined): { ok: boolean; flagged: boolean } {
  if (n > 30 && !confirmed) return { ok: false, flagged: true };
  return { ok: true, flagged: n > 30 };
}

/** Same id twice in one request counts once. */
export function uniqueIds(ids: string[]): string[] {
  return [...new Set(ids.map((x) => x.toLowerCase()))];
}
