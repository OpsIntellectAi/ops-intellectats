import { assertEquals } from '../_shared/testing.ts';
import { twilioSignature, validateTwilioRequest } from '../_shared/twilio.ts';
import { callOutcome, classify } from './logic.ts';

const SID = 'SM' + 'a'.repeat(32);

Deno.test('signature: Twilio documented example', async () => {
  // Example from Twilio's security docs (auth token 12345).
  const url = 'https://mycompany.com/myapp.php?foo=1&bar=2';
  const params = { CallSid: 'CA1234567890ABCDE', Caller: '+12349013030', Digits: '1234', From: '+12349013030', To: '+18005551212' };
  assertEquals(await twilioSignature('12345', url, params), '0/KCTR6DLpKmkAf8muzZqo1nDgQ=');
});

Deno.test('bad or missing signature is rejected', async () => {
  const url = 'https://x.supabase.co/functions/v1/twilio-webhook';
  const params = { Body: 'hi', From: '+12025550101', MessageSid: SID };
  const good = await twilioSignature('secret-token-123456', url, params);
  assertEquals(await validateTwilioRequest('secret-token-123456', good, url, params), true);
  assertEquals(await validateTwilioRequest('secret-token-123456', null, url, params), false);
  assertEquals(await validateTwilioRequest('secret-token-123456', good, url, { ...params, Body: 'changed' }), false);
  assertEquals(await validateTwilioRequest('other-token-1234567', good, url, params), false);
});

Deno.test('events are classified', () => {
  const q = (s: string) => new URLSearchParams(s);
  assertEquals(classify(q(''), { From: '+12025550101', Body: 'STOP', MessageSid: SID }).kind, 'inbound');
  assertEquals(classify(q('kind=status'), { MessageSid: SID, MessageStatus: 'delivered' }).kind, 'status');
  assertEquals(classify(q(''), { MessageSid: 'bad', Body: 'x', From: '+1' }).kind, 'unknown');
  assertEquals(classify(q('kind=disclosure'), {}).kind, 'disclosure');
  assertEquals(classify(q(`kind=call&call=${crypto.randomUUID()}`), { CallSid: 'CA1', CallStatus: 'completed' }).kind, 'call');
  assertEquals(classify(q('kind=call&call=nope'), { CallSid: 'CA1' }).kind, 'unknown');
});

Deno.test('call statuses map to outcomes', () => {
  assertEquals(callOutcome('no-answer'), 'no_answer');
  assertEquals(callOutcome('busy'), 'busy');
  assertEquals(callOutcome('canceled'), 'failed');
});
