/**
 * Public webhook for Twilio (inbound texts, delivery status, CSR call status/recordings).
 * Every request must carry a valid X-Twilio-Signature, otherwise 403.
 * Repeated events change nothing (message SID / idempotency keys).
 */
import { adminClient } from '../_shared/supabase.ts';
import { publicUrl, twiml, validateTwilioRequest, xml } from '../_shared/twilio.ts';
import { finishCall } from '../_shared/dispatch.ts';
import { callOutcome, classify } from './logic.ts';

Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  const token = Deno.env.get('TWILIO_AUTH_TOKEN') ?? '';
  const raw = await req.text();
  if (raw.length > 64 * 1024) return new Response('Too large', { status: 413 });
  const params: Record<string, string> = {};
  for (const [k, v] of new URLSearchParams(raw)) params[k] = v;
  const url = publicUrl(req, 'twilio-webhook');
  if (!token || !(await validateTwilioRequest(token, req.headers.get('x-twilio-signature'), url, params))) {
    return new Response('Forbidden', { status: 403 });
  }

  const admin = adminClient();
  const ev = classify(new URL(req.url).searchParams, params);
  try {
    if (ev.kind === 'disclosure') {
      return twiml('<Say>Hello. This call is from a recruiter and is recorded.</Say>');
    }
    if (ev.kind === 'status') {
      await admin.rpc('update_message_status', { p_sid: ev.sid, p_status: ev.status, p_error: ev.error });
      return twiml();
    }
    if (ev.kind === 'inbound') {
      const { data, error } = await admin.rpc('process_inbound_sms', { p_from: ev.from, p_body: ev.body, p_sid: ev.sid });
      if (error) throw new Error('inbound failed');
      const reply = (data as { reply?: string | null } | null)?.reply;
      return twiml(reply ? `<Message>${xml(reply)}</Message>` : '');
    }
    if (ev.kind === 'call') {
      const first = await admin.rpc('claim_idempotency', {
        p_key: `twilio:${ev.callSid}:${ev.recordingUrl ? 'rec' : ev.status}`,
        p_source: 'twilio',
      });
      if (first.data === true && (ev.recordingUrl || ev.status === 'completed' || ev.status === 'no-answer' || ev.status === 'busy' || ev.status === 'failed')) {
        await finishCall(admin, ev.callId, {
          providerCallId: ev.callSid,
          callId: ev.callId,
          outcome: ev.recordingUrl ? 'completed' : callOutcome(ev.status),
          durationSeconds: ev.duration,
          transcript: null,
          recordingUrl: ev.recordingUrl,
          answers: [],
        }).catch(() => null); // second event for the same call: already finished
      }
      return twiml();
    }
    return twiml();
  } catch (e) {
    console.error('twilio webhook error', e instanceof Error ? e.message : String(e));
    // 500 makes Twilio retry; idempotency keeps the retry harmless.
    return new Response('Error', { status: 500 });
  }
});
