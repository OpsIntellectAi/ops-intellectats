export type TwilioEvent =
  | { kind: 'disclosure' }
  | { kind: 'inbound'; from: string; body: string; sid: string }
  | { kind: 'status'; sid: string; status: string; error: string | null }
  | { kind: 'call'; callId: string; callSid: string; status: string | null; duration: number | null; recordingUrl: string | null }
  | { kind: 'unknown' };

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Turns Twilio's form fields (+ our ?kind=) into one event. */
export function classify(query: URLSearchParams, p: Record<string, string>): TwilioEvent {
  const kind = query.get('kind');
  if (kind === 'disclosure') return { kind: 'disclosure' };
  if (kind === 'call') {
    const callId = query.get('call') ?? '';
    if (!UUID.test(callId) || !p.CallSid) return { kind: 'unknown' };
    const d = Number(p.RecordingDuration ?? p.CallDuration ?? '');
    return {
      kind: 'call',
      callId,
      callSid: p.CallSid,
      status: p.CallStatus ?? null,
      duration: Number.isFinite(d) ? d : null,
      recordingUrl: p.RecordingUrl ? `${p.RecordingUrl}.mp3` : null,
    };
  }
  const sid = p.MessageSid ?? p.SmsSid ?? '';
  if (!/^(SM|MM)[0-9a-f]{32}$/i.test(sid)) return { kind: 'unknown' };
  if (kind === 'status' || (p.MessageStatus && p.Body === undefined)) {
    return { kind: 'status', sid, status: p.MessageStatus ?? p.SmsStatus ?? '', error: p.ErrorCode ?? null };
  }
  if (p.From && p.Body !== undefined) return { kind: 'inbound', from: p.From, body: p.Body.slice(0, 1600), sid };
  return { kind: 'unknown' };
}

export function callOutcome(status: string | null): 'completed' | 'no_answer' | 'busy' | 'failed' {
  if (status === 'completed') return 'completed';
  if (status === 'no-answer') return 'no_answer';
  if (status === 'busy') return 'busy';
  return 'failed';
}
