/**
 * POST /functions/v1/start-ai-call   { applicationId }
 * "AI call" button. Checks: signed in, "candidates.act", candidate visible to the caller,
 * rate limits, then the database rules (consent, stage, attempts, NYC notice, opt-out).
 */
import { z } from 'zod';
import { writeAudit } from '../_shared/audit.ts';
import { requireAuth, requirePermission } from '../_shared/auth.ts';
import { startAiCall } from '../_shared/dispatch.ts';
import { handleBrowserRequest } from '../_shared/handler.ts';
import { HttpError, json } from '../_shared/http.ts';
import { enforceRateLimit } from '../_shared/rate-limit.ts';
import { parseBody, uuid } from '../_shared/validate.ts';

const Body = z.object({ applicationId: uuid });

Deno.serve((req) =>
  handleBrowserRequest(req, async (cors) => {
    const body = await parseBody(req, Body);
    const ctx = await requireAuth(req);
    requirePermission(ctx, 'candidates.act');
    const { data: app } = await ctx.user.from('applications').select('id, client_id').eq('id', body.applicationId).maybeSingle();
    if (!app) throw new HttpError(403, 'forbidden', 'This candidate is not yours to call.');
    await enforceRateLimit(ctx.admin, 'startCall', 'user', ctx.userId);
    await enforceRateLimit(ctx.admin, 'startCall', 'client', app.client_id as string);

    const { data: reason, error } = await ctx.admin.rpc('ai_call_check', { p_application: body.applicationId, p_automatic: false });
    if (error) throw new Error('check failed');
    if (reason) throw new HttpError(409, 'not_allowed', String(reason));

    const r = await startAiCall(ctx.admin, body.applicationId, ctx.userId);
    await writeAudit(ctx.admin, req, { userId: ctx.userId, role: ctx.access.role, deviceKey: ctx.deviceKey }, {
      action: 'AI call requested',
      clientId: app.client_id as string,
      targetType: 'application',
      targetId: body.applicationId,
      after: r.test ? 'test mode' : `attempt ${r.attempt}`,
    });
    return json({ callId: r.callId, attempt: r.attempt, test: r.test }, 200, cors);
  })
);
