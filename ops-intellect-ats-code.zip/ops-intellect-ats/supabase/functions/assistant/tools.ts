/**
 * The ONLY things the assistant can look at. Every tool runs through the asking user's own
 * database session (RLS), inside the one client they have open. No raw SQL, read-only.
 * Candidates are given to the AI as references (#1, #2…), never names; names are put back
 * into the final answer on the server for the person who asked.
 */
import type { SupabaseClient } from '@supabase/supabase-js';
import type { LlmTool } from '../_shared/llm.ts';

const STAGES = ['interview', 'shortlisted', 'pre_onboarding', 'onboarding', 'hired', 'not_interested', 'rejected'];

interface Row {
  id: string;
  full_name: string;
  stage: string;
  station_id: string;
  job_role_id: string;
  applied_at: string;
  stage_changed_at: string;
  last_in_at: string | null;
  last_out_at: string | null;
  completed_ai_calls: number;
  required_left: number;
}

export interface ToolContext {
  user: SupabaseClient;
  clientId: string;
  jobRoleId: string | null;
  refs: Map<string, string>;
}

const days = (iso: string | null, now = Date.now()) => (iso ? Math.floor((now - new Date(iso).getTime()) / 86_400_000) : null);

async function rows(t: ToolContext, sinceDays?: number): Promise<Row[]> {
  let q = t.user.from('application_rows')
    .select('id, full_name, stage, station_id, job_role_id, applied_at, stage_changed_at, last_in_at, last_out_at, completed_ai_calls, required_left')
    .eq('client_id', t.clientId)
    .limit(5000);
  if (t.jobRoleId) q = q.eq('job_role_id', t.jobRoleId);
  if (sinceDays) q = q.gte('applied_at', new Date(Date.now() - sinceDays * 86_400_000).toISOString());
  const { data, error } = await q;
  if (error) throw new Error('could not read candidates');
  return (data ?? []) as Row[];
}

async function stations(t: ToolContext): Promise<Map<string, string>> {
  const { data } = await t.user.from('stations').select('id, code').eq('client_id', t.clientId);
  return new Map((data ?? []).map((s) => [s.id as string, s.code as string]));
}

function ref(t: ToolContext, r: Row): string {
  const existing = [...t.refs.entries()].find(([, v]) => v === r.id);
  if (existing) return existing[0];
  const k = `#${t.refs.size + 1}`;
  t.refs.set(k, r.id);
  return k;
}

const num = (v: unknown, lo: number, hi: number): number | undefined => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(hi, Math.max(lo, Math.round(n))) : undefined;
};
const stageOf = (v: unknown) => (typeof v === 'string' && STAGES.includes(v) ? v : undefined);

export function buildTools(t: ToolContext): LlmTool[] {
  return [
    {
      name: 'count_applications',
      description: 'Count candidates by stage, optionally for one station code and only those who applied in the last N days.',
      schema: { type: 'object', properties: { stage: { type: 'string', enum: STAGES }, station_code: { type: 'string' }, days: { type: 'number' } } },
      async run(i) {
        const st = await stations(t);
        const code = typeof i.station_code === 'string' ? i.station_code.toUpperCase() : undefined;
        const list = (await rows(t, num(i.days, 1, 365))).filter((r) => !code || st.get(r.station_id) === code);
        const by: Record<string, number> = {};
        for (const r of list) by[r.stage] = (by[r.stage] ?? 0) + 1;
        const s = stageOf(i.stage);
        return s ? { stage: s, count: by[s] ?? 0 } : { total: list.length, by_stage: by };
      },
    },
    {
      name: 'list_applications',
      description: 'List up to 25 candidates (as #references) filtered by stage, days without a reply, or AI interview not done.',
      schema: {
        type: 'object',
        properties: {
          stage: { type: 'string', enum: STAGES },
          no_reply_days: { type: 'number' },
          not_interviewed: { type: 'boolean' },
          limit: { type: 'number' },
        },
      },
      async run(i) {
        const st = await stations(t);
        const s = stageOf(i.stage);
        const nr = num(i.no_reply_days, 1, 60);
        const list = (await rows(t))
          .filter((r) => !s || r.stage === s)
          .filter((r) => !nr || (r.last_out_at && (days(r.last_in_at) ?? 999) >= nr && (days(r.last_out_at) ?? 0) >= 0))
          .filter((r) => !i.not_interviewed || r.completed_ai_calls === 0)
          .slice(0, num(i.limit, 1, 25) ?? 25);
        return list.map((r) => ({
          ref: ref(t, r), stage: r.stage, station: st.get(r.station_id) ?? '', days_in_stage: days(r.stage_changed_at),
          days_since_reply: days(r.last_in_at),
        }));
      },
    },
    {
      name: 'funnel',
      description: 'Hiring funnel for people who applied in the last N days (default 30): applied, interviewed, shortlisted, onboarding, hired.',
      schema: { type: 'object', properties: { days: { type: 'number' } } },
      async run(i) {
        const list = await rows(t, num(i.days, 1, 365) ?? 30);
        const reached = (s: string[]) => list.filter((r) => s.includes(r.stage)).length;
        return {
          applied: list.length,
          interviewed: list.filter((r) => r.completed_ai_calls > 0).length,
          shortlisted: reached(['shortlisted', 'pre_onboarding', 'onboarding', 'hired']),
          onboarding: reached(['onboarding', 'hired']),
          hired: reached(['hired']),
        };
      },
    },
    {
      name: 'call_stats',
      description: 'AI and phone call counts by outcome in the last N days (default 7), with the answer rate.',
      schema: { type: 'object', properties: { days: { type: 'number' } } },
      async run(i) {
        const since = new Date(Date.now() - (num(i.days, 1, 90) ?? 7) * 86_400_000).toISOString();
        let q = t.user.from('call_rows').select('outcome, via, review_verdict').eq('client_id', t.clientId).gte('created_at', since).limit(5000);
        if (t.jobRoleId) q = q.eq('job_role_id', t.jobRoleId);
        const { data, error } = await q;
        if (error) throw new Error('could not read calls');
        const by: Record<string, number> = {};
        for (const c of data ?? []) by[c.outcome as string] = (by[c.outcome as string] ?? 0) + 1;
        const total = (data ?? []).length;
        return { total, by_outcome: by, answer_rate_pct: total ? Math.round((100 * (by.completed ?? 0)) / total) : null,
          not_reviewed: (data ?? []).filter((c) => c.via === 'ai' && c.outcome === 'completed' && !c.review_verdict).length };
      },
    },
    {
      name: 'onboarding_stalls',
      description: 'Onboarding steps that are not done, with how many people wait on each and (as #references) who. Optional step name filter, e.g. "DSP Portal".',
      schema: { type: 'object', properties: { step: { type: 'string' }, older_than_hours: { type: 'number' } } },
      async run(i) {
        const list = (await rows(t)).filter((r) => r.stage === 'onboarding' || r.stage === 'pre_onboarding');
        if (!list.length) return [];
        const { data, error } = await t.user.from('onboarding_steps')
          .select('application_id, status, changed_at, onboarding_step_defs(name, done_statuses)')
          .in('application_id', list.map((r) => r.id)).limit(5000);
        if (error) throw new Error('could not read onboarding');
        const hours = num(i.older_than_hours, 0, 24 * 60) ?? 0;
        const want = typeof i.step === 'string' ? i.step.toLowerCase() : '';
        const out = new Map<string, string[]>();
        for (const s of data ?? []) {
          const d = (Array.isArray(s.onboarding_step_defs) ? s.onboarding_step_defs[0] : s.onboarding_step_defs) as { name: string; done_statuses: string[] } | null;
          if (!d || d.done_statuses.includes(s.status as string) || s.status === 'Waived') continue;
          if (want && !d.name.toLowerCase().includes(want)) continue;
          if (hours && Date.now() - new Date(s.changed_at as string).getTime() < hours * 3_600_000) continue;
          const r = list.find((x) => x.id === s.application_id);
          if (r) out.set(d.name, [...(out.get(d.name) ?? []), ref(t, r)]);
        }
        return [...out.entries()].map(([step, refs]) => ({ step, waiting: refs.length, who: refs.slice(0, 25) }));
      },
    },
  ];
}

/** Swaps #references back to names for the person who asked (they can see these people). */
export async function putNamesBack(user: SupabaseClient, text: string, refs: Map<string, string>): Promise<string> {
  if (!refs.size) return text;
  const { data } = await user.from('application_rows').select('id, full_name').in('id', [...refs.values()]);
  const names = new Map((data ?? []).map((r) => [r.id as string, r.full_name as string]));
  return text.replace(/#(\d{1,4})\b/g, (m) => {
    const id = refs.get(m);
    return id && names.has(id) ? names.get(id)! : m;
  });
}
