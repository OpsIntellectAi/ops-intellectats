import { assertEquals } from '../_shared/testing.ts';
import { buildTools, putNamesBack } from './tools.ts';
import type { SupabaseClient } from '@supabase/supabase-js';

// A fake database session that records which client/filters every query used.
function fakeUser(rows: Record<string, unknown>[], seen: string[]): SupabaseClient {
  const chain = (table: string) => {
    const q: Record<string, unknown> = {};
    const api = {
      select: () => api, limit: () => api, gte: () => api,
      eq: (k: string, v: string) => { seen.push(`${table}.${k}=${v}`); q[k] = v; return api; },
      in: () => api,
      then: (res: (x: unknown) => unknown) =>
        res({ data: table === 'stations' ? [{ id: 's1', code: 'NL1' }] : rows.filter((r) => !q.client_id || r.client_id === q.client_id), error: null }),
    };
    return api;
  };
  return { from: chain } as unknown as SupabaseClient;
}

const base = { station_id: 's1', job_role_id: 'j1', applied_at: new Date().toISOString(), stage_changed_at: new Date().toISOString(),
  last_in_at: null, last_out_at: null, completed_ai_calls: 0, required_left: 0 };

Deno.test('tools only ask for the open client, and hide names behind references', async () => {
  const seen: string[] = [];
  const rows = [
    { ...base, id: 'a1', client_id: 'C1', full_name: 'Jordan Miles', stage: 'shortlisted' },
    { ...base, id: 'a2', client_id: 'C1', full_name: 'Alicia Gomez', stage: 'interview' },
  ];
  const refs = new Map<string, string>();
  const tools = buildTools({ user: fakeUser(rows, seen), clientId: 'C1', jobRoleId: null, refs });
  const list = await tools.find((t) => t.name === 'list_applications')!.run({ stage: 'shortlisted' }) as { ref: string }[];
  assertEquals(JSON.stringify(list).includes('Jordan'), false);
  assertEquals(list[0]?.ref, '#1');
  assertEquals(seen.every((s) => !s.includes('client_id') || s.endsWith('=C1')), true);
  const count = await tools.find((t) => t.name === 'count_applications')!.run({ stage: 'interview' });
  assertEquals(count, { stage: 'interview', count: 1 });
});

Deno.test('bad tool input is clamped, not trusted', async () => {
  const refs = new Map<string, string>();
  const tools = buildTools({ user: fakeUser([], []), clientId: 'C1', jobRoleId: null, refs });
  assertEquals(await tools.find((t) => t.name === 'count_applications')!.run({ stage: "x'; drop table" }), { total: 0, by_stage: {} });
});

Deno.test('names are put back only for references we issued', async () => {
  const refs = new Map([['#1', 'a1']]);
  const user = { from: () => ({ select: () => ({ in: () => Promise.resolve({ data: [{ id: 'a1', full_name: 'Jordan Miles' }] }) }) }) } as unknown as SupabaseClient;
  assertEquals(await putNamesBack(user, 'Waiting: #1 and #7.', refs), 'Waiting: Jordan Miles and #7.');
});
