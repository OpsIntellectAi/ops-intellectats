/**
 * POST /functions/v1/assistant   { clientId, jobRoleId?, question }
 * AI recruitment assistant. The model may only call the read-only tools in tools.ts,
 * which run with the asking user's own permissions. Every question and answer is logged.
 */
import { z } from 'zod';
import { requireAuth, requireClientAccess, requirePermission } from '../_shared/auth.ts';
import { handleBrowserRequest } from '../_shared/handler.ts';
import { json } from '../_shared/http.ts';
import { runWithTools } from '../_shared/llm.ts';
import { enforceRateLimit } from '../_shared/rate-limit.ts';
import { parseBody, uuid } from '../_shared/validate.ts';
import { buildTools, putNamesBack } from './tools.ts';
import { requireFeature } from '../_shared/features.ts';

const Body = z.object({ clientId: uuid, jobRoleId: uuid.nullable().optional(), question: z.string().trim().min(3).max(500) });

const SYSTEM =
  'You are the recruitment assistant inside Ops Intellect ATS. Answer in 1-4 short sentences, plain English. ' +
  'Use the tools to get numbers; never invent numbers. People appear as references like #3: keep those exactly. ' +
  'If a question is not about this client\'s hiring data, say you can only help with hiring questions. ' +
  'Never rank or judge candidates as people.';

Deno.serve((req) =>
  handleBrowserRequest(req, async (cors) => {
    const body = await parseBody(req, Body);
    const ctx = await requireAuth(req);
    requirePermission(ctx, 'assistant.use');
    await requireClientAccess(ctx, body.clientId);
    await requireFeature(ctx.admin, body.clientId, 'ai_assistant');
    await enforceRateLimit(ctx.admin, 'assistant', 'user', ctx.userId);
    await enforceRateLimit(ctx.admin, 'assistant', 'client', body.clientId);

    const refs = new Map<string, string>();
    const tools = buildTools({ user: ctx.user, clientId: body.clientId, jobRoleId: body.jobRoleId ?? null, refs });
    const r = await runWithTools(SYSTEM, body.question, tools);
    const answer = await putNamesBack(ctx.user, r.text || 'I could not find an answer.', refs);
    await ctx.admin.rpc('log_assistant', {
      p_user: ctx.userId, p_client: body.clientId, p_question: body.question, p_answer: answer, p_tools: r.toolsUsed,
    });
    return json({ answer, tools: r.toolsUsed.map((t) => t.name) }, 200, cors);
  })
);
