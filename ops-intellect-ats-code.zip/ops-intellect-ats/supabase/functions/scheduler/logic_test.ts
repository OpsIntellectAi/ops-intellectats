import { assertEquals } from '../_shared/testing.ts';
import { alertsDue, etParts, retentionDue, weeklyReportDue } from './logic.ts';

Deno.test('Eastern time, including daylight saving', () => {
  assertEquals(etParts(new Date('2026-11-16T13:05:00Z')).hour, 8); // EST (UTC-5)
  assertEquals(etParts(new Date('2026-07-06T12:05:00Z')).hour, 8); // EDT (UTC-4)
});

Deno.test('weekly report only Monday 8 AM ET, once per day key', () => {
  assertEquals(weeklyReportDue(new Date('2026-11-16T13:05:00Z')), 'weekly_report:2026-11-16');
  assertEquals(weeklyReportDue(new Date('2026-11-17T13:05:00Z')), null);
  assertEquals(weeklyReportDue(new Date('2026-11-16T15:05:00Z')), null);
});

Deno.test('retention at 3 AM ET; alerts every 15 minutes', () => {
  assertEquals(retentionDue(new Date('2026-11-16T08:10:00Z')) !== null, true);
  assertEquals(retentionDue(new Date('2026-11-16T09:10:00Z')), null);
  assertEquals(alertsDue(new Date('2026-11-16T09:15:30Z')), true);
  assertEquals(alertsDue(new Date('2026-11-16T09:20:00Z')), false);
});
