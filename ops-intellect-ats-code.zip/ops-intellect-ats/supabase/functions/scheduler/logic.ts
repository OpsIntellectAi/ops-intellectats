/** When the periodic jobs run (all in US Eastern time, where the team works). */
export function etParts(d: Date): { weekday: string; hour: number; minute: number; date: string } {
  const f = new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/New_York', weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false,
    year: 'numeric', month: '2-digit', day: '2-digit',
  });
  const p = Object.fromEntries(f.formatToParts(d).map((x) => [x.type, x.value]));
  return {
    weekday: p.weekday ?? '',
    hour: Number(p.hour) % 24,
    minute: Number(p.minute),
    date: `${p.year}-${p.month}-${p.day}`,
  };
}

/** Weekly client report: Monday 8:00 AM ET (any run between 8:00 and 8:59 sends once). */
export function weeklyReportDue(d: Date): string | null {
  const t = etParts(d);
  return t.weekday === 'Mon' && t.hour === 8 ? `weekly_report:${t.date}` : null;
}

/** Retention clean-up: daily at 3 AM ET. */
export function retentionDue(d: Date): string | null {
  const t = etParts(d);
  return t.hour === 3 ? `retention:${t.date}` : null;
}

/** Alerts are checked every 15 minutes. */
export function alertsDue(d: Date): boolean {
  return etParts(d).minute % 15 < 2;
}
