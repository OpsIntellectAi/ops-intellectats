/**
 * Runs every minute (pg_cron → pg_net). Not callable from a browser: the request must
 * carry the x-cron-secret stored in app_config (service role only).
 * Steps: first texts + no-reply cadence → queued jobs (texts, reminders, AI calls,
 * retries) → alerts (every 15 min) → weekly client report (Mon 8 AM ET) → retention (3 AM ET).
 * The emergency stop is enforced in the database (claim_jobs / run_cadence / ai_call_check).
 */
import { adminClient } from '../_shared/supabase.ts';
import { dispatchDue, sendQueuedMessage, startAiCall } from '../_shared/dispatch.ts';
import { emailConfigured, escapeHtml, sendEmail } from '../_shared/email.ts';
import { safeEqual, sendSms, twilioConfig, functionsBaseUrl } from '../_shared/twilio.ts';
import { alertsDue, retentionDue, weeklyReportDue } from './logic.ts';

interface Job {
  id: string;
  kind: string;
  payload: Record<string, unknown>;
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  const admin = adminClient();
  const { data: cfg } = await admin.from('app_config').select('value').eq('key', 'cron_secret').maybeSingle();
  const secret = (cfg as { value?: string } | null)?.value ?? '';
  if (secret.length < 32 || !safeEqual(secret, req.headers.get('x-cron-secret') ?? '')) {
    return new Response('Forbidden', { status: 403 });
  }
  const now = new Date();
  const report: Record<string, unknown> = {};

  const cad = await admin.rpc('run_cadence', {});
  report.cadence = cad.data ?? cad.error?.message;

  const { data: jobs } = await admin.rpc('claim_jobs', { p_limit: 50, p_kinds: ['send_sms', 'call_reminder', 'ai_call'] });
  let done = 0;
  for (const j of (jobs ?? []) as Job[]) {
    try {
      if (j.kind === 'send_sms' && typeof j.payload.message_id === 'string') {
        await sendQueuedMessage(admin, j.payload.message_id);
      } else if (j.kind === 'call_reminder') {
        const appId = String(j.payload.application_id ?? '');
        const { data: app } = await admin.from('applications').select('booked_call_at').eq('id', appId).maybeSingle();
        const { data: rem } = await admin.from('call_reminders').select('body, enabled').eq('id', String(j.payload.reminder_id ?? '')).maybeSingle();
        // Only if the booking did not change and the reminder is still on.
        if (app?.booked_call_at && rem?.enabled && new Date(app.booked_call_at).getTime() === new Date(String(j.payload.booked_at)).getTime()) {
          await admin.rpc('queue_text', { p_application: appId, p_body: rem.body, p_automatic: true, p_sent_by: null, p_not_before: null, p_fill_time: app.booked_call_at });
        }
      } else if (j.kind === 'ai_call') {
        const appId = String(j.payload.application_id ?? '');
        const { data: reason } = await admin.rpc('ai_call_check', { p_application: appId, p_automatic: true });
        if (!reason) await startAiCall(admin, appId, null);
      }
      await admin.rpc('finish_job', { p_id: j.id, p_ok: true });
      done++;
    } catch (e) {
      await admin.rpc('finish_job', {
        p_id: j.id, p_ok: false, p_error: e instanceof Error ? e.message : 'error',
        p_retry_at: new Date(Date.now() + 10 * 60_000).toISOString(),
      });
    }
  }
  report.jobs = done;
  // Reminders queued above are usually already inside the sending window.
  report.sentAfter = (await dispatchDue(admin, 50)).sent;

  if (alertsDue(now)) {
    const { data: alerts } = await admin.rpc('evaluate_alerts', { p_now: now.toISOString() });
    const tw = twilioConfig();
    let sent = 0;
    for (const a of (alerts ?? []) as { message: string; channel: string; phones: string[]; emails: string[] }[]) {
      if (a.channel !== 'email' && tw?.fromNumber) {
        for (const to of a.phones.slice(0, 10)) {
          await sendSms(tw, { to, body: `Ops Intellect alert: ${a.message}`.slice(0, 320), messagingServiceSid: null, statusCallback: `${functionsBaseUrl()}/twilio-webhook?kind=status` }).catch(() => null);
        }
      }
      if (a.channel !== 'text') {
        await sendEmail(a.emails, `Alert: ${a.message.slice(0, 80)}`, `<p>${escapeHtml(a.message)}</p>`).catch(() => null);
      }
      sent++;
    }
    report.alerts = sent;
  }

  const weeklyKey = weeklyReportDue(now);
  if (weeklyKey) {
    const { data: first } = await admin.rpc('claim_idempotency', { p_key: weeklyKey, p_source: 'scheduler' });
    if (first === true) {
      const { data: reports } = await admin.rpc('weekly_reports', {});
      let n = 0;
      for (const r of (reports ?? []) as { client_id: string; to: string | null; subject: string; html: string }[]) {
        const status = r.to ? await sendEmail([r.to], r.subject, r.html).catch(() => 'failed') : 'no_contact';
        await admin.rpc('log_weekly_report', { p_client: r.client_id, p_status: emailConfigured() ? status : 'test' });
        n++;
      }
      report.weekly = n;
    }
  }

  const retentionKey = retentionDue(now);
  if (retentionKey) {
    const { data: first } = await admin.rpc('claim_idempotency', { p_key: retentionKey, p_source: 'scheduler' });
    if (first === true) {
      const { data: r } = await admin.rpc('run_retention', { p_now: now.toISOString() });
      // The shared test-mode sample is never deleted.
      const paths = ((r as { recording_paths?: string[] } | null)?.recording_paths ?? []).filter((p) => p && !p.startsWith('samples/'));
      for (let i = 0; i < paths.length; i += 100) await admin.storage.from('recordings').remove(paths.slice(i, i + 100));
      report.retention = r;
    }
  }

  return new Response(JSON.stringify(report), { status: 200, headers: { 'content-type': 'application/json' } });
});
