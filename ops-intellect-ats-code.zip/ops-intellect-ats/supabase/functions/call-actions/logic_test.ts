import { assertEquals } from '../_shared/testing.ts';
import { CallActionBody, RECORDING_LINK_SECONDS, serviceStatus } from './logic.ts';

Deno.test('recording links expire in 10 minutes or less', () => {
  assertEquals(RECORDING_LINK_SECONDS <= 600, true);
});

Deno.test('actions are validated', () => {
  assertEquals(CallActionBody.safeParse({ action: 'recording_url', callId: 'x' }).success, false);
  assertEquals(CallActionBody.safeParse({ action: 'delete_everything' }).success, false);
  assertEquals(CallActionBody.safeParse({ action: 'set_my_phone', phone: '+442079460958' }).success, true);
  assertEquals(CallActionBody.safeParse({ action: 'set_my_phone', phone: '442079460958' }).success, false);
  assertEquals(CallActionBody.safeParse({ action: 'set_my_phone', phone: '+12025550123' }).success, true);
});

Deno.test('service status: yes/no only, never a key', () => {
  const env: Record<string, string> = { TWILIO_ACCOUNT_SID: 'AC1', TWILIO_AUTH_TOKEN: 'x', TWILIO_FROM_NUMBER: '+1', OPENAI_API_KEY: 'sk' };
  const s = serviceStatus((k) => env[k]);
  assertEquals(s, { twilio: true, voice: 'test', ai: 'openai', email: false, encryption: false });
  assertEquals(JSON.stringify(s).includes('sk'), false);
});

Deno.test('own phone: any country with country code', () => {
  assertEquals(CallActionBody.safeParse({ action: 'set_my_phone', phone: '+919812345678' }).success, true);
  assertEquals(CallActionBody.safeParse({ action: 'set_my_phone', phone: '+12025550123' }).success, true);
  assertEquals(CallActionBody.safeParse({ action: 'set_my_phone', phone: '9812345678' }).success, false);
});
