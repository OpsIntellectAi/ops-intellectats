import { z } from 'zod';

export const CallActionBody = z.discriminatedUnion('action', [
  z.object({ action: z.literal('recording_url'), callId: z.string().uuid() }),
  z.object({ action: z.literal('csr_call'), applicationId: z.string().uuid() }),
  z.object({
    action: z.literal('set_my_phone'),
    // Any country: the team works from India and the US. Twilio needs the country enabled
    // in its Voice geo permissions for numbers outside the US.
    phone: z.string().trim().regex(/^\+[1-9][0-9]{7,14}$/, 'Use the full number with country code, like +12025550123 or +919812345678'),
  }),
  z.object({ action: z.literal('service_status') }),
]);
export type CallActionBody = z.infer<typeof CallActionBody>;

/** Signed links to recordings never live longer than 10 minutes. */
export const RECORDING_LINK_SECONDS = 600;

/** Which outside services have keys set. Only yes/no is returned; never a key. */
export function serviceStatus(env: (k: string) => string | undefined) {
  const has = (k: string) => Boolean(env(k));
  const llm = has('ANTHROPIC_API_KEY') ? 'anthropic' : has('OPENAI_API_KEY') ? 'openai' : 'test';
  return {
    twilio: has('TWILIO_ACCOUNT_SID') && has('TWILIO_AUTH_TOKEN') && has('TWILIO_FROM_NUMBER'),
    voice: has('VAPI_API_KEY') && has('VAPI_PHONE_NUMBER_ID') && has('VAPI_WEBHOOK_SECRET') ? 'vapi' : 'test',
    ai: llm,
    email: has('RESEND_API_KEY') && has('EMAIL_FROM'),
    encryption: has('FIELD_ENCRYPTION_KEY'),
  };
}
