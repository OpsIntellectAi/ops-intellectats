/**
 * POST /functions/v1/call-actions
 *   { action: 'recording_url', callId }      → 10-minute signed link to a private recording
 *   { action: 'csr_call', applicationId }    → Twilio rings you, then the candidate (recorded)
 *   { action: 'set_my_phone', phone }        → the phone Twilio rings for your calls
 *   { action: 'service_status' }             → which outside services have keys (yes/no only)
 */
import { writeAudit } from '../_shared/audit.ts';
import { requireAuth, requirePermission } from '../_shared/auth.ts';
import { handleBrowserRequest } from '../_shared/handler.ts';
import { HttpError, json } from '../_shared/http.ts';
import { enforceRateLimit } from '../_shared/rate-limit.ts';
import { startCsrCall, twilioConfig } from '../_shared/twilio.ts';
import { parseBody } from '../_shared/validate.ts';
import { requireFeature } from '../_shared/features.ts';
import { CallActionBody, RECORDING_LINK_SECONDS, serviceStatus } from './logic.ts';

Deno.serve((req) =>
  handleBrowserRequest(req, async (cors) => {
    const body = await parseBody(req, CallActionBody);
    const ctx = await requireAuth(req);
    const actor = { userId: ctx.userId, role: ctx.access.role, deviceKey: ctx.deviceKey };

    if (body.action === 'service_status') {
      requirePermission(ctx, 'candidates.act');
      return json(serviceStatus((k) => Deno.env.get(k)), 200, cors);
    }

    if (body.action === 'set_my_phone') {
      const { error } = await ctx.admin.from('profiles').update({ phone_e164: body.phone }).eq('id', ctx.userId);
      if (error) throw new Error('save failed');
      await writeAudit(ctx.admin, req, actor, { action: 'Own phone number set', targetType: 'user', targetId: ctx.userId });
      return json({ ok: true }, 200, cors);
    }

    if (body.action === 'recording_url') {
      // RLS: the caller can only see calls of candidates in their scope.
      const { data: call } = await ctx.user.from('calls').select('id, client_id, recording_path').eq('id', body.callId).maybeSingle();
      if (!call) throw new HttpError(403, 'forbidden', 'This call is not in your scope.');
      if (!call.recording_path) throw new HttpError(404, 'no_recording', 'There is no recording for this call.');
      const { data, error } = await ctx.admin.storage.from('recordings').createSignedUrl(call.recording_path as string, RECORDING_LINK_SECONDS);
      if (error || !data) throw new Error('signing failed');
      await writeAudit(ctx.admin, req, actor, {
        action: 'Recording opened', clientId: call.client_id as string, targetType: 'call', targetId: body.callId,
      });
      return json({ url: data.signedUrl }, 200, cors);
    }

    // csr_call
    requirePermission(ctx, 'candidates.act');
    const { data: app } = await ctx.user.from('applications').select('id, client_id, candidate_id').eq('id', body.applicationId).maybeSingle();
    if (!app) throw new HttpError(403, 'forbidden', 'This candidate is not yours to call.');
    await requireFeature(ctx.admin, app.client_id as string, 'phone_calls');
    await enforceRateLimit(ctx.admin, 'startCall', 'user', ctx.userId);
    const { data: me } = await ctx.admin.from('profiles').select('phone_e164').eq('id', ctx.userId).maybeSingle();
    const { data: cand } = await ctx.admin.from('candidates').select('phone_e164, opted_out_at').eq('id', app.candidate_id).maybeSingle();
    if (!cand) throw new HttpError(404, 'not_found', 'Candidate not found.');
    const cfg = twilioConfig();
    if (cfg && !me?.phone_e164) throw new HttpError(409, 'no_phone', 'Add your own phone number first, so Twilio can ring you.');

    const { data: created, error } = await ctx.admin.rpc('create_call', {
      p_application: body.applicationId, p_via: 'csr', p_provider: 'twilio', p_placed_by: ctx.userId,
    });
    if (error || !created) throw new Error('could not create the call');
    const callId = (created as { call_id: string }).call_id;

    if (!cfg) {
      // Test mode: no real call; the call is logged as completed so screens can be checked.
      await ctx.admin.rpc('set_provider_call_id', { p_call: callId, p_provider_call_id: `test-${callId}`, p_outcome: 'in_progress' });
      await ctx.admin.rpc('record_call_result', { p_call: callId, p_outcome: 'completed', p_duration: 0, p_transcript: '[TEST CALL: Twilio is not set up]' });
      return json({ callId, test: true }, 200, cors);
    }
    const r = await startCsrCall(cfg, { csrPhone: me!.phone_e164 as string, candidatePhone: cand.phone_e164 as string, callId });
    await ctx.admin.rpc('set_provider_call_id', { p_call: callId, p_provider_call_id: r.sid, p_outcome: 'in_progress' });
    return json({ callId, test: false }, 200, cors);
  })
);
