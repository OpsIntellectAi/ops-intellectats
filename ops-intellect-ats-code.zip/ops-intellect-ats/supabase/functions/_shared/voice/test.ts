/**
 * TEST provider (used when Vapi secrets are not set). No phone call is made. The call
 * finishes at once with a made-up result so every screen, rule and retry can be checked:
 *   phone ending in 9 → voicemail · 8 → no answer · 7 → one unclear answer · else every answer clear.
 * A short sample recording (samples/test-call.mp3 in the private bucket) is attached so
 * "Listen" can be checked too; the overview says it is a test.
 */
import type { CallAnswer, CallReport, CallRequest, VoiceProvider } from './types.ts';
import { condition, fillFacts, openingLine } from './script.ts';

export const TEST_RECORDING_PATH = 'samples/test-call.mp3';

export function testProvider(): VoiceProvider {
  return {
    name: 'test',
    start(r: CallRequest) {
      return Promise.resolve({ providerCallId: `test-${r.callId}` });
    },
  };
}

export function simulateReport(r: CallRequest, providerCallId: string): CallReport {
  const last = r.to.slice(-1);
  const outcome = last === '9' ? 'voicemail' : last === '8' ? 'no_answer' : 'completed';
  const results = new Map<string, CallAnswer['result']>();
  const answers: CallAnswer[] = [];
  let t = 30;
  let topYesNo = 0;
  if (outcome === 'completed') {
    for (const q of r.questions) {
      const cond = condition(q.key);
      if (cond) {
        const parent = results.get(cond.parent);
        if (parent !== cond.answer) continue; // branch not taken
      }
      // Phone ending in 7: the second main yes/no answer is unclear.
      const unclear = last === '7' && q.type === 'yes_no' && !cond && topYesNo === 1;
      if (q.type === 'yes_no' && !cond) topYesNo++;
      const result: CallAnswer['result'] = q.type === 'yes_no' ? (unclear ? 'needs_review' : 'yes') : q.type === 'info' ? 'info' : 'recorded';
      results.set(q.key, result);
      answers.push({
        key: q.key,
        text: fillFacts(q.text, r),
        heard: q.type === 'yes_no' ? (unclear ? 'Hmm, I think so, maybe?' : 'Yes.') : q.type === 'info' ? '' : 'Next Monday works.',
        result,
        at: t,
      });
      t += q.type === 'info' ? 15 : 35;
    }
  }
  const yesNo = answers.filter((a) => a.result === 'yes' || a.result === 'no' || a.result === 'needs_review');
  const yes = yesNo.filter((a) => a.result === 'yes').length;
  const unclear = yesNo.filter((a) => a.result === 'needs_review').length;
  const summary = outcome !== 'completed' ? null :
    `${r.firstName} answered ${yes} of ${yesNo.length} requirements Yes${unclear ? `, ${unclear} unclear (needs review)` : ''}. ` +
    `Start: next Monday. ${r.pay ? `Pay discussed: ${r.pay}. ` : ''}[Test call: no real phone call was made.]`;
  const transcript = outcome !== 'completed' ? null : [
    `AI: ${openingLine(r)}`,
    'Candidate: Yes, now is fine.',
    ...answers.flatMap((a) => (a.result === 'info' ? [`AI: ${a.text}`] : [`AI: ${a.text}`, `Candidate: ${a.heard}`])),
    'AI: Thank you! The team will text you about next steps.',
    '[TEST CALL: no real phone call was made]',
  ].join('\n');
  return {
    providerCallId,
    callId: r.callId,
    outcome,
    durationSeconds: outcome === 'completed' ? t + 20 : 0,
    transcript,
    recordingUrl: null,
    recordingPath: outcome === 'completed' ? TEST_RECORDING_PATH : null,
    summary,
    answers,
  };
}
