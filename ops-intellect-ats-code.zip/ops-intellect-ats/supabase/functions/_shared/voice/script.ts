import type { CallAnswer, CallRequest, JobFacts, ScriptQuestion } from './types.ts';

/**
 * [placeholders] used by the standard script. One script works for every client: only the
 * client name and the job role facts (pay, address, training location, shift, schedule) change.
 */
export function fillFacts(text: string, f: JobFacts & { firstName?: string }): string {
  const map: Record<string, string | null | undefined> = {
    company: f.client,
    client: f.client,
    dsp: f.client,
    role: f.role,
    pay: f.pay,
    'pay rate': f.pay,
    address: f.address,
    'station address': f.address,
    location: f.address,
    'training location': f.trainingLocation,
    shift: f.shift,
    schedule: f.schedule,
    'min age': f.minAge != null ? String(f.minAge) : null,
    'first name': f.firstName,
  };
  return text.replace(/\[([a-z ]{2,20})\]/gi, (all, name: string) => {
    const v = map[name.toLowerCase()];
    return v == null || v === '' ? all : v;
  });
}

/** "18.yes.yes" → parent "18.yes", answer "yes". Plain keys have no condition. */
export function condition(key: string): { parent: string; answer: 'yes' | 'no' } | null {
  const m = /^(.+)\.(yes|no)$/i.exec(key);
  return m ? { parent: m[1] as string, answer: (m[2] as string).toLowerCase() as 'yes' | 'no' } : null;
}

/** The opening line every AI call must use (section 7 of the build prompt). */
export function openingLine(r: Pick<CallRequest, 'firstName' | 'client' | 'role'>): string {
  return `Hi ${r.firstName}, this is an AI assistant calling for ${r.client} about the ${r.role} role you applied for. ` +
    `This call is recorded. Is now a safe time to talk for about 8 minutes?`;
}

/** System instructions for the voice model. Built only from the published script. */
export function interviewPrompt(r: CallRequest): string {
  const qs = r.questions.map((q, i) => {
    const text = fillFacts(q.text, r);
    const cond = condition(q.key);
    const when = cond ? `ONLY IF the answer to [${cond.parent}] was ${cond.answer.toUpperCase()}: ` : '';
    const verb = q.type === 'info' ? 'Say' : 'Ask';
    const parts = [`${i + 1}. [${q.key}] ${when}${verb}: ${text}`];
    if (q.type === 'yes_no') {
      if (q.yes) parts.push(`   Counts as YES: ${q.yes}`);
      if (q.no) parts.push(`   Counts as NO: ${q.no}`);
      parts.push(`   If unclear, ask once: ${q.cross || 'Could you say a little more about that?'} If still unclear, mark needs_review.`);
      if (q.dealbreaker) parts.push('   DEALBREAKER: if the answer is clearly NO, say the matching closing line (if any), thank them politely and end the call.');
    } else if (q.type === 'recorded') {
      parts.push('   Record their answer in their own words.');
    }
    return parts.join('\n');
  }).join('\n');
  const facts = [
    `role ${r.role}`,
    r.pay ? `pay ${r.pay}` : '',
    r.address ? `location ${r.address}` : '',
    r.trainingLocation ? `training location ${r.trainingLocation}` : '',
    r.shift ? `shift ${r.shift}` : '',
    r.schedule ? `schedule ${r.schedule}` : '',
  ].filter(Boolean).join(', ');
  return [
    'You are a polite AI recruiting assistant doing a short phone screen. Follow these rules exactly:',
    '- You already said you are an AI assistant, who you call for, and that the call is recorded.',
    '- If they are driving or busy, offer to call back later and end the call.',
    '- If they ask for a person, say a recruiter will call them back, and end the call.',
    '- Never ask about national origin, citizenship (beyond being allowed to work in the US), religion, family, health, disability, or arrests.',
    '- Never judge accent, emotion or personality. You do not make hiring decisions.',
    `- Job facts you may share: ${facts}.`,
    ...r.rules.map((x) => `- ${fillFacts(x, r)}`),
    '',
    'Go through these steps in order. Skip a step marked ONLY IF when its condition is not met:',
    qs,
    '',
    'Finish by thanking them and saying the team will text them about next steps.',
  ].join('\n');
}

/** Structured output we ask the provider to extract after the call. */
export function answerSchema(questions: ScriptQuestion[]): Record<string, unknown> {
  return {
    type: 'object',
    properties: {
      answers: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            key: { type: 'string', enum: questions.map((q) => q.key) },
            heard: { type: 'string' },
            result: { type: 'string', enum: ['yes', 'no', 'needs_review', 'recorded', 'info'] },
            at: { type: 'number' },
          },
          required: ['key', 'heard', 'result'],
        },
      },
    },
    required: ['answers'],
  };
}

/** Cleans provider answers: unknown keys dropped; yes/no questions can only be yes/no/needs_review. */
export function normaliseAnswers(questions: ScriptQuestion[], raw: unknown): CallAnswer[] {
  const list = Array.isArray(raw) ? raw : [];
  const out: CallAnswer[] = [];
  for (const q of questions) {
    const a = list.find((x) => x && typeof x === 'object' && (x as { key?: unknown }).key === q.key) as
      | { heard?: unknown; result?: unknown; at?: unknown }
      | undefined;
    if (!a) continue;
    const heard = typeof a.heard === 'string' ? a.heard.slice(0, 1000) : '';
    let result = typeof a.result === 'string' ? a.result : 'needs_review';
    if (q.type === 'yes_no' && !['yes', 'no', 'needs_review'].includes(result)) result = 'needs_review';
    if (q.type === 'recorded') result = 'recorded';
    if (q.type === 'info') result = 'info';
    // A candidate is never rejected on an unclear answer: "no" with nothing heard → review.
    if (q.type === 'yes_no' && result === 'no' && heard.trim() === '') result = 'needs_review';
    out.push({
      key: q.key,
      text: q.text,
      heard,
      result: result as CallAnswer['result'],
      at: typeof a.at === 'number' && a.at >= 0 ? Math.round(a.at) : null,
    });
  }
  return out;
}
