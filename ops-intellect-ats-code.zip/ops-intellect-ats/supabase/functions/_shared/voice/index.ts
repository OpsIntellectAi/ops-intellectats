import { testProvider } from './test.ts';
import type { VoiceProvider } from './types.ts';
import { vapiConfigured, vapiProvider } from './vapi.ts';

/** Vapi when its secrets are set; otherwise the test provider (no real calls). */
export function voiceProvider(): VoiceProvider {
  return vapiConfigured() ? vapiProvider() : testProvider();
}

export * from './types.ts';
