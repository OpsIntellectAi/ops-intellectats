/**
 * Vapi adapter. Secrets: VAPI_API_KEY, VAPI_PHONE_NUMBER_ID, VAPI_WEBHOOK_SECRET.
 * Vapi calls back voice-webhook with an "end-of-call-report"; the shared secret is sent
 * in the x-vapi-secret header and checked there.
 */
import { functionsBaseUrl } from '../twilio.ts';
import { answerSchema, interviewPrompt, normaliseAnswers, openingLine } from './script.ts';
import type { CallReport, CallRequest, Outcome, ScriptQuestion, VoiceProvider } from './types.ts';

export function vapiConfigured(env: (k: string) => string | undefined = (k) => Deno.env.get(k)): boolean {
  return Boolean(env('VAPI_API_KEY') && env('VAPI_PHONE_NUMBER_ID') && env('VAPI_WEBHOOK_SECRET'));
}

export function vapiProvider(fetcher: typeof fetch = fetch): VoiceProvider {
  return {
    name: 'vapi',
    async start(r: CallRequest) {
      const res = await fetcher('https://api.vapi.ai/call', {
        method: 'POST',
        headers: { authorization: `Bearer ${Deno.env.get('VAPI_API_KEY')}`, 'content-type': 'application/json' },
        body: JSON.stringify({
          phoneNumberId: Deno.env.get('VAPI_PHONE_NUMBER_ID'),
          customer: { number: r.to },
          metadata: { callId: r.callId },
          assistant: {
            firstMessage: openingLine(r),
            model: { provider: 'openai', model: 'gpt-4o-mini', messages: [{ role: 'system', content: interviewPrompt(r) }] },
            voicemailDetection: { provider: 'twilio' },
            recordingEnabled: true,
            maxDurationSeconds: 900,
            server: { url: `${functionsBaseUrl()}/voice-webhook`, secret: Deno.env.get('VAPI_WEBHOOK_SECRET') },
            serverMessages: ['end-of-call-report'],
            analysisPlan: { structuredDataPlan: { enabled: true, schema: answerSchema(r.questions) } },
          },
        }),
      });
      const data = (await res.json().catch(() => ({}))) as { id?: string };
      if (!res.ok || !data.id) throw new Error(`Vapi start failed (${res.status})`);
      return { providerCallId: data.id };
    },
  };
}

export function mapEndedReason(reason: string): Outcome {
  const r = reason.toLowerCase();
  if (r.includes('voicemail')) return 'voicemail';
  if (r.includes('did-not-answer') || r.includes('no-answer')) return 'no_answer';
  if (r.includes('busy')) return 'busy';
  if (r.includes('ended-call') || r.includes('max-duration') || r.includes('silence-timed-out')) return 'completed';
  if (r.includes('disconnect') || r.includes('dropped')) return 'dropped';
  return 'failed';
}

interface VapiReport {
  message?: {
    type?: string;
    endedReason?: string;
    durationSeconds?: number;
    artifact?: { transcript?: string; recordingUrl?: string };
    recordingUrl?: string;
    transcript?: string;
    analysis?: { structuredData?: { answers?: unknown } };
    call?: { id?: string; metadata?: { callId?: string } };
  };
}

export function parseVapiReport(body: unknown, questions: ScriptQuestion[]): CallReport | null {
  const m = (body as VapiReport)?.message;
  if (!m || m.type !== 'end-of-call-report' || !m.call?.id) return null;
  const outcome = mapEndedReason(m.endedReason ?? '');
  return {
    providerCallId: m.call.id,
    callId: m.call.metadata?.callId ?? null,
    outcome,
    durationSeconds: typeof m.durationSeconds === 'number' ? Math.round(m.durationSeconds) : null,
    transcript: m.artifact?.transcript ?? m.transcript ?? null,
    recordingUrl: m.artifact?.recordingUrl ?? m.recordingUrl ?? null,
    answers: outcome === 'completed' ? normaliseAnswers(questions, m.analysis?.structuredData?.answers) : [],
  };
}
