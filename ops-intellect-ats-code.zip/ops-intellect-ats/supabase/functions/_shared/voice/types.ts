/**
 * One interface for every AI voice provider. Business logic (who may be called, retries,
 * answers, reviews) lives in the database and never depends on the provider.
 * Add Retell or Twilio ConversationRelay by writing another adapter with this shape.
 */

export interface ScriptQuestion {
  /** "q3" or a path like "17.yes" / "18.yes.yes": asked only when the parent's answer matches. */
  key: string;
  type: 'yes_no' | 'recorded' | 'info';
  text: string;
  yes?: string;
  no?: string;
  cross?: string;
  dealbreaker?: boolean;
}

/** Facts about the job that fill [placeholders] in the script, so one script fits every client. */
export interface JobFacts {
  /** Company (client) name. */
  client: string;
  role: string;
  pay: string | null;
  address: string | null;
  trainingLocation?: string | null;
  shift?: string | null;
  schedule?: string | null;
  minAge?: number | null;
}

export interface CallRequest extends JobFacts {
  callId: string;
  to: string;
  firstName: string;
  questions: ScriptQuestion[];
  rules: string[];
}

export interface CallAnswer {
  key: string;
  text: string;
  heard: string;
  result: 'yes' | 'no' | 'needs_review' | 'recorded' | 'info';
  at: number | null;
}

export type Outcome = 'completed' | 'voicemail' | 'no_answer' | 'busy' | 'failed' | 'dropped';

/** What every provider's "call ended" webhook is turned into. */
export interface CallReport {
  providerCallId: string;
  callId: string | null;
  outcome: Outcome;
  durationSeconds: number | null;
  transcript: string | null;
  recordingUrl: string | null;
  answers: CallAnswer[];
  /** Test mode only: a recording already in the private bucket, and a ready overview. */
  recordingPath?: string | null;
  summary?: string | null;
}

export interface VoiceProvider {
  readonly name: 'vapi' | 'test';
  start(req: CallRequest): Promise<{ providerCallId: string }>;
}
