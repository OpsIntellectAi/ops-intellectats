/**
 * Tiny assertion helpers on top of Node's built-in assert (bundled in Deno),
 * so tests run without downloading anything.
 */
import nodeAssert from 'node:assert/strict';

export function assert(cond: unknown, msg?: string): asserts cond {
  nodeAssert.ok(cond, msg);
}

export function assertEquals<T>(actual: T, expected: T, msg?: string): void {
  nodeAssert.deepStrictEqual(actual, expected, msg);
}

export function assertNotEquals<T>(actual: T, expected: T, msg?: string): void {
  nodeAssert.notDeepStrictEqual(actual, expected, msg);
}

// deno-lint-ignore no-explicit-any
type ErrorClass<E> = new (...args: any[]) => E;

export function assertThrows<E extends Error = Error>(fn: () => unknown, cls?: ErrorClass<E>): E {
  try {
    fn();
  } catch (e) {
    if (cls && !(e instanceof cls)) throw new Error(`Expected ${cls.name}, got ${String(e)}`);
    return e as E;
  }
  throw new Error('Expected function to throw');
}

export async function assertRejects<E extends Error = Error>(fn: () => Promise<unknown>, cls?: ErrorClass<E>): Promise<E> {
  try {
    await fn();
  } catch (e) {
    if (cls && !(e instanceof cls)) throw new Error(`Expected ${cls.name}, got ${String(e)}`);
    return e as E;
  }
  throw new Error('Expected promise to reject');
}
