/**
 * Wraps a browser-facing Edge Function: allowed-origin check, preflight, and safe
 * error responses (no stack traces or provider messages ever reach the browser).
 */
import { allowedOrigins, corsHeaders, guardCors, resolveOrigins } from './cors.ts';
import { errorResponse } from './http.ts';
import { adminClient } from './supabase.ts';

export async function handleBrowserRequest(
  req: Request,
  fn: (cors: Record<string, string>) => Promise<Response>,
): Promise<Response> {
  let origins: string[];
  try {
    origins = await resolveOrigins(adminClient);
  } catch {
    origins = allowedOrigins();
  }
  const cors = corsHeaders(req, origins);
  try {
    const pre = guardCors(req, origins);
    if (pre) return pre;
    return await fn(cors);
  } catch (err) {
    return errorResponse(err, cors);
  }
}
