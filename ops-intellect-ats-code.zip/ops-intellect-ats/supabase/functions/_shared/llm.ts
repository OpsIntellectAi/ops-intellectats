/**
 * LLM adapter. Called ONLY from Edge Functions.
 * Secrets: LLM_PROVIDER ("anthropic" | "openai"), ANTHROPIC_API_KEY or OPENAI_API_KEY,
 * optional LLM_MODEL. Without a key the adapter runs in TEST MODE with simple,
 * deterministic answers so the screens and limits can be checked.
 * Guardrails: we send IDs and numbers, not names, wherever possible; prompts forbid
 * inferring protected traits or scoring accent, emotion or personality.
 */

export interface LlmTool {
  name: string;
  description: string;
  schema: Record<string, unknown>;
  run: (input: Record<string, unknown>) => Promise<unknown>;
}

export interface ToolRunResult {
  text: string;
  toolsUsed: { name: string; input: Record<string, unknown> }[];
}

export const GUARDRAILS =
  'Never guess or mention protected traits (race, national origin, religion, sex, age, disability, health, family). ' +
  'Never judge accent, emotion or personality. People make every hiring decision; you only summarise facts.';

type Provider = 'anthropic' | 'openai' | 'test';

export function llmProvider(env: (k: string) => string | undefined = (k) => Deno.env.get(k)): Provider {
  const wanted = (env('LLM_PROVIDER') ?? '').toLowerCase();
  if (wanted === 'openai' && env('OPENAI_API_KEY')) return 'openai';
  if (wanted === 'anthropic' && env('ANTHROPIC_API_KEY')) return 'anthropic';
  if (env('ANTHROPIC_API_KEY')) return 'anthropic';
  if (env('OPENAI_API_KEY')) return 'openai';
  return 'test';
}

function model(p: Provider): string {
  return Deno.env.get('LLM_MODEL') ?? (p === 'openai' ? 'gpt-4o-mini' : 'claude-haiku-5-5');
}

/** One plain completion (summaries, overviews, wording suggestions). */
export async function complete(system: string, user: string, maxTokens = 600, fetcher: typeof fetch = fetch): Promise<string> {
  const p = llmProvider();
  if (p === 'test') return testComplete(user);
  if (p === 'anthropic') {
    const data = await anthropic({ system: `${system}\n${GUARDRAILS}`, messages: [{ role: 'user', content: user }], max_tokens: maxTokens }, fetcher);
    return textOf(data.content);
  }
  const data = await openai({
    messages: [{ role: 'system', content: `${system}\n${GUARDRAILS}` }, { role: 'user', content: user }],
    max_tokens: maxTokens,
  }, fetcher);
  return data.choices?.[0]?.message?.content?.trim() ?? '';
}

/**
 * Lets the model call approved read-only tools (each one runs with the asking user's own
 * permissions), up to maxSteps rounds, then returns the final answer.
 */
export async function runWithTools(
  system: string,
  question: string,
  tools: LlmTool[],
  maxSteps = 4,
  fetcher: typeof fetch = fetch,
): Promise<ToolRunResult> {
  const p = llmProvider();
  const used: ToolRunResult['toolsUsed'] = [];
  const byName = new Map(tools.map((t) => [t.name, t]));
  const call = async (name: string, input: Record<string, unknown>) => {
    const t = byName.get(name);
    if (!t) return { error: 'unknown tool' };
    used.push({ name, input });
    try {
      return await t.run(input);
    } catch (e) {
      return { error: e instanceof Error ? e.message : 'tool failed' };
    }
  };

  if (p === 'test') return testTools(question, tools, call, used);

  if (p === 'anthropic') {
    // deno-lint-ignore no-explicit-any
    const messages: any[] = [{ role: 'user', content: question }];
    for (let step = 0; step < maxSteps; step++) {
      const data = await anthropic({
        system: `${system}\n${GUARDRAILS}`,
        messages,
        max_tokens: 900,
        tools: tools.map((t) => ({ name: t.name, description: t.description, input_schema: t.schema })),
      }, fetcher);
      const uses = (data.content ?? []).filter((b: { type: string }) => b.type === 'tool_use');
      if (!uses.length) return { text: textOf(data.content), toolsUsed: used };
      messages.push({ role: 'assistant', content: data.content });
      const results = [];
      for (const u of uses) {
        const out = await call(u.name, (u.input ?? {}) as Record<string, unknown>);
        results.push({ type: 'tool_result', tool_use_id: u.id, content: JSON.stringify(out).slice(0, 12000) });
      }
      messages.push({ role: 'user', content: results });
    }
    return { text: 'I could not finish that question. Please ask it in a simpler way.', toolsUsed: used };
  }

  // deno-lint-ignore no-explicit-any
  const messages: any[] = [{ role: 'system', content: `${system}\n${GUARDRAILS}` }, { role: 'user', content: question }];
  for (let step = 0; step < maxSteps; step++) {
    const data = await openai({
      messages,
      max_tokens: 900,
      tools: tools.map((t) => ({ type: 'function', function: { name: t.name, description: t.description, parameters: t.schema } })),
    }, fetcher);
    const msg = data.choices?.[0]?.message;
    const calls = msg?.tool_calls ?? [];
    if (!calls.length) return { text: (msg?.content ?? '').trim(), toolsUsed: used };
    messages.push(msg);
    for (const c of calls) {
      let input: Record<string, unknown> = {};
      try {
        input = JSON.parse(c.function?.arguments ?? '{}');
      } catch { /* empty input */ }
      const out = await call(c.function?.name ?? '', input);
      messages.push({ role: 'tool', tool_call_id: c.id, content: JSON.stringify(out).slice(0, 12000) });
    }
  }
  return { text: 'I could not finish that question. Please ask it in a simpler way.', toolsUsed: used };
}

// ---------- providers ----------
// deno-lint-ignore no-explicit-any
async function anthropic(body: Record<string, unknown>, fetcher: typeof fetch): Promise<any> {
  const res = await fetcher('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': Deno.env.get('ANTHROPIC_API_KEY') ?? '',
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    body: JSON.stringify({ model: model('anthropic'), ...body }),
  });
  if (!res.ok) throw new Error(`AI provider error (${res.status})`);
  return await res.json();
}

// deno-lint-ignore no-explicit-any
async function openai(body: Record<string, unknown>, fetcher: typeof fetch): Promise<any> {
  const res = await fetcher('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { authorization: `Bearer ${Deno.env.get('OPENAI_API_KEY') ?? ''}`, 'content-type': 'application/json' },
    // store: false → OpenAI does not keep the conversation for its own use.
    body: JSON.stringify({ model: model('openai'), store: false, ...body }),
  });
  if (!res.ok) throw new Error(`AI provider error (${res.status})`);
  return await res.json();
}

function textOf(content: unknown): string {
  if (!Array.isArray(content)) return '';
  return content.filter((b) => b?.type === 'text').map((b) => String(b.text)).join('\n').trim();
}

// ---------- test mode ----------
function testComplete(user: string): string {
  const firstLine = user.split('\n').find((l) => l.trim()) ?? '';
  return `[Test AI] Summary based on the facts given. ${firstLine.slice(0, 160)}`.trim();
}

/** Picks a tool by keywords so the assistant screen works without an AI key. */
async function testTools(
  q: string,
  tools: LlmTool[],
  call: (name: string, input: Record<string, unknown>) => Promise<unknown>,
  used: ToolRunResult['toolsUsed'],
): Promise<ToolRunResult> {
  const s = q.toLowerCase();
  const stage = ['interview', 'shortlisted', 'pre_onboarding', 'onboarding', 'hired', 'not_interested', 'rejected']
    .find((x) => s.includes(x.replace('_', ' ')) || s.includes(x.replace('_', '-')) || s.includes(x));
  let name = 'count_applications';
  if (/funnel|drop/.test(s)) name = 'funnel';
  else if (/call/.test(s)) name = 'call_stats';
  else if (/stuck|stall|invite|dsp|onboarding step/.test(s)) name = 'onboarding_stalls';
  else if (/who|list|which|names?/.test(s)) name = 'list_applications';
  if (!tools.some((t) => t.name === name)) name = tools[0]?.name ?? '';
  const input: Record<string, unknown> = stage ? { stage } : {};
  if (/this week|7 days/.test(s)) input.days = 7;
  const out = await call(name, input);
  return { text: `[Test AI] ${name.replace('_', ' ')}: ${JSON.stringify(out).slice(0, 600)}`, toolsUsed: used };
}
