import { assertEquals } from './testing.ts';
import { isOn } from './features.ts';

Deno.test('toggles: missing = ON, only false turns a feature off', () => {
  assertEquals(isOn({}, 'ai_calls'), true);
  assertEquals(isOn(null, 'ai_calls'), true);
  assertEquals(isOn({ ai_calls: false }, 'ai_calls'), false);
  assertEquals(isOn({ ai_calls: true }, 'ai_calls'), true);
  assertEquals(isOn({ bulk_texts: false }, 'ai_calls'), true);
});
