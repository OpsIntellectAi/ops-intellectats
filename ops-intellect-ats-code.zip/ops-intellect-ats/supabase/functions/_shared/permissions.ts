/**
 * Permission names. The source of truth is the role_permissions table (migration 0008);
 * the server always asks the database. This list exists so TypeScript catches typos.
 */
export const PERMISSIONS = [
  'view',
  'candidates.act',
  'messages.send',
  'onboarding.update',
  'calls.review',
  'reports.view',
  'assistant.use',
  'candidates.assign',
  'audit.view',
  'audit.view_all',
  'templates.edit',
  'settings.edit',
  'reports.manage',
  'users.manage',
  'platform.admin',
] as const;

export type Permission = (typeof PERMISSIONS)[number];

export const ROLES = [
  'csr',
  'supervisor',
  'admin',
  'super_admin',
  'ops',
  'station_manager',
  'dsp_manager',
  'viewer',
] as const;

export type AppRole = (typeof ROLES)[number];

/** Shape returned by the SQL function public.my_access(). */
export interface MyAccess {
  user_id: string;
  full_name: string;
  email: string;
  role: AppRole;
  status: 'pending' | 'active' | 'disabled';
  session_ok: boolean;
  mfa_required: boolean;
  mfa_ok: boolean;
  effective_role: AppRole | null;
  permissions: Permission[];
}

export function isPermission(value: string): value is Permission {
  return (PERMISSIONS as readonly string[]).includes(value);
}

/** Why a signed-in user currently has no access (for a clear message). */
export function accessBlockReason(a: MyAccess): string | null {
  if (a.status === 'pending') return 'Your account is waiting for a Super Admin to give you access.';
  if (a.status === 'disabled') return 'Your account is turned off. Ask your Admin.';
  if (!a.session_ok) return 'Your session has ended (12-hour limit). Please sign in again.';
  if (a.mfa_required && !a.mfa_ok) return 'Finish two-step verification to continue.';
  if (!a.effective_role) return 'You do not have access.';
  return null;
}
