import { assert, assertEquals, assertNotEquals, assertRejects, assertThrows } from './testing.ts';
import { z } from 'zod';
import { decryptField, encryptField, importFieldKey, maskTail } from './crypto.ts';
import { allowedOrigins, corsHeaders, guardCors } from './cors.ts';
import { clientIp, errorResponse, HttpError } from './http.ts';
import { parseBody } from './validate.ts';
import { accessBlockReason, isPermission, type MyAccess } from './permissions.ts';
import { auditRow } from './audit.ts';
import { limitKey } from './rate-limit.ts';
import { requireAuth, requirePermission, type AuthDeps } from './auth.ts';

// ---------- crypto ----------
const KEY_B64 = btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(32))));

Deno.test('AES-GCM round trip, random IV every time', async () => {
  const key = await importFieldKey(KEY_B64);
  const a = await encryptField('D1234-5678-90', key);
  const b = await encryptField('D1234-5678-90', key);
  assert(a.startsWith('v1:'));
  assertNotEquals(a, b);
  assertEquals(await decryptField(a, key), 'D1234-5678-90');
});

Deno.test('tampered ciphertext and wrong key both fail', async () => {
  const key = await importFieldKey(KEY_B64);
  const other = await importFieldKey(btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(32)))));
  const enc = await encryptField('1990-01-31', key);
  const raw = atob(enc.slice(3));
  const flipped = 'v1:' + btoa(raw.slice(0, -1) + String.fromCharCode(raw.charCodeAt(raw.length - 1) ^ 1));
  await assertRejects(() => decryptField(flipped, key));
  await assertRejects(() => decryptField(enc, other));
});

Deno.test('key must be 32 bytes', async () => {
  await assertRejects(() => importFieldKey(btoa('short')));
});

Deno.test('mask keeps last 4', () => {
  assertEquals(maskTail('D12345678'), '•••••5678');
});

// ---------- CORS ----------
Deno.test('only listed origins are allowed', () => {
  const origins = allowedOrigins('https://app.example.com, https://staging.example.com/ ,javascript:alert(1)');
  assertEquals(origins, ['https://app.example.com', 'https://staging.example.com']);
  const ok = new Request('https://fn', { method: 'OPTIONS', headers: { origin: 'https://app.example.com' } });
  assertEquals(guardCors(ok, origins)?.status, 204);
  assertEquals(corsHeaders(ok, origins)['access-control-allow-origin'], 'https://app.example.com');
  const bad = new Request('https://fn', { method: 'POST', headers: { origin: 'https://evil.example' } });
  assertThrows(() => guardCors(bad, origins), HttpError);
  const server = new Request('https://fn', { method: 'POST' });
  assertEquals(guardCors(server, origins), null);
});

// ---------- HTTP ----------
Deno.test('unexpected errors never leak details', async () => {
  const res = errorResponse(new Error('relation "secret_table" does not exist'));
  assertEquals(res.status, 500);
  assert(!(await res.text()).includes('secret_table'));
});

Deno.test('client IP is the first forwarded address, validated', () => {
  assertEquals(clientIp(new Request('https://x', { headers: { 'x-forwarded-for': '203.0.113.5, 10.0.0.1' } })), '203.0.113.5');
  assertEquals(clientIp(new Request('https://x', { headers: { 'x-forwarded-for': '<script>' } })), null);
});

// ---------- validation ----------
const Schema = z.object({ name: z.string().min(2) });
const post = (body: string, type = 'application/json') =>
  new Request('https://x', { method: 'POST', headers: { 'content-type': type }, body });

Deno.test('valid body passes, bad body is a 400', async () => {
  assertEquals(await parseBody(post('{"name":"Ana"}'), Schema), { name: 'Ana' });
  const e = await assertRejects(() => parseBody(post('{"name":"A"}'), Schema), HttpError);
  assertEquals(e.status, 400);
  const j = await assertRejects(() => parseBody(post('{oops'), Schema), HttpError);
  assertEquals(j.code, 'bad_json');
  const t = await assertRejects(() => parseBody(post('{}', 'text/plain'), Schema), HttpError);
  assertEquals(t.status, 415);
  const big = await assertRejects(() => parseBody(post(JSON.stringify({ name: 'x'.repeat(70000) })), Schema), HttpError);
  assertEquals(big.status, 413);
});

// ---------- permissions ----------
const access = (over: Partial<MyAccess> = {}): MyAccess => ({
  user_id: 'u1', full_name: 'Test', email: 't@example.com', role: 'csr', status: 'active',
  session_ok: true, mfa_required: false, mfa_ok: true, effective_role: 'csr', permissions: ['view', 'candidates.act'],
  ...over,
});

Deno.test('block reasons are clear', () => {
  assertEquals(accessBlockReason(access()), null);
  assert(accessBlockReason(access({ status: 'pending', effective_role: null }))?.includes('waiting'));
  assert(accessBlockReason(access({ role: 'admin', mfa_required: true, mfa_ok: false, effective_role: null }))?.includes('two-step'));
  assert(accessBlockReason(access({ session_ok: false, effective_role: null }))?.includes('12-hour'));
  assert(isPermission('platform.admin'));
  assert(!isPermission('drop.tables'));
});

// ---------- audit ----------
Deno.test('audit row records device, IP and trims long values', () => {
  const req = new Request('https://x', { headers: { 'x-forwarded-for': '198.51.100.7', 'user-agent': 'UA' } });
  const row = auditRow(req, { userId: 'u1', role: 'admin', deviceKey: 'd1' }, { action: 'Test', after: 'y'.repeat(5000) });
  assertEquals(row.ip, '198.51.100.7');
  assertEquals(row.device_key, 'd1');
  assertEquals((row.after_value as string).length, 2000);
});

Deno.test('rate limit keys are per user / per client', () => {
  assertEquals(limitKey('sendText', 'client', 'c1'), 'sendText:client:c1');
});

// ---------- auth gate with fake Supabase clients (no network) ----------
// deno-lint-ignore no-explicit-any
type Any = any;
function fakeDeps(opts: { user?: boolean; access?: MyAccess | null; blocked?: boolean }): AuthDeps {
  const user = {
    auth: { getUser: () => Promise.resolve(opts.user === false ? { data: { user: null }, error: { message: 'bad' } } : { data: { user: { id: 'u1' } }, error: null }) },
    rpc: () => Promise.resolve({ data: opts.access === undefined ? access() : opts.access, error: null }),
  };
  const chain: Any = {
    select: () => chain, eq: () => chain,
    maybeSingle: () => Promise.resolve({ data: opts.blocked ? { blocked: true } : null, error: null }),
  };
  const admin = { from: () => chain };
  return { user: () => user as Any, admin: () => admin as Any };
}
const authed = (headers: Record<string, string> = {}) =>
  new Request('https://x', { method: 'POST', headers: { authorization: 'Bearer token', ...headers } });

Deno.test('no token → 401', async () => {
  const e = await assertRejects(() => requireAuth(new Request('https://x'), {}, fakeDeps({})), HttpError);
  assertEquals(e.status, 401);
});

Deno.test('invalid token → 401', async () => {
  const e = await assertRejects(() => requireAuth(authed(), {}, fakeDeps({ user: false })), HttpError);
  assertEquals(e.status, 401);
});

Deno.test('pending account / missing MFA → 403', async () => {
  const p = await assertRejects(() => requireAuth(authed(), {}, fakeDeps({ access: access({ status: 'pending', effective_role: null }) })), HttpError);
  assertEquals(p.status, 403);
  const m = await assertRejects(
    () => requireAuth(authed(), {}, fakeDeps({ access: access({ role: 'super_admin', mfa_required: true, mfa_ok: false, effective_role: null }) })),
    HttpError,
  );
  assertEquals(m.status, 403);
});

Deno.test('blocked computer → 403, allowed with allowBlocked (sign-in recorder)', async () => {
  const dev = { 'x-device-id': '3f2b8c1a-1111-4222-8333-444455556666' };
  const e = await assertRejects(() => requireAuth(authed(dev), {}, fakeDeps({ blocked: true })), HttpError);
  assertEquals(e.code, 'device_blocked');
  const ctx = await requireAuth(authed(dev), { allowBlocked: true }, fakeDeps({ blocked: true }));
  assertEquals(ctx.userId, 'u1');
});

Deno.test('permission check uses the database list', async () => {
  const ctx = await requireAuth(authed(), {}, fakeDeps({}));
  requirePermission(ctx, 'candidates.act');
  assertThrows(() => requirePermission(ctx, 'platform.admin'), HttpError);
});
