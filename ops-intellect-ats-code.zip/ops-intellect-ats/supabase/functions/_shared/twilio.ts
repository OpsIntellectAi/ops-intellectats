/**
 * Twilio over its REST API (no SDK download needed in Edge Functions).
 * - Secrets: TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, optional TWILIO_FROM_NUMBER
 *   (used when a client has no Messaging Service SID yet).
 * - Without those secrets the app runs in TEST MODE: nothing is sent, messages are
 *   marked "test_sent" so every screen and rule can still be checked.
 * - Webhook signatures follow Twilio's documented algorithm (the same one the SDK's
 *   validateRequest uses): base64(HMAC-SHA1(authToken, url + sorted key/value pairs)).
 */

export interface TwilioConfig {
  accountSid: string;
  authToken: string;
  fromNumber: string | null;
}

export function twilioConfig(env: (k: string) => string | undefined = (k) => Deno.env.get(k)): TwilioConfig | null {
  const accountSid = env('TWILIO_ACCOUNT_SID') ?? '';
  const authToken = env('TWILIO_AUTH_TOKEN') ?? '';
  if (!/^AC[0-9a-f]{32}$/.test(accountSid) || authToken.length < 16) return null;
  const from = env('TWILIO_FROM_NUMBER') ?? '';
  return { accountSid, authToken, fromNumber: /^\+[1-9][0-9]{7,14}$/.test(from) ? from : null };
}

export function functionsBaseUrl(): string {
  return `${(Deno.env.get('SUPABASE_URL') ?? '').replace(/\/$/, '')}/functions/v1`;
}

function basicAuth(cfg: TwilioConfig): string {
  return 'Basic ' + btoa(`${cfg.accountSid}:${cfg.authToken}`);
}

export interface SendResult {
  sid: string;
  status: string;
}

export async function sendSms(
  cfg: TwilioConfig,
  msg: { to: string; body: string; messagingServiceSid: string | null; statusCallback: string },
  fetcher: typeof fetch = fetch,
): Promise<SendResult> {
  const form = new URLSearchParams({ To: msg.to, Body: msg.body, StatusCallback: msg.statusCallback });
  if (msg.messagingServiceSid) form.set('MessagingServiceSid', msg.messagingServiceSid);
  else if (cfg.fromNumber) form.set('From', cfg.fromNumber);
  else throw new Error('No Messaging Service SID for this client and no TWILIO_FROM_NUMBER');
  const res = await fetcher(`https://api.twilio.com/2010-04-01/Accounts/${cfg.accountSid}/Messages.json`, {
    method: 'POST',
    headers: { authorization: basicAuth(cfg), 'content-type': 'application/x-www-form-urlencoded' },
    body: form,
  });
  const data = (await res.json().catch(() => ({}))) as { sid?: string; status?: string; code?: number };
  if (!res.ok || !data.sid) throw new TwilioError(data.code ? String(data.code) : `http_${res.status}`);
  return { sid: data.sid, status: data.status ?? 'queued' };
}

export class TwilioError extends Error {
  constructor(public readonly code: string) {
    super(`Twilio error ${code}`);
    this.name = 'TwilioError';
  }
}

/** Escapes text for TwiML. */
export function xml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

export function twiml(inner = ''): Response {
  return new Response(`<?xml version="1.0" encoding="UTF-8"?><Response>${inner}</Response>`, {
    status: 200,
    headers: { 'content-type': 'text/xml; charset=utf-8', 'cache-control': 'no-store' },
  });
}

/**
 * CSR call: Twilio rings the recruiter first, then dials the candidate. The candidate
 * hears the recording notice (whisper URL) before they are connected; both sides recorded.
 */
export async function startCsrCall(
  cfg: TwilioConfig,
  c: { csrPhone: string; candidatePhone: string; callId: string },
  fetcher: typeof fetch = fetch,
): Promise<SendResult> {
  if (!cfg.fromNumber) throw new Error('TWILIO_FROM_NUMBER is needed for phone calls');
  const base = functionsBaseUrl();
  const notice = `${base}/twilio-webhook?kind=disclosure`;
  const status = `${base}/twilio-webhook?kind=call&amp;call=${c.callId}`;
  const body =
    `<Response><Say>Connecting you to the candidate. This call is recorded.</Say>` +
    `<Dial callerId="${xml(cfg.fromNumber)}" record="record-from-answer-dual" recordingStatusCallback="${status}">` +
    `<Number url="${xml(notice)}">${xml(c.candidatePhone)}</Number></Dial></Response>`;
  const form = new URLSearchParams({
    To: c.csrPhone,
    From: cfg.fromNumber,
    Twiml: body,
    StatusCallback: `${base}/twilio-webhook?kind=call&call=${c.callId}`,
  });
  form.append('StatusCallbackEvent', 'completed');
  const res = await fetcher(`https://api.twilio.com/2010-04-01/Accounts/${cfg.accountSid}/Calls.json`, {
    method: 'POST',
    headers: { authorization: basicAuth(cfg), 'content-type': 'application/x-www-form-urlencoded' },
    body: form,
  });
  const data = (await res.json().catch(() => ({}))) as { sid?: string; status?: string; code?: number };
  if (!res.ok || !data.sid) throw new TwilioError(data.code ? String(data.code) : `http_${res.status}`);
  return { sid: data.sid, status: data.status ?? 'queued' };
}

// ---------- webhook signatures ----------
export async function twilioSignature(authToken: string, url: string, params: Record<string, string>): Promise<string> {
  const data = url + Object.keys(params).sort().map((k) => k + params[k]).join('');
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(authToken), { name: 'HMAC', hash: 'SHA-1' }, false, [
    'sign',
  ]);
  const sig = new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(data)));
  return btoa(String.fromCharCode(...sig));
}

export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export async function validateTwilioRequest(
  authToken: string,
  signature: string | null,
  url: string,
  params: Record<string, string>,
): Promise<boolean> {
  if (!signature) return false;
  return safeEqual(await twilioSignature(authToken, url, params), signature);
}

/** The public URL Twilio called (Edge Functions see an internal URL; the query string is kept). */
export function publicUrl(req: Request, fn: string): string {
  const u = new URL(req.url);
  return `${functionsBaseUrl()}/${fn}${u.search}`;
}
