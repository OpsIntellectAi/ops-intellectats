/**
 * Rate limits per user and per client, counted in Postgres (public.hit_rate_limit).
 * Limits are per fixed window. Values here are the defaults from the build prompt.
 */
import type { SupabaseClient } from '@supabase/supabase-js';
import { HttpError } from './http.ts';

export const LIMITS = {
  signIn: { limit: 20, windowSeconds: 3600 },
  sendText: { limit: 120, windowSeconds: 3600 },
  startCall: { limit: 60, windowSeconds: 3600 },
  bulkAction: { limit: 10, windowSeconds: 3600 },
  assistant: { limit: 60, windowSeconds: 3600 },
  invite: { limit: 30, windowSeconds: 3600 },
  selfService: { limit: 40, windowSeconds: 3600 },
  export: { limit: 20, windowSeconds: 3600 },
} as const;

export type LimitName = keyof typeof LIMITS;

export function limitKey(name: LimitName, scope: 'user' | 'client' | 'token', id: string): string {
  return `${name}:${scope}:${id}`;
}

export async function enforceRateLimit(
  admin: SupabaseClient,
  name: LimitName,
  scope: 'user' | 'client' | 'token',
  id: string,
): Promise<void> {
  const { limit, windowSeconds } = LIMITS[name];
  const { data, error } = await admin.rpc('hit_rate_limit', {
    p_key: limitKey(name, scope, id),
    p_limit: limit,
    p_window_seconds: windowSeconds,
  });
  if (error) throw new Error('rate limit check failed');
  if (data !== true) throw new HttpError(429, 'rate_limited', 'Too many requests. Please wait a few minutes.');
}
