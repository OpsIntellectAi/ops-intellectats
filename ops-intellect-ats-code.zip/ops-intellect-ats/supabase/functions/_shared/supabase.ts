/**
 * Supabase clients for Edge Functions.
 * - userClient: acts AS the caller (their JWT) so RLS and helper functions apply to them.
 * - adminClient: service role, bypasses RLS. Use only after the caller was checked,
 *   and never return its raw results to the browser without filtering.
 */
import { createClient, type SupabaseClient } from '@supabase/supabase-js';

function env(name: string): string {
  const v = Deno.env.get(name);
  if (!v) throw new Error(`Missing function secret ${name}`);
  return v;
}

export function userClient(authorization: string): SupabaseClient {
  return createClient(env('SUPABASE_URL'), env('SUPABASE_ANON_KEY'), {
    global: { headers: { Authorization: authorization } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

let admin: SupabaseClient | null = null;
export function adminClient(): SupabaseClient {
  if (!admin) {
    admin = createClient(env('SUPABASE_URL'), env('SUPABASE_SERVICE_ROLE_KEY'), {
      auth: { persistSession: false, autoRefreshToken: false },
    });
  }
  return admin;
}
