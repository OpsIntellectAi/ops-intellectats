/** HTTP helpers shared by every Edge Function. */

export class HttpError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
  ) {
    super(message);
    this.name = 'HttpError';
  }
}

export function json(body: unknown, status = 200, headers: HeadersInit = {}): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers },
  });
}

/**
 * Turns any thrown value into a safe response. Unexpected errors never leak details
 * (stack traces, SQL, provider messages) to the browser.
 */
export function errorResponse(err: unknown, headers: HeadersInit = {}): Response {
  if (err instanceof HttpError) {
    return json({ error: { code: err.code, message: err.message } }, err.status, headers);
  }
  console.error('unexpected error', err instanceof Error ? err.message : String(err));
  return json({ error: { code: 'internal', message: 'Something went wrong. Please try again.' } }, 500, headers);
}

/** First IP from x-forwarded-for (set by the Supabase edge), or null. */
export function clientIp(req: Request): string | null {
  const raw = req.headers.get('x-forwarded-for') ?? req.headers.get('x-real-ip');
  if (!raw) return null;
  const first = raw.split(',')[0]?.trim() ?? '';
  return /^[0-9a-fA-F:.]{3,45}$/.test(first) ? first : null;
}
