/** Input validation: every function parses its body with a Zod schema before doing anything. */
import { z } from 'zod';
import { HttpError } from './http.ts';

const MAX_BODY_BYTES = 64 * 1024;

export async function parseBody<T extends z.ZodTypeAny>(req: Request, schema: T): Promise<z.infer<T>> {
  if (req.method !== 'POST') throw new HttpError(405, 'method_not_allowed', 'Use POST.');
  const type = req.headers.get('content-type') ?? '';
  if (!type.includes('application/json')) throw new HttpError(415, 'unsupported_type', 'Send JSON.');
  const text = await req.text();
  if (text.length > MAX_BODY_BYTES) throw new HttpError(413, 'too_large', 'Request is too large.');
  let data: unknown;
  try {
    data = text.length ? JSON.parse(text) : {};
  } catch {
    throw new HttpError(400, 'bad_json', 'Request is not valid JSON.');
  }
  const result = schema.safeParse(data);
  if (!result.success) {
    const first = result.error.issues[0];
    const where = first?.path.join('.') || 'body';
    throw new HttpError(400, 'invalid_input', `Invalid ${where}: ${first?.message ?? 'bad value'}`);
  }
  return result.data;
}

export const uuid = z.string().uuid();
