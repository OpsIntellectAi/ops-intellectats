/**
 * Field-level encryption (AES-256-GCM) for sensitive fields such as the driver's licence
 * number and date of birth. Runs only inside Edge Functions. The key lives in the
 * function secret FIELD_ENCRYPTION_KEY (32 random bytes, base64) and never reaches the browser.
 *
 * Stored format: "v1:" + base64(12-byte IV || ciphertext+tag)
 */

const PREFIX = 'v1:';

function b64ToBytes(b64: string): Uint8Array<ArrayBuffer> {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function bytesToB64(bytes: Uint8Array): string {
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin);
}

export async function importFieldKey(keyB64: string): Promise<CryptoKey> {
  const raw = b64ToBytes(keyB64);
  if (raw.length !== 32) throw new Error('FIELD_ENCRYPTION_KEY must be 32 bytes (base64)');
  return await crypto.subtle.importKey('raw', raw, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
}

export async function encryptField(plain: string, key: CryptoKey): Promise<string> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(plain)));
  const packed = new Uint8Array(iv.length + ct.length);
  packed.set(iv, 0);
  packed.set(ct, iv.length);
  return PREFIX + bytesToB64(packed);
}

export async function decryptField(stored: string, key: CryptoKey): Promise<string> {
  if (!stored.startsWith(PREFIX)) throw new Error('Unknown ciphertext format');
  const packed = b64ToBytes(stored.slice(PREFIX.length));
  if (packed.length < 13 + 16) throw new Error('Ciphertext too short');
  const iv = packed.slice(0, 12);
  const ct = packed.slice(12);
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ct);
  return new TextDecoder().decode(pt);
}

/** Only the last 4 characters, for showing in the app ("••••1234"). */
export function maskTail(value: string, keep = 4): string {
  const tail = value.slice(-keep);
  return '•'.repeat(Math.max(0, Math.min(8, value.length - keep))) + tail;
}
