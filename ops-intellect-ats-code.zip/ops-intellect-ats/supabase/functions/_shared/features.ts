/**
 * Super Admin feature toggles (client_settings.features). A missing key means ON.
 * Read with the service-role client so it also works for webhooks and the scheduler.
 */
import type { SupabaseClient } from '@supabase/supabase-js';
import { HttpError } from './http.ts';

export type FeatureKey =
  | 'auto_texts' | 'follow_ups' | 'booking_reminders' | 'ai_calls' | 'bulk_ai_calls' | 'phone_calls'
  | 'bulk_texts' | 'ai_overview' | 'ai_assistant' | 'alerts' | 'weekly_report' | 'self_service'
  | 'message_popups' | 'csv_export' | 'bulk_upload';

export const FEATURE_OFF_MESSAGE: Record<FeatureKey, string> = {
  auto_texts: 'Automatic texts are turned off for this client.',
  follow_ups: 'Follow-up texts are turned off for this client.',
  booking_reminders: 'Booking reminders are turned off for this client.',
  ai_calls: 'AI calls are turned off for this client.',
  bulk_ai_calls: 'Bulk AI calls are turned off for this client.',
  phone_calls: 'Phone calls are turned off for this client.',
  bulk_texts: 'Bulk texts are turned off for this client.',
  ai_overview: 'AI overviews are turned off for this client.',
  ai_assistant: 'The assistant is turned off for this client.',
  alerts: 'Alerts are turned off for this client.',
  weekly_report: 'The weekly report is turned off for this client.',
  self_service: 'This link is not active.',
  message_popups: 'Message pop-ups are turned off for this client.',
  csv_export: 'CSV download is turned off for this client.',
  bulk_upload: 'Bulk upload is turned off for this client.',
};

export function isOn(features: unknown, key: FeatureKey): boolean {
  if (!features || typeof features !== 'object') return true;
  const v = (features as Record<string, unknown>)[key];
  return v !== false;
}

export async function featureOn(admin: SupabaseClient, clientId: string, key: FeatureKey): Promise<boolean> {
  const { data } = await admin.from('client_settings').select('features').eq('client_id', clientId).maybeSingle();
  return isOn((data as { features?: unknown } | null)?.features, key);
}

export async function requireFeature(admin: SupabaseClient, clientId: string, key: FeatureKey, status = 409): Promise<void> {
  if (!(await featureOn(admin, clientId, key))) throw new HttpError(status, 'feature_off', FEATURE_OFF_MESSAGE[key]);
}
