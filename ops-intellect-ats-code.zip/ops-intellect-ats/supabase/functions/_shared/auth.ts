/**
 * Every Edge Function that acts for a user starts with requireAuth().
 * It: verifies the JWT with Supabase Auth, loads the caller's level from the database
 * (status, MFA, 12-hour session, permissions), refuses blocked devices, and returns
 * clients that act as the caller (RLS applies) or as the service.
 */
import type { SupabaseClient } from '@supabase/supabase-js';
import { HttpError } from './http.ts';
import { accessBlockReason, type MyAccess, type Permission } from './permissions.ts';
import { adminClient, userClient } from './supabase.ts';

export interface AuthContext {
  userId: string;
  access: MyAccess;
  deviceKey: string | null;
  user: SupabaseClient;
  admin: SupabaseClient;
}

const DEVICE_KEY = /^[0-9a-f-]{36}$/;

export interface AuthDeps {
  user: (authorization: string) => SupabaseClient;
  admin: () => SupabaseClient;
}

export async function requireAuth(
  req: Request,
  opts: { allowBlocked?: boolean } = {},
  deps: AuthDeps = { user: userClient, admin: adminClient },
): Promise<AuthContext> {
  const authorization = req.headers.get('authorization') ?? '';
  const token = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
  if (!token) throw new HttpError(401, 'no_session', 'Please sign in.');

  const user = deps.user(authorization);
  const { data: u, error: uErr } = await user.auth.getUser(token);
  if (uErr || !u?.user) throw new HttpError(401, 'bad_session', 'Your session is not valid. Please sign in again.');

  const { data: access, error: aErr } = await user.rpc('my_access');
  if (aErr || !access) throw new HttpError(403, 'no_profile', 'Your account is not set up yet.');
  const a = access as MyAccess;
  const reason = accessBlockReason(a);
  if (reason) throw new HttpError(403, 'no_access', reason);

  const rawDevice = (req.headers.get('x-device-id') ?? '').toLowerCase();
  const deviceKey = DEVICE_KEY.test(rawDevice) ? rawDevice : null;
  const admin = deps.admin();

  if (deviceKey && !opts.allowBlocked) {
    const { data: dev } = await admin
      .from('devices')
      .select('blocked')
      .eq('user_id', u.user.id)
      .eq('device_key', deviceKey)
      .maybeSingle();
    if (dev?.blocked) throw new HttpError(403, 'device_blocked', 'This computer has been blocked by a Super Admin.');
  }

  return { userId: u.user.id, access: a, deviceKey, user, admin };
}

export function requirePermission(ctx: AuthContext, permission: Permission): void {
  if (!ctx.access.permissions.includes(permission)) {
    throw new HttpError(403, 'forbidden', 'Your access level cannot do this.');
  }
}

/** Asks the database (as the caller) whether they may open this client. */
export async function requireClientAccess(ctx: AuthContext, clientId: string): Promise<void> {
  const { data, error } = await ctx.user.rpc('has_client_access', { p_client: clientId });
  if (error || data !== true) throw new HttpError(403, 'forbidden_client', 'You do not have access to this client.');
}
