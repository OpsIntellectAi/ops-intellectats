/**
 * Sending queued texts and starting/finishing AI calls. Used by send-sms, start-ai-call,
 * the scheduler and the voice webhook. Always runs with the service role AFTER the
 * caller's permission was checked (or from the scheduler).
 */
import type { SupabaseClient } from '@supabase/supabase-js';
import { complete, llmProvider } from './llm.ts';
import { functionsBaseUrl, sendSms, TwilioError, twilioConfig } from './twilio.ts';
import { voiceProvider } from './voice/index.ts';
import { simulateReport, TEST_RECORDING_PATH } from './voice/test.ts';
import type { CallReport, CallRequest, ScriptQuestion } from './voice/types.ts';

export interface SmsRow {
  message_id: string;
  status: string;
  body: string;
  is_automatic: boolean;
  to: string;
  opted_out: boolean;
  client_id: string;
  client_live: boolean;
  messaging_service_sid: string | null;
  a2p_status: string;
  environment: string;
  allow_listed: boolean;
}

/** Decides what happens to one text before Twilio is called. Pure, so it is unit-tested. */
export function smsGate(m: SmsRow, twilioReady: boolean): { send: boolean; status?: string; reason?: string } {
  if (m.status !== 'queued') return { send: false, reason: 'not_queued' };
  if (m.opted_out) return { send: false, status: 'cancelled', reason: 'opted_out' };
  if (m.environment !== 'production' && !m.allow_listed) {
    return { send: false, status: 'blocked_not_allowlisted', reason: 'Staging texts only go to allow-listed test phones' };
  }
  if (m.environment === 'production' && m.is_automatic && !m.client_live) {
    return { send: false, status: 'blocked_not_live', reason: 'Automatic texts start when the client goes live' };
  }
  if (m.environment === 'production' && m.a2p_status !== 'approved') {
    return { send: false, status: 'blocked_a2p', reason: 'Texting is blocked until the A2P campaign is approved' };
  }
  if (!twilioReady) return { send: false, status: 'test_sent', reason: 'Test mode: Twilio is not set up' };
  return { send: true };
}

export async function sendQueuedMessage(admin: SupabaseClient, messageId: string): Promise<string> {
  const { data, error } = await admin.rpc('sms_to_send', { p_message: messageId });
  if (error || !data) throw new Error('message lookup failed');
  const m = data as SmsRow;
  const cfg = twilioConfig();
  const gate = smsGate(m, cfg !== null);
  if (!gate.send) {
    if (gate.status) await admin.rpc('mark_message_sent', { p_message: messageId, p_status: gate.status, p_sid: null, p_error: null });
    return gate.status ?? gate.reason ?? 'skipped';
  }
  try {
    const r = await sendSms(cfg!, {
      to: m.to,
      body: m.body,
      messagingServiceSid: m.messaging_service_sid,
      statusCallback: `${functionsBaseUrl()}/twilio-webhook?kind=status`,
    });
    await admin.rpc('mark_message_sent', { p_message: messageId, p_status: r.status, p_sid: r.sid, p_error: null });
    return r.status;
  } catch (e) {
    const code = e instanceof TwilioError ? e.code : 'send_error';
    await admin.rpc('mark_message_sent', { p_message: messageId, p_status: 'failed', p_sid: null, p_error: code });
    return 'failed';
  }
}

interface CreatedCall {
  call_id: string;
  attempt: number;
  to: string;
  first_name: string;
  role: string;
  client: string;
  pay: string | null;
  address: string | null;
  training_location?: string | null;
  shift_text?: string | null;
  schedule_text?: string | null;
  min_age?: number | null;
  questions: ScriptQuestion[];
  rules: string[];
}

/** Starts an AI interview call. The caller already checked public.ai_call_check(). */
export async function startAiCall(admin: SupabaseClient, applicationId: string, placedBy: string | null) {
  const provider = voiceProvider();
  const { data, error } = await admin.rpc('create_call', {
    p_application: applicationId,
    p_via: 'ai',
    p_provider: provider.name === 'test' ? 'vapi' : provider.name,
    p_placed_by: placedBy,
  });
  if (error || !data) throw new Error('could not create the call');
  const c = data as CreatedCall;
  const req: CallRequest = {
    callId: c.call_id,
    to: c.to,
    firstName: c.first_name,
    role: c.role,
    client: c.client,
    pay: c.pay,
    address: c.address,
    trainingLocation: c.training_location ?? null,
    shift: c.shift_text ?? null,
    schedule: c.schedule_text ?? null,
    minAge: c.min_age ?? null,
    questions: Array.isArray(c.questions) ? c.questions : [],
    rules: Array.isArray(c.rules) ? c.rules.map(String) : [],
  };
  try {
    const { providerCallId } = await provider.start(req);
    await admin.rpc('set_provider_call_id', { p_call: c.call_id, p_provider_call_id: providerCallId, p_outcome: 'in_progress' });
    if (provider.name === 'test') {
      await finishCall(admin, c.call_id, simulateReport(req, providerCallId));
    }
    return { callId: c.call_id, attempt: c.attempt, test: provider.name === 'test' };
  } catch (e) {
    await admin.rpc('record_call_result', { p_call: c.call_id, p_outcome: 'failed' });
    throw e;
  }
}

/**
 * Test mode: the sample recording lives once in the private bucket. If it is missing it is
 * copied from the website (/samples/test-call.mp3, a synthetic voice reading a made-up call).
 */
export async function ensureTestRecording(admin: SupabaseClient): Promise<boolean> {
  try {
    const { data } = await admin.storage.from('recordings').list('samples', { search: 'test-call.mp3' });
    if ((data ?? []).some((f) => f.name === 'test-call.mp3')) return true;
    const { data: cfg } = await admin.from('app_config').select('value').eq('key', 'allowed_origins').maybeSingle();
    const origin = String((cfg as { value?: string } | null)?.value ?? '').split(',')[0]?.trim() ?? '';
    if (!/^https:\/\/[^\s/]+$/.test(origin)) return false;
    const res = await fetch(`${origin}/samples/test-call.mp3`);
    if (!res.ok) return false;
    const up = await admin.storage.from('recordings').upload(TEST_RECORDING_PATH, await res.arrayBuffer(), { contentType: 'audio/mpeg', upsert: true });
    return !up.error;
  } catch {
    return false;
  }
}

/** Saves a finished call: recording into the private bucket, summary, answers, retries. */
export async function finishCall(admin: SupabaseClient, callId: string, report: CallReport) {
  let recordingPath: string | null = report.recordingPath ?? null;
  if (recordingPath === TEST_RECORDING_PATH && !(await ensureTestRecording(admin))) recordingPath = null;
  const { data: call } = await admin.from('calls').select('client_id').eq('id', callId).maybeSingle();
  if (report.recordingUrl && call && /^https:\/\//.test(report.recordingUrl)) {
    try {
      const res = await fetch(report.recordingUrl);
      if (res.ok) {
        const path = `${call.client_id}/${callId}.wav`;
        const up = await admin.storage.from('recordings').upload(path, await res.arrayBuffer(), {
          contentType: res.headers.get('content-type') ?? 'audio/wav',
          upsert: true,
        });
        if (!up.error) recordingPath = path;
      }
    } catch {
      // The call result is still saved; the recording can be fetched again from the provider.
    }
  }
  let summary: string | null = report.summary ?? null;
  let facts: Record<string, unknown> | null = null;
  if (report.outcome === 'completed' && report.transcript && !(report.summary && llmProvider() === 'test')) {
    try {
      const text = await complete(
        'You summarise a recruiting phone screen for a recruiter. Reply as JSON: ' +
          '{"summary": "<3 short sentences>", "start_date": "<or null>", "shifts": "<or null>", "commute": "<or null>"}. ' +
          'Use only what was said. The candidate is called "the candidate".',
        report.transcript.slice(0, 20000),
        400,
      );
      const m = text.match(/\{[\s\S]*\}/);
      if (m) {
        const parsed = JSON.parse(m[0]) as Record<string, unknown>;
        summary = typeof parsed.summary === 'string' ? parsed.summary.slice(0, 1500) : null;
        facts = { start_date: parsed.start_date ?? null, shifts: parsed.shifts ?? null, commute: parsed.commute ?? null };
      } else {
        summary = text.slice(0, 1500);
      }
    } catch {
      summary = report.summary ?? null;
    }
  }
  const { data, error } = await admin.rpc('record_call_result', {
    p_call: callId,
    p_outcome: report.outcome,
    p_duration: report.durationSeconds,
    p_transcript: report.transcript,
    p_answers: report.answers,
    p_recording_path: recordingPath,
    p_summary: summary,
    p_facts: facts,
  });
  if (error) throw new Error('could not save the call result');
  return data;
}

/** Queues + immediately sends texts that are already inside the sending window. */
export async function dispatchDue(admin: SupabaseClient, limit = 25): Promise<{ sent: number; other: number }> {
  const { data, error } = await admin.rpc('claim_jobs', { p_limit: limit, p_kinds: ['send_sms'] });
  if (error) throw new Error('claim failed');
  let sent = 0;
  for (const j of (data ?? []) as { id: string; payload: { message_id?: string } }[]) {
    try {
      if (j.payload.message_id) await sendQueuedMessage(admin, j.payload.message_id);
      await admin.rpc('finish_job', { p_id: j.id, p_ok: true });
      sent++;
    } catch (e) {
      await admin.rpc('finish_job', {
        p_id: j.id,
        p_ok: false,
        p_error: e instanceof Error ? e.message : 'error',
        p_retry_at: new Date(Date.now() + 5 * 60_000).toISOString(),
      });
    }
  }
  return { sent, other: 0 };
}
