/**
 * CORS: only our own web domains may call the functions from a browser.
 * The list comes from the ALLOWED_ORIGINS function secret (comma-separated), e.g.
 *   https://app.opsintellect.com,https://staging.opsintellect.com
 * If that secret is not set, the functions read the same list from the
 * public.app_config table (key "allowed_origins"), which only the service role can read.
 */
import type { SupabaseClient } from '@supabase/supabase-js';
import { HttpError } from './http.ts';

export function allowedOrigins(raw = Deno.env.get('ALLOWED_ORIGINS') ?? ''): string[] {
  return raw.split(',').map((o) => o.trim().replace(/\/$/, '')).filter((o) => /^https?:\/\/[^\s/]+$/.test(o));
}

let cache: { at: number; origins: string[] } | null = null;

/** Secret first; otherwise the app_config row (cached for 60 seconds per function instance). */
export async function resolveOrigins(admin: () => SupabaseClient, now = Date.now()): Promise<string[]> {
  const fromEnv = allowedOrigins();
  if (fromEnv.length > 0) return fromEnv;
  if (cache && now - cache.at < 60_000) return cache.origins;
  const { data } = await admin().from('app_config').select('value').eq('key', 'allowed_origins').maybeSingle();
  const origins = allowedOrigins((data as { value?: string } | null)?.value ?? '');
  cache = { at: now, origins };
  return origins;
}

export function corsHeaders(req: Request, origins: string[]): Record<string, string> {
  const origin = req.headers.get('origin');
  const base: Record<string, string> = {
    'access-control-allow-headers': 'authorization, x-client-info, apikey, content-type, x-device-id',
    'access-control-allow-methods': 'POST, OPTIONS',
    'access-control-max-age': '600',
    vary: 'Origin',
  };
  if (origin && origins.includes(origin)) base['access-control-allow-origin'] = origin;
  return base;
}

/**
 * Handles the preflight and refuses browser calls from any other website.
 * Server-to-server calls (no Origin header, e.g. webhooks) are not affected here;
 * they are protected by signatures instead.
 */
export function guardCors(req: Request, origins: string[]): Response | null {
  const origin = req.headers.get('origin');
  if (origin && !origins.includes(origin)) {
    throw new HttpError(403, 'origin_not_allowed', 'This website is not allowed to call this service.');
  }
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders(req, origins) });
  }
  return null;
}
