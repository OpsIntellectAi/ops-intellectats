/**
 * Email through Resend. Secrets: RESEND_API_KEY, EMAIL_FROM (e.g. "Ops Intellect <reports@yourdomain.com>").
 * Without them: TEST MODE (nothing sent; the caller still logs what would have gone out).
 */
export function emailConfigured(): boolean {
  return Boolean(Deno.env.get('RESEND_API_KEY') && Deno.env.get('EMAIL_FROM'));
}

export async function sendEmail(
  to: string[],
  subject: string,
  html: string,
  fetcher: typeof fetch = fetch,
): Promise<'sent' | 'test'> {
  const clean = to.filter((x) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x)).slice(0, 20);
  if (!clean.length) return 'test';
  if (!emailConfigured()) return 'test';
  const res = await fetcher('https://api.resend.com/emails', {
    method: 'POST',
    headers: { authorization: `Bearer ${Deno.env.get('RESEND_API_KEY')}`, 'content-type': 'application/json' },
    body: JSON.stringify({ from: Deno.env.get('EMAIL_FROM'), to: clean, subject: subject.slice(0, 200), html }),
  });
  if (!res.ok) throw new Error(`email failed (${res.status})`);
  return 'sent';
}

export function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
