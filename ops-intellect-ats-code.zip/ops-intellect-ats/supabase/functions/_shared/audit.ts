/** Writes one row to the append-only activity log (service role; users cannot insert). */
import type { SupabaseClient } from '@supabase/supabase-js';
import { clientIp } from './http.ts';
import type { AppRole } from './permissions.ts';

export interface AuditEntry {
  action: string;
  clientId?: string | null;
  targetType?: string | null;
  targetId?: string | null;
  targetLabel?: string | null;
  before?: string | null;
  after?: string | null;
  flagged?: boolean;
  flagReason?: string | null;
}

export interface AuditActor {
  userId: string | null;
  role: AppRole | null;
  deviceKey: string | null;
}

export function auditRow(req: Request, actor: AuditActor, e: AuditEntry): Record<string, unknown> {
  const cut = (v: string | null | undefined, n: number) => (v == null ? null : v.slice(0, n));
  return {
    actor_id: actor.userId,
    actor_role: actor.role,
    client_id: e.clientId ?? null,
    action: e.action.slice(0, 120),
    target_type: e.targetType ?? null,
    target_id: e.targetId ?? null,
    target_label: cut(e.targetLabel, 200),
    before_value: cut(e.before, 2000),
    after_value: cut(e.after, 2000),
    device_key: actor.deviceKey,
    ip: clientIp(req),
    user_agent: cut(req.headers.get('user-agent'), 400),
    flagged: e.flagged ?? false,
    flag_reason: e.flagReason ?? null,
  };
}

export async function writeAudit(admin: SupabaseClient, req: Request, actor: AuditActor, e: AuditEntry): Promise<void> {
  const { error } = await admin.from('audit_log').insert(auditRow(req, actor, e));
  if (error) {
    // The action itself already happened; never fail silently on the log.
    console.error('audit write failed', error.message);
    throw new Error('audit write failed');
  }
}
