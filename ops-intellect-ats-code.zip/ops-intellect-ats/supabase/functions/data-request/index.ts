/**
 * POST /functions/v1/data-request
 *   { action: 'export', candidateId }          → everything we hold on the person (JSON)
 *   { action: 'delete', candidateId, reason }  → deletes the person, their recordings and licence photos
 * Admin and up, for clients they were given. Both are logged (deletion without the person's name).
 */
import { z } from 'zod';
import { requireAuth, requirePermission } from '../_shared/auth.ts';
import { handleBrowserRequest } from '../_shared/handler.ts';
import { HttpError, json } from '../_shared/http.ts';
import { enforceRateLimit } from '../_shared/rate-limit.ts';
import { parseBody, uuid } from '../_shared/validate.ts';

const Body = z.discriminatedUnion('action', [
  z.object({ action: z.literal('export'), candidateId: uuid }),
  z.object({ action: z.literal('delete'), candidateId: uuid, reason: z.string().trim().min(4).max(300) }),
]);

Deno.serve((req) =>
  handleBrowserRequest(req, async (cors) => {
    const body = await parseBody(req, Body);
    const ctx = await requireAuth(req);
    requirePermission(ctx, 'users.manage');
    await enforceRateLimit(ctx.admin, 'export', 'user', ctx.userId);
    if (body.action === 'export') {
      const { data, error } = await ctx.user.rpc('export_candidate', { p_candidate: body.candidateId });
      if (error) throw new HttpError(403, 'forbidden', 'You cannot export this candidate.');
      return json({ data }, 200, cors);
    }
    const { data, error } = await ctx.user.rpc('delete_candidate', { p_candidate: body.candidateId, p_reason: body.reason });
    if (error) throw new HttpError(403, 'forbidden', 'You cannot delete this candidate.');
    const r = data as { recording_paths: string[]; licence_prefixes: string[] };
    if (r.recording_paths.length) await ctx.admin.storage.from('recordings').remove(r.recording_paths);
    for (const prefix of r.licence_prefixes) {
      const { data: files } = await ctx.admin.storage.from('licences').list(prefix, { limit: 100 });
      if (files?.length) await ctx.admin.storage.from('licences').remove(files.map((f) => `${prefix}/${f.name}`));
    }
    return json({ deleted: true }, 200, cors);
  })
);
