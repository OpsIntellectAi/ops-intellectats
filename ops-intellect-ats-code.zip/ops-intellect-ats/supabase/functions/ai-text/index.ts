/**
 * POST /functions/v1/ai-text
 *   overview            → one-paragraph overview of a candidate's text chat (name removed first)
 *   insights            → plain-English findings from the AI-insights numbers (no people)
 *   script_suggestions  → optional wording suggestions for AI script questions (no people)
 */
import { requireAuth, requireClientAccess, requirePermission } from '../_shared/auth.ts';
import { handleBrowserRequest } from '../_shared/handler.ts';
import { HttpError, json } from '../_shared/http.ts';
import { complete, llmProvider } from '../_shared/llm.ts';
import { requireFeature } from '../_shared/features.ts';
import { enforceRateLimit } from '../_shared/rate-limit.ts';
import { parseBody } from '../_shared/validate.ts';
import { AiTextBody, plainOverview, redact } from './logic.ts';

Deno.serve((req) =>
  handleBrowserRequest(req, async (cors) => {
    const body = await parseBody(req, AiTextBody);
    const ctx = await requireAuth(req);
    await enforceRateLimit(ctx.admin, 'assistant', 'user', ctx.userId);

    if (body.action === 'overview') {
      const { data: app } = await ctx.user.from('application_rows').select('id, full_name, client_id').eq('id', body.applicationId).maybeSingle();
      if (!app) throw new HttpError(403, 'forbidden', 'This candidate is not in your scope.');
      await requireFeature(ctx.admin, app.client_id as string, 'ai_overview');
      const { data: msgs } = await ctx.user.from('messages').select('direction, body, created_at')
        .eq('application_id', body.applicationId).order('created_at').limit(60);
      if (!msgs?.length) return json({ overview: 'No texts yet.' }, 200, cors);
      if (llmProvider() === 'test') {
        return json({ overview: plainOverview(msgs as { direction: string; body: string; created_at: string }[]) }, 200, cors);
      }
      const chat = msgs.map((m) => `${m.direction === 'inbound' ? 'Candidate' : 'Team'}: ${redact(m.body as string, app.full_name as string)}`).join('\n');
      const overview = await complete(
        'Write ONE short paragraph (max 3 sentences) for a recruiter: where this text conversation stands and what to do next. Facts only.',
        chat.slice(-8000), 220);
      return json({ overview }, 200, cors);
    }

    if (body.action === 'insights') {
      requirePermission(ctx, 'reports.view');
      await requireClientAccess(ctx, body.clientId);
      await requireFeature(ctx.admin, body.clientId, 'ai_overview');
      const { data, error } = await ctx.user.rpc('insights_data', { p_client: body.clientId, p_job_role: body.jobRoleId ?? null, p_days: body.days });
      if (error) throw new HttpError(403, 'forbidden', 'Your access level cannot see AI insights.');
      const text = await complete(
        'You read hiring numbers for a delivery-driver recruiting team. Give 3-5 short findings, each on its own line starting with "- ", ' +
          'covering: why only X of Y got through, the biggest drop, questions where people drop, the best time to call, and one next action each. ' +
          'Use only these numbers.',
        JSON.stringify(data).slice(0, 12000), 500);
      return json({ findings: text.split('\n').map((l) => l.replace(/^[-•*]\s*/, '').trim()).filter(Boolean).slice(0, 6) }, 200, cors);
    }

    requirePermission(ctx, 'platform.admin');
    await requireClientAccess(ctx, body.clientId);
    const text = await complete(
      'You review phone-screen questions for delivery driver jobs. For each question that could be clearer, kinder or more ' +
        'compliant, reply on one line as "key: suggested wording". Never add questions about origin, citizenship beyond work ' +
        'authorization, religion, family, health, disability or arrests. Reply "OK" if nothing needs changing.',
      body.questions.map((q) => `${q.key}: ${q.text}`).join('\n'), 600);
    const suggestions = text.split('\n')
      .map((l) => l.match(/^\s*([a-z0-9_]{1,20})\s*:\s*(.{5,400})$/i))
      .filter((m): m is RegExpMatchArray => Boolean(m) && body.questions.some((q) => q.key === m![1]))
      .map((m) => ({ key: m[1]!, text: m[2]!.trim() }));
    return json({ suggestions }, 200, cors);
  })
);
