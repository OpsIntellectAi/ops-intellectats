import { assertEquals } from '../_shared/testing.ts';
import { AiTextBody, redact } from './logic.ts';

Deno.test('names, emails and phones are removed before the AI sees text', () => {
  const out = redact('Hi Jordan Miles! jordan.m@example.com or (202) 555-0101. jordan said ok', 'Jordan Miles');
  assertEquals(/jordan|miles|example\.com|555/i.test(out), false);
});

Deno.test('ai-text input is validated', () => {
  assertEquals(AiTextBody.safeParse({ action: 'overview', applicationId: 'x' }).success, false);
  assertEquals(AiTextBody.safeParse({ action: 'raw_sql', sql: 'select 1' }).success, false);
  assertEquals(AiTextBody.safeParse({ action: 'insights', clientId: crypto.randomUUID() }).success, true);
});

Deno.test('plain overview without an AI key', async () => {
  const { plainOverview } = await import('./logic.ts');
  const now = Date.parse('2026-11-11T12:00:00Z');
  assertEquals(plainOverview([], now), 'No texts yet.');
  assertEquals(plainOverview([{ direction: 'outbound', body: 'Hi', created_at: '2026-11-09T12:00:00Z' }], now),
    '1 text sent, no reply yet (last 2 days ago). Try an AI call or a phone call next.');
  assertEquals(plainOverview([
    { direction: 'outbound', body: 'Hi', created_at: '2026-11-11T09:00:00Z' },
    { direction: 'inbound', body: 'Can I move my call to 5:45?', created_at: '2026-11-11T11:00:00Z' },
  ], now), 'They replied 1 h ago: "Can I move my call to 5:45?". Waiting for your answer — reply next.');
});
