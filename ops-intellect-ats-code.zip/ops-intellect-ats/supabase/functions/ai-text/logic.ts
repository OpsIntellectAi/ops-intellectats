import { z } from 'zod';

const uuid = z.string().uuid();

export const AiTextBody = z.discriminatedUnion('action', [
  z.object({ action: z.literal('overview'), applicationId: uuid }),
  z.object({ action: z.literal('insights'), clientId: uuid, jobRoleId: uuid.nullable().optional(), days: z.number().int().min(1).max(365).default(30) }),
  z.object({
    action: z.literal('script_suggestions'),
    clientId: uuid,
    questions: z.array(z.object({ key: z.string().max(20), text: z.string().max(400) })).min(1).max(40),
  }),
]);
export type AiTextBody = z.infer<typeof AiTextBody>;

/** Removes the person's name and contact details before text is sent to the AI provider. */
export function redact(text: string, fullName: string): string {
  let out = text;
  const parts = fullName.split(/\s+/).filter((p) => p.length >= 2).sort((a, b) => b.length - a.length);
  for (const p of [fullName, ...parts]) {
    out = out.replace(new RegExp(p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), 'the candidate');
  }
  return out
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[email]')
    .replace(/\+?1?[\s.-]?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}/g, '[phone]');
}

/** Overview without an AI key: plain facts from the texts, so the button is useful in test mode. */
export function plainOverview(msgs: { direction: string; body: string; created_at: string }[], now = Date.now()): string {
  if (!msgs.length) return 'No texts yet.';
  const last = msgs[msgs.length - 1]!;
  const lastIn = [...msgs].reverse().find((m) => m.direction === 'inbound');
  const outs = msgs.filter((m) => m.direction === 'outbound').length;
  const ago = (iso: string) => {
    const h = Math.max(0, Math.round((now - new Date(iso).getTime()) / 3_600_000));
    return h < 1 ? 'just now' : h < 48 ? `${h} h ago` : `${Math.round(h / 24)} days ago`;
  };
  const cut = (s: string) => (s.length > 90 ? `${s.slice(0, 87)}…` : s);
  if (last.direction === 'inbound') {
    return `They replied ${ago(last.created_at)}: "${cut(last.body)}". Waiting for your answer — reply next.`;
  }
  if (lastIn) {
    return `Last reply ${ago(lastIn.created_at)}: "${cut(lastIn.body)}". You texted after that (${ago(last.created_at)}); waiting for them.`;
  }
  return `${outs} text${outs === 1 ? '' : 's'} sent, no reply yet (last ${ago(last.created_at)}). Try an AI call or a phone call next.`;
}
