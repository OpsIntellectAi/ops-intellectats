import { assert, assertEquals } from '../_shared/testing.ts';
import { canInvite, InviteBody, safeRedirect } from './logic.ts';

Deno.test('admins invite below Admin only; super admins invite anyone; others nobody', () => {
  assert(canInvite('admin', 'csr'));
  assert(canInvite('admin', 'station_manager'));
  assert(!canInvite('admin', 'admin'));
  assert(!canInvite('admin', 'super_admin'));
  assert(canInvite('super_admin', 'admin'));
  assert(!canInvite('supervisor', 'csr'));
  assert(!canInvite('csr', 'viewer'));
});

Deno.test('invite links only go back to our own websites', () => {
  const allowed = ['https://ops-intellect-staging.vercel.app'];
  assertEquals(safeRedirect('https://ops-intellect-staging.vercel.app/', allowed), 'https://ops-intellect-staging.vercel.app/auth/callback?invited=1');
  assertEquals(safeRedirect('https://evil.example', allowed), null);
});

Deno.test('invite input is validated', () => {
  assert(!InviteBody.safeParse({ action: 'invite', email: 'not-an-email', fullName: 'A B', role: 'csr', redirectOrigin: 'https://x.y' }).success);
  assert(!InviteBody.safeParse({ action: 'invite', email: 'a@b.co', fullName: 'A B', role: 'owner', redirectOrigin: 'https://x.y' }).success);
  const ok = InviteBody.safeParse({ action: 'invite', email: ' New.Person@Example.com ', fullName: 'New Person', role: 'csr', redirectOrigin: 'https://x.y' });
  assert(ok.success);
  if (ok.success) assertEquals(ok.data.email, 'new.person@example.com');
});
