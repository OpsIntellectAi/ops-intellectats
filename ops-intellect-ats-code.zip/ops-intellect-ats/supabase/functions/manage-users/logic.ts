import { z } from 'zod';
import type { AppRole } from '../_shared/permissions.ts';
import { ROLES } from '../_shared/permissions.ts';

export const InviteBody = z.object({
  action: z.literal('invite'),
  email: z.string().trim().toLowerCase().email().max(254),
  fullName: z.string().trim().min(2).max(120),
  role: z.enum(ROLES),
  redirectOrigin: z.string().url().max(200),
});
export type InviteBody = z.infer<typeof InviteBody>;

/** Admins may invite every level below Admin; only a Super Admin may invite Admins. */
export function canInvite(inviter: AppRole, role: AppRole): boolean {
  if (inviter === 'super_admin') return true;
  if (inviter === 'admin') return role !== 'admin' && role !== 'super_admin';
  return false;
}

/** The invite link must send people back to one of our own websites. */
export function safeRedirect(origin: string, allowed: string[]): string | null {
  const clean = origin.replace(/\/$/, '');
  return allowed.includes(clean) ? `${clean}/auth/callback?invited=1` : null;
}
