/**
 * POST /functions/v1/manage-users
 *   { action: 'invite', email, fullName, role, redirectOrigin }
 * Creates the account and returns a one-time invite link for the inviter to send.
 * The new person has NO client until a Super Admin gives client access.
 */
import { requireAuth, requirePermission } from '../_shared/auth.ts';
import { writeAudit } from '../_shared/audit.ts';
import { resolveOrigins } from '../_shared/cors.ts';
import { handleBrowserRequest } from '../_shared/handler.ts';
import { HttpError, json } from '../_shared/http.ts';
import { enforceRateLimit } from '../_shared/rate-limit.ts';
import { adminClient } from '../_shared/supabase.ts';
import { parseBody } from '../_shared/validate.ts';
import { canInvite, InviteBody, safeRedirect } from './logic.ts';

Deno.serve((req) =>
  handleBrowserRequest(req, async (cors) => {
    const body = await parseBody(req, InviteBody);
    const ctx = await requireAuth(req);
    requirePermission(ctx, 'users.manage');
    if (!canInvite(ctx.access.role, body.role)) {
      throw new HttpError(403, 'forbidden', 'Only a Super Admin can add Admins or Super Admins.');
    }
    await enforceRateLimit(ctx.admin, 'invite', 'user', ctx.userId);

    const redirectTo = safeRedirect(body.redirectOrigin, await resolveOrigins(adminClient));
    if (!redirectTo) throw new HttpError(400, 'bad_redirect', 'This website address is not on the allowed list.');

    if (body.role === 'super_admin') {
      const { count } = await ctx.admin.from('profiles').select('id', { count: 'exact', head: true })
        .eq('role', 'super_admin').eq('status', 'active');
      if ((count ?? 0) >= 3) throw new HttpError(409, 'too_many', 'There can be at most 3 Super Admins.');
    }

    const { data, error } = await ctx.admin.auth.admin.generateLink({
      type: 'invite',
      email: body.email,
      options: { data: { full_name: body.fullName }, redirectTo },
    });
    if (error || !data?.user) {
      const exists = /already|registered|exists/i.test(error?.message ?? '');
      throw new HttpError(409, 'exists', exists ? 'This email already has an account.' : 'Could not create the invite.');
    }

    const { error: pErr } = await ctx.admin.from('profiles').update({
      full_name: body.fullName,
      role: body.role,
      status: 'active',
      invited_by: ctx.userId,
    }).eq('id', data.user.id);
    if (pErr) throw new Error('profile update failed');

    const flagged = body.role === 'admin' || body.role === 'super_admin';
    await writeAudit(ctx.admin, req, { userId: ctx.userId, role: ctx.access.role, deviceKey: ctx.deviceKey }, {
      action: 'User invited',
      targetType: 'user',
      targetId: data.user.id,
      targetLabel: `${body.fullName} <${body.email}>`,
      after: body.role,
      flagged,
      flagReason: flagged ? 'Admin-level user invited' : null,
    });

    return json({ ok: true, userId: data.user.id, link: data.properties?.action_link ?? null }, 200, cors);
  })
);
