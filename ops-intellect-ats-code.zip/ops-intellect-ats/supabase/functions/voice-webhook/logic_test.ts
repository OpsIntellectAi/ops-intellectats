import { assertEquals } from '../_shared/testing.ts';
import { mapEndedReason, parseVapiReport } from '../_shared/voice/vapi.ts';
import { interviewPrompt, normaliseAnswers, openingLine } from '../_shared/voice/script.ts';
import { simulateReport } from '../_shared/voice/test.ts';
import type { CallRequest, ScriptQuestion } from '../_shared/voice/types.ts';

const QS: ScriptQuestion[] = [
  { key: 'q1', type: 'yes_no', text: 'Are you 21 or older?', dealbreaker: true },
  { key: 'q2', type: 'yes_no', text: 'Valid licence?' },
  { key: 'q4', type: 'recorded', text: 'When could you start?' },
];
const REQ: CallRequest = {
  callId: 'c1', to: '+12025550101', firstName: 'Jordan', role: 'Delivery Driver', client: 'Northline Delivery',
  pay: '$20/hr', address: '100 Example Way', questions: QS, rules: ['Say the call is recorded'],
};

Deno.test('opening line: AI, who for, recorded, safe time', () => {
  const l = openingLine(REQ);
  for (const part of ['AI assistant', 'Northline Delivery', 'recorded', 'safe time']) assertEquals(l.includes(part), true, part);
});

Deno.test('prompt forbids protected topics and offers a person', () => {
  const p = interviewPrompt(REQ);
  assertEquals(p.includes('religion'), true);
  assertEquals(p.includes('ask for a person'), true);
  assertEquals(p.includes('DEALBREAKER'), true);
});

Deno.test('answers: unknown keys dropped, never rejected on an unclear answer', () => {
  const a = normaliseAnswers(QS, [
    { key: 'q1', heard: 'Yes I am 25', result: 'yes', at: 12 },
    { key: 'q2', heard: '', result: 'no' },
    { key: 'zz', heard: 'x', result: 'yes' },
    { key: 'q4', heard: 'Monday', result: 'yes' },
  ]);
  assertEquals(a.map((x) => [x.key, x.result]), [['q1', 'yes'], ['q2', 'needs_review'], ['q4', 'recorded']]);
});

Deno.test('Vapi ended reasons', () => {
  assertEquals(mapEndedReason('voicemail'), 'voicemail');
  assertEquals(mapEndedReason('customer-did-not-answer'), 'no_answer');
  assertEquals(mapEndedReason('customer-busy'), 'busy');
  assertEquals(mapEndedReason('customer-ended-call'), 'completed');
  assertEquals(mapEndedReason('twilio-failed-to-connect-call'), 'failed');
});

Deno.test('Vapi report: voicemail saves no answers', () => {
  const r = parseVapiReport({
    message: { type: 'end-of-call-report', endedReason: 'voicemail', call: { id: 'v1' },
      analysis: { structuredData: { answers: [{ key: 'q1', heard: 'yes', result: 'yes' }] } } },
  }, QS);
  assertEquals(r?.outcome, 'voicemail');
  assertEquals(r?.answers.length, 0);
  assertEquals(parseVapiReport({ message: { type: 'status-update' } }, QS), null);
});

Deno.test('test provider outcomes by last digit', () => {
  assertEquals(simulateReport({ ...REQ, to: '+12025550109' }, 't').outcome, 'voicemail');
  assertEquals(simulateReport({ ...REQ, to: '+12025550108' }, 't').outcome, 'no_answer');
  assertEquals(simulateReport({ ...REQ, to: '+12025550107' }, 't').answers[1]?.result, 'needs_review');
  assertEquals(simulateReport(REQ, 't').answers.every((a) => a.result !== 'no'), true);
});

Deno.test('standard script: placeholders are filled from the job facts', async () => {
  const { fillFacts } = await import('../_shared/voice/script.ts');
  const f = { client: 'Rider Logistics', role: 'Driver', pay: '$22.25 per hour', address: '1000 Richard Petty Way, Lebanon TN',
    trainingLocation: 'Nashville DSP office', shift: '10:00 AM to 8:30 PM', schedule: '4 days incl. 1 weekend day', minAge: 21 };
  assertEquals(fillFacts('Calling for [company] at [address]. Pay [pay]. Training at [training location]. [min age]+ only.', f),
    'Calling for Rider Logistics at 1000 Richard Petty Way, Lebanon TN. Pay $22.25 per hour. Training at Nashville DSP office. 21+ only.');
  assertEquals(fillFacts('Shift [shift]; schedule [schedule]; [unknown] stays', f), 'Shift 10:00 AM to 8:30 PM; schedule 4 days incl. 1 weekend day; [unknown] stays');
  assertEquals(fillFacts('Pay [pay]', { ...f, pay: null }), 'Pay [pay]');
});

Deno.test('follow-up questions: path keys become conditions', async () => {
  const { condition } = await import('../_shared/voice/script.ts');
  assertEquals(condition('17.yes'), { parent: '17', answer: 'yes' });
  assertEquals(condition('18.yes.yes'), { parent: '18.yes', answer: 'yes' });
  assertEquals(condition('3.no'), { parent: '3', answer: 'no' });
  assertEquals(condition('q4'), null);
});

Deno.test('prompt: conditional steps and filled facts', () => {
  const r: CallRequest = { ...REQ, client: 'Rider Logistics', trainingLocation: 'Nashville', questions: [
    { key: '3', type: 'yes_no', text: 'Are you [min age] or older with a licence?', dealbreaker: true },
    { key: '3.no', type: 'info', text: 'Once you turn 21 you can re-apply.' },
    { key: '4', type: 'recorded', text: 'Training is at [training location]. How will you get there?' },
  ], minAge: 21 };
  const p = interviewPrompt(r);
  assertEquals(p.includes('Are you 21 or older with a licence?'), true);
  assertEquals(p.includes('ONLY IF the answer to [3] was NO: Say: Once you turn 21'), true);
  assertEquals(p.includes('Training is at Nashville.'), true);
});

Deno.test('test call: takes YES branches only, adds overview and sample recording', () => {
  const r: CallRequest = { ...REQ, to: '+12025550101', questions: [
    { key: '17', type: 'yes_no', text: 'Are you currently employed?' },
    { key: '17.yes', type: 'recorded', text: 'Why are you looking for a change?' },
    { key: '17.no', type: 'info', text: 'Okay.' },
    { key: '18', type: 'yes_no', text: 'Worked with Amazon?' },
  ] };
  const rep = simulateReport(r, 'p1');
  assertEquals(rep.answers.map((a) => a.key), ['17', '17.yes', '18']);
  assertEquals(rep.recordingPath, 'samples/test-call.mp3');
  assertEquals((rep.summary ?? '').startsWith('Jordan answered 2 of 2 requirements Yes'), true);
  const vm = simulateReport({ ...r, to: '+12025550109' }, 'p2');
  assertEquals([vm.outcome, vm.recordingPath, vm.summary], ['voicemail', null, null]);
  const unclear = simulateReport({ ...r, to: '+12025550107' }, 'p3');
  assertEquals((unclear.summary ?? '').includes('1 unclear'), true);
});
