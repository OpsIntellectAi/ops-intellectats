/**
 * Public webhook for the AI voice provider (Vapi "end-of-call-report").
 * The shared secret (VAPI_WEBHOOK_SECRET) must match the x-vapi-secret header, else 403.
 * Each provider event is processed once (idempotency_keys).
 */
import { adminClient } from '../_shared/supabase.ts';
import { finishCall } from '../_shared/dispatch.ts';
import { safeEqual } from '../_shared/twilio.ts';
import { parseVapiReport } from '../_shared/voice/vapi.ts';
import type { ScriptQuestion } from '../_shared/voice/types.ts';

Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  const secret = Deno.env.get('VAPI_WEBHOOK_SECRET') ?? '';
  const got = req.headers.get('x-vapi-secret') ?? '';
  if (secret.length < 16 || !safeEqual(secret, got)) return new Response('Forbidden', { status: 403 });
  const raw = await req.text();
  if (raw.length > 2 * 1024 * 1024) return new Response('Too large', { status: 413 });
  let body: unknown;
  try {
    body = JSON.parse(raw);
  } catch {
    return new Response('Bad JSON', { status: 400 });
  }
  const type = (body as { message?: { type?: string } })?.message?.type;
  if (type !== 'end-of-call-report') return new Response(JSON.stringify({ ok: true }), { status: 200 });

  const admin = adminClient();
  const providerId = (body as { message?: { call?: { id?: string } } }).message?.call?.id ?? '';
  const { data: callId } = await admin.rpc('call_by_provider_id', { p_provider_call_id: providerId });
  if (!callId) return new Response(JSON.stringify({ ok: true, unknown: true }), { status: 200 });

  const { data: first } = await admin.rpc('claim_idempotency', { p_key: `vapi:${providerId}:end`, p_source: 'vapi' });
  if (first !== true) return new Response(JSON.stringify({ ok: true, duplicate: true }), { status: 200 });

  // The call is pinned to its script version: answers are read against those questions.
  const { data: call } = await admin.from('calls').select('script_version_id').eq('id', callId).maybeSingle();
  const { data: version } = call?.script_version_id
    ? await admin.from('script_versions').select('question_tree').eq('id', call.script_version_id).maybeSingle()
    : { data: null };
  const questions = (Array.isArray(version?.question_tree) ? version!.question_tree : []) as ScriptQuestion[];
  const report = parseVapiReport(body, questions);
  if (!report) return new Response(JSON.stringify({ ok: true }), { status: 200 });
  try {
    await finishCall(admin, callId as string, report);
  } catch (e) {
    console.error('voice webhook error', e instanceof Error ? e.message : String(e));
    return new Response('Error', { status: 500 });
  }
  return new Response(JSON.stringify({ ok: true }), { status: 200 });
});
