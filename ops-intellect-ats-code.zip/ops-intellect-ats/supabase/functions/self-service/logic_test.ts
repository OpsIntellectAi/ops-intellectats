import { assertEquals } from '../_shared/testing.ts';
import { bookingProblem, SelfBody } from './logic.ts';

const now = new Date('2026-11-16T14:00:00Z'); // 9 AM ET

Deno.test('booking window rules', () => {
  const tz = 'America/New_York';
  assertEquals(bookingProblem(new Date('2026-11-16T14:10:00Z'), now, tz, '10:00', '18:00')?.includes('30 minutes'), true);
  assertEquals(bookingProblem(new Date('2026-12-16T15:00:00Z'), now, tz, '10:00', '18:00')?.includes('14 days'), true);
  assertEquals(bookingProblem(new Date('2026-11-17T01:00:00Z'), now, tz, '10:00', '18:00')?.includes('between'), true);
  assertEquals(bookingProblem(new Date('2026-11-16T16:00:00Z'), now, tz, '10:00', '18:00'), null);
});

Deno.test('links are validated', () => {
  assertEquals(SelfBody.safeParse({ action: 'get', token: 'abc' }).success, false);
  assertEquals(SelfBody.safeParse({ action: 'get', token: 'a'.repeat(36) }).success, true);
  assertEquals(SelfBody.safeParse({ action: 'upload_url', token: 'a'.repeat(36), ext: 'exe' }).success, false);
});
