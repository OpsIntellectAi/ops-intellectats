/**
 * Candidate self-service page (no sign-in; the link carries an unguessable token).
 *   get        → first name, job, booked AI call, onboarding checklist (no other data)
 *   book       → book or move their AI call (reminders are planned by the database)
 *   cancel     → cancel the booking
 *   upload_url → one-time upload link for a licence photo (private bucket; nobody can read it from the browser)
 *   ask_person → "I'd like a person instead of the AI" (NYC AEDT option, open to everyone)
 */
import { writeAudit } from '../_shared/audit.ts';
import { handleBrowserRequest } from '../_shared/handler.ts';
import { HttpError, json } from '../_shared/http.ts';
import { enforceRateLimit } from '../_shared/rate-limit.ts';
import { adminClient } from '../_shared/supabase.ts';
import { parseBody } from '../_shared/validate.ts';
import { bookingProblem, SelfBody } from './logic.ts';
import { featureOn } from '../_shared/features.ts';

Deno.serve((req) =>
  handleBrowserRequest(req, async (cors) => {
    const body = await parseBody(req, SelfBody);
    const admin = adminClient();
    await enforceRateLimit(admin, 'selfService', 'token', body.token);
    const { data: app } = await admin
      .from('applications')
      .select('id, client_id, candidate_id, stage, booked_call_at, job_roles(name), clients(name), stations(address), candidates(full_name, opted_out_at)')
      .eq('self_token', body.token)
      .maybeSingle();
    if (!app || app.stage === 'rejected') throw new HttpError(404, 'not_found', 'This link is not active.');
    if (!(await featureOn(admin, app.client_id as string, 'self_service'))) throw new HttpError(404, 'not_found', 'This link is not active.');
    const one = <T>(x: unknown): T | null => (Array.isArray(x) ? ((x[0] as T) ?? null) : ((x as T) ?? null));
    const cand = one<{ full_name: string; opted_out_at: string | null }>(app.candidates);
    const { data: tz } = await admin.rpc('candidate_tz', { p_application: app.id });
    const { data: cs } = await admin.from('client_settings').select('best_call_start, best_call_end').eq('client_id', app.client_id).maybeSingle();
    const actor = { userId: null, role: null, deviceKey: null };

    if (body.action === 'get') {
      const { data: steps } = await admin
        .from('onboarding_steps')
        .select('status, onboarding_step_defs(name, sort_order, done_statuses)')
        .eq('application_id', app.id);
      const { data: consent } = await admin.rpc('has_active_consent', { p_candidate: app.candidate_id, p_type: 'ai_call' });
      return json({
        firstName: (cand?.full_name ?? '').split(' ')[0],
        role: one<{ name: string }>(app.job_roles)?.name ?? '',
        client: one<{ name: string }>(app.clients)?.name ?? '',
        address: one<{ address: string | null }>(app.stations)?.address ?? null,
        stage: app.stage,
        bookedAt: app.booked_call_at,
        timeZone: tz ?? 'America/New_York',
        window: { start: String(cs?.best_call_start ?? '10:00').slice(0, 5), end: String(cs?.best_call_end ?? '18:00').slice(0, 5) },
        canBook: app.stage === 'interview' && consent === true && !cand?.opted_out_at,
        steps: (steps ?? [])
          .map((s) => {
            const d = one<{ name: string; sort_order: number; done_statuses: string[] }>(s.onboarding_step_defs);
            return { name: d?.name ?? '', order: d?.sort_order ?? 0, status: s.status, done: Boolean(d?.done_statuses.includes(s.status)) || s.status === 'Waived' };
          })
          .sort((a, b) => a.order - b.order),
      }, 200, cors);
    }

    if (body.action === 'book') {
      if (app.stage !== 'interview') throw new HttpError(409, 'not_open', 'Your interview step is already done.');
      const { data: consent } = await admin.rpc('has_active_consent', { p_candidate: app.candidate_id, p_type: 'ai_call' });
      if (consent !== true || cand?.opted_out_at) throw new HttpError(409, 'no_consent', 'Booking is not available. Please reply to our text instead.');
      const at = new Date(body.at);
      const problem = bookingProblem(at, new Date(), String(tz ?? 'America/New_York'), String(cs?.best_call_start ?? '10:00'), String(cs?.best_call_end ?? '18:00'));
      if (problem) throw new HttpError(400, 'bad_time', problem);
      const { error } = await admin.from('applications').update({ booked_call_at: at.toISOString() }).eq('id', app.id);
      if (error) throw new Error('booking failed');
      await writeAudit(admin, req, actor, { action: 'AI call booked by candidate', clientId: app.client_id, targetType: 'application', targetId: app.id, after: at.toISOString() });
      return json({ ok: true, bookedAt: at.toISOString() }, 200, cors);
    }

    if (body.action === 'cancel') {
      await admin.from('applications').update({ booked_call_at: null }).eq('id', app.id);
      await writeAudit(admin, req, actor, { action: 'AI call booking cancelled by candidate', clientId: app.client_id, targetType: 'application', targetId: app.id });
      return json({ ok: true }, 200, cors);
    }

    if (body.action === 'ask_person') {
      await admin.from('applications').update({ manual_call_needed: true }).eq('id', app.id);
      await admin.from('aedt_notices').update({ asked_for_person: true }).eq('candidate_id', app.candidate_id);
      await writeAudit(admin, req, actor, {
        action: 'Candidate asked for a person', clientId: app.client_id, targetType: 'application', targetId: app.id,
        flagged: true, flagReason: 'Call this candidate yourself (no AI interview)',
      });
      return json({ ok: true }, 200, cors);
    }

    // upload_url
    const path = `${app.client_id}/${app.id}/licence-${Date.now()}.${body.ext}`;
    const { data, error } = await admin.storage.from('licences').createSignedUploadUrl(path);
    if (error || !data) throw new Error('upload link failed');
    await writeAudit(admin, req, actor, { action: 'Licence photo upload started', clientId: app.client_id, targetType: 'application', targetId: app.id });
    return json({ signedUrl: data.signedUrl, path }, 200, cors);
  })
);
