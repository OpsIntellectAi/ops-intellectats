import { z } from 'zod';

const token = z.string().regex(/^[0-9a-f]{36}$/, 'bad link');

export const SelfBody = z.discriminatedUnion('action', [
  z.object({ action: z.literal('get'), token }),
  z.object({ action: z.literal('book'), token, at: z.string().datetime({ offset: true }) }),
  z.object({ action: z.literal('cancel'), token }),
  z.object({ action: z.literal('upload_url'), token, ext: z.enum(['jpg', 'jpeg', 'png', 'heic', 'pdf']) }),
  z.object({ action: z.literal('ask_person'), token }),
]);
export type SelfBody = z.infer<typeof SelfBody>;

/** Local wall-clock hour/minute of an instant in a time zone. */
export function localMinutes(at: Date, tz: string): number {
  const f = new Intl.DateTimeFormat('en-US', { timeZone: tz, hour: '2-digit', minute: '2-digit', hour12: false });
  const p = Object.fromEntries(f.formatToParts(at).map((x) => [x.type, x.value]));
  return (Number(p.hour) % 24) * 60 + Number(p.minute);
}

/** A booking must be 30 min to 14 days ahead and inside the client's call window. */
export function bookingProblem(at: Date, now: Date, tz: string, start: string, end: string): string | null {
  const ms = at.getTime() - now.getTime();
  if (ms < 30 * 60_000) return 'Please pick a time at least 30 minutes from now.';
  if (ms > 14 * 24 * 3600_000) return 'Please pick a time in the next 14 days.';
  const toMin = (t: string) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5));
  const m = localMinutes(at, tz);
  if (m < toMin(start) || m >= toMin(end)) return `Please pick a time between ${start.slice(0, 5)} and ${end.slice(0, 5)} your time.`;
  return null;
}
