import { assertEquals } from '../_shared/testing.ts';
import { dobProblem, looksLikeSsn, SensitiveBody } from './logic.ts';

Deno.test('SSN-shaped values are refused', () => {
  assertEquals(looksLikeSsn('123-45-6789'), true);
  assertEquals(looksLikeSsn('123456789'), true);
  assertEquals(looksLikeSsn('D1234-5678'), false);
});

Deno.test('date of birth checks', () => {
  const now = new Date('2026-11-11T00:00:00Z');
  assertEquals(dobProblem('2010-01-01', now), 'Age must be between 18 and 90');
  assertEquals(dobProblem('1990-02-30', now) === null || dobProblem('1990-02-30', now) === 'Not a real date', true);
  assertEquals(dobProblem('1990-05-01', now), null);
  assertEquals(SensitiveBody.safeParse({ action: 'set', candidateId: crypto.randomUUID(), dateOfBirth: '01/02/1990' }).success, false);
});
