import { z } from 'zod';

export const SensitiveBody = z.discriminatedUnion('action', [
  z.object({
    action: z.literal('set'),
    candidateId: z.string().uuid(),
    licenceNumber: z.string().trim().regex(/^[A-Za-z0-9-]{4,20}$/, 'Licence number: letters, digits and dashes').optional(),
    dateOfBirth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date of birth: YYYY-MM-DD').optional(),
  }),
  z.object({ action: z.literal('masked'), candidateId: z.string().uuid() }),
]);
export type SensitiveBody = z.infer<typeof SensitiveBody>;

/** Never store an SSN by mistake: 9 digits (with or without dashes) is refused as a licence number. */
export function looksLikeSsn(v: string): boolean {
  return /^\d{3}-?\d{2}-?\d{4}$/.test(v);
}

/** Age 18–90 only (DOB is used for the minimum-age check). */
export function dobProblem(iso: string, now = new Date()): string | null {
  const d = new Date(`${iso}T00:00:00Z`);
  if (Number.isNaN(d.getTime())) return 'Not a real date';
  const age = (now.getTime() - d.getTime()) / (365.25 * 86_400_000);
  return age < 18 || age > 90 ? 'Age must be between 18 and 90' : null;
}
