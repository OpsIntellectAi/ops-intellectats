/**
 * POST /functions/v1/sensitive-fields
 *   set    → encrypts driver's licence number and/or date of birth (AES-256-GCM) and saves them
 *   masked → returns only "•••• 1234" and the birth year, never the full values
 * Key: FIELD_ENCRYPTION_KEY function secret (32 random bytes, base64). SSNs are never stored.
 */
import { writeAudit } from '../_shared/audit.ts';
import { requireAuth, requirePermission } from '../_shared/auth.ts';
import { decryptField, encryptField, importFieldKey, maskTail } from '../_shared/crypto.ts';
import { handleBrowserRequest } from '../_shared/handler.ts';
import { HttpError, json } from '../_shared/http.ts';
import { parseBody } from '../_shared/validate.ts';
import { dobProblem, looksLikeSsn, SensitiveBody } from './logic.ts';

Deno.serve((req) =>
  handleBrowserRequest(req, async (cors) => {
    const body = await parseBody(req, SensitiveBody);
    const ctx = await requireAuth(req);
    const { data: cand } = await ctx.user.from('candidates').select('id, client_id, licence_number_enc, date_of_birth_enc')
      .eq('id', body.candidateId).maybeSingle();
    if (!cand) throw new HttpError(403, 'forbidden', 'This candidate is not in your scope.');
    const raw = Deno.env.get('FIELD_ENCRYPTION_KEY') ?? '';
    if (!raw) throw new HttpError(503, 'not_set_up', 'Encryption is not set up yet (FIELD_ENCRYPTION_KEY).');
    const key = await importFieldKey(raw);

    if (body.action === 'masked') {
      if (!ctx.access.permissions.includes('candidates.act') && !ctx.access.permissions.includes('onboarding.update')) {
        throw new HttpError(403, 'forbidden', 'Your access level cannot see licence details.');
      }
      const lic = cand.licence_number_enc ? maskTail(await decryptField(cand.licence_number_enc as string, key)) : null;
      const dob = cand.date_of_birth_enc ? (await decryptField(cand.date_of_birth_enc as string, key)).slice(0, 4) : null;
      return json({ licence: lic, birthYear: dob }, 200, cors);
    }

    requirePermission(ctx, 'candidates.act');
    if (body.licenceNumber && looksLikeSsn(body.licenceNumber)) {
      throw new HttpError(400, 'looks_like_ssn', 'That looks like a Social Security number. We never store SSNs.');
    }
    if (body.dateOfBirth) {
      const p = dobProblem(body.dateOfBirth);
      if (p) throw new HttpError(400, 'bad_dob', p);
    }
    const patch: Record<string, string> = {};
    if (body.licenceNumber) patch.licence_number_enc = await encryptField(body.licenceNumber.toUpperCase(), key);
    if (body.dateOfBirth) patch.date_of_birth_enc = await encryptField(body.dateOfBirth, key);
    if (!Object.keys(patch).length) throw new HttpError(400, 'nothing', 'Nothing to save.');
    const { error } = await ctx.admin.from('candidates').update(patch).eq('id', body.candidateId);
    if (error) throw new Error('save failed');
    await writeAudit(ctx.admin, req, { userId: ctx.userId, role: ctx.access.role, deviceKey: ctx.deviceKey }, {
      action: 'Sensitive fields saved', clientId: cand.client_id as string, targetType: 'candidate', targetId: body.candidateId,
      after: Object.keys(patch).map((k) => k.replace('_enc', '')).join(', '),
    });
    return json({ ok: true }, 200, cors);
  })
);
