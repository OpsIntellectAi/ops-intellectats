/**
 * POST /functions/v1/record-sign-in   body: { deviceKey }
 * Called by the web app right after sign-in. Records the computer, browser and IP,
 * flags new computers / new locations, and refuses blocked computers.
 */
import { requireAuth } from '../_shared/auth.ts';
import { writeAudit } from '../_shared/audit.ts';
import { handleBrowserRequest } from '../_shared/handler.ts';
import { clientIp, HttpError, json } from '../_shared/http.ts';
import { enforceRateLimit } from '../_shared/rate-limit.ts';
import { parseBody } from '../_shared/validate.ts';
import { assessDevice, type DeviceRow, deviceLabel, SignInBody } from './logic.ts';

Deno.serve((req) =>
  handleBrowserRequest(req, async (cors) => {
    const body = await parseBody(req, SignInBody);
    const ctx = await requireAuth(req, { allowBlocked: true });
    await enforceRateLimit(ctx.admin, 'signIn', 'user', ctx.userId);

    const ip = clientIp(req);
    const ua = req.headers.get('user-agent');
    const { data: rows, error } = await ctx.admin
      .from('devices')
      .select('device_key, blocked, trusted, last_ip')
      .eq('user_id', ctx.userId);
    if (error) throw new Error('device lookup failed');

    const verdict = assessDevice((rows ?? []) as DeviceRow[], body.deviceKey, ip);
    const actor = { userId: ctx.userId, role: ctx.access.role, deviceKey: body.deviceKey };

    if (verdict.blocked) {
      await writeAudit(ctx.admin, req, actor, {
        action: 'Sign-in refused',
        targetType: 'device',
        targetId: body.deviceKey,
        targetLabel: deviceLabel(ua),
        flagged: true,
        flagReason: verdict.flag,
      });
      throw new HttpError(403, 'device_blocked', 'This computer has been blocked by a Super Admin.');
    }

    const now = new Date().toISOString();
    const { error: upErr } = await ctx.admin.from('devices').upsert(
      {
        user_id: ctx.userId,
        device_key: body.deviceKey,
        label: deviceLabel(ua),
        user_agent: ua?.slice(0, 400) ?? null,
        last_ip: ip,
        last_seen_at: now,
        ...(verdict.isNew ? { first_ip: ip, first_seen_at: now } : {}),
      },
      { onConflict: 'user_id,device_key' },
    );
    if (upErr) throw new Error('device save failed');

    await writeAudit(ctx.admin, req, actor, {
      action: 'Signed in',
      targetType: 'device',
      targetId: body.deviceKey,
      targetLabel: deviceLabel(ua),
      flagged: verdict.flag !== null,
      flagReason: verdict.flag,
    });

    return json({ ok: true, newDevice: verdict.isNew, flagged: verdict.flag !== null }, 200, cors);
  })
);
