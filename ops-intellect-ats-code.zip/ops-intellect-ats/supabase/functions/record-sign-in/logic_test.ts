import { assertEquals } from '../_shared/testing.ts';
import { assessDevice, deviceLabel, SignInBody } from './logic.ts';

const KEY = '3f2b8c1a-1111-4222-8333-444455556666';

Deno.test('first ever computer is not flagged', () => {
  assertEquals(assessDevice([], KEY, '1.2.3.4'), { isNew: true, blocked: false, flag: null });
});

Deno.test('a second, new computer is flagged', () => {
  const v = assessDevice([{ device_key: 'aaaaaaaa-1111-4222-8333-444455556666', blocked: false, trusted: false, last_ip: null }], KEY, null);
  assertEquals(v.isNew, true);
  assertEquals(v.flag, 'Sign-in from a new computer');
});

Deno.test('a blocked computer is refused', () => {
  const v = assessDevice([{ device_key: KEY, blocked: true, trusted: false, last_ip: null }], KEY, null);
  assertEquals(v.blocked, true);
});

Deno.test('changed IP on an untrusted computer is flagged, not on a trusted one', () => {
  const untrusted = assessDevice([{ device_key: KEY, blocked: false, trusted: false, last_ip: '1.1.1.1' }], KEY, '2.2.2.2');
  assertEquals(untrusted.flag, 'Sign-in from a new location (IP changed)');
  const trusted = assessDevice([{ device_key: KEY, blocked: false, trusted: true, last_ip: '1.1.1.1' }], KEY, '2.2.2.2');
  assertEquals(trusted.flag, null);
});

Deno.test('device label from user agent', () => {
  assertEquals(deviceLabel('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/130.0 Safari/537.36'), 'Windows · Chrome');
  assertEquals(deviceLabel(null), 'Unknown device');
});

Deno.test('body must carry a device id', () => {
  assertEquals(SignInBody.safeParse({ deviceKey: KEY }).success, true);
  assertEquals(SignInBody.safeParse({ deviceKey: 'not-a-device' }).success, false);
  assertEquals(SignInBody.safeParse({}).success, false);
});
