import { z } from 'zod';

export const SignInBody = z.object({
  deviceKey: z.string().toLowerCase().regex(/^[0-9a-f-]{36}$/, 'must be a device id'),
});
export type SignInBody = z.infer<typeof SignInBody>;

export interface DeviceRow {
  device_key: string;
  blocked: boolean;
  trusted: boolean;
  last_ip: string | null;
}

export interface DeviceVerdict {
  isNew: boolean;
  blocked: boolean;
  flag: string | null;
}

/** New computer → flagged (unless it is the very first one). Changed IP on an untrusted computer → flagged. */
export function assessDevice(existing: DeviceRow[], deviceKey: string, ip: string | null): DeviceVerdict {
  const found = existing.find((d) => d.device_key === deviceKey);
  if (found?.blocked) return { isNew: false, blocked: true, flag: 'Sign-in attempt from a blocked computer' };
  if (!found) {
    return { isNew: true, blocked: false, flag: existing.length > 0 ? 'Sign-in from a new computer' : null };
  }
  if (!found.trusted && ip && found.last_ip && found.last_ip !== ip) {
    return { isNew: false, blocked: false, flag: 'Sign-in from a new location (IP changed)' };
  }
  return { isNew: false, blocked: false, flag: null };
}

/** "Windows · Chrome" style label from a user-agent string. */
export function deviceLabel(ua: string | null): string {
  if (!ua) return 'Unknown device';
  const os = /Windows/i.test(ua)
    ? 'Windows'
    : /iPhone|iPad/i.test(ua)
    ? 'iPhone/iPad'
    : /Android/i.test(ua)
    ? 'Android'
    : /Mac OS X|Macintosh/i.test(ua)
    ? 'Mac'
    : /Linux/i.test(ua)
    ? 'Linux'
    : 'Other';
  const browser = /Edg\//.test(ua)
    ? 'Edge'
    : /OPR\//.test(ua)
    ? 'Opera'
    : /Chrome\//.test(ua)
    ? 'Chrome'
    : /Firefox\//.test(ua)
    ? 'Firefox'
    : /Safari\//.test(ua)
    ? 'Safari'
    : 'Browser';
  return `${os} · ${browser}`;
}
