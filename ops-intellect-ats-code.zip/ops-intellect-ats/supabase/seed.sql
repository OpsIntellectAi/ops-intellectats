-- Fictional demo data for LOCAL and STAGING only. Never run against production.
-- Every company, person, address and phone number here is invented.
-- Phone numbers use the reserved 555-01xx range.
-- Demo password for every account: Demo-Only-Passw0rd!  (Admins and Super Admins must also set up MFA.)

-- ---------- users ----------
with u(id, email, full_name) as (values
  ('00000000-0000-4000-8000-000000000001'::uuid, 'maya.sterling@demo.opsintellect.test', 'Maya Sterling'),
  ('00000000-0000-4000-8000-000000000002'::uuid, 'leo.hart@demo.opsintellect.test', 'Leo Hart'),
  ('00000000-0000-4000-8000-000000000003'::uuid, 'priya.nair@demo.opsintellect.test', 'Priya Nair'),
  ('00000000-0000-4000-8000-000000000004'::uuid, 'omar.diaz@demo.opsintellect.test', 'Omar Diaz'),
  ('00000000-0000-4000-8000-000000000005'::uuid, 'grace.kim@demo.opsintellect.test', 'Grace Kim'),
  ('00000000-0000-4000-8000-000000000006'::uuid, 'theo.brooks@demo.opsintellect.test', 'Theo Brooks'),
  ('00000000-0000-4000-8000-000000000007'::uuid, 'rosa.vega@demo.opsintellect.test', 'Rosa Vega'),
  ('00000000-0000-4000-8000-000000000008'::uuid, 'ben.walsh@demo.opsintellect.test', 'Ben Walsh'),
  ('00000000-0000-4000-8000-000000000009'::uuid, 'ivy.chen@demo.opsintellect.test', 'Ivy Chen'),
  ('00000000-0000-4000-8000-000000000010'::uuid, 'sam.patel@demo.opsintellect.test', 'Sam Patel'),
  ('00000000-0000-4000-8000-000000000011'::uuid, 'nora.pending@demo.opsintellect.test', 'Nora Quinn')
)
insert into auth.users (
  instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
  raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
  confirmation_token, email_change, email_change_token_new, recovery_token
)
select '00000000-0000-0000-0000-000000000000', id, 'authenticated', 'authenticated', email,
  extensions.crypt('Demo-Only-Passw0rd!', extensions.gen_salt('bf')), now(),
  '{"provider":"email","providers":["email"]}'::jsonb, jsonb_build_object('full_name', full_name),
  now(), now(), '', '', '', ''
from u;

insert into auth.identities (id, user_id, provider_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
select gen_random_uuid(), id, id::text,
  jsonb_build_object('sub', id::text, 'email', email, 'email_verified', true),
  'email', now(), now(), now()
from auth.users where email like '%@demo.opsintellect.test';

-- Profiles were created as "pending viewer" by the sign-up trigger; give each a level.
update public.profiles p set role = v.role::public.app_role, status = v.status::public.user_status
from (values
  ('00000000-0000-4000-8000-000000000001'::uuid, 'super_admin', 'active'),
  ('00000000-0000-4000-8000-000000000002'::uuid, 'admin', 'active'),
  ('00000000-0000-4000-8000-000000000003'::uuid, 'supervisor', 'active'),
  ('00000000-0000-4000-8000-000000000004'::uuid, 'csr', 'active'),
  ('00000000-0000-4000-8000-000000000005'::uuid, 'csr', 'active'),
  ('00000000-0000-4000-8000-000000000006'::uuid, 'ops', 'active'),
  ('00000000-0000-4000-8000-000000000007'::uuid, 'station_manager', 'active'),
  ('00000000-0000-4000-8000-000000000008'::uuid, 'dsp_manager', 'active'),
  ('00000000-0000-4000-8000-000000000009'::uuid, 'viewer', 'active'),
  ('00000000-0000-4000-8000-000000000010'::uuid, 'csr', 'active'),
  ('00000000-0000-4000-8000-000000000011'::uuid, 'csr', 'pending')
) as v(id, role, status)
where p.id = v.id;

-- ---------- clients, stations, job roles ----------
insert into public.clients (id, name, slug, is_live) values
  ('10000000-0000-4000-8000-000000000001', 'Northline Delivery', 'northline', false),
  ('10000000-0000-4000-8000-000000000002', 'Bluepeak Logistics', 'bluepeak', false),
  ('10000000-0000-4000-8000-000000000003', 'Cedar Route DSP', 'cedar-route', false);

insert into public.client_settings (client_id, time_zone, contact_name, contact_email, contact_phone) values
  ('10000000-0000-4000-8000-000000000001', 'America/New_York', 'Dana Mercer', 'dana.mercer@northline.example', '+12025550101'),
  ('10000000-0000-4000-8000-000000000002', 'America/Chicago', 'Felix Romano', 'felix.romano@bluepeak.example', '+13125550102'),
  ('10000000-0000-4000-8000-000000000003', 'America/Denver', 'Hana Okafor', 'hana.okafor@cedarroute.example', '+17205550103');

insert into public.stations (id, client_id, code, name, address, time_zone) values
  ('20000000-0000-4000-8000-000000000001', '10000000-0000-4000-8000-000000000001', 'NL1', 'Riverton Hub', '100 Example Way, Riverton, NJ 07000', 'America/New_York'),
  ('20000000-0000-4000-8000-000000000002', '10000000-0000-4000-8000-000000000001', 'NL2', 'Lakeside Hub', '200 Sample Road, Lakeside, NJ 07001', 'America/New_York'),
  ('20000000-0000-4000-8000-000000000003', '10000000-0000-4000-8000-000000000002', 'BP1', 'Eastgate Hub', '300 Demo Avenue, Eastgate, IL 60000', 'America/Chicago'),
  ('20000000-0000-4000-8000-000000000004', '10000000-0000-4000-8000-000000000003', 'CR1', 'Millbrook Hub', '400 Placeholder Street, Millbrook, CO 80000', 'America/Denver');

insert into public.job_roles (id, client_id, station_id, name, pay_text, min_age, days_per_week) values
  ('30000000-0000-4000-8000-000000000001', '10000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000001', 'Delivery Driver', '$20.00 / hr (demo)', 21, '4–5'),
  ('30000000-0000-4000-8000-000000000002', '10000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000001', 'Walker', '$18.50 / hr (demo)', 18, '3–5'),
  ('30000000-0000-4000-8000-000000000003', '10000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000002', 'Delivery Driver', '$20.00 / hr (demo)', 21, '4–5'),
  ('30000000-0000-4000-8000-000000000004', '10000000-0000-4000-8000-000000000002', '20000000-0000-4000-8000-000000000003', 'Delivery Driver', '$19.50 / hr (demo)', 21, '4'),
  ('30000000-0000-4000-8000-000000000005', '10000000-0000-4000-8000-000000000002', '20000000-0000-4000-8000-000000000003', 'Helper', '$17.00 / hr (demo)', 18, '3–4'),
  ('30000000-0000-4000-8000-000000000006', '10000000-0000-4000-8000-000000000003', '20000000-0000-4000-8000-000000000004', 'Delivery Driver', '$21.00 / hr (demo)', 21, '4–5');

-- ---------- access ----------
insert into public.user_client_access (user_id, client_id, station_ids) values
  ('00000000-0000-4000-8000-000000000002', '10000000-0000-4000-8000-000000000001', null),
  ('00000000-0000-4000-8000-000000000002', '10000000-0000-4000-8000-000000000002', null),
  ('00000000-0000-4000-8000-000000000003', '10000000-0000-4000-8000-000000000001', null),
  ('00000000-0000-4000-8000-000000000004', '10000000-0000-4000-8000-000000000001', null),
  ('00000000-0000-4000-8000-000000000005', '10000000-0000-4000-8000-000000000001', null),
  ('00000000-0000-4000-8000-000000000005', '10000000-0000-4000-8000-000000000002', null),
  ('00000000-0000-4000-8000-000000000006', '10000000-0000-4000-8000-000000000001', null),
  ('00000000-0000-4000-8000-000000000007', '10000000-0000-4000-8000-000000000001', array['20000000-0000-4000-8000-000000000001'::uuid]),
  ('00000000-0000-4000-8000-000000000008', '10000000-0000-4000-8000-000000000002', null),
  ('00000000-0000-4000-8000-000000000009', '10000000-0000-4000-8000-000000000003', null),
  ('00000000-0000-4000-8000-000000000010', '10000000-0000-4000-8000-000000000002', null),
  ('00000000-0000-4000-8000-000000000011', '10000000-0000-4000-8000-000000000001', null);

insert into public.teams (supervisor_id, csr_id) values
  ('00000000-0000-4000-8000-000000000003', '00000000-0000-4000-8000-000000000004'),
  ('00000000-0000-4000-8000-000000000003', '00000000-0000-4000-8000-000000000005');

-- ---------- candidates and applications ----------
-- Northline: 16 people across NL1 (Driver, Walker) and NL2 (Driver), owned by Omar and Grace.
with names(n, full_name) as (
  select row_number() over (), x from unnest(array[
    'Jordan Miles', 'Alicia Gomez', 'Marcus Bell', 'Tanya Rowe', 'Devon Park', 'Keisha Lane',
    'Luis Ortega', 'Hannah Pryor', 'Andre Foster', 'Nina Volkov', 'Caleb Shaw', 'Riya Desai',
    'Owen Grant', 'Zoe Whitaker', 'Isaac Moreno', 'Leah Benson'
  ]) as x
)
insert into public.candidates (id, client_id, full_name, phone_e164, email, city, zip)
select ('40000000-0000-4000-8000-0000000000' || lpad(n::text, 2, '0'))::uuid,
  '10000000-0000-4000-8000-000000000001', full_name,
  '+1202555' || lpad((100 + n)::text, 4, '0'),
  lower(replace(full_name, ' ', '.')) || '@example.com', 'Riverton', '07000'
from names;

insert into public.applications (id, client_id, candidate_id, station_id, job_role_id, stage, owner_id, source, applied_at, not_interested_reason)
select ('50000000-0000-4000-8000-0000000000' || lpad(n::text, 2, '0'))::uuid,
  '10000000-0000-4000-8000-000000000001',
  ('40000000-0000-4000-8000-0000000000' || lpad(n::text, 2, '0'))::uuid,
  case when n % 3 = 0 then '20000000-0000-4000-8000-000000000002'::uuid else '20000000-0000-4000-8000-000000000001'::uuid end,
  case when n % 3 = 0 then '30000000-0000-4000-8000-000000000003'::uuid
       when n % 2 = 0 then '30000000-0000-4000-8000-000000000002'::uuid
       else '30000000-0000-4000-8000-000000000001'::uuid end,
  st.stage::public.app_stage,
  case when n % 2 = 1 then '00000000-0000-4000-8000-000000000004'::uuid else '00000000-0000-4000-8000-000000000005'::uuid end,
  (array['Indeed', 'Facebook', 'Referral', 'Craigslist'])[1 + n % 4],
  now() - (n || ' days')::interval,
  case when st.stage::public.app_stage = 'not_interested' then 'Found another job' end
from generate_series(1, 16) as n
cross join lateral (select (array[
    'interview', 'interview', 'interview', 'interview', 'interview', 'shortlisted', 'shortlisted',
    'pre_onboarding', 'onboarding', 'onboarding', 'onboarding', 'hired', 'hired', 'not_interested',
    'rejected', 'interview'
  ])[n] as stage) as st;

-- Bluepeak: 8 people at BP1, owned by Grace and Sam. Candidate 61 shares a phone with a
-- Northline candidate (allowed: different client).
insert into public.candidates (id, client_id, full_name, phone_e164, email, city, zip)
select ('40000000-0000-4000-8000-0000000000' || (60 + n))::uuid,
  '10000000-0000-4000-8000-000000000002',
  (array['Jordan Miles', 'Paula Reyes', 'Victor Hale', 'Simone Clark', 'Tariq Owens', 'Megan Ruiz', 'Felipe Duarte', 'Wendy Sato'])[n],
  case when n = 1 then '+12025550101' else '+1312555' || lpad((120 + n)::text, 4, '0') end,
  null, 'Eastgate', '60000'
from generate_series(1, 8) as n;

insert into public.applications (id, client_id, candidate_id, station_id, job_role_id, stage, owner_id, source, applied_at)
select ('50000000-0000-4000-8000-0000000000' || (60 + n))::uuid,
  '10000000-0000-4000-8000-000000000002',
  ('40000000-0000-4000-8000-0000000000' || (60 + n))::uuid,
  '20000000-0000-4000-8000-000000000003',
  case when n % 2 = 0 then '30000000-0000-4000-8000-000000000005'::uuid else '30000000-0000-4000-8000-000000000004'::uuid end,
  (array['interview', 'interview', 'interview', 'shortlisted', 'onboarding', 'interview', 'pre_onboarding', 'interview'])[n]::public.app_stage,
  case when n % 2 = 1 then '00000000-0000-4000-8000-000000000005'::uuid else '00000000-0000-4000-8000-000000000010'::uuid end,
  'Indeed', now() - (n || ' days')::interval
from generate_series(1, 8) as n;

-- Cedar Route: 5 people at CR1, not assigned to a CSR yet.
insert into public.candidates (id, client_id, full_name, phone_e164, city, zip)
select ('40000000-0000-4000-8000-0000000000' || (80 + n))::uuid,
  '10000000-0000-4000-8000-000000000003',
  (array['Grant Ellis', 'Maribel Soto', 'Kofi Mensah', 'Erin Doyle', 'Rafael Lima'])[n],
  '+1720555' || lpad((150 + n)::text, 4, '0'), 'Millbrook', '80000'
from generate_series(1, 5) as n;

insert into public.applications (id, client_id, candidate_id, station_id, job_role_id, stage, owner_id, source)
select ('50000000-0000-4000-8000-0000000000' || (80 + n))::uuid,
  '10000000-0000-4000-8000-000000000003',
  ('40000000-0000-4000-8000-0000000000' || (80 + n))::uuid,
  '20000000-0000-4000-8000-000000000004', '30000000-0000-4000-8000-000000000006',
  'interview', null, 'Facebook'
from generate_series(1, 5) as n;

-- ---------- consents ----------
insert into public.consents (candidate_id, client_id, consent_type, wording_version, source)
select c.id, c.client_id, t, 'v1-2026-11', 'Application form checkbox'
from public.candidates c
cross join unnest(array['sms', 'ai_call', 'recording']::public.consent_type[]) as t;

-- ---------- onboarding step definitions (13 per client) ----------
insert into public.onboarding_step_defs (client_id, key, name, phase, owner_label, statuses, done_statuses, bad_statuses, guidance, required, sort_order)
select c.id, d.key, d.name, d.phase, d.owner_label, d.statuses, d.done_statuses, d.bad_statuses, d.guidance, d.required, d.sort_order
from public.clients c
cross join (values
  ('licence', 'Driver''s licence verification', 'Pre-hire', 'CSR', array['Not started','Pending','Verified','Failed','Waived'], array['Verified'], array['Failed'], '{}'::jsonb, true, 1),
  ('dsp_invite', 'DSP Portal invitation', 'Pre-hire', 'CSR', array['Not started','Invited','Account created','Associate Settings done','Waived'], array['Associate Settings done'], array[]::text[], '{"Invited":"The invite is sent by hand in the Amazon DSP portal, then marked here."}'::jsonb, true, 2),
  ('offer', 'Offer letter', 'Pre-hire', 'CSR', array['Not started','Sent','Signed','Declined','Waived'], array['Signed'], array['Declined'], '{}'::jsonb, true, 3),
  ('handbook', 'Handbook', 'Pre-hire', 'CSR', array['Not started','Sent','Acknowledged','Waived'], array['Acknowledged'], array[]::text[], '{}'::jsonb, true, 4),
  ('background', 'Background check', 'Screening', 'Ops', array['Not started','Draft / Pending','Report Review','Meets Requirements','Adverse','Waived'], array['Meets Requirements'], array['Adverse'], '{"Report Review":"Report Review cannot be expedited.","Adverse":"Adverse results go to the client. Do not explain the result to the candidate yourself."}'::jsonb, true, 5),
  ('drug_test', 'Drug test', 'Screening', 'Ops', array['Not started','Ordered','Collected','Negative','Negative Dilute','Positive','Waived'], array['Negative'], array['Positive'], '{"Collected":"Collected is not a result. Wait for the lab.","Negative Dilute":"Negative Dilute is its own status. Follow the client''s retest policy.","Positive":"Positive results go to the client."}'::jsonb, true, 6),
  ('payroll', 'Payroll profile', 'Paperwork', 'Ops', array['Not started','Sent','Completed','Waived'], array['Completed'], array[]::text[], '{}'::jsonb, true, 7),
  ('wotc', 'WOTC', 'Paperwork', 'Ops', array['Not started','Sent','Completed','Waived'], array['Completed'], array[]::text[], '{}'::jsonb, false, 8),
  ('i9', 'I-9', 'Paperwork', 'Ops', array['Not started','Section 1 done','Verified','Waived'], array['Verified'], array[]::text[], '{}'::jsonb, true, 9),
  ('ready_email', 'Ready for Training email', 'Training', 'CSR', array['Not started','Sent','Waived'], array['Sent'], array[]::text[], '{}'::jsonb, true, 10),
  ('training_1', 'Training Day 1', 'Training', 'Station', array['Not started','Booked','Pass','No-show','Fail','Waived'], array['Pass'], array['No-show','Fail'], '{}'::jsonb, true, 11),
  ('training_2', 'Training Day 2', 'Training', 'Station', array['Not started','Booked','Pass','No-show','Fail','Waived'], array['Pass'], array['No-show','Fail'], '{}'::jsonb, true, 12),
  ('active', 'Active / client notified', 'Done', 'CSR', array['Not started','Notified','Waived'], array['Notified'], array[]::text[], '{}'::jsonb, true, 13)
) as d(key, name, phase, owner_label, statuses, done_statuses, bad_statuses, guidance, required, sort_order);

-- Steps: hired people have every step done; people in onboarding are part-way.
insert into public.onboarding_steps (application_id, client_id, step_def_id, status)
select a.id, a.client_id, d.id,
  case
    when a.stage = 'hired' then d.done_statuses[1]
    when d.sort_order <= 2 then d.done_statuses[1]
    when d.sort_order = 3 then 'Sent'
    when d.key = 'background' then 'Draft / Pending'
    else 'Not started'
  end
from public.applications a
join public.onboarding_step_defs d on d.client_id = a.client_id
where a.stage in ('onboarding', 'hired');

-- ---------- scripts (one per job role, version 1) ----------
insert into public.scripts (id, client_id, job_role_id, name)
select gen_random_uuid(), j.client_id, j.id, j.name || ' interview' from public.job_roles j;

insert into public.script_versions (script_id, client_id, version, question_tree, global_rules, note, published_by, published_at)
select s.id, s.client_id, 1,
  '[
    {"key":"q1","type":"yes_no","text":"Are you 21 or older?","yes":"Says yes or gives an age of 21+","no":"Under 21","dealbreaker":true},
    {"key":"q2","type":"yes_no","text":"Do you have a valid US driver''s licence?","yes":"Has a valid, non-suspended licence","no":"No licence or suspended","dealbreaker":true},
    {"key":"q3","type":"yes_no","text":"Can you work at least one weekend day?","yes":"Saturday or Sunday works","no":"No weekend days"},
    {"key":"q4","type":"recorded","text":"When could you start?"}
  ]'::jsonb,
  '["Say you are an AI assistant calling for the company","Say the call is recorded","Ask if now is a safe time to talk","Never ask about origin, religion, family, health, disability or arrests"]'::jsonb,
  'Starter script (demo)', '00000000-0000-4000-8000-000000000001', now()
from public.scripts s;

update public.scripts s set current_version_id = v.id
from public.script_versions v where v.script_id = s.id and v.version = 1;

-- ---------- calls, answers, reviews (a few, for screens and tests) ----------
insert into public.calls (id, application_id, client_id, provider, via, outcome, duration_seconds, script_version_id, provider_call_id, started_at, ended_at)
select gen_random_uuid(), a.id, a.client_id, 'vapi', 'ai', 'completed', 360 + (row_number() over ()) * 7,
  (select s.current_version_id from public.scripts s where s.job_role_id = a.job_role_id),
  'demo-call-' || a.id, now() - interval '2 days', now() - interval '2 days' + interval '6 minutes'
from public.applications a
where a.stage in ('shortlisted', 'pre_onboarding', 'onboarding', 'hired');

-- Northline candidate 01 finished a call but one answer needs a person.
insert into public.calls (id, application_id, client_id, provider, via, outcome, duration_seconds, script_version_id, provider_call_id, started_at, ended_at)
select '60000000-0000-4000-8000-000000000001', a.id, a.client_id, 'vapi', 'ai', 'completed', 402,
  (select s.current_version_id from public.scripts s where s.job_role_id = a.job_role_id),
  'demo-call-review-1', now() - interval '3 hours', now() - interval '3 hours' + interval '402 seconds'
from public.applications a where a.id = '50000000-0000-4000-8000-000000000001';

insert into public.call_answers (call_id, client_id, question_key, question_text, heard_text, result, at_seconds)
select c.id, c.client_id, q.key, q.text, q.heard, q.result::public.answer_result, q.at
from public.calls c
cross join (values
  ('q1', 'Are you 21 or older?', 'Yes, I am 26.', 'yes', 41),
  ('q2', 'Do you have a valid US driver''s licence?', 'I have a learner thing, I think.', 'needs_review', 88),
  ('q3', 'Can you work at least one weekend day?', 'Saturdays are fine.', 'yes', 130),
  ('q4', 'When could you start?', 'Next Monday.', 'recorded', 171)
) as q(key, text, heard, result, at)
where c.id = '60000000-0000-4000-8000-000000000001';

insert into public.call_reviews (call_id, client_id, verdict, reviewer_id)
select c.id, c.client_id, 'looks_right', '00000000-0000-4000-8000-000000000003'
from public.calls c where c.provider_call_id like 'demo-call-5%' and c.client_id = '10000000-0000-4000-8000-000000000001'
limit 3;

-- ---------- messages ----------
insert into public.messages (application_id, client_id, direction, body, status, is_automatic, created_at)
select a.id, a.client_id, 'outbound',
  'Hi ' || split_part(c.full_name, ' ', 1) || ', thanks for applying to ' || cl.name || '. Book your short AI interview here: https://example.com/book',
  'delivered', true, a.applied_at + interval '1 hour'
from public.applications a
join public.candidates c on c.id = a.candidate_id
join public.clients cl on cl.id = a.client_id;

insert into public.messages (application_id, client_id, direction, body, status, topics, created_at)
values
  ('50000000-0000-4000-8000-000000000002', '10000000-0000-4000-8000-000000000001', 'inbound', 'Yes, you can call me now.', 'received', array['said_yes'], now() - interval '20 minutes'),
  ('50000000-0000-4000-8000-000000000006', '10000000-0000-4000-8000-000000000001', 'inbound', 'My email is keisha.lane@example.com', 'received', array['shared_email'], now() - interval '2 hours');

-- ---------- templates, step texts, reminders, alerts, targets, views ----------
insert into public.message_templates (client_id, name, body, stages, is_scheduling_link)
select c.id, t.name, t.body, t.stages::public.app_stage[], t.link
from public.clients c
cross join (values
  ('Free for an AI call?', 'Hi [first name], if you are free we can do a quick AI call for the [role] role at [client]. Reply YES and we will call you now.', array['interview'], true),
  ('AI call scheduling link', 'Hi [first name], book your short AI interview for the [role] role here: [link]', array['interview'], true),
  ('Ask for email', 'Hi [first name], please text us an email address you have never used with Amazon, so we can send your onboarding invitation.', array['interview','shortlisted','pre_onboarding'], false),
  ('Create a Gmail', 'Hi [first name], please create a new Gmail address for your Amazon account and reply here with it.', array['shortlisted','pre_onboarding'], false),
  ('Background check', 'Hi [first name], your background check link is in your email. Please finish it today; it takes about 10 minutes.', array['onboarding'], false)
) as t(name, body, stages, link);

insert into public.step_messages (client_id, trigger_key, label, body, enabled)
select c.id, s.k, s.label, s.body, s.enabled
from public.clients c
cross join (values
  ('stage:shortlisted', 'Shortlisted', 'Great news [first name]! You passed the interview for [role] at [client]. Reply with your email so we can start onboarding.', true),
  ('step:dsp_invite:Associate Settings done', 'DSP Portal passed', 'You are all set on the DSP Portal, [first name]. Next: your offer letter and background check.', true),
  ('step:drug_test:Ordered', 'Drug test ordered', 'Hi [first name], your drug test is ordered. Go to the collection site within 24 hours with photo ID.', true),
  ('stage:hired', 'Hired', 'Congratulations [first name], you are hired at [client]!', true)
) as s(k, label, body, enabled);

insert into public.call_reminders (client_id, minutes_before, body, enabled)
select c.id, r.m, r.body, r.enabled
from public.clients c
cross join (values
  (300, 'Hi [first name], reminder: your AI interview for [role] at [client] is today at [time]. Reply C to change the time.', false),
  (120, 'Hi [first name], your AI interview for [role] at [client] is at [time] today, about 8 minutes. Reply C to change the time.', true),
  (15, 'Hi [first name], your AI interview starts at [time], in 15 minutes. Keep your phone close.', true)
) as r(m, body, enabled);

insert into public.alert_rules (client_id, rule_key, label, threshold, channel)
select c.id, r.k, r.label, r.t, r.ch::public.alert_channel
from public.clients c
cross join (values
  ('answer_rate', 'Answer rate on AI calls today drops below (%)', 70, 'text_email'),
  ('unreviewed_calls', 'AI calls not reviewed for 24 hours reach', 5, 'text_email'),
  ('shortlisted_no_reply', 'Shortlisted with no reply for 2+ days reach', 3, 'email'),
  ('onboarding_stuck', 'People stuck in onboarding over 24 h reach', 3, 'email'),
  ('behind_target', 'Hiring falls behind target pace by', 2, 'email')
) as r(k, label, t, ch);

insert into public.hiring_targets (client_id, job_role_id, hires, from_date, by_date, created_by)
values ('10000000-0000-4000-8000-000000000001', '30000000-0000-4000-8000-000000000001', 12, current_date - 10, current_date + 20, '00000000-0000-4000-8000-000000000002');

insert into public.saved_views (client_id, owner_id, name, filters, shared)
values ('10000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000003', 'Shortlisted · no reply 2+ days · mine',
  '{"stage":"shortlisted","noReplyDays":2,"mine":true}', true);

-- Every default automatic text, reminder and alert that a new client gets (same as staging).
do $$ begin perform private.seed_client_defaults(id) from public.clients; end $$;
