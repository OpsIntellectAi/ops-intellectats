-- Feedback round 1: flexible phones, Super Admin toggles, reason templates, bulk AI calls,
-- alert status, last-message columns, call overview column.
begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;
select plan(30);

create schema tests;
create function tests.login(p_user uuid, p_aal text default 'aal2')
returns void language plpgsql as $$
declare sid uuid := gen_random_uuid();
begin
  insert into auth.sessions (id, user_id, created_at, updated_at) values (sid, p_user, now() - interval '1 hour', now());
  perform set_config('request.jwt.claims',
    json_build_object('sub', p_user, 'role', 'authenticated', 'aal', p_aal, 'session_id', sid)::text, true);
end $$;
create function tests.text_as(p_user uuid, p_sql text)
returns text language plpgsql as $$
declare t text;
begin
  perform tests.login(p_user);
  execute 'set local role authenticated';
  begin
    execute p_sql into t;
  exception when others then
    t := 'error:' || sqlstate || ':' || sqlerrm;
  end;
  execute 'reset role';
  perform set_config('request.jwt.claims', '', true);
  return t;
end $$;
grant usage on schema tests to authenticated;

-- People: 01 Super Admin · 02 Admin · 04 CSR (Northline). Northline client id from the seed.
create temp table nl as select id from public.clients where name = 'Northline Delivery';
grant select on nl to authenticated;

-- ---------- phones ----------
select is(public.normalize_us_phone('7073330140'), '+17073330140', '10 digits → +1');
select is(public.normalize_us_phone('(707) 333-0140'), '+17073330140', 'brackets, space and dash are ignored');
select is(public.normalize_us_phone('707.333.0140'), '+17073330140', 'dots are ignored');
select is(public.normalize_us_phone(' 707 333 0140 '), '+17073330140', 'spaces are ignored');
select is(public.normalize_us_phone('+1 707-333-0140'), '+17073330140', '+1 prefix accepted');
select is(public.normalize_us_phone('1-707-333-0140'), '+17073330140', 'leading 1 accepted');
select is(public.normalize_us_phone('70733301'), null, '8 digits rejected');
select is(public.normalize_us_phone('27073330140'), null, '11 digits not starting with 1 rejected');
select is(public.normalize_us_phone('abc'), null, 'letters only rejected');

-- ---------- toggles ----------
select is(private.feature_on((select id from nl), 'ai_calls'), true, 'A toggle with no setting is ON');
select is(tests.text_as('00000000-0000-4000-8000-000000000002',
  $$select public.set_feature((select id from nl), 'ai_calls', false)::text$$) like 'error:42501%', true,
  'Admin cannot change toggles');
select is(tests.text_as('00000000-0000-4000-8000-000000000004',
  $$update public.client_settings set features = '{"ai_calls": false}' where client_id = (select id from nl) returning 'x'$$) is distinct from 'x', true,
  'CSR cannot change toggles by a direct update');
select is(tests.text_as('00000000-0000-4000-8000-000000000001',
  $$select public.set_feature((select id from nl), 'nonsense', false)::text$$) like 'error:23514%', true,
  'Unknown toggle is refused');
select is(tests.text_as('00000000-0000-4000-8000-000000000001',
  $$select (public.set_feature((select id from nl), 'ai_calls', false) ->> 'ai_calls')$$), 'false',
  'Super Admin turns AI calls off');
select is(public.ai_call_check('50000000-0000-4000-8000-000000000003', false), 'AI calls are turned off for this client',
  'AI call check honours the toggle');
select ok(exists (select 1 from public.audit_log where action = 'Feature toggles changed'), 'Toggle change is in the activity log');
select is(tests.text_as('00000000-0000-4000-8000-000000000004',
  $$select public.feature_on((select id from nl), 'ai_calls')::text$$), 'false', 'Signed-in users can read a toggle');
select is(tests.text_as('00000000-0000-4000-8000-000000000001',
  $$select (public.set_feature((select id from nl), 'ai_calls', true) ->> 'ai_calls')$$), 'true',
  'Super Admin turns AI calls back on');

-- ---------- reason templates ----------
select ok(cardinality((select reject_reasons from public.client_settings where client_id = (select id from nl))) >= 5,
  'Reject reason templates exist by default');
select ok(cardinality((select not_interested_reasons from public.client_settings where client_id = (select id from nl))) >= 5,
  'Not-interested reason templates exist by default');

-- ---------- add applicant with any phone format ----------
select is(tests.text_as('00000000-0000-4000-8000-000000000001',
  $$select public.add_applicant((select id from nl), (select station_id from public.applications where id = '50000000-0000-4000-8000-000000000003'),
     (select job_role_id from public.applications where id = '50000000-0000-4000-8000-000000000003'),
     'Test Person', '707 333.01-40', null, null, null, 'Indeed', null, true, true, true) ->> 'status'$$), 'added',
  'Add applicant accepts "707 333.01-40"');
select is((select phone_e164 from public.candidates where full_name = 'Test Person'), '+17073330140', 'Saved as +17073330140');

-- ---------- bulk AI calls ----------
create temp table bulk as select tests.text_as('00000000-0000-4000-8000-000000000001',
  $$select public.queue_ai_calls(array(select id from public.applications where client_id = (select id from nl) and stage = 'interview'))::text$$)::jsonb as r;
select ok(((select r from bulk) ->> 'queued')::int + jsonb_array_length((select r from bulk) -> 'skipped')
  = (select count(*) from public.applications where client_id = (select id from nl) and stage = 'interview'),
  'Every chosen candidate is either queued or skipped with a reason');
select ok(not exists (select 1 from jsonb_array_elements((select r from bulk) -> 'skipped') x where coalesce(x ->> 'reason', '') = ''),
  'Each skipped candidate has a reason');
create temp table one_q as select (payload ->> 'application_id')::uuid as id from public.job_queue where kind = 'ai_call' and status = 'queued' and payload ? 'bulk' limit 1;
grant select on one_q to authenticated;
select is(tests.text_as('00000000-0000-4000-8000-000000000001',
  $$select (public.queue_ai_calls(array(select id from one_q)) ->> 'queued')$$),
  '0', 'A candidate already queued is not queued twice');
select ok((select count(*) from public.audit_log where action = 'Bulk AI calls queued') >= 1, 'Bulk AI calls are in the activity log');
select tests.text_as('00000000-0000-4000-8000-000000000001', $$select public.set_feature((select id from nl), 'bulk_ai_calls', false)::text$$);
select is(tests.text_as('00000000-0000-4000-8000-000000000001',
  $$select public.queue_ai_calls(array['50000000-0000-4000-8000-000000000003'::uuid])::text$$) like 'error:23514%', true,
  'Bulk AI calls OFF → refused');

-- ---------- alert status ----------
select is(tests.text_as('00000000-0000-4000-8000-000000000003', $$select count(*)::text from public.alert_status((select id from nl))$$) ~ '^[0-9]+$', true,
  'Alert status runs for a Supervisor of the client');

-- ---------- views ----------
select has_column('public', 'application_rows', 'last_status', 'Candidate rows carry the last message status');
select has_column('public', 'call_rows', 'summary', 'Call rows carry the overview');

select * from finish();
rollback;
