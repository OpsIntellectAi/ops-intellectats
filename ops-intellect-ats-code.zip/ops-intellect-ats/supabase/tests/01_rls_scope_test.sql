-- RLS tests: what each of the 8 roles can and cannot read or write.
-- Runs on the fictional seed (supabase/seed.sql). Expected numbers below come from it:
--   Northline: 16 applications (11 at NL1, 5 at NL2), Omar owns 8, Grace owns 8
--   Bluepeak: 8 applications, Grace owns 4, Sam owns 4
--   Cedar Route: 5 applications, nobody assigned
begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;
select plan(52);

create schema tests;

-- Pretend to be a signed-in user: a real auth.sessions row + JWT claims.
create function tests.login(p_user uuid, p_aal text default 'aal2', p_age interval default interval '1 hour')
returns void language plpgsql as $$
declare sid uuid := gen_random_uuid();
begin
  insert into auth.sessions (id, user_id, created_at, updated_at) values (sid, p_user, now() - p_age, now());
  perform set_config('request.jwt.claims',
    json_build_object('sub', p_user, 'role', 'authenticated', 'aal', p_aal, 'session_id', sid)::text, true);
end $$;

-- Count rows of a query as that user (RLS applies).
create function tests.count_as(p_user uuid, p_sql text, p_aal text default 'aal2', p_age interval default interval '1 hour')
returns bigint language plpgsql as $$
declare n bigint;
begin
  perform tests.login(p_user, p_aal, p_age);
  execute 'set local role authenticated';
  execute 'select count(*) from (' || p_sql || ') q' into n;
  execute 'reset role';
  perform set_config('request.jwt.claims', '', true);
  return n;
end $$;

-- Run a write as that user. Returns 'ok:<rows>' or 'error:<sqlstate>'.
create function tests.try_as(p_user uuid, p_sql text, p_aal text default 'aal2')
returns text language plpgsql as $$
declare n bigint;
begin
  perform tests.login(p_user, p_aal);
  execute 'set local role authenticated';
  begin
    execute p_sql;
    get diagnostics n = row_count;
    execute 'reset role';
    perform set_config('request.jwt.claims', '', true);
    return 'ok:' || n;
  exception when others then
    execute 'reset role';
    perform set_config('request.jwt.claims', '', true);
    return 'error:' || sqlstate;
  end;
end $$;

-- Anonymous visitor: no rows, or no permission at all (-1).
create function tests.anon_count(p_sql text)
returns bigint language plpgsql as $$
declare n bigint;
begin
  perform set_config('request.jwt.claims', '{"role":"anon"}', true);
  execute 'set local role anon';
  begin
    execute 'select count(*) from (' || p_sql || ') q' into n;
  exception when insufficient_privilege then
    n := -1;
  end;
  execute 'reset role';
  perform set_config('request.jwt.claims', '', true);
  return n;
end $$;

-- Rows of one client a user can see, summed over every client-owned table.
create function tests.leak_rows(p_user uuid, p_client uuid)
returns bigint language plpgsql as $$
declare t text; total bigint := 0; n bigint;
begin
  for t in
    select c.table_name from information_schema.columns c
    join information_schema.tables tb on tb.table_schema = c.table_schema and tb.table_name = c.table_name and tb.table_type = 'BASE TABLE'
    where c.table_schema = 'public' and c.column_name = 'client_id'
  loop
    n := tests.count_as(p_user, format('select 1 from public.%I where client_id = %L', t, p_client));
    total := total + n;
  end loop;
  return total + tests.count_as(p_user, format('select 1 from public.clients where id = %L', p_client));
end $$;

grant usage on schema tests to authenticated, anon;


-- ---------------- anonymous ----------------
select ok(tests.anon_count('select 1 from public.applications') <= 0, 'anon: 0 applications');
select ok(tests.anon_count('select 1 from public.candidates') <= 0, 'anon: 0 candidates');
select ok(tests.anon_count('select 1 from public.clients') <= 0, 'anon: 0 clients');
select ok(tests.anon_count('select 1 from public.profiles') <= 0, 'anon: 0 profiles');
select ok(tests.anon_count('select 1 from public.audit_log') <= 0, 'anon: 0 audit rows');

-- ---------------- applications by role ----------------
select is(tests.count_as('00000000-0000-4000-8000-000000000004', 'select 1 from public.applications'), 8::bigint, 'CSR Omar: only his 8');
select is(tests.count_as('00000000-0000-4000-8000-000000000005', 'select 1 from public.applications'), 12::bigint, 'CSR Grace: her 8 Northline + 4 Bluepeak');
select is(tests.count_as('00000000-0000-4000-8000-000000000010', 'select 1 from public.applications'), 4::bigint, 'CSR Sam: his 4');
select is(tests.count_as('00000000-0000-4000-8000-000000000003', 'select 1 from public.applications'), 16::bigint, 'Supervisor Priya: her team in Northline (not Grace''s Bluepeak)');
select is(tests.count_as('00000000-0000-4000-8000-000000000002', 'select 1 from public.applications'), 24::bigint, 'Admin Leo (MFA): Northline + Bluepeak');
select is(tests.count_as('00000000-0000-4000-8000-000000000002', 'select 1 from public.applications', 'aal1'), 0::bigint, 'Admin without MFA: 0');
select is(tests.count_as('00000000-0000-4000-8000-000000000001', 'select 1 from public.applications'), 29::bigint, 'Super Admin (MFA): all 29');
select is(tests.count_as('00000000-0000-4000-8000-000000000001', 'select 1 from public.applications', 'aal1'), 0::bigint, 'Super Admin without MFA: 0');
select is(tests.count_as('00000000-0000-4000-8000-000000000006', 'select 1 from public.applications'), 16::bigint, 'Ops Theo: all of Northline');
select is(tests.count_as('00000000-0000-4000-8000-000000000007', 'select 1 from public.applications'), 11::bigint, 'Station Manager Rosa: NL1 only');
select is(tests.count_as('00000000-0000-4000-8000-000000000008', 'select 1 from public.applications'), 8::bigint, 'DSP Manager Ben: Bluepeak only');
select is(tests.count_as('00000000-0000-4000-8000-000000000009', 'select 1 from public.applications'), 5::bigint, 'Viewer Ivy: Cedar Route only');
select is(tests.count_as('00000000-0000-4000-8000-000000000011', 'select 1 from public.applications'), 0::bigint, 'Pending account: 0');
select is(tests.count_as('00000000-0000-4000-8000-000000000004', 'select 1 from public.applications', 'aal1', interval '13 hours'), 0::bigint, 'Session older than 12 h: 0');

-- ---------------- clients, stations, candidates ----------------
select is(tests.count_as('00000000-0000-4000-8000-000000000004', 'select 1 from public.clients'), 1::bigint, 'Omar sees 1 client');
select is(tests.count_as('00000000-0000-4000-8000-000000000005', 'select 1 from public.clients'), 2::bigint, 'Grace sees 2 clients');
select is(tests.count_as('00000000-0000-4000-8000-000000000007', 'select 1 from public.clients'), 1::bigint, 'Rosa sees 1 client');
select is(tests.count_as('00000000-0000-4000-8000-000000000009', 'select 1 from public.clients'), 1::bigint, 'Ivy sees 1 client');
select is(tests.count_as('00000000-0000-4000-8000-000000000001', 'select 1 from public.clients'), 3::bigint, 'Super Admin sees all 3 clients');
select is(tests.count_as('00000000-0000-4000-8000-000000000007', 'select 1 from public.stations'), 1::bigint, 'Station Manager sees only her station');
select is(tests.count_as('00000000-0000-4000-8000-000000000006', 'select 1 from public.stations'), 2::bigint, 'Ops sees both Northline stations');
select is(tests.count_as('00000000-0000-4000-8000-000000000004', 'select 1 from public.candidates'), 8::bigint, 'Omar sees only his 8 candidates');
select is(tests.count_as('00000000-0000-4000-8000-000000000009', 'select 1 from public.candidates'), 5::bigint, 'Ivy sees the 5 Cedar candidates');

-- ---------------- Client A user reads 0 rows of Client B (every client-owned table) ----------------
select is(tests.leak_rows('00000000-0000-4000-8000-000000000004', '10000000-0000-4000-8000-000000000002'), 0::bigint, 'Omar (Northline) → 0 rows of Bluepeak');
select is(tests.leak_rows('00000000-0000-4000-8000-000000000004', '10000000-0000-4000-8000-000000000003'), 0::bigint, 'Omar (Northline) → 0 rows of Cedar');
select is(tests.leak_rows('00000000-0000-4000-8000-000000000002', '10000000-0000-4000-8000-000000000003'), 0::bigint, 'Admin Leo → 0 rows of Cedar (not given)');
select is(tests.leak_rows('00000000-0000-4000-8000-000000000008', '10000000-0000-4000-8000-000000000001'), 0::bigint, 'DSP Manager Ben (Bluepeak) → 0 rows of Northline');
select is(tests.leak_rows('00000000-0000-4000-8000-000000000009', '10000000-0000-4000-8000-000000000001'), 0::bigint, 'Viewer Ivy (Cedar) → 0 rows of Northline');
select is(tests.count_as('00000000-0000-4000-8000-000000000007', 'select 1 from public.applications where station_id = ''20000000-0000-4000-8000-000000000002'''), 0::bigint, 'Station Manager → 0 applications of the other station');

-- ---------------- writes that must be refused ----------------
select is(tests.try_as('00000000-0000-4000-8000-000000000004', $q$insert into public.clients (name, slug) values ('Sneaky Co', 'sneaky')$q$), 'error:42501', 'CSR cannot add a client');
select is(tests.try_as('00000000-0000-4000-8000-000000000004', $q$insert into public.user_client_access (user_id, client_id) values ('00000000-0000-4000-8000-000000000004', '10000000-0000-4000-8000-000000000002')$q$), 'error:42501', 'CSR cannot give himself client access');
select is(tests.try_as('00000000-0000-4000-8000-000000000002', $q$insert into public.user_client_access (user_id, client_id) values ('00000000-0000-4000-8000-000000000004', '10000000-0000-4000-8000-000000000002')$q$), 'error:42501', 'Admin cannot give client access (Super Admin only)');
select is(tests.try_as('00000000-0000-4000-8000-000000000004', $q$update public.applications set owner_id = '00000000-0000-4000-8000-000000000004' where id = '50000000-0000-4000-8000-000000000002'$q$), 'ok:0', 'CSR cannot change another CSR''s application');
select is(tests.try_as('00000000-0000-4000-8000-000000000004', $q$insert into public.applications (client_id, candidate_id, station_id, job_role_id) values ('10000000-0000-4000-8000-000000000002', '40000000-0000-4000-8000-000000000062', '20000000-0000-4000-8000-000000000003', '30000000-0000-4000-8000-000000000004')$q$), 'error:42501', 'CSR cannot add an applicant to another client');
select is(tests.try_as('00000000-0000-4000-8000-000000000008', $q$update public.onboarding_steps set status = 'Signed' where client_id = '10000000-0000-4000-8000-000000000002'$q$), 'ok:0', 'DSP Manager (read-only) cannot update onboarding');
select is(tests.try_as('00000000-0000-4000-8000-000000000006', $q$update public.onboarding_steps s set status = 'Signed' from public.onboarding_step_defs d where d.id = s.step_def_id and d.key = 'offer' and s.application_id = '50000000-0000-4000-8000-000000000009'$q$), 'ok:1', 'Ops can update an onboarding step');
select is(tests.try_as('00000000-0000-4000-8000-000000000009', $q$insert into public.message_templates (client_id, name, body, stages) values ('10000000-0000-4000-8000-000000000003', 'Viewer try', 'Hello there', '{interview}')$q$), 'error:42501', 'Viewer cannot add a template');
select is(tests.try_as('00000000-0000-4000-8000-000000000004', $q$insert into public.message_templates (client_id, name, body, stages) values ('10000000-0000-4000-8000-000000000001', 'CSR try', 'Hello there', '{interview}')$q$), 'error:42501', 'CSR cannot add a template');
select is(tests.try_as('00000000-0000-4000-8000-000000000003', $q$insert into public.message_templates (client_id, name, body, stages) values ('10000000-0000-4000-8000-000000000001', 'I-9 documents', 'Bring two IDs on Day 1', '{onboarding}')$q$), 'ok:1', 'Supervisor can add a template');
select is(tests.try_as('00000000-0000-4000-8000-000000000004', $q$update public.feature_flags set enabled = false where key = 'my_day'$q$), 'ok:0', 'CSR cannot switch features');
select is(tests.try_as('00000000-0000-4000-8000-000000000001', $q$update public.feature_flags set enabled = false where key = 'my_day'$q$), 'ok:1', 'Super Admin can switch features');
select is(tests.try_as('00000000-0000-4000-8000-000000000001', $q$update public.feature_flags set enabled = true where key = 'my_day'$q$, 'aal1'), 'ok:0', 'Super Admin without MFA cannot switch features');
select is(tests.try_as('00000000-0000-4000-8000-000000000004', $q$insert into public.messages (application_id, client_id, direction, body) values ('50000000-0000-4000-8000-000000000001', '10000000-0000-4000-8000-000000000001', 'outbound', 'hi')$q$), 'error:42501', 'Users cannot write messages directly (Edge Functions only)');

-- ---------------- activity log and people ----------------
select is(tests.count_as('00000000-0000-4000-8000-000000000004', 'select 1 from public.audit_log'), 0::bigint, 'CSR cannot read the activity log');
select ok(tests.count_as('00000000-0000-4000-8000-000000000002', 'select 1 from public.audit_log') > 0, 'Admin reads the activity log of his clients');
select is(tests.count_as('00000000-0000-4000-8000-000000000002', 'select 1 from public.audit_log where client_id = ''10000000-0000-4000-8000-000000000003'''), 0::bigint, 'Admin reads 0 activity rows of a client he was not given');
select is(tests.count_as('00000000-0000-4000-8000-000000000004', 'select 1 from public.profiles'), 7::bigint, 'CSR sees only colleagues who share Northline');

select * from finish();
rollback;
