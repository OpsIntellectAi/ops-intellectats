-- Database-level business rules and the append-only activity log.
begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;
select plan(26);

create schema tests;
create function tests.login(p_user uuid, p_aal text default 'aal2', p_age interval default interval '1 hour')
returns void language plpgsql as $$
declare sid uuid := gen_random_uuid();
begin
  insert into auth.sessions (id, user_id, created_at, updated_at) values (sid, p_user, now() - p_age, now());
  perform set_config('request.jwt.claims',
    json_build_object('sub', p_user, 'role', 'authenticated', 'aal', p_aal, 'session_id', sid)::text, true);
end $$;
create function tests.try_as(p_user uuid, p_sql text, p_aal text default 'aal2')
returns text language plpgsql as $$
declare n bigint;
begin
  perform tests.login(p_user, p_aal);
  execute 'set local role authenticated';
  begin
    execute p_sql;
    get diagnostics n = row_count;
    execute 'reset role';
    perform set_config('request.jwt.claims', '', true);
    return 'ok:' || n;
  exception when others then
    execute 'reset role';
    perform set_config('request.jwt.claims', '', true);
    return 'error:' || sqlstate;
  end;
end $$;
create function tests.json_as(p_user uuid, p_sql text, p_aal text default 'aal2')
returns jsonb language plpgsql as $$
declare j jsonb;
begin
  perform tests.login(p_user, p_aal);
  execute 'set local role authenticated';
  execute p_sql into j;
  execute 'reset role';
  perform set_config('request.jwt.claims', '', true);
  return j;
end $$;
grant usage on schema tests to authenticated;

-- ---------------- append-only activity log ----------------
select throws_ok($$update public.audit_log set action = 'edited'$$, '42501', null, 'Nobody can edit the activity log (even the owner)');
select throws_ok($$delete from public.audit_log$$, '42501', null, 'Nobody can delete from the activity log');
select throws_ok($$truncate public.audit_log$$, '42501', null, 'Nobody can truncate the activity log');
select ok(not has_table_privilege('service_role', 'public.audit_log', 'UPDATE'), 'service role has no UPDATE on the activity log');
select ok(not has_table_privilege('authenticated', 'public.audit_log', 'INSERT'), 'users cannot insert activity rows directly');

-- ---------------- stage rules ----------------
-- Jordan Miles (app 01, owned by Omar) has an answer that still needs review.
select is(tests.try_as('00000000-0000-4000-8000-000000000004',
  $q$update public.applications set stage = 'shortlisted' where id = '50000000-0000-4000-8000-000000000001'$q$),
  'error:23514', 'Cannot shortlist while an answer needs review');
update public.call_answers set reviewed_at = now(), reviewed_by = '00000000-0000-4000-8000-000000000003'
  where call_id = '60000000-0000-4000-8000-000000000001';
select is(tests.try_as('00000000-0000-4000-8000-000000000004',
  $q$update public.applications set stage = 'shortlisted' where id = '50000000-0000-4000-8000-000000000001'$q$),
  'ok:1', 'Shortlist works once the answer is reviewed');
select is((select count(*) from public.stage_history where application_id = '50000000-0000-4000-8000-000000000001' and to_stage = 'shortlisted' and changed_by = '00000000-0000-4000-8000-000000000004'), 1::bigint, 'Stage change is recorded with who did it');
select is((select count(*) from public.audit_log where action = 'Stage changed' and actor_id = '00000000-0000-4000-8000-000000000004' and before_value = 'interview' and after_value = 'shortlisted'), 1::bigint, 'Stage change is in the activity log (before → after)');
-- Marcus Bell (app 03) never finished an AI interview.
select is(tests.try_as('00000000-0000-4000-8000-000000000004',
  $q$update public.applications set stage = 'shortlisted' where id = '50000000-0000-4000-8000-000000000003'$q$),
  'error:23514', 'Cannot shortlist without a completed AI interview');
-- Andre Foster (app 09) is part-way through onboarding.
select is(tests.try_as('00000000-0000-4000-8000-000000000004',
  $q$update public.applications set stage = 'hired' where id = '50000000-0000-4000-8000-000000000009'$q$),
  'error:23514', 'Cannot mark hired until every required step is done');
select is(tests.try_as('00000000-0000-4000-8000-000000000004',
  $q$update public.applications set stage = 'not_interested' where id = '50000000-0000-4000-8000-000000000005'$q$),
  'error:23514', 'Not interested needs a reason');
select throws_ok($$update public.onboarding_steps set status = 'Waived' where application_id = '50000000-0000-4000-8000-000000000009' and waived_reason is null$$,
  '23514', null, 'Waived needs a reason');

-- ---------------- field-level rules ----------------
select is(tests.try_as('00000000-0000-4000-8000-000000000006',
  $q$update public.applications set stage = 'rejected', rejection_reason = 'test' where id = '50000000-0000-4000-8000-000000000004'$q$),
  'error:42501', 'Ops cannot move a candidate to Rejected (only onboarding work)');
select is(tests.try_as('00000000-0000-4000-8000-000000000004',
  $q$update public.applications set owner_id = '00000000-0000-4000-8000-000000000005' where id = '50000000-0000-4000-8000-000000000003'$q$),
  'error:42501', 'CSR cannot reassign a candidate');
select is(tests.try_as('00000000-0000-4000-8000-000000000003',
  $q$update public.applications set owner_id = '00000000-0000-4000-8000-000000000005' where id = '50000000-0000-4000-8000-000000000003'$q$),
  'ok:1', 'Supervisor can reassign within the team');
select is(tests.try_as('00000000-0000-4000-8000-000000000004',
  $q$update public.applications set station_id = '20000000-0000-4000-8000-000000000002' where id = '50000000-0000-4000-8000-000000000001'$q$),
  'error:42501', 'Station / job role / client of an application cannot be changed by a person');

-- ---------------- data integrity ----------------
select throws_ok($$insert into public.candidates (client_id, full_name, phone_e164) values ('10000000-0000-4000-8000-000000000001', 'Copy Person', '+12025550101')$$,
  '23505', null, 'Same phone in the same client is blocked');
select is((select count(*) from public.candidates where phone_e164 = '+12025550101'), 2::bigint, 'Same phone in another client is allowed');
select throws_ok($$insert into public.messages (application_id, client_id, direction, body) values ('50000000-0000-4000-8000-000000000001', '10000000-0000-4000-8000-000000000002', 'outbound', 'x')$$,
  '23503', null, 'A row cannot be attached to a parent of another client');
select throws_ok($$update public.client_settings set quiet_start = '22:00' where client_id = '10000000-0000-4000-8000-000000000001'$$,
  '23514', null, 'Sending window can never go past 9:00 PM');

-- ---------------- MFA, new users, rate limits ----------------
select is(tests.json_as('00000000-0000-4000-8000-000000000002', 'select public.my_access()', 'aal1') ->> 'mfa_ok', 'false', 'Admin without MFA: my_access says MFA needed');
select is(tests.json_as('00000000-0000-4000-8000-000000000002', 'select public.my_access()', 'aal2') ->> 'effective_role', 'admin', 'Admin with MFA: role is active');
insert into auth.users (id, email, raw_user_meta_data) values ('00000000-0000-4000-8000-000000000099', 'new.person@example.com', '{"full_name":"New Person"}');
select is((select role::text || '/' || status::text from public.profiles where id = '00000000-0000-4000-8000-000000000099'), 'viewer/pending', 'A new sign-up starts pending with no access');
select ok(not has_function_privilege('authenticated', 'public.hit_rate_limit(text, integer, integer)', 'EXECUTE'), 'Users cannot call the rate limiter');
select is(array[public.hit_rate_limit('t:1', 2, 60), public.hit_rate_limit('t:1', 2, 60), public.hit_rate_limit('t:1', 2, 60)], array[true, true, false], 'Rate limiter allows 2 then blocks');

select * from finish();
rollback;
