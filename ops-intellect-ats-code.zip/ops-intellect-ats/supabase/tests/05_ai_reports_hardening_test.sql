-- Phases 4 + 5: insights stay in scope, training pack (Admin, names removed), alerts,
-- weekly report without names, retention, export / delete on request.
begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;
select plan(22);

create schema tests;
create function tests.login(p_user uuid, p_aal text default 'aal2')
returns void language plpgsql as $$
declare sid uuid := gen_random_uuid();
begin
  insert into auth.sessions (id, user_id, created_at, updated_at) values (sid, p_user, now() - interval '1 hour', now());
  perform set_config('request.jwt.claims',
    json_build_object('sub', p_user, 'role', 'authenticated', 'aal', p_aal, 'session_id', sid)::text, true);
end $$;
create function tests.json_as(p_user uuid, p_sql text)
returns jsonb language plpgsql as $$
declare j jsonb;
begin
  perform tests.login(p_user);
  execute 'set local role authenticated';
  begin
    execute p_sql into j;
  exception when others then
    j := jsonb_build_object('error', sqlstate);
  end;
  execute 'reset role';
  perform set_config('request.jwt.claims', '', true);
  return j;
end $$;
grant usage on schema tests to authenticated;

-- Users: 01 Maya super · 02 Leo admin · 03 Priya supervisor · 04 Omar CSR · 09 Ivy viewer (Cedar only)
-- ---------- insights ----------
select is(tests.json_as('00000000-0000-4000-8000-000000000004', $q$select public.insights_data('10000000-0000-4000-8000-000000000001')$q$) ->> 'error',
  '42501', 'CSR cannot open AI insights');
select is((tests.json_as('00000000-0000-4000-8000-000000000003', $q$select public.insights_data('10000000-0000-4000-8000-000000000001', null, 60)$q$) -> 'funnel' ->> 'applied')::integer,
  16, 'Supervisor sees the funnel of her team (16)');
select is(tests.json_as('00000000-0000-4000-8000-000000000009', $q$select public.insights_data('10000000-0000-4000-8000-000000000001')$q$) ->> 'error',
  '42501', 'Viewer of another client gets nothing');
select ok(jsonb_array_length(tests.json_as('00000000-0000-4000-8000-000000000003', $q$select public.insights_data('10000000-0000-4000-8000-000000000001', null, 60)$q$) -> 'questions') > 0,
  'Insights list the questions where people drop');

-- ---------- training pack ----------
update public.calls set transcript = 'AI: Hi Jordan. Candidate: Yes, this is Jordan Miles, call me on 2025550101.'
  where id = '60000000-0000-4000-8000-000000000001';
select is(tests.json_as('00000000-0000-4000-8000-000000000003', $q$select public.training_pack('10000000-0000-4000-8000-000000000001')$q$) ->> 'error',
  '42501', 'Supervisor cannot download the training pack (Admin and up)');
create temp table tp as select tests.json_as('00000000-0000-4000-8000-000000000002', $q$select public.training_pack('10000000-0000-4000-8000-000000000001')$q$) as j;
select ok(jsonb_array_length((select j from tp) -> 'calls') > 0, 'Admin downloads the training pack');
select ok(position('Jordan' in (select j::text from tp)) = 0, 'Training pack has no candidate names');
select ok(position('2025550101' in (select j::text from tp)) = 0, 'Training pack has no phone numbers');
select ok(exists (select 1 from public.audit_log where action = 'Training pack downloaded'), 'Download is in the activity log');

-- ---------- alerts ----------
update public.alert_rules set threshold = 1 where client_id = '10000000-0000-4000-8000-000000000001' and rule_key = 'onboarding_stuck';
update public.applications set stage_changed_at = now() - interval '3 days' where client_id = '10000000-0000-4000-8000-000000000001' and stage = 'onboarding';
alter table public.onboarding_steps disable trigger onboarding_steps_stamp; -- the stamp trigger always writes now()
update public.onboarding_steps set changed_at = now() - interval '3 days' where client_id = '10000000-0000-4000-8000-000000000001';
alter table public.onboarding_steps enable trigger onboarding_steps_stamp;
update public.profiles set phone_e164 = '+12025550190' where id = '00000000-0000-4000-8000-000000000003';
create temp table al as select * from public.evaluate_alerts(now());
select ok(exists (select 1 from al where message like 'Northline Delivery: % people stuck in onboarding%'), 'Onboarding-stuck alert fires');
select ok((select '+12025550190' = any (phones) from al where message like '%stuck in onboarding%'), 'Alert goes to the client''s Supervisor');
select is((select count(*) from public.evaluate_alerts(now()) x where x.message like '%stuck in onboarding%'), 0::bigint,
  'Same alert is not repeated within 6 hours');
select is(tests.json_as('00000000-0000-4000-8000-000000000004', $q$select to_jsonb(public.test_alert((select id from public.alert_rules limit 1)))$q$) ->> 'error',
  '42501', 'CSR cannot send test alerts');

-- ---------- weekly report ----------
create temp table wr as select private.weekly_report_html('10000000-0000-4000-8000-000000000001') as j;
select is((select j ->> 'to' from wr), 'dana.mercer@northline.example', 'Weekly report goes to the client contact');
select ok(position('Jordan' in (select j ->> 'html' from wr)) = 0 and position('Alicia' in (select j ->> 'html' from wr)) = 0,
  'Weekly report has no candidate names');
select ok(not has_function_privilege('authenticated', 'public.weekly_reports()', 'EXECUTE'), 'Only the scheduler can send weekly reports');

-- ---------- retention ----------
update public.calls set recording_path = '10000000-0000-4000-8000-000000000001/old.wav', ended_at = now() - interval '200 days'
  where id = '60000000-0000-4000-8000-000000000001';
update public.applications set stage_changed_at = now() - interval '2 years' where id = '50000000-0000-4000-8000-000000000015';
create temp table ret as select public.run_retention(now()) as j;
select ok((select j -> 'recording_paths' ? '10000000-0000-4000-8000-000000000001/old.wav' from ret), 'Recording older than 90 days is removed');
select is((select count(*) from public.applications where id = '50000000-0000-4000-8000-000000000015'), 0::bigint,
  'Rejected candidate older than 12 months is deleted');

-- ---------- export / delete on request ----------
select is(tests.json_as('00000000-0000-4000-8000-000000000004', $q$select public.export_candidate('40000000-0000-4000-8000-000000000001')$q$) ->> 'error',
  '42501', 'CSR cannot export a candidate''s data');
select is(tests.json_as('00000000-0000-4000-8000-000000000002', $q$select public.export_candidate('40000000-0000-4000-8000-000000000001')$q$) -> 'candidate' ->> 'full_name',
  'Jordan Miles', 'Admin exports a candidate''s data');
select ok(tests.json_as('00000000-0000-4000-8000-000000000002', $q$select public.delete_candidate('40000000-0000-4000-8000-000000000003', 'Asked by email to delete')$q$) ? 'recording_paths',
  'Admin deletes a candidate on request');
select ok(not exists (select 1 from public.candidates where id = '40000000-0000-4000-8000-000000000003')
  and exists (select 1 from public.audit_log where action = 'Candidate deleted on request' and target_label not like '%Marcus%'),
  'Deleted, and logged without the person''s name');

select * from finish();
rollback;
