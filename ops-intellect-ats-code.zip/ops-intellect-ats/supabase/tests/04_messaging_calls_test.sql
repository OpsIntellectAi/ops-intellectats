-- Phase 3: sending window, queue, automatic texts, no-reply cadence, replies and STOP,
-- emergency stop, booking reminders, AI call checks, call results and retries.
begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;
select plan(46);

create schema tests;
create function tests.login(p_user uuid, p_aal text default 'aal2')
returns void language plpgsql as $$
declare sid uuid := gen_random_uuid();
begin
  insert into auth.sessions (id, user_id, created_at, updated_at) values (sid, p_user, now() - interval '1 hour', now());
  perform set_config('request.jwt.claims',
    json_build_object('sub', p_user, 'role', 'authenticated', 'aal', p_aal, 'session_id', sid)::text, true);
end $$;
create function tests.text_as(p_user uuid, p_sql text)
returns text language plpgsql as $$
declare t text;
begin
  perform tests.login(p_user);
  execute 'set local role authenticated';
  begin
    execute p_sql into t;
  exception when others then
    t := 'error:' || sqlstate;
  end;
  execute 'reset role';
  perform set_config('request.jwt.claims', '', true);
  return t;
end $$;
grant usage on schema tests to authenticated;

-- Seed people used here (all Northline unless noted):
--   app 02 Alicia +12025550102 · app 03 Marcus · app 04 Tanya · app 05 Devon · app 16 Leah
--   app 62 Paula (Bluepeak, no email on file)

-- ---------- sending window (America/New_York, quiet 8 PM – 8 AM) ----------
select is(public.next_send_time('America/New_York', '20:00', '08:00', '2026-11-10 23:00+00'), '2026-11-10 23:00+00'::timestamptz,
  '6 PM local is inside the window → send now');
select is(public.next_send_time('America/New_York', '20:00', '08:00', '2026-11-11 02:00+00'), '2026-11-11 13:00+00'::timestamptz,
  '9 PM local → waits until 8 AM next morning');
select is(public.next_send_time('America/New_York', '20:00', '08:00', '2026-11-11 10:00+00'), '2026-11-11 13:00+00'::timestamptz,
  '5 AM local → waits until 8 AM the same day');
select is(public.first_text_due('America/New_York', '08:00', '20:00', '08:00', '2026-11-11 10:00+00'), '2026-11-11 13:00+00'::timestamptz,
  'Applied at 5 AM → first text at the client''s 8 AM');
select is(public.first_text_due('America/Chicago', '08:00', '20:00', '08:00', '2026-11-11 17:00+00'), '2026-11-11 17:00+00'::timestamptz,
  'Applied at 11 AM local → first text right away');

-- ---------- queue_text ----------
update public.candidates set opted_out_at = now() where id = '40000000-0000-4000-8000-000000000007';
select is(public.queue_text('50000000-0000-4000-8000-000000000007', 'Hi [first name]', true) ->> 'skipped', 'opted_out',
  'Opted-out candidate gets no text');
update public.consents set revoked_at = now() where candidate_id = '40000000-0000-4000-8000-000000000008' and consent_type = 'sms';
select is(public.queue_text('50000000-0000-4000-8000-000000000008', 'Hi [first name]', true) ->> 'skipped', 'no_sms_consent',
  'No SMS consent → no text');
create temp table q1 as select public.queue_text('50000000-0000-4000-8000-000000000003', 'Hi [first name], about [role] at [client]', false, '00000000-0000-4000-8000-000000000004') as r;
select is((select body from public.messages where id = ((select r from q1) ->> 'message_id')::uuid),
  'Hi Marcus, about Delivery Driver at Northline Delivery', 'Placeholders are filled');
select is((select count(*) from public.job_queue where payload ->> 'message_id' = (select r from q1) ->> 'message_id' and status = 'queued'),
  1::bigint, 'A queued send job is created');
select ok(not has_function_privilege('authenticated', 'public.queue_text(uuid, text, boolean, uuid, timestamptz, timestamptz)', 'EXECUTE'),
  'Signed-in users cannot queue texts directly (Edge Functions only)');

-- ---------- replies ----------
select is(public.process_inbound_sms('+12025550105', 'Yes', 'SMin0000000000000000000000000000001') -> 'topics', '["said_yes"]'::jsonb,
  'YES is tagged "said yes"');
select ok((select said_yes_at is not null from public.applications where id = '50000000-0000-4000-8000-000000000005'),
  'said_yes_at is set');
select is(public.process_inbound_sms('+12025550105', 'Yes', 'SMin0000000000000000000000000000001') ->> 'duplicate', 'true',
  'Same Twilio message twice is processed once');
select is(public.process_inbound_sms('+13125550122', 'sure, it is Paula.Reyes@Example.com', 'SMin0000000000000000000000000000002') -> 'topics' ? 'shared_email',
  true, 'Email in a reply is detected');
select is((select email from public.candidates where id = '40000000-0000-4000-8000-000000000062'), 'paula.reyes@example.com',
  'Detected email is saved on the candidate');
select ok(public.process_inbound_sms('+12025550104', 'HELP', 'SMin0000000000000000000000000000003') ->> 'reply' like 'Northline Delivery recruiting%',
  'HELP replies with the company name and contact');

-- STOP
create temp table q2 as select public.queue_text('50000000-0000-4000-8000-000000000002', 'Hi [first name]', true) as r;
select is(public.process_inbound_sms('+12025550102', 'stop', 'SMin0000000000000000000000000000004') ->> 'opted_out', 'true',
  'STOP opts the candidate out');
select is((select status::text from public.job_queue where payload ->> 'message_id' = (select r from q2) ->> 'message_id'), 'cancelled',
  'Texts waiting to go are cancelled after STOP');
select ok((select revoked_at is not null from public.consents where candidate_id = '40000000-0000-4000-8000-000000000002' and consent_type = 'sms'),
  'SMS consent is revoked after STOP');
select is(public.queue_text('50000000-0000-4000-8000-000000000002', 'Hi again', false) ->> 'skipped', 'opted_out',
  'No texts after STOP, not even by a person');
select is(public.process_inbound_sms('+12025550102', 'START', 'SMin0000000000000000000000000000005') ->> 'opted_in', 'true',
  'START re-subscribes');

-- ---------- no-reply cadence ----------
update public.applications set first_text_at = now() - interval '2 days 1 hour', cadence_step = 0, no_response_at = null
  where id = '50000000-0000-4000-8000-000000000001';
delete from public.messages where application_id = '50000000-0000-4000-8000-000000000001' and direction = 'inbound';
select public.run_cadence();
select is((select cadence_step from public.applications where id = '50000000-0000-4000-8000-000000000001'), 1::smallint,
  'Day 2: follow-up text');
update public.applications set first_text_at = now() - interval '5 days 1 hour' where id = '50000000-0000-4000-8000-000000000001';
select public.run_cadence();
select is((select cadence_step from public.applications where id = '50000000-0000-4000-8000-000000000001'), 2::smallint,
  'Day 5: final text');
update public.applications set first_text_at = now() - interval '7 days 1 hour' where id = '50000000-0000-4000-8000-000000000001';
select public.run_cadence();
select ok((select no_response_at is not null from public.applications where id = '50000000-0000-4000-8000-000000000001'),
  'Day 7: marked No response');
update public.candidates set phone_e164 = '+13125550199' where id = '40000000-0000-4000-8000-000000000061';
select public.process_inbound_sms('+12025550101', 'sorry, still interested', 'SMin0000000000000000000000000000006');
select ok((select no_response_at is null from public.applications where id = '50000000-0000-4000-8000-000000000001'),
  'Any reply reopens the candidate');

-- ---------- emergency stop ----------
select public.queue_text('50000000-0000-4000-8000-000000000003', 'Manual text', false, '00000000-0000-4000-8000-000000000004');
select public.queue_text('50000000-0000-4000-8000-000000000003', 'Automatic text', true);
update public.job_queue set run_at = now() - interval '1 minute' where status = 'queued';
update public.feature_flags set enabled = true where key = 'emergency_stop';
create temp table claimed as select * from public.claim_jobs(200);
select ok((select count(*) from claimed) > 0 and (select bool_and(not coalesce((payload ->> 'automatic')::boolean, true)) from claimed),
  'Emergency stop: only one-off texts by a person are picked up');
select ok((select count(*) from public.job_queue where status = 'queued' and coalesce((payload ->> 'automatic')::boolean, true)) > 0,
  'Emergency stop: automated texts wait in the queue');
update public.feature_flags set enabled = false where key = 'emergency_stop';
select is(public.run_cadence() ->> 'skipped', null, 'Cadence runs again once the stop is off');

-- ---------- booking reminders ----------
update public.applications set booked_call_at = now() + interval '3 hours' where id = '50000000-0000-4000-8000-000000000003';
select is((select count(*) from public.job_queue where status = 'queued' and kind = 'call_reminder'
           and payload ->> 'application_id' = '50000000-0000-4000-8000-000000000003'), 2::bigint,
  'Booked call in 3 h: 2 h and 15 min reminders (5 h is off)');
update public.applications set booked_call_at = now() + interval '1 hour' where id = '50000000-0000-4000-8000-000000000003';
select is((select count(*) from public.job_queue where status = 'queued' and kind = 'call_reminder'
           and payload ->> 'application_id' = '50000000-0000-4000-8000-000000000003'), 1::bigint,
  'Rebooked in 1 h: old reminders cancelled, 2 h reminder skipped (already past)');
update public.applications set booked_call_at = null where id = '50000000-0000-4000-8000-000000000003';

-- ---------- AI calls ----------
select is(public.ai_call_check('50000000-0000-4000-8000-000000000003'), null, 'AI call allowed with consent in Interview');
update public.consents set revoked_at = now() where candidate_id = '40000000-0000-4000-8000-000000000004' and consent_type = 'ai_call';
select is(public.ai_call_check('50000000-0000-4000-8000-000000000004'), 'No AI-call consent on file', 'No AI-call consent → no call');
select is(public.ai_call_check('50000000-0000-4000-8000-000000000006'), 'AI interviews are for the Interview stage', 'Shortlisted → no AI interview');

create temp table c1 as select public.create_call('50000000-0000-4000-8000-000000000003', 'ai', 'vapi', '00000000-0000-4000-8000-000000000004') as r;
select is(jsonb_array_length((select r from c1) -> 'questions'), 4, 'Call is pinned to the script version (4 questions)');
select is(public.record_call_result(((select r from c1) ->> 'call_id')::uuid, 'voicemail') ->> 'retry', 'true',
  'Voicemail → retry planned');
select is((select count(*) from public.call_answers where call_id = ((select r from c1) ->> 'call_id')::uuid), 0::bigint,
  'Voicemail → no answers saved');
select ok(exists (select 1 from public.messages where application_id = '50000000-0000-4000-8000-000000000003'
                  and is_automatic and body like 'Hi Marcus, book your short AI interview%'),
  'Voicemail → scheduling link texted instead');
select is(public.record_call_result(((select r from c1) ->> 'call_id')::uuid, 'completed') ->> 'duplicate', 'true',
  'A result that arrives twice changes nothing');

update public.client_settings set max_ai_attempts_total = 2 where client_id = '10000000-0000-4000-8000-000000000001';
create temp table c2 as select public.create_call('50000000-0000-4000-8000-000000000003', 'ai', 'vapi') as r;
select public.record_call_result(((select r from c2) ->> 'call_id')::uuid, 'no_answer');
select ok((select manual_call_needed from public.applications where id = '50000000-0000-4000-8000-000000000003'),
  'All attempts used → manual-call task for the CSR');
select is(public.ai_call_check('50000000-0000-4000-8000-000000000003'), 'All AI call attempts used; call them yourself',
  'No more AI calls after the limit');

-- Auto-shortlist (optional, off by default) and NYC rule.
update public.client_settings set auto_shortlist = true, max_ai_attempts_total = 4 where client_id = '10000000-0000-4000-8000-000000000001';
create temp table c3 as select public.create_call('50000000-0000-4000-8000-000000000016', 'ai', 'vapi') as r;
select is(public.record_call_result(((select r from c3) ->> 'call_id')::uuid, 'completed', 380, 'transcript',
  '[{"key":"q1","text":"21+?","heard":"Yes","result":"yes","at":40},{"key":"q2","text":"Licence?","heard":"Yes","result":"yes","at":80},{"key":"q4","text":"Start?","heard":"Monday","result":"recorded","at":120}]')
  ->> 'auto_shortlisted', 'true', 'Every answer Yes + auto-shortlist on → shortlisted');
select ok(exists (select 1 from public.messages where application_id = '50000000-0000-4000-8000-000000000016'
                  and body like 'Great news Leah!%'), 'Shortlisting sends the "ask for email" text');
update public.candidates set lives_in_nyc = true where id = '40000000-0000-4000-8000-000000000005';
create temp table c4 as select public.create_call('50000000-0000-4000-8000-000000000005', 'ai', 'vapi') as r;
select is(public.record_call_result(((select r from c4) ->> 'call_id')::uuid, 'completed', 300, 't',
  '[{"key":"q1","text":"21+?","heard":"Yes","result":"yes","at":40}]') ->> 'auto_shortlisted', 'false',
  'NYC resident without AEDT compliance → a person decides');

-- ---------- status callbacks, idempotency, access ----------
update public.messages set twilio_sid = 'SMout000000000000000000000000000001', status = 'sent'
  where id = ((select r from q1) ->> 'message_id')::uuid;
select public.update_message_status('SMout000000000000000000000000000001', 'delivered');
select public.update_message_status('SMout000000000000000000000000000001', 'sent');
select is((select status from public.messages where twilio_sid = 'SMout000000000000000000000000000001'), 'delivered',
  'Late "sent" callback never moves a delivered text back');
select is(array[public.claim_idempotency('vapi:evt-1', 'vapi'), public.claim_idempotency('vapi:evt-1', 'vapi')], array[true, false],
  'Webhook event IDs are claimed once');
select is(tests.text_as('00000000-0000-4000-8000-000000000009', $q$select public.ai_call_reason('50000000-0000-4000-8000-000000000003')$q$),
  'No access', 'Viewer of another client cannot probe AI call status');

select * from finish();
rollback;
