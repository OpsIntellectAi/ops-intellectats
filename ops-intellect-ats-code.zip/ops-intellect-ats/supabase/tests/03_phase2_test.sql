-- Phase 2 server actions: add applicant, bulk upload, reviews, DSP invite, user levels,
-- new client, emergency stop, list views.
begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;
select plan(37);

create schema tests;
create function tests.login(p_user uuid, p_aal text default 'aal2')
returns void language plpgsql as $$
declare sid uuid := gen_random_uuid();
begin
  insert into auth.sessions (id, user_id, created_at, updated_at) values (sid, p_user, now() - interval '1 hour', now());
  perform set_config('request.jwt.claims',
    json_build_object('sub', p_user, 'role', 'authenticated', 'aal', p_aal, 'session_id', sid)::text, true);
end $$;
create function tests.json_as(p_user uuid, p_sql text)
returns jsonb language plpgsql as $$
declare j jsonb;
begin
  perform tests.login(p_user);
  execute 'set local role authenticated';
  begin
    execute p_sql into j;
  exception when others then
    j := jsonb_build_object('error', sqlstate, 'message', sqlerrm);
  end;
  execute 'reset role';
  perform set_config('request.jwt.claims', '', true);
  return j;
end $$;
create function tests.count_as(p_user uuid, p_sql text)
returns bigint language plpgsql as $$
declare n bigint;
begin
  perform tests.login(p_user);
  execute 'set local role authenticated';
  execute 'select count(*) from (' || p_sql || ') q' into n;
  execute 'reset role';
  perform set_config('request.jwt.claims', '', true);
  return n;
end $$;
grant usage on schema tests to authenticated;

-- ids
create temp table ids as select
  '00000000-0000-4000-8000-000000000001'::uuid as maya, '00000000-0000-4000-8000-000000000002'::uuid as leo,
  '00000000-0000-4000-8000-000000000003'::uuid as priya, '00000000-0000-4000-8000-000000000004'::uuid as omar,
  '00000000-0000-4000-8000-000000000006'::uuid as theo, '00000000-0000-4000-8000-000000000008'::uuid as ben,
  '00000000-0000-4000-8000-000000000009'::uuid as ivy, '00000000-0000-4000-8000-000000000011'::uuid as nora;
grant select on ids to authenticated;

-- ---------- phone normalisation ----------
select is(public.normalize_us_phone('(202) 555-0177'), '+12025550177', 'Phone with punctuation → E.164');
select is(public.normalize_us_phone('1-202-555-0177'), '+12025550177', 'Leading 1 is accepted');
select is(public.normalize_us_phone('555-0177'), null, 'Too short → rejected');
select is(public.normalize_us_phone('+44 20 7946 0958'), null, 'Non-US number → rejected');

-- ---------- add applicant ----------
select is(tests.json_as((select omar from ids), $q$select public.add_applicant('10000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000001', '30000000-0000-4000-8000-000000000001', 'Test Person', '(202) 555-0190', 'test.person@example.com', 'Riverton', '07000', 'Indeed', null, true, true, true)$q$) ->> 'status',
  'added', 'CSR adds an applicant');
select is((select owner_id from public.applications a join public.candidates c on c.id = a.candidate_id where c.phone_e164 = '+12025550190'),
  (select omar from ids), 'A CSR''s new applicant is owned by that CSR');
select is((select count(*) from public.consents s join public.candidates c on c.id = s.candidate_id where c.phone_e164 = '+12025550190'),
  3::bigint, 'Three consents recorded');
select is((select count(*) from public.stage_history h join public.applications a on a.id = h.application_id join public.candidates c on c.id = a.candidate_id where c.phone_e164 = '+12025550190'),
  1::bigint, 'Applied is in the stage history');
select is(tests.json_as((select omar from ids), $q$select public.add_applicant('10000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000001', '30000000-0000-4000-8000-000000000001', 'Copy Person', '202-555-0102', null, null, null, 'Indeed')$q$) ->> 'status',
  'duplicate', 'Same phone in the same client is blocked and returns the existing person');
select is(tests.json_as((select omar from ids), $q$select public.add_applicant('10000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000001', '30000000-0000-4000-8000-000000000001', 'Copy Person', '202-555-0102', null, null, null, 'Indeed')$q$) ->> 'visible',
  'false', 'The duplicate belongs to another CSR, so its name is not shown');
select is(tests.json_as((select omar from ids), $q$select public.add_applicant('10000000-0000-4000-8000-000000000002', '20000000-0000-4000-8000-000000000003', '30000000-0000-4000-8000-000000000004', 'Wrong Client', '(202) 555-0191')$q$) ->> 'error',
  '42501', 'CSR cannot add to a client he was not given');
select is(tests.json_as((select theo from ids), $q$select public.add_applicant('10000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000001', '30000000-0000-4000-8000-000000000001', 'Ops Try', '(202) 555-0192')$q$) ->> 'error',
  '42501', 'Ops cannot add applicants');
select is(tests.json_as((select omar from ids), $q$select public.add_applicant('10000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000001', '30000000-0000-4000-8000-000000000003', 'Bad Role', '(202) 555-0193')$q$) ->> 'error',
  '23514', 'Job role must belong to the station');

-- ---------- bulk upload ----------
select is(tests.json_as((select priya from ids), $q$select public.import_applicants('10000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000001', '30000000-0000-4000-8000-000000000001',
  '[{"full_name":"Bulk One","phone":"202-555-0181"},{"full_name":"Bulk Two","phone":"202-555-0181"},{"full_name":"","phone":"202-555-0182"},{"full_name":"Walker Person","phone":"202-555-0183","job_role":"Walker"},{"full_name":"Already Here","phone":"202-555-0101"},{"full_name":"Bulk Three","phone":"(202) 555-0184","job_role":"delivery driver"}]', true)$q$) ->> 'ready',
  '2', 'Preview: 2 rows ready (duplicates, missing name, other role skipped)');
select is((select count(*) from public.candidates where phone_e164 in ('+12025550181', '+12025550184')), 0::bigint, 'Preview imports nothing');
select is(tests.json_as((select priya from ids), $q$select public.import_applicants('10000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000001', '30000000-0000-4000-8000-000000000001',
  '[{"full_name":"Bulk One","phone":"202-555-0181"},{"full_name":"Bulk Two","phone":"202-555-0181"},{"full_name":"","phone":"202-555-0182"},{"full_name":"Walker Person","phone":"202-555-0183","job_role":"Walker"},{"full_name":"Already Here","phone":"202-555-0101"},{"full_name":"Bulk Three","phone":"(202) 555-0184","job_role":"delivery driver"}]', false)$q$) ->> 'added',
  '2', 'Import adds the 2 good rows');
select is((select count(*) from public.audit_log where action = 'Bulk upload'), 1::bigint, 'Bulk upload is in the activity log');
select is(tests.json_as((select ivy from ids), $q$select public.import_applicants('10000000-0000-4000-8000-000000000003', '20000000-0000-4000-8000-000000000004', '30000000-0000-4000-8000-000000000006', '[{"full_name":"X Y","phone":"720-555-0199"}]', false)$q$) ->> 'error',
  '42501', 'Viewer cannot upload');

-- ---------- list view respects RLS ----------
select is(tests.count_as((select omar from ids), 'select 1 from public.application_rows'), 9::bigint, 'List view: Omar sees his 8 + the one he added');
select is(tests.count_as((select ben from ids), 'select 1 from public.application_rows where client_id = ''10000000-0000-4000-8000-000000000001'''), 0::bigint, 'List view: Bluepeak user sees 0 Northline rows');
select is(tests.count_as((select ivy from ids), 'select 1 from public.call_rows where client_id <> ''10000000-0000-4000-8000-000000000003'''), 0::bigint, 'Call view: Viewer sees no calls of other clients');
select ok(not has_table_privilege('anon', 'public.application_rows', 'SELECT'), 'Anonymous cannot read the list view');

-- ---------- answer review ----------
select is(tests.json_as((select ivy from ids), $q$select to_jsonb(public.review_answer((select id from public.call_answers where result = 'needs_review' limit 1), 'yes'))$q$) ->> 'error',
  '42501', 'Viewer cannot review answers');
select is(tests.json_as((select omar from ids), $q$select to_jsonb(public.review_answer((select id from public.call_answers where result = 'needs_review' limit 1), 'yes'))$q$) ->> 'error',
  null, 'The owning CSR can review the answer');
select is((select count(*) from public.call_answers where result = 'needs_review' and reviewed_at is null), 0::bigint, 'Answer is no longer waiting');

-- ---------- DSP invite ----------
-- Northline app 06 is shortlisted (owned by Grace, team of Priya).
select is(tests.json_as((select priya from ids), $q$select to_jsonb(public.mark_dsp_invite_sent('50000000-0000-4000-8000-000000000006'))$q$) ->> 'error',
  null, 'Supervisor marks the DSP invite sent');
select is((select stage::text from public.applications where id = '50000000-0000-4000-8000-000000000006'), 'onboarding', 'Candidate moves to Onboarding');
select is((select s.status from public.onboarding_steps s join public.onboarding_step_defs d on d.id = s.step_def_id where s.application_id = '50000000-0000-4000-8000-000000000006' and d.key = 'dsp_invite'),
  'Invited', 'DSP Portal step is Invited');
select is((select count(*) from public.onboarding_steps where application_id = '50000000-0000-4000-8000-000000000006'), 13::bigint, 'All 13 onboarding steps exist');

-- ---------- user levels ----------
select is(tests.json_as((select leo from ids), $q$select to_jsonb(public.set_user_role('00000000-0000-4000-8000-000000000011', 'csr', 'active'))$q$) ->> 'error',
  null, 'Admin activates a pending CSR who shares a client');
select is(tests.json_as((select leo from ids), $q$select to_jsonb(public.set_user_role('00000000-0000-4000-8000-000000000004', 'admin', 'active'))$q$) ->> 'error',
  '42501', 'Admin cannot make someone an Admin');
select is(tests.json_as((select omar from ids), $q$select to_jsonb(public.set_user_role('00000000-0000-4000-8000-000000000005', 'supervisor', 'active'))$q$) ->> 'error',
  '42501', 'CSR cannot change levels');

-- ---------- new client and emergency stop ----------
select is(tests.json_as((select leo from ids), $q$select to_jsonb(public.create_client('Sneaky Co', 'sneaky', 'America/New_York', 'SN1', 'Hub'))$q$) ->> 'error',
  '42501', 'Admin cannot add a client');
select is(tests.json_as((select maya from ids), $q$select to_jsonb(public.create_client('Harbor Lane Delivery', 'harbor-lane', 'America/Chicago', 'HL1', 'Harbor Hub'))$q$) ->> 'error',
  null, 'Super Admin adds a client');
select is((select count(*) from public.onboarding_step_defs d join public.clients c on c.id = d.client_id where c.slug = 'harbor-lane'),
  13::bigint, 'The new client gets 13 default onboarding steps');
select is(tests.json_as((select leo from ids), $q$select to_jsonb(public.set_emergency_stop(true))$q$) ->> 'error', null, 'Admin can switch the emergency stop on');
select ok((select enabled from public.feature_flags where key = 'emergency_stop') and exists (select 1 from public.audit_log where action = 'Emergency stop ON' and flagged),
  'Emergency stop is on and flagged in the activity log');

select * from finish();
rollback;
