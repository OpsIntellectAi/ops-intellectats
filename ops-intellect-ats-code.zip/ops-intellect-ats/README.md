# Ops Intellect ATS

Multi-client applicant tracking for last-mile delivery hiring (drivers, walkers, helpers).
Private repository of Ops Intellect. All demo data is fictional.

| Part | Where | Tech |
|---|---|---|
| Web app | `apps/web` | React 18, Vite, TypeScript (strict), Tailwind, TanStack Query, React Hook Form + Zod |
| Database | `supabase/migrations` | Postgres with Row Level Security on every table |
| Server functions | `supabase/functions` | Supabase Edge Functions (Deno, TypeScript) |
| Tests | `supabase/tests`, `apps/web/src/**/*.test.ts`, `supabase/functions/**/*_test.ts` | pgTAP, Vitest, Deno test |

**Status:** Phase 0 (setup) and Phase 1 (foundation) are done. See `CHANGELOG.md`.

## Start here
- `docs/TESTING.md`: how to test everything, step by step (start with the Codespace).
- `docs/SETUP.md`: click-by-click setup of GitHub, Supabase, Vercel and Sentry (browser only).
- `docs/PHASE-0-1-CHECKLIST.md`: how to check this phase, and the open questions.
- `docs/SECURITY.md`: the security rules and where each one is enforced.

## Commands (run in CI or a Codespace)
```
npm ci                 # install
npm run check:all      # every automatic check in one go (Codespace)
npm run app:codespace  # local Supabase + demo data + the app, to click through
npm run dev            # web app on http://localhost:5173 (needs apps/web/.env.local)
npm run typecheck && npm run lint && npm test
npm run build && npm run check:secrets
cd supabase/functions && deno test       # server helper tests
supabase start && supabase test db       # database + RLS tests (needs Docker, e.g. in a Codespace)
npm run db:test:local                    # same tests on plain Postgres + pgTAP, no Docker
```

## Rules for every change
- No secret ever in `apps/web` or in any `VITE_` variable. CI fails if one appears.
- Every database change is a new numbered file in `supabase/migrations`; never edit an old one.
- Every new table: RLS on, policies, and a test in `supabase/tests`.
- Every Edge Function: Zod input validation, server permission check, rate limit, activity log row, a test.
- Update `CHANGELOG.md`; record bugs in `BUGS.md` (not with feature requests).
