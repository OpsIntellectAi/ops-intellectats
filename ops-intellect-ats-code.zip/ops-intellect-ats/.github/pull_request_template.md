## What changed

## Why

## Checklist
- [ ] No secret, key or real person/company data in this change
- [ ] Database changes are a new numbered migration (old migrations not edited)
- [ ] New table has RLS on + policies + a test in `supabase/tests`
- [ ] New Edge Function validates input (Zod), checks permission, rate-limits, writes the activity log, has a test
- [ ] CHANGELOG.md updated (and BUGS.md if this fixes a bug)
