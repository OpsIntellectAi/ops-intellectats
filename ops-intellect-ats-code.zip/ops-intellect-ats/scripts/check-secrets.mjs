#!/usr/bin/env node
/**
 * Fails (exit 1) if a secret could reach the browser.
 * Scans the given folders (default: apps/web/src and apps/web/dist) for:
 *   1. names of server-only secrets (Twilio, AI, email, voice, encryption, service role…)
 *   2. any VITE_ variable that is not on the public allow-list
 *   3. strings shaped like real keys (sk-…, SG.…, AKIA…, private keys…)
 *   4. JWTs whose payload says role = service_role (the anon key is allowed)
 * Usage: node scripts/check-secrets.mjs [folder ...]
 */
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { extname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

export const PUBLIC_VITE_VARS = ['VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY', 'VITE_SENTRY_DSN', 'VITE_APP_ENV'];

const FORBIDDEN_NAMES =
  /\b(?:VITE_)?(TWILIO_AUTH_TOKEN|TWILIO_API_SECRET|TWILIO_API_KEY|SUPABASE_SERVICE_ROLE_KEY|SERVICE_ROLE_KEY|OPENAI_API_KEY|ANTHROPIC_API_KEY|RESEND_API_KEY|SENDGRID_API_KEY|VAPI_API_KEY|VAPI_PRIVATE_KEY|RETELL_API_KEY|FIELD_ENCRYPTION_KEY|SENTRY_AUTH_TOKEN|SUPABASE_DB_PASSWORD|SUPABASE_ACCESS_TOKEN|GOOGLE_CLIENT_SECRET|SUPABASE_AUTH_EXTERNAL_GOOGLE_SECRET)\b/g;

const KEY_SHAPES = [
  ['OpenAI/Anthropic-style key', /\bsk-(?:ant-)?[A-Za-z0-9_-]{24,}/g],
  ['SendGrid key', /\bSG\.[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{16,}/g],
  ['Resend key', /\bre_[A-Za-z0-9]{24,}/g],
  ['Twilio API key SID', /\bSK[0-9a-f]{32}\b/g],
  ['AWS access key', /\bAKIA[0-9A-Z]{16}\b/g],
  ['GitHub token', /\bgh[pousr]_[A-Za-z0-9]{30,}/g],
  ['Slack token', /\bxox[baprs]-[A-Za-z0-9-]{10,}/g],
  ['Private key block', /-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----/g],
  ['Supabase secret key', /\bsb_secret_[A-Za-z0-9_-]{16,}/g],
];

const JWT = /\beyJ[A-Za-z0-9_-]{8,}\.(eyJ[A-Za-z0-9_-]{8,})\.[A-Za-z0-9_-]{8,}/g;
const TEXT_EXT = new Set(['.ts', '.tsx', '.js', '.mjs', '.cjs', '.jsx', '.json', '.html', '.css', '.map', '.txt', '.svg', '.env', '']);

function* walk(dir) {
  let entries;
  try {
    entries = readdirSync(dir);
  } catch {
    return;
  }
  for (const name of entries) {
    if (name === 'node_modules' || name === '.git') continue;
    const p = join(dir, name);
    const st = statSync(p);
    if (st.isDirectory()) yield* walk(p);
    else if (TEXT_EXT.has(extname(name)) && st.size < 15 * 1024 * 1024) yield p;
  }
}

function decodeJwtPayload(part) {
  try {
    return JSON.parse(Buffer.from(part.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'));
  } catch {
    return null;
  }
}

/** Returns a list of findings for one file's text. Exported for the unit test. */
export function scanText(text) {
  const findings = [];
  for (const m of text.matchAll(FORBIDDEN_NAMES)) findings.push(`server-only secret name ${m[0]}`);
  for (const m of text.matchAll(/\bVITE_[A-Z0-9_]+\b/g)) {
    if (!PUBLIC_VITE_VARS.includes(m[0])) findings.push(`VITE_ variable not on the public list: ${m[0]}`);
  }
  for (const [label, re] of KEY_SHAPES) for (const m of text.matchAll(re)) findings.push(`${label}: ${m[0].slice(0, 12)}…`);
  for (const m of text.matchAll(JWT)) {
    const payload = decodeJwtPayload(m[1]);
    if (payload && payload.role && payload.role !== 'anon') findings.push(`JWT with role "${payload.role}" (only the anon key may ship)`);
  }
  return [...new Set(findings)];
}

export function scanPaths(paths) {
  const problems = [];
  for (const root of paths) {
    for (const file of walk(root)) {
      const found = scanText(readFileSync(file, 'utf8'));
      for (const f of found) problems.push(`${relative(process.cwd(), file)}: ${f}`);
    }
  }
  return problems;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const targets = process.argv.slice(2);
  const paths = targets.length ? targets : ['apps/web/src', 'apps/web/dist'];
  const problems = scanPaths(paths);
  if (problems.length) {
    console.error('Secret scan FAILED. These must never reach the browser:\n' + problems.map((p) => '  - ' + p).join('\n'));
    process.exit(1);
  }
  console.log(`Secret scan passed (${paths.join(', ')}).`);
}
