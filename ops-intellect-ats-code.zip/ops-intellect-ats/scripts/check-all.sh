#!/usr/bin/env bash
# Runs EVERY automatic check, in the same order as CI. Use it in a Codespace.
# Prints a summary at the end. Needs: npm ci done, Docker (Codespace has it), deno.
set -uo pipefail
cd "$(dirname "$0")/.."
declare -a RESULTS=()
run() {
  local name="$1"; shift
  echo; echo "━━━ $name"
  if "$@"; then RESULTS+=("PASS  $name"); else RESULTS+=("FAIL  $name"); fi
}
export VITE_SUPABASE_URL=https://ci-placeholder.supabase.co VITE_SUPABASE_ANON_KEY=ci-placeholder-anon-key-not-real VITE_APP_ENV=staging

run "1. Web app type check"            npm run typecheck
run "2. Web app lint"                  npm run lint
run "3. Web app unit tests"            npm test
run "4. Secret scanner self-test"      node --test scripts/check-secrets.test.mjs
run "5. Production build"              npm run build
run "6. Secret scan (src + dist)"      npm run check:secrets
run "7. No public source maps"         bash -c '! find apps/web/dist -name "*.map" | grep -q .'
run "8. Edge Functions lint"           bash -c 'cd supabase/functions && deno lint'
run "9. Edge Functions type check"     bash -c 'cd supabase/functions && deno check */index.ts'
run "10. Edge Functions tests"         bash -c 'cd supabase/functions && deno test --allow-env'
run "11. Start local Supabase"         npx supabase start -x studio,imgproxy,logflare,vector,supavisor,realtime
run "12. Database tests (RLS, 8 roles)" npx supabase test db

echo; echo "━━━━━━━━━━ SUMMARY ━━━━━━━━━━"
printf '%s\n' "${RESULTS[@]}"
if printf '%s\n' "${RESULTS[@]}" | grep -q '^FAIL'; then echo "Some checks FAILED (scroll up for details)."; exit 1; fi
echo "All checks passed."
