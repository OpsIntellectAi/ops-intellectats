#!/usr/bin/env bash
# Bundles every Edge Function into one file (dist-functions/<name>/index.js + deno.json).
# Used when deploying through the Supabase dashboard/API without the CLI. The normal path
# is `supabase functions deploy` (GitHub Actions → Deploy backend), which needs no bundling.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT=dist-functions
rm -rf "$OUT"
for dir in supabase/functions/*/; do
  name="$(basename "$dir")"
  [ "$name" = "_shared" ] && continue
  [ -f "$dir/index.ts" ] || continue
  mkdir -p "$OUT/$name"
  npx esbuild "$dir/index.ts" --bundle --format=esm --platform=neutral --target=es2022 \
    --external:@supabase/supabase-js --external:zod --external:'node:*' --minify --legal-comments=none \
    --outfile="$OUT/$name/index.js" --log-level=error
  printf '{"imports":{"@supabase/supabase-js":"npm:@supabase/supabase-js@2.45.4","zod":"npm:zod@3.23.8"}}' > "$OUT/$name/deno.json"
  echo "bundled $name ($(wc -c < "$OUT/$name/index.js") bytes)"
done
