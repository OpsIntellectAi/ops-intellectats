#!/usr/bin/env bash
# Starts local Supabase (with the fictional demo data) + the web app inside a Codespace,
# so you can sign in as each demo user in your browser. Nothing here touches staging/production.
set -euo pipefail
cd "$(dirname "$0")/.."

echo "Starting local Supabase (first time takes 3–5 minutes)…"
npx supabase start -x studio,imgproxy,logflare,vector,supavisor,realtime
eval "$(npx supabase status -o env | sed -n 's/^\(ANON_KEY\)=/export \1=/p')"

if [ -n "${CODESPACE_NAME:-}" ]; then
  ORIGIN="https://${CODESPACE_NAME}-5173.${GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN}"
else
  ORIGIN="http://localhost:5173"
fi

# The browser talks to Supabase through the web app's own address (/supabase),
# so no extra port has to be made public.
cat > apps/web/.env.local <<ENV
VITE_SUPABASE_URL=${ORIGIN}/supabase
VITE_SUPABASE_ANON_KEY=${ANON_KEY}
VITE_APP_ENV=local
ENV
printf 'ALLOWED_ORIGINS=%s\nFIELD_ENCRYPTION_KEY=%s\n' "$ORIGIN" "$(openssl rand -base64 32)" > supabase/functions/.env

echo "Starting Edge Functions…"
(npx supabase functions serve --env-file supabase/functions/.env > /tmp/functions.log 2>&1 &)

echo
echo "────────────────────────────────────────────────────────"
echo " Open the app:  ${ORIGIN}"
echo " Demo password: Demo-Only-Passw0rd!"
echo " Stop with Ctrl+C. Run 'npx supabase stop' when finished."
echo "────────────────────────────────────────────────────────"
npm run dev -- --host
