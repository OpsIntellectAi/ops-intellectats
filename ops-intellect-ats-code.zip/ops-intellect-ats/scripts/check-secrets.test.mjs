import assert from 'node:assert/strict';
import { test } from 'node:test';
import { scanText } from './check-secrets.mjs';

const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const jwt = (role) => `eyJhbGciOiJIUzI1NiJ9.${b64({ iss: 'supabase', role })}.c2lnbmF0dXJlLXZhbHVl`;

test('allows the public variables and the anon key', () => {
  assert.deepEqual(scanText(`VITE_SUPABASE_URL VITE_SUPABASE_ANON_KEY VITE_SENTRY_DSN ${jwt('anon')}`), []);
});

test('blocks server-only names, even with VITE_ in front', () => {
  assert.ok(scanText('const k = import.meta.env.VITE_TWILIO_AUTH_TOKEN').length > 0);
  assert.ok(scanText('OPENAI_API_KEY=').length > 0);
  assert.ok(scanText('SUPABASE_SERVICE_ROLE_KEY').length > 0);
});

test('blocks unknown VITE_ variables', () => {
  assert.match(scanText('VITE_MY_NEW_THING')[0], /not on the public list/);
});

test('blocks key-shaped strings', () => {
  assert.ok(scanText('sk-ant-abcdefghijklmnopqrstuvwxyz0123').length > 0);
  assert.ok(scanText('AKIAABCDEFGHIJKLMNOP').length > 0);
  assert.ok(scanText('-----BEGIN PRIVATE KEY-----').length > 0);
});

test('blocks a service-role JWT', () => {
  assert.match(scanText(`const k = "${jwt('service_role')}"`).join(), /service_role/);
});
