#!/usr/bin/env bash
# LOCAL TEST ONLY: start a throwaway Postgres, load the Supabase stand-in, run every
# migration, the seed and the pgTAP RLS tests. CI runs the same tests on real Supabase.
# Needs Postgres 15+ binaries and pgTAP. Usage: scripts/local-db/run.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
PGBIN="${PGBIN:-$(ls -d /usr/lib/postgresql/*/bin | sort -V | tail -1)}"
DATA="$(mktemp -d)"
PORT="${PORT:-54329}"
SOCK="$DATA"
cleanup() { "$PGBIN/pg_ctl" -D "$DATA" -m immediate stop >/dev/null 2>&1 || true; rm -rf "$DATA"; }
trap cleanup EXIT

RUNAS=""
if [ "$(id -u)" = "0" ]; then chown -R postgres "$DATA"; RUNAS="runuser -u postgres --"; fi
$RUNAS "$PGBIN/initdb" -D "$DATA" -U postgres --auth=trust >/dev/null
$RUNAS "$PGBIN/pg_ctl" -D "$DATA" -o "-p $PORT -k $SOCK -c listen_addresses=''" -w start >/dev/null
PSQL=(psql -h "$SOCK" -p "$PORT" -U postgres -d postgres -v ON_ERROR_STOP=1 -q -X)

"${PSQL[@]}" -f "$ROOT/scripts/local-db/supabase-shim.sql"
for f in "$ROOT"/supabase/migrations/*.sql; do
  echo "migrate: $(basename "$f")"
  "${PSQL[@]}" -f "$f"
done
echo "seed"
"${PSQL[@]}" -f "$ROOT/supabase/seed.sql"
"${PSQL[@]}" -c "create extension if not exists pgtap with schema extensions;"

fail=0
for t in "$ROOT"/supabase/tests/*.sql; do
  echo "test: $(basename "$t")"
  out="$("${PSQL[@]}" -t -A -f "$t" 2>&1)" || { echo "$out"; fail=1; continue; }
  echo "$out" | grep -E '^(not ok|# )' || true
  if echo "$out" | grep -qE '^not ok|Looks like you'; then fail=1; fi
  echo "$out" | grep -cE '^ok' | xargs -I{} echo "  {} passed"
done
exit $fail
