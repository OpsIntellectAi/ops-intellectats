# Phase 0 + 1 · test checklist and open questions

Tick each line on **staging** after following `docs/SETUP.md`. Demo password for every seeded account: `Demo-Only-Passw0rd!` (staging only).

## A. Automatic checks (GitHub → Actions → CI must be green)
- [ ] **Web app** job: type check, lint, 9 unit tests, build, secret scan of `src/` and `dist/`, no `.map` files.
- [ ] **Edge Functions** job: lint, type check, 22 tests.
- [ ] **Database** job: migrations + seed load on real Supabase; 78 pgTAP tests pass (52 RLS scope, 26 rules/audit).
- [ ] **Git history secret scan** job passes.
- [ ] Try it: on a test branch add `VITE_TWILIO_AUTH_TOKEN=x` to any file under `apps/web/src`, open a PR → CI fails on the secret scan. Delete the branch.

## B. Deploy
- [ ] Merging into `staging` deploys the web app (Vercel staging) and the database + functions (Actions → Deploy backend → green).
- [ ] Merging `staging → main` waits for a founder's approval, then deploys production.
- [ ] Staging opens only after Vercel sign-in (Deployment Protection).
- [ ] Open the site → browser DevTools → Network → the document response shows `content-security-policy`, `strict-transport-security`, `x-frame-options: DENY`.
- [ ] DevTools → Sources: no readable original `.tsx` files (no public source maps).

## C. Sign-in and access (staging, after "Load demo data into STAGING")
| Sign in as | Expect |
|---|---|
| omar.diaz@demo.opsintellect.test (CSR) | Opens **Northline Delivery** directly (1 client). Counts show only his candidates. |
| grace.kim@demo.opsintellect.test (CSR) | Client picker with 2 clients. |
| priya.nair@demo.opsintellect.test (Supervisor) | Northline only; her team's numbers. |
| leo.hart@demo.opsintellect.test (Admin) | Asked to set up two-step verification first; then Northline + Bluepeak. |
| maya.sterling@demo.opsintellect.test (Super Admin) | Two-step verification; then all 3 clients; "+ Add a client" shows (Phase 2). |
| rosa.vega@demo.opsintellect.test (Station Manager) | Northline, station NL1 only in the station list. |
| ben.walsh@demo.opsintellect.test (DSP Manager) | Bluepeak only. |
| ivy.chen@demo.opsintellect.test (Viewer) | Cedar Route only. |
| nora.pending@demo.opsintellect.test | "Waiting for a Super Admin to give you access". |

- [ ] Wrong password → "Email or password is not right."
- [ ] Google sign-in with an email that was never invited → "This Google account has no Ops Intellect access."
- [ ] Admin: cancel the two-step screen and type `/c/<client id>` in the address bar → sent back to two-step verification; no data loads.
- [ ] Supabase → Table Editor → `devices`: a row per computer you signed in from. `audit_log`: "Signed in" rows; a second computer shows a flagged "Sign-in from a new computer".
- [ ] Set your own device's `blocked = true` (as Super Admin, SQL Editor) → sign out and in again → "This computer has been blocked". Set it back to `false`.
- [ ] Try `update public.audit_log set action = 'x';` in the SQL Editor → error "audit_log is append-only".

## D. Open questions for you
1. **Domain:** what domain will the app use (e.g. `app.opsintellect.com`)? Needed for Google sign-in branding, `ALLOWED_ORIGINS` and email sending.
2. **Founders' emails:** which two Google/email accounts become Super Admin in production?
3. **Supabase plan:** OK to put production on Pro (backups, 12-hour session time-box in Auth, no pausing)? Staging can stay Free.
4. **Ops Team scope:** the matrix lets Ops send texts and update onboarding but not call or move stages. Should Ops be able to mark "Hired"? (The matrix says yes via onboarding update; confirm.)
5. **Station Manager writes:** they can update onboarding steps for their stations (e.g. Training Day 1 Pass). Confirm they should not text candidates.
6. **Supervisor and client access:** a Supervisor sees their CSRs' candidates only in clients the Supervisor was also given. Correct, or should they follow their CSRs into every client?
7. **Candidates in two clients:** "also applied elsewhere" is visible to Super Admin only. Should Admins see it for clients they share?
8. **Sentry:** create the Sentry organisation now, or wait for Phase 2?
9. **IP location:** for "new location" alerts we need an IP-to-city service (a small paid API, server-side). OK to add one in Phase 5?
10. **Time zone of record:** client time zone defaults to the station's; the header shows ET for the team. Any client outside US time zones planned?
