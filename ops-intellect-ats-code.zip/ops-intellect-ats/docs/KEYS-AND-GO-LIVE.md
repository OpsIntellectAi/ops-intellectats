# Switching on real texts, calls and AI (staging)

Everything runs today in **test mode**: no real text, call, AI request or email leaves the system,
but every screen, rule, queue and log works. Each service switches on by itself as soon as its
keys are saved. Keys are typed into Supabase only — never into chat, GitHub or the website.

**Where:** supabase.com → your staging project → **Edge Functions → Secrets → Add new secret**.

| Service | Secret names | Where to find the value |
|---|---|---|
| Twilio texts | `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM_NUMBER` (e.g. +12025550123) | Twilio Console → Account info; Phone Numbers → Active numbers |
| AI (Anthropic) | `ANTHROPIC_API_KEY` (optional `LLM_MODEL`) | console.anthropic.com → API keys |
| AI (OpenAI instead) | `OPENAI_API_KEY`, `LLM_PROVIDER=openai` | platform.openai.com → API keys |
| AI voice (Vapi) | `VAPI_API_KEY`, `VAPI_PHONE_NUMBER_ID`, `VAPI_WEBHOOK_SECRET` (any 32+ random characters) | dashboard.vapi.ai |
| Email (alerts, weekly report) | `RESEND_API_KEY`, `EMAIL_FROM` | resend.com |
| Licence / DOB encryption | `FIELD_ENCRYPTION_KEY` (32 random bytes, base64) | see below |

**Encryption key:** in a browser console run
`btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(32))))` and paste the result.
Keep a copy in your password manager: without it, saved licence numbers cannot be read.

## Twilio webhooks
Twilio Console → Phone Numbers → your number → Messaging → "A message comes in":
`https://<project>.supabase.co/functions/v1/twilio-webhook` (HTTP POST). Unsigned requests get 403.

## Staging safety
Staging only texts and calls numbers on the **test phone list** (Client setup → Test and go live,
Super Admin). Everything else is marked "not sent · staging texts only test phones".
