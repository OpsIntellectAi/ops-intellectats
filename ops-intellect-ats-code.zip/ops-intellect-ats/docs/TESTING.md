# How to test Phase 0 + 1

Three levels. Do them in order. Everything happens in your web browser.

| Level | What it proves | Accounts needed | Time |
|---|---|---|---|
| **A. Codespace** | Every automatic test passes, and the app works when you sign in as each of the 8 levels | GitHub only | 30–45 min |
| **B. GitHub CI** | The same checks run on every change, and a leaked key is caught | GitHub only | 10 min |
| **C. Staging** | The real hosted setup works (Google sign-in, security headers, deploys) | GitHub, Supabase, Vercel | after `docs/SETUP.md` |

---

## A. Test everything in a GitHub Codespace (no Supabase or Vercel yet)

A Codespace is a computer in the cloud that opens in your browser. The free plan gives you enough hours for this.

### A1. Open the Codespace
1. The code must be in your GitHub repository (see `docs/SETUP.md` §1.1–1.2, or ask Claude to push it).
2. On the repository page: **Code → Codespaces → Create codespace on main**.
3. Wait until the setup finishes (about 3–5 minutes the first time; the terminal at the bottom shows `npm ci` and then stops).

### A2. Run every automatic check (one command)
In the terminal at the bottom, type and press Enter:
```
npm run check:all
```
The first run takes 5–10 minutes (it downloads the Supabase database images). At the end you get a summary. Every line must say **PASS**:

| Line | What it checks |
|---|---|
| 1–3 | The web app's code is correct (types, style rules, 9 unit tests) |
| 4 | The secret scanner itself works (it catches fake leaked keys) |
| 5–7 | The app builds; no secret and no readable source code is in what goes to the browser |
| 8–10 | The server helpers are correct (22 tests: login check, blocked computers, encryption, input checks) |
| 11 | A real Supabase starts with all 8 migrations and the fictional demo data |
| 12 | **78 database tests**: each of the 8 levels sees exactly what it should; a user of one client sees 0 rows of another; nobody can edit the activity log; shortlist and hire rules hold |

If line 12 fails, the output above it says which test number failed and what it expected. Copy that part to Claude.

### A3. Use the app as each person
In the same terminal:
```
npm run app:codespace
```
When it prints **Open the app: https://….app.github.dev**, click that link (or open **Ports** tab → port 5173 → globe icon). Password for every demo account: `Demo-Only-Passw0rd!`

Sign in as each person below, check what you see, then click **Sign out** (bottom of the sidebar or the client list).

| Email (all end with `@demo.opsintellect.test`) | Level | What you should see |
|---|---|---|
| `omar.diaz` | CSR | Goes straight into **Northline Delivery** (he has 1 client). NL1 · Delivery Driver shows only *his* candidates. |
| `grace.kim` | CSR | A list of **2 clients**: Northline and Bluepeak. |
| `priya.nair` | Supervisor | Northline only; numbers include Omar's and Grace's candidates. |
| `theo.brooks` | Ops Team | Northline only; all candidates there. |
| `rosa.vega` | Station Manager | Northline, and the Station list has **only NL1**. |
| `ben.walsh` | DSP Manager | Bluepeak only. |
| `ivy.chen` | Viewer | Cedar Route only. |
| `sam.patel` | CSR | Bluepeak only; only his candidates. |
| `nora.pending` | (pending) | "Your account is waiting for a Super Admin…" and nothing else. |
| `leo.hart` | Admin | **Two-step verification** screen first (see A4). Then Northline + Bluepeak. |
| `maya.sterling` | Super Admin | Two-step verification, then **all 3 clients** and a disabled "+ Add a client (Phase 2)". |

Things to compare: the **Interview / Shortlisted / … / Hired** numbers change between people for the same client, station and job role. That is the database hiding what each level must not see. Also try:
- A wrong password → "Email or password is not right."
- As Omar, open Northline, copy the address bar, sign out, sign in as **ivy.chen**, paste the address → "You do not have access to this client". Ivy cannot open Northline even with the link.
- Change **Station** and **Job role** in the sidebar → the numbers change.

The client search box appears when someone has 4 or more clients; the demo has 3, so it is tested by the unit tests instead.

### A4. Two-step verification (Admin and Super Admin)
1. Install **Google Authenticator** or **Microsoft Authenticator** on your phone.
2. Sign in as `leo.hart`. Scan the QR code with the app (or type the key shown under it).
3. Type the 6-digit code → **Verify** → you get in.
4. Sign out and in again → it asks only for the code now (no QR).
5. Try a wrong code (e.g. `123456`) → "That code did not work."

### A5. Check the security records by hand
Open a **second terminal** (the **+** button in the terminal panel) and run these one at a time.

See which computers signed in:
```
docker exec -i supabase_db_ops-intellect-ats psql -U postgres -c "select p.email, d.label, d.last_ip, d.blocked from devices d join profiles p on p.id = d.user_id;"
```
See the latest activity log rows (a second computer or browser shows `flagged = t`):
```
docker exec -i supabase_db_ops-intellect-ats psql -U postgres -c "select occurred_at, action, target_label, flagged, flag_reason from audit_log order by id desc limit 10;"
```
Prove nobody can change the activity log, not even the database owner (expect the error *audit_log is append-only*):
```
docker exec -i supabase_db_ops-intellect-ats psql -U postgres -c "update audit_log set action = 'edited';"
```
Block Omar's computer, then sign in as Omar again (expect "This computer has been blocked by a Super Admin."):
```
docker exec -i supabase_db_ops-intellect-ats psql -U postgres -c "update devices set blocked = true where user_id = '00000000-0000-4000-8000-000000000004';"
```
Unblock it afterwards:
```
docker exec -i supabase_db_ops-intellect-ats psql -U postgres -c "update devices set blocked = false;"
```
Prove a shortlist needs a reviewed answer (expect *Cannot shortlist: an answer still needs review*):
```
docker exec -i supabase_db_ops-intellect-ats psql -U postgres -c "update applications set stage = 'shortlisted' where id = '50000000-0000-4000-8000-000000000001';"
```

### A6. Finish
1. In the app terminal press **Ctrl + C**.
2. Type `npx supabase stop`.
3. Codespaces menu (bottom-left) → **Stop Current Codespace**, so it stops using your free hours.

---

## B. Check GitHub CI catches problems
1. Make a change on a branch and open a pull request (in the Codespace: `git checkout -b test-ci`, edit any text in `README.md`, then `git commit -am "test" && git push -u origin test-ci`, and click the link GitHub prints).
2. On the pull request, wait for **4 green checks**: Web app, Edge Functions, Database, Git history secret scan.
3. Now prove the leak guard works: in `apps/web/src/lib/env.ts` add a line `// VITE_TWILIO_AUTH_TOKEN`, commit and push. The **Web app** check turns **red** at "Secret scan of source and built files". Close the pull request and delete the branch without merging.

---

## C. Test staging (after `docs/SETUP.md`)
Follow `docs/PHASE-0-1-CHECKLIST.md`. It repeats the sign-in table on the real hosted site and adds: Google sign-in, security headers in DevTools, the staging password gate, and the deploy flow (staging → main with approval).

---

## If something goes wrong

| What you see | What to do |
|---|---|
| `npm run check:all` says `deno: command not found` | Run `npm install -g deno@2.1.4`, then try again. |
| Line 11 fails with "Cannot connect to the Docker daemon" | Wait 1 minute (Docker is still starting) and run it again. If it keeps failing, rebuild: Codespaces menu → **Rebuild Container**. |
| Line 11 fails with "port is already allocated" | Run `npx supabase stop`, then try again. |
| The app link shows "502" | The app is still starting; wait 20 seconds and refresh. |
| Sign-in spins forever | In the terminal running the app, look for red errors; run `npx supabase status` to check Supabase is running. |
| "Your session has ended (12-hour limit)" | Expected after 12 hours. Sign in again. |
| Anything else | Copy the last 30 lines of the terminal and send them to Claude. |
