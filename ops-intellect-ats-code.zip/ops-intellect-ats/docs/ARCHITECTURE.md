# Architecture

```
 Browser (React app, anon key only)
   │  reads/writes allowed rows ──────────────▶ Supabase Postgres (RLS on every table)
   │  actions that cost money / touch others ─▶ Supabase Edge Functions ──▶ Twilio · Voice AI · LLM · Email
   │                                              (JWT check, permission,   (Phase 3–4)
   │                                               rate limit, audit)
   └─ errors ─▶ Sentry (no candidate data)
```

## Tenancy
- **Client** = a delivery company we hire for. Each has **stations**; each station has **job roles**.
- **Candidate** is per client (same phone may exist in two clients; never twice in one).
- **Application** = candidate × station × job role. Stage, owner, calls, messages, onboarding hang off the application.
- One client is open at a time in the UI; the database never returns another client's rows to a user without access.

## Who sees what (database rule `application_visible`)
| Level | Applications they can read |
|---|---|
| CSR | owner = me, in my clients/stations |
| Supervisor | owner ∈ me + my CSRs |
| Admin, Ops, DSP Manager, Viewer | every application in clients I was given (and stations, if a list is set) |
| Station Manager | only applications at my listed stations |
| Super Admin | all (only after MFA) |

What they may *do* comes from `role_permissions` (`can('…')`), checked in RLS policies and again in Edge Functions.

## Request flow for a protected action (Phase 3 example: send a text)
1. Browser calls `send-sms` with its JWT and `x-device-id`.
2. Function: CORS allow-list → Zod body → `requireAuth` (JWT valid, account active, MFA if needed, session < 12 h, computer not blocked) → `requirePermission('messages.send')` → `requireClientAccess` → rate limit → emergency-stop + quiet-hours + opt-out checks → Twilio → `messages` row + activity log.

## Folders
- `apps/web/src/app`: router, providers. `features/*`: screens by area. `components/`: shared UI. `lib/`: Supabase client (anon), env, roles (UI hints only), formatters.
- `supabase/migrations`: numbered SQL. `supabase/functions/_shared`: helpers. `supabase/tests`: pgTAP. `supabase/seed.sql`: fictional staging data.
- `scripts/`: secret scanner, local DB test runner (plain Postgres stand-in for Supabase when Docker is not available).
