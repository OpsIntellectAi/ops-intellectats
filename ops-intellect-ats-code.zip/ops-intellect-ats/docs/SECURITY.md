# Security

Goal: nobody can read our secrets, call our paid services, or see another client's data, even with every line of the browser code in hand. The browser is treated as hostile; the database and Edge Functions decide everything.

## Where each rule is enforced

| # | Rule | How | Status |
|---|---|---|---|
| 1 | No secret in the frontend | Only `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_SENTRY_DSN`, `VITE_APP_ENV` exist. `scripts/check-secrets.mjs` scans `src/` and `dist/` for server-only names, unknown `VITE_` names, key-shaped strings and non-anon JWTs; CI fails on any hit. gitleaks scans git history. | Done |
| 2 | Third-party calls only via Edge Functions | `_shared/auth.ts` (JWT + `my_access()` + blocked device), `permissions.ts`, `rate-limit.ts`, `validate.ts` (Zod), `audit.ts`. Twilio / AI / voice / email functions are built in Phases 3–4 on these helpers. | Helpers done |
| 3 | Service-role key only in functions | Read from `SUPABASE_SERVICE_ROLE_KEY` (injected by Supabase) in `_shared/supabase.ts`; never logged; the scanner blocks the name in the web app. | Done |
| 4 | RLS on every table, deny by default | Migration 0006 enables RLS on all 36 tables; tables without a policy are service-only. Helpers in 0005. Tests: anon reads 0; Client A user reads 0 rows of Client B across every client-owned table; Station Manager only her station; CSR only own; Supervisor only team. | Done + tested |
| 5 | Signed, idempotent webhooks | `idempotency_keys` table ready. Twilio `validateRequest` and voice HMAC checks come with the webhook functions in Phase 3. | Phase 3 |
| 6 | Encryption | TLS everywhere (Supabase, Vercel, HSTS). At rest by Supabase. Field-level AES-256-GCM in `_shared/crypto.ts`, key in `FIELD_ENCRYPTION_KEY`; columns `licence_number_enc`, `date_of_birth_enc` accept only `v1:` ciphertext. No SSN column exists. Private buckets; signed URLs only. | Done (helpers + schema) |
| 7 | Authentication | Google + email/password; self sign-up off; MFA mandatory for Admin/Super Admin, enforced in the database (`aal2`), not just the screen; 12-hour session enforced in the database (`private.session_ok()`) and in Auth settings; sign-in records computer, browser and IP; new computer / new IP flagged; blocked computer refused. | Done (location lookup: Phase 5) |
| 8 | Rate limits | `hit_rate_limit()` (service-only) + `LIMITS` in `_shared/rate-limit.ts` for sign-in, texts, calls, bulk, assistant. Sign-in recorder uses it now. | Done for sign-in |
| 9 | Browser hardening | `apps/web/vercel.json`: strict CSP (no inline scripts), HSTS, X-Frame-Options DENY, Referrer-Policy, Permissions-Policy, COOP. CORS allow-list in functions (`ALLOWED_ORIGINS`). Verified in a browser with the headers applied: no CSP errors. | Done |
| 10 | Production build | Minified, `console.*`/`debugger` dropped, no public source maps (CI fails if `.map` files are in `dist/`). | Done |
| 11 | Append-only activity log | Privileges revoked + trigger blocks UPDATE/DELETE/TRUNCATE for everyone, including the service role. Rows carry who, role, client, before → after, device, IP, user agent. | Done + tested |
| 12 | Repository hygiene | `.gitignore` blocks `.env*` (except `.env.example`); secret scanning, push protection, Dependabot, branch rules (docs/SETUP.md §1). | Done (needs the GitHub switches) |
| 13 | Staging vs production | Separate Supabase and Vercel projects and keys; demo seed only via a confirmed manual workflow on staging; `STAGING_PHONE_ALLOWLIST` enforced in the send functions in Phase 3. | Partly (Phase 3) |
| 14 | Emergency stop | `feature_flags.emergency_stop`; shown in the sidebar; every automated send function will check it server-side (Phase 3). | Flag done |
| 15 | Data retention | Per-client settings exist (`recording_retention_days`, `rejected_retention_months`); jobs in Phase 5. | Phase 5 |
| 16 | AI safety | Phase 4. LLM only in functions, read-only scoped tools, no protected-trait inference. | Phase 4 |

## Known limits (honest list)
- Blocking a computer stops new sign-ins and every Edge Function call from it. A session that was already open keeps reading data until it expires (≤ 12 h) unless the user is also disabled. Disabling the user (status `disabled`) cuts all data access at once.
- IP → city/country for "new location" needs an IP lookup service (Phase 5). Today the flag is based on IP change.
- JavaScript obfuscation is not used; it is not a security boundary.

## Reporting a security problem
Treat as **P0** in `BUGS.md` and tell both founders immediately. If a key may have leaked: rotate it first (Supabase → API keys / function secrets, Twilio, AI provider), then investigate.
