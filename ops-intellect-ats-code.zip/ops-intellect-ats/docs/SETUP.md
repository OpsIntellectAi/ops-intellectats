# Setup guide (browser only)

Everything here is done in a web browser. You never install anything on your laptop.
Dashboards change their menus from time to time; if a button has moved, look for the same words nearby.

You will create:

| Service | Staging | Production |
|---|---|---|
| GitHub | branch `staging` | branch `main` |
| Supabase | project `ops-intellect-staging` | project `ops-intellect-production` |
| Vercel | project `ops-intellect-staging` | project `ops-intellect-production` |
| Sentry | one project `ops-intellect-web` (environment tells them apart) | same |

Keep a password manager open. Every password, key and token you create goes there and nowhere else (never into chat, email, Slack or a document).

---

## 1. GitHub

### 1.1 Create the private repository
1. Go to github.com → top-right **+** → **New repository**.
2. Owner: your company organisation (create one first under **Your organizations → New organization** if you want the code owned by Ops Intellect, not a person).
3. Name: `ops-intellect-ats`. Visibility: **Private**. Tick **Add a README**. Click **Create repository**.

### 1.2 Put the code in it (no software needed)
Option A (simplest): tell Claude the repository name and give it access; Claude pushes the code for you.

Option B (yourself, in the browser):
1. On the repository page click **Code → Codespaces → Create codespace on main**. A VS Code window opens in the browser.
2. Drag `ops-intellect-ats.zip` from your computer into the file list on the left.
3. In the terminal at the bottom, type:
   ```
   unzip -o ops-intellect-ats.zip -d /tmp/oi && cp -r /tmp/oi/ops-intellect-ats/. . && rm ops-intellect-ats.zip
   git add -A && git commit -m "Phase 0-1: foundation" && git push
   git checkout -b staging && git push -u origin staging
   ```
4. Close the codespace (**Codespaces** menu → **Stop**) so it does not use your free hours.

### 1.3 Protect the branches
1. Repository → **Settings → Rules → Rulesets → New ruleset → New branch ruleset**.
2. Name: `protect main and staging`. Enforcement: **Active**.
3. Target branches → **Add target → Include by pattern** → `main`, then again `staging`.
4. Tick: **Restrict deletions**, **Require a pull request before merging** (1 approval), **Require status checks to pass** → add `Web app · types, lint, tests, build, secret scan`, `Edge Functions · lint, type check, tests`, `Database · migrations, seed, RLS tests (all 8 roles)`, `Git history secret scan` (they appear after CI has run once), **Block force pushes**.
5. **Create**.

### 1.4 Turn on secret scanning and Dependabot
Repository → **Settings → Code security** → turn on **Dependabot alerts**, **Dependabot security updates**, **Secret scanning** and **Push protection**.

### 1.5 Deployment environments and secrets
1. Repository → **Settings → Environments → New environment** → `staging` → **Configure environment**.
2. Under **Environment secrets → Add environment secret**, add:
   - `SUPABASE_ACCESS_TOKEN`: from supabase.com → your avatar → **Account preferences → Access Tokens → Generate new token** (name it `github-deploy`).
   - `SUPABASE_PROJECT_REF`: the staging project's Reference ID (step 2.2).
   - `SUPABASE_DB_PASSWORD`: the staging database password (step 2.1).
3. Repeat for a `production` environment with the production values. In `production` also tick **Required reviewers** and add both founders, so nothing reaches production without one of you approving.

---

## 2. Supabase (do this twice: staging, then production)

### 2.1 Create the project
1. supabase.com/dashboard → **New project**.
2. Name: `ops-intellect-staging` (then `ops-intellect-production`).
3. Database password: click **Generate a password**, copy it into your password manager.
4. Region: **East US (North Virginia)** (closest to US candidates and Twilio).
5. Plan: Free is fine for staging. Use **Pro** for production (daily backups, 12-hour session time-box, leaked-password check, no pausing).
6. **Create new project** and wait about 2 minutes.

### 2.2 Copy the two public values
**Project Settings → API Keys** (or **Data API**):
- **Project URL** → this is `VITE_SUPABASE_URL`.
- **anon / publishable** key → this is `VITE_SUPABASE_ANON_KEY`.
- **Project Settings → General → Reference ID** → `SUPABASE_PROJECT_REF` for GitHub (1.5).

Do **not** copy the `service_role` / secret key anywhere. Edge Functions receive it automatically.

### 2.3 Sign-in settings
**Authentication → Sign In / Providers**:
1. **Allow new users to sign up: OFF.** People only get in when invited.
2. **Email**: enabled, **Confirm email** ON.
3. **Google**: turn on. It asks for a Client ID and Secret:
   1. Open console.cloud.google.com → create a project `Ops Intellect ATS`.
   2. **APIs & Services → OAuth consent screen**: User type **External**, app name `Ops Intellect ATS`, your support email, save. Add your own domain when you have one.
   3. **APIs & Services → Credentials → Create credentials → OAuth client ID** → **Web application**.
   4. **Authorized redirect URIs → Add URI**: copy the **Callback URL** shown on the Supabase Google provider screen (looks like `https://<ref>.supabase.co/auth/v1/callback`).
   5. **Create**, then paste the Client ID and Client secret into Supabase and **Save**.

**Authentication → URL Configuration**:
- **Site URL**: your Vercel URL for this environment (step 3), e.g. `https://ops-intellect-staging.vercel.app`.
- **Redirect URLs**: add `https://<that same address>/auth/callback`.

**Authentication → Multi-Factor**: make sure **TOTP (Authenticator app)** is enabled.

**Authentication → Sessions** (Pro): **Time-box user sessions = 12 hours**. (The database also enforces 12 hours on every query, so staging on the Free plan is still protected.)

**Authentication → Policies / Passwords**: minimum length **12**, require lowercase, uppercase, digits and symbols; turn on **leaked password protection** (Pro).

### 2.4 Database safety
- **Database → Settings → SSL Configuration → Enforce SSL**: ON.
- **Database → Backups** (production, Pro): check daily backups are listed. Point-in-time recovery is an optional add-on.

### 2.5 Edge Function secrets
**Edge Functions → Secrets → Add new secret**:
- `ALLOWED_ORIGINS` = the web address(es) of this environment, comma-separated, no trailing slash. Example: `https://ops-intellect-staging.vercel.app`.
- `FIELD_ENCRYPTION_KEY`: make one in the browser: **SQL Editor → New query** → run `select encode(gen_random_bytes(32), 'base64');` → copy the result into the secret, then close the query **without saving it**. Use a different key for staging and production, and keep a copy in the password manager (without it, encrypted licence numbers cannot be read).

### 2.6 First deploy of the database
Pushing to the `staging` branch runs **Deploy backend (Supabase)** in GitHub Actions: it applies every migration and deploys the Edge Functions. Check **GitHub → Actions** shows it green.

Staging only, to load the fictional demo data: **GitHub → Actions → Load demo data into STAGING (manual) → Run workflow** → type `SEED STAGING` → **Run**. Never run the seed against production.

### 2.7 Your first Super Admin (production)
1. **Authentication → Users → Add user → Send invitation** to your own email. Accept the email and set a password.
2. **SQL Editor → New query**, paste, replace the email, run:
   ```sql
   update public.profiles set role = 'super_admin', status = 'active', full_name = 'Your Name'
   where email = 'you@yourcompany.com';
   ```
3. Sign in to the app. It asks you to set up two-step verification with an authenticator app. After that you can see everything.

Do the same for your co-founder. Everyone else is added from the app in Phase 2.

---

## 3. Vercel (do this twice: staging, then production)

1. vercel.com → **Add New… → Project** → **Import** your GitHub repository (allow Vercel access to just this repository).
2. **Project Name**: `ops-intellect-staging` (then `ops-intellect-production`).
3. **Root Directory → Edit → `apps/web`**. Framework: **Vite** (detected). Leave build settings as they are; `apps/web/vercel.json` sets them.
4. **Environment Variables** (all environments):
   | Name | Value |
   |---|---|
   | `VITE_SUPABASE_URL` | Project URL from 2.2 (this environment's project) |
   | `VITE_SUPABASE_ANON_KEY` | anon / publishable key from 2.2 |
   | `VITE_APP_ENV` | `staging` (or `production`) |
   | `VITE_SENTRY_DSN` | from step 4 (optional for now) |
   | `SENTRY_AUTH_TOKEN`, `SENTRY_ORG`, `SENTRY_PROJECT` | from step 4 (optional; uploads source maps privately) |

   Never add any other `VITE_` variable. The CI check fails the build if you do.
5. **Deploy**.
6. **Settings → Git → Production Branch**: `staging` for the staging project, `main` for the production project.
7. **Settings → Git → Ignored Build Step → Custom**, so each project only builds its own branch:
   - staging project: `if [ "$VERCEL_GIT_COMMIT_REF" = "staging" ]; then exit 1; else exit 0; fi`
   - production project: `if [ "$VERCEL_GIT_COMMIT_REF" = "main" ]; then exit 1; else exit 0; fi`
8. **Settings → Deployment Protection** (staging): turn on **Vercel Authentication** so only your team can open staging.
9. **Settings → Domains** (when you have a domain): `app.yourdomain.com` → production, `staging.yourdomain.com` → staging. Then update `ALLOWED_ORIGINS` (2.5) and the Supabase Site URL / Redirect URLs (2.3) to the new addresses.

---

## 4. Sentry (error monitoring)
1. sentry.io → create an organisation `ops-intellect` → **Create project** → platform **React** → name `ops-intellect-web`.
2. Copy the **DSN** → `VITE_SENTRY_DSN` in both Vercel projects (a DSN is meant to be public).
3. **Settings → Auth Tokens → Create new token** (scope: project releases / source maps) → `SENTRY_AUTH_TOKEN` in Vercel, plus `SENTRY_ORG` and `SENTRY_PROJECT`. This token is secret: it is a build-only variable without the `VITE_` prefix.

---

## 5. How a change reaches production
1. Work on a new branch → open a pull request into `staging`.
2. CI runs (types, lint, tests, secret scan, RLS tests). Merge only when green.
3. Merging deploys staging: Vercel builds the web app; GitHub Actions applies migrations and functions to the staging Supabase.
4. Test on staging. Then open a pull request `staging → main`. A founder approves the `production` environment and it deploys.
