# Database

All tables live in `public`, use UUID keys (the activity log uses a growing number), and have RLS on. Times are `timestamptz` (stored UTC).

## Migrations
| File | Contents |
|---|---|
| `…0001_types.sql` | pgcrypto, enums (8 roles, stages, call/answer/review types…), `set_updated_at()` |
| `…0002_core_tables.sql` | clients, client_settings, stations, job_roles, profiles, user_client_access, teams, role_permissions, feature_flags |
| `…0003_candidate_tables.sql` | candidates, applications, stage_history, consents, messages, scripts, script_versions, calls, call_answers, call_reviews, onboarding_step_defs, onboarding_steps, message_templates, step_messages, call_reminders |
| `…0004_ops_tables.sql` | alert_rules, alert_log, hiring_targets, saved_views, devices, audit_log, idempotency_keys, job_queue, bug_reports, ai_assistant_log, aedt_notices, rate_limits |
| `…0005_helpers.sql` | `auth_user_role`, `is_super_admin`, `can`, `has_client_access`, `has_station_access`, `my_team_ids`, `application_visible`, `app_id_visible`, `call_visible`, `candidate_visible`, `shares_client_with`, `my_access`, `hit_rate_limit`, `private.session_ok`, `private.req_header` |
| `…0006_rls.sql` | RLS on for all tables; every policy; anon has no table privileges; audit log write privileges revoked |
| `…0007_triggers.sql` | append-only audit log, generic settings audit, access/profile audit, stage rules (shortlist / hired / not interested), stage history, onboarding stamp + audit, new sign-up → pending profile |
| `…0008_reference_data.sql` | permission matrix, feature switches, private storage buckets |
| `…0009_revoke_anon_helpers.sql` | anonymous visitors cannot call the access-helper functions (security advisor finding) |

## Integrity guarantees
- Composite foreign keys `(parent_id, client_id)` on every child table: a message, call, step or consent cannot point at a parent from another client.
- `applications (job_role_id, station_id)` must match a real job role at that station.
- `unique (client_id, phone_e164)` on candidates; phone must be E.164.
- `client_settings` quiet hours: sending window never wider than 8:00 AM–9:00 PM.
- `onboarding_steps.status = 'Waived'` requires `waived_reason`.
- `call_reviews.verdict = 'flagged'` requires a reason.

## Adding a table (checklist)
1. New migration file with the next number.
2. `client_id` + composite FK to its parent if it belongs to a client.
3. `alter table … enable row level security;` and policies using the helpers.
4. If it is a setting, add it to the audit trigger list.
5. A test in `supabase/tests` proving another client's user reads 0 rows.
