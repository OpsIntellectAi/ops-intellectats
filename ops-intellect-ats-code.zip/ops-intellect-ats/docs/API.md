# API

The browser talks to two things only: Supabase (REST/RPC with RLS) and our Edge Functions.

## Database functions callable by a signed-in user (RPC)
| Function | Returns |
|---|---|
| `my_access()` | `{ user_id, full_name, email, role, status, session_ok, mfa_required, mfa_ok, effective_role, permissions[] }` |
| `can(p_permission)` | boolean for the caller |
| `has_client_access(p_client)` | boolean for the caller |

`hit_rate_limit` is service-only.

## Edge Functions
### `POST /functions/v1/record-sign-in`
Called once after each sign-in.
- Headers: `Authorization: Bearer <user JWT>`, `x-device-id: <uuid>`, `Content-Type: application/json`
- Body: `{ "deviceKey": "<uuid>" }`
- 200 `{ ok: true, newDevice: boolean, flagged: boolean }`
- 400 invalid body · 401 no/invalid session · 403 `no_access` / `device_blocked` / `origin_not_allowed` · 429 too many sign-ins
- Side effects: upserts `devices`; activity log row "Signed in" (flagged for a new computer or IP change) or "Sign-in refused".

## Error format (all functions)
`{ "error": { "code": "snake_case", "message": "Plain sentence for the user." } }`. Unexpected errors return 500 with a generic message; details stay in the logs.

Functions for texts, calls, webhooks, uploads, scheduler, reports and the assistant are added in Phases 3–5 and listed here as they land.
