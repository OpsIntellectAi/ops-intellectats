# Runbook

## Someone cannot sign in
1. Supabase → Authentication → Users: does the email exist? If not, invite them.
2. SQL Editor: `select role, status from public.profiles where email = '…';`
   - `pending` → a Super Admin sets the level and client access.
   - `disabled` → intended? If not, set `status = 'active'`.
3. Admin / Super Admin stuck at two-step verification: lost phone → Authentication → Users → the user → remove the MFA factor; they set it up again at next sign-in. Log who asked and why.
4. "This computer has been blocked": a Super Admin blocked it. Unblock only after checking with the person.

## Suspected leak or stolen laptop
1. Set the user's status to `disabled` (cuts all data access at once).
2. Block their devices (`devices.blocked = true`).
3. Supabase → Authentication → Users → **Sign out user** (revokes refresh tokens).
4. Review `audit_log` for that user (filter `actor_id`), export it, then decide next steps. Treat as P0.

## Emergency stop
Turn on the `emergency_stop` feature switch (Super Admin). From Phase 3 every automated text, reminder, AI call and bulk send checks it on the server before sending. Manual work continues.

## A deploy went wrong
- Web app: Vercel → Deployments → previous good deployment → **Promote to Production** (instant rollback).
- Database: migrations are forward-only. Write a new migration that undoes the change, run CI, deploy. For data damage, restore from the Supabase backup (Pro) into a new project first and compare.

## Rotating a secret
1. Create the new value (Supabase function secret / Twilio / AI provider).
2. Update it in Supabase → Edge Functions → Secrets (functions pick it up on the next request).
3. Revoke the old value at the provider.
4. Note it in the activity log channel and `CHANGELOG.md` (never the value itself).
