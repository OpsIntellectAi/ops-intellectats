# Changelog

## 0.2.0 · Phases 2–5 (staging)

### Added
- **Phase 2 · screens:** sidebar with live counters, My day, Today, Candidates (tabs, saved views, filters, bulk actions, add applicant, CSV/XLSX upload), candidate panel, Calls, Messages, Dashboard, Users & activity, Client setup (8 steps, AI script editor with compliance check), invite users.
- **Phase 3 · texts and calls:** sending window in the candidate's local time, first text at the client's set time, Day 2 / Day 5 / Day 7 no-reply cadence, automatic step texts, booked-call reminders (5 h off, 2 h, 15 min; past ones skipped), STOP/START/HELP/YES/C replies, email capture, Twilio sending with signed webhooks, CSR calls (rings you first, recording notice), AI interview calls through a voice adapter (Vapi or test provider), voicemail → scheduling link, retries in the best answer window (2/day, 4 total) then a manual-call task, emergency stop enforced in the database, staging test-phone allow-list, candidate self-service page, scheduler every minute (pg_cron).
- **Phase 4 · AI:** LLM adapter (Anthropic / OpenAI / test), post-call summary and facts, chat overview, AI insights with plain-English findings, recruitment assistant with read-only tools in the user's own scope (names sent as references), AI training pack (names and phones removed).
- **Phase 5 · hardening:** alerts every 15 minutes (5 rules, 6-hour de-duplication, test send), weekly client report (Monday 8 AM ET, no names), retention clean-up, candidate export / delete on request, AES-256-GCM licence number and date of birth, more rate limits.
- Migrations 0010–0013; database tests 03–05 (183 total), 56 Edge Function tests, 30 web unit tests.


## 0.1.1 · 2026-11-11
- Codespace setup (`.devcontainer`), `npm run check:all` (every check in one command) and `npm run app:codespace` (local Supabase + demo data + app).
- Dev server proxies `/supabase` to local Supabase so nothing has to be made public in a Codespace.
- `docs/TESTING.md`: step-by-step testing guide.

## 0.1.0 · 2026-11-11 · Phase 0 + Phase 1

### Phase 0: setup
- Monorepo: `apps/web` (React 18 + Vite + TypeScript strict + Tailwind) and `supabase/`.
- CI (GitHub Actions): type check, lint, unit tests, build, secret scan of source and built files, no published source maps, Edge Function lint/type check/tests, database migrations + RLS tests on real Supabase, gitleaks history scan.
- Deploy: Vercel Git integration for the web app (staging and production projects); GitHub Action pushes migrations and Edge Functions to the matching Supabase project; manual, confirmed workflow to load demo data into staging only.
- `vercel.json` security headers: strict CSP, HSTS, X-Frame-Options DENY, Referrer-Policy, Permissions-Policy, COOP, noindex.
- Production build drops `console.*` and `debugger`; source maps only when uploaded privately to Sentry, then deleted from `dist/`.
- `.env.example` (public vs server-only values), Dependabot, PR template.

### Phase 1: foundation
- 36 tables from the data model, every one with RLS on and deny-by-default; composite keys stop a row from being attached to another client's parent.
- 8 access levels and the permission matrix in `role_permissions`; helper functions `auth_user_role()`, `can()`, `has_client_access()`, `has_station_access()`, `application_visible()` used by every policy.
- Admin and Super Admin get no data until MFA (aal2) is passed; any session older than 12 hours gets no data.
- Append-only activity log: no UPDATE/DELETE/TRUNCATE for anyone (privileges revoked + blocking trigger). Automatic log rows for stage changes, assignments, onboarding steps, access changes, user level changes and every settings table.
- Database rules: shortlist needs a completed AI interview and no answer awaiting review; hired needs every required step done or waived with a reason; not-interested needs a reason; same phone blocked within a client; quiet hours can never extend past 8 AM–9 PM.
- New sign-ups start as pending with no access; self sign-up is off.
- Private storage buckets for recordings, licences and documents (signed URLs only).
- Edge Function shared helpers: auth (JWT + database access check + blocked device), permissions, Zod validation, rate limits, activity log, AES-256-GCM field encryption, CORS allow-list, safe error responses.
- `record-sign-in` function: records computer, browser and IP; flags new computers and IP changes; refuses blocked computers.
- Web app: sign in (Google + email/password), two-step verification set-up and check, access gate (pending / disabled / 12-hour / MFA), client picker with search (only assigned clients), Phase 1 client shell with live, RLS-filtered numbers.
- Fictional seed: 3 clients, 4 stations, 6 job roles, 11 users across all 8 levels, 29 applications.
- Field rules: only Supervisor+ can reassign; Ops and Station Managers can only move people to Onboarding/Hired; client, candidate, station and job role of an application cannot be changed by a person.
- Tests: 78 database tests (52 RLS scope + 26 rules/audit), 22 Edge Function tests, 9 web unit tests, 5 secret-scanner tests.

## 2026-11-19 · Speed
- Database: the "who are you" check behind every security rule now runs once per request instead of once per row. Candidates list on staging: 287 ms → 22 ms. 13 rules rewritten to run their checks once per query.
- App start: page code, access, client, team and candidates now load at the same time instead of one after another. Candidates page (simulated 250 ms per round trip): first visit 948 → 601 ms, repeat visit 973 → 379 ms.
- Removed a duplicate access request on every page load; other pages' code is fetched quietly after the first screen; web fonts no longer block the first paint.
- Fix: the AI call column said "Link sent" even when the text was blocked or still waiting; it now says "Text not sent" with the reason.
- Edge Functions type-check on the newer Deno (2.9).
