# Bugs

Bugs only. Feature requests go in the product backlog, not here.
Priority: **P0** = data leak, security hole, or the app is down · **P1** = a main workflow is broken · **P2** = everything else.

| ID | Priority | Found | Where | What happens | Status | Fixed in |
|---|---|---|---|---|---|---|
| B-001 | P1 | 2026-11-11 | RLS · profiles | CSRs could not see colleagues' names (policy read another RLS-protected table). Found by test `01_rls_scope_test` #52. | Fixed | 0.1.0 (`shares_client_with()` helper) |
