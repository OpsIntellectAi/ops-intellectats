import type { Config } from 'tailwindcss';

export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        canvas: '#F6F4EF',
        ink: '#1B1D1F',
        muted: '#5F625F',
        line: '#E6E2D9',
        brand: { DEFAULT: '#1E5A4E', dark: '#174A40', soft: '#E5EFEC' },
        warn: { DEFAULT: '#9A5512', soft: '#FBEFE1' },
        bad: { DEFAULT: '#8C2F22', soft: '#F9E8E5' },
        info: { DEFAULT: '#24498A', soft: '#E8EEF8' },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        serif: ['"Instrument Serif"', 'Georgia', 'serif'],
      },
      borderRadius: { card: '16px' },
    },
  },
  plugins: [],
} satisfies Config;
