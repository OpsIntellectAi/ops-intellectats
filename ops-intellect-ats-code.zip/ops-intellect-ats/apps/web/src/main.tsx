import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from '@/app/App';
import { initSentry } from '@/lib/sentry';
import './styles.css';

initSentry();

// Web fonts load without holding up the first paint (the page shows in the system font
// for a moment, then switches). In index.html this stylesheet blocked rendering.
const fonts = document.createElement('link');
fonts.rel = 'stylesheet';
fonts.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Instrument+Serif&display=swap';
document.head.appendChild(fonts);

const root = document.getElementById('root');
if (!root) throw new Error('Missing #root');
createRoot(root).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
