import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { lazy, Suspense } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { ToastProvider } from '@/components/kit';
import { AuthCallbackPage } from '@/features/auth/AuthCallbackPage';
import { MfaPage } from '@/features/auth/MfaPage';
import { RequireAccess } from '@/features/auth/RequireAccess';
import { SessionProvider } from '@/features/auth/session';
import { SignInPage } from '@/features/auth/SignInPage';
import { ClientPickerPage } from '@/features/clients/ClientPickerPage';
import { ClientLayout } from '@/features/shell/ClientLayout';
import { Guard } from '@/features/shell/Guard';
import { Spinner } from '@/components/ui';
import { warmUp } from '@/lib/warmup';
import { pageLoaders } from './pages';

// Each page loads on first use, so the first screen downloads less.
const MyDayPage = lazy(pageLoaders['my-day']);
const TodayPage = lazy(pageLoaders.today);
const CandidatesPage = lazy(pageLoaders.candidates);
const CallsPage = lazy(pageLoaders.calls);
const InsightsPage = lazy(pageLoaders.insights);
const MessagesPage = lazy(pageLoaders.messages);
const DashboardPage = lazy(pageLoaders.dashboard);
const ReportsPage = lazy(pageLoaders.reports);
const AdminPage = lazy(pageLoaders.admin);
const SetupPage = lazy(pageLoaders.setup);
const SelfServicePage = lazy(pageLoaders.selfService);

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false, staleTime: 15_000 } },
});

// Start loading the page code and its data at once, before React has even drawn.
if (typeof window !== 'undefined') void warmUp(queryClient, window.location.pathname).catch(() => undefined);

export function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ToastProvider>
        <SessionProvider>
          <BrowserRouter>
            <Suspense fallback={<div className="flex min-h-[40vh] items-center justify-center"><Spinner /></div>}>
            <Routes>
              <Route path="/sign-in" element={<SignInPage />} />
              <Route path="/auth/callback" element={<AuthCallbackPage />} />
              <Route path="/mfa" element={<MfaPage />} />
              <Route path="/s/:token" element={<SelfServicePage />} />
              <Route path="/" element={<RequireAccess>{(a) => <ClientPickerPage access={a} />}</RequireAccess>} />
              <Route path="/c/:clientId" element={<RequireAccess>{(a) => <ClientLayout access={a} />}</RequireAccess>}>
                <Route index element={<Navigate to="my-day" replace />} />
                <Route path="my-day" element={<MyDayPage />} />
                <Route path="today" element={<TodayPage />} />
                <Route path="candidates" element={<CandidatesPage />} />
                <Route path="calls" element={<CallsPage />} />
                <Route path="insights" element={<Guard need="reports.view"><InsightsPage /></Guard>} />
                <Route path="messages" element={<MessagesPage />} />
                <Route path="dashboard" element={<DashboardPage />} />
                <Route path="reports" element={<Guard need="reports.view"><ReportsPage /></Guard>} />
                <Route path="admin" element={<Guard need="audit.view"><AdminPage /></Guard>} />
                <Route path="setup" element={<Guard need="settings.edit"><SetupPage /></Guard>} />
                <Route path="*" element={<Navigate to="my-day" replace />} />
              </Route>
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
            </Suspense>
          </BrowserRouter>
        </SessionProvider>
      </ToastProvider>
    </QueryClientProvider>
  );
}
