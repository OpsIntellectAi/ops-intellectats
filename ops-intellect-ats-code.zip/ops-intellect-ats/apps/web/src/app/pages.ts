// Page code is downloaded on first use. The same loaders are used to start the download of
// the page in the address bar straight away, while sign-in is still being checked.
export const pageLoaders = {
  'my-day': () => import('@/features/myday/MyDayPage').then((m) => ({ default: m.MyDayPage })),
  today: () => import('@/features/today/TodayPage').then((m) => ({ default: m.TodayPage })),
  candidates: () => import('@/features/candidates/CandidatesPage').then((m) => ({ default: m.CandidatesPage })),
  calls: () => import('@/features/calls/CallsPage').then((m) => ({ default: m.CallsPage })),
  insights: () => import('@/features/insights/InsightsPage').then((m) => ({ default: m.InsightsPage })),
  messages: () => import('@/features/messages/MessagesPage').then((m) => ({ default: m.MessagesPage })),
  dashboard: () => import('@/features/dashboard/DashboardPage').then((m) => ({ default: m.DashboardPage })),
  reports: () => import('@/features/reports/ReportsPage').then((m) => ({ default: m.ReportsPage })),
  admin: () => import('@/features/admin/AdminPage').then((m) => ({ default: m.AdminPage })),
  setup: () => import('@/features/setup/SetupPage').then((m) => ({ default: m.SetupPage })),
  selfService: () => import('@/features/selfservice/SelfServicePage').then((m) => ({ default: m.SelfServicePage })),
} as const;

export type PageKey = keyof typeof pageLoaders;

/** "/c/<client>/candidates" → "candidates"; "/c/<client>" → "my-day"; "/s/<token>" → "selfService". */
export function pageForPath(pathname: string): PageKey | null {
  if (pathname.startsWith('/s/')) return 'selfService';
  const m = /^\/c\/[^/]+\/?([^/?#]*)/.exec(pathname);
  if (!m) return null;
  const page = m[1] || 'my-day';
  return page in pageLoaders ? (page as PageKey) : 'my-day';
}
