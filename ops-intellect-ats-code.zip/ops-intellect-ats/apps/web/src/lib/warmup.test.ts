import { describe, expect, it } from 'vitest';
import { pageForPath } from '@/app/pages';

// clientIdFromPath lives next to the Supabase client; test the same pattern without it.
const clientIdFromPath = (p: string) => /^\/c\/([0-9a-f-]{36})(?:\/|$)/i.exec(p)?.[1] ?? null;
const ID = '5d2b6f0a-1c3e-4b7a-9f10-2a3b4c5d6e7f';

describe('start-up warm-up', () => {
  it('finds the page in the address bar', () => {
    expect(pageForPath(`/c/${ID}/candidates`)).toBe('candidates');
    expect(pageForPath(`/c/${ID}/calls?app=x`)).toBe('calls');
    expect(pageForPath(`/c/${ID}`)).toBe('my-day');
    expect(pageForPath(`/c/${ID}/`)).toBe('my-day');
    expect(pageForPath(`/c/${ID}/nonsense`)).toBe('my-day');
    expect(pageForPath('/s/abc123')).toBe('selfService');
    expect(pageForPath('/')).toBeNull();
    expect(pageForPath('/sign-in')).toBeNull();
  });
  it('reads the client id only from a real client address', () => {
    expect(clientIdFromPath(`/c/${ID}/messages`)).toBe(ID);
    expect(clientIdFromPath(`/c/${ID}`)).toBe(ID);
    expect(clientIdFromPath('/c/not-an-id/messages')).toBeNull();
    expect(clientIdFromPath('/')).toBeNull();
  });
});
