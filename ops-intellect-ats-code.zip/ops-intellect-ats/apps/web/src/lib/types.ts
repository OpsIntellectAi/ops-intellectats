import type { Stage } from './format';
import type { AppRole } from './roles';

/** One row of the application_rows view (RLS-filtered to the signed-in person). */
export interface AppRow {
  id: string;
  client_id: string;
  candidate_id: string;
  station_id: string;
  job_role_id: string;
  stage: Stage;
  owner_id: string | null;
  source: string;
  applied_at: string;
  stage_changed_at: string;
  not_interested_reason: string | null;
  not_interested_until: string | null;
  rejection_reason: string | null;
  booked_call_at: string | null;
  full_name: string;
  phone_e164: string;
  email: string | null;
  city: string | null;
  zip: string | null;
  time_zone: string | null;
  opted_out_at: string | null;
  is_landline: boolean;
  lives_in_nyc: boolean;
  last_out_at: string | null;
  last_in_at: string | null;
  out_count: number;
  in_count: number;
  last_body: string | null;
  last_topics: string[] | null;
  ai_calls: number;
  completed_ai_calls: number;
  last_call_at: string | null;
  last_call_outcome: CallOutcome | null;
  unreviewed_calls: number;
  answers_to_review: number;
  steps_total: number;
  steps_done: number;
  required_left: number;
  last_step_change: string | null;
  said_yes_at: string | null;
  no_response_at: string | null;
  manual_call_needed: boolean;
  reschedule_requested_at: string | null;
  cadence_step: number;
  last_direction: 'inbound' | 'outbound' | null;
  last_status: string | null;
  last_is_automatic: boolean | null;
  last_at: string | null;
  last_call_via: 'ai' | 'csr' | null;
  last_call_summary: string | null;
}

export type CallOutcome = 'queued' | 'in_progress' | 'completed' | 'voicemail' | 'no_answer' | 'busy' | 'failed' | 'dropped';

export interface CallRow {
  id: string;
  client_id: string;
  application_id: string;
  provider: string;
  direction: 'inbound' | 'outbound';
  via: 'ai' | 'csr';
  outcome: CallOutcome;
  duration_seconds: number | null;
  recording_path: string | null;
  script_version_id: string | null;
  attempt_number: number;
  placed_by: string | null;
  started_at: string | null;
  ended_at: string | null;
  created_at: string;
  job_role_id: string;
  station_id: string;
  owner_id: string | null;
  stage: Stage;
  full_name: string;
  phone_e164: string;
  answers_to_review: number;
  review_verdict: 'looks_right' | 'flagged' | null;
  review_reason: string | null;
  summary: string | null;
}

export interface TeamMember {
  user_id: string;
  full_name: string;
  role: AppRole;
  station_ids: string[] | null;
}

export interface Message {
  id: string;
  application_id: string;
  direction: 'inbound' | 'outbound';
  body: string;
  status: string;
  topics: string[];
  is_automatic: boolean;
  sent_by: string | null;
  error_code: string | null;
  created_at: string;
}

export interface StepDef {
  id: string;
  key: string;
  name: string;
  phase: string;
  owner_label: string;
  statuses: string[];
  done_statuses: string[];
  bad_statuses: string[];
  guidance: Record<string, string>;
  required: boolean;
  sort_order: number;
}

export interface StepRow {
  id: string;
  application_id: string;
  step_def_id: string;
  status: string;
  note: string | null;
  waived_reason: string | null;
  changed_by: string | null;
  changed_at: string;
}

export interface Answer {
  id: string;
  call_id: string;
  question_key: string;
  question_text: string;
  heard_text: string | null;
  result: 'yes' | 'no' | 'needs_review' | 'recorded' | 'info';
  at_seconds: number | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
}

export interface Template {
  id: string;
  name: string;
  body: string;
  stages: Stage[];
  is_scheduling_link: boolean;
}
