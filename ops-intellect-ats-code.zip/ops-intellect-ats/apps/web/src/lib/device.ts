/**
 * A random id for this browser on this computer, so the activity log can tell computers
 * apart and a Super Admin can block one. It is not a secret and not a fingerprint.
 */
const KEY = 'oi.deviceKey';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

let memoryKey: string | null = null;

export function getDeviceKey(storage: Pick<Storage, 'getItem' | 'setItem'> | null = safeLocalStorage()): string {
  try {
    const existing = storage?.getItem(KEY) ?? null;
    if (existing && UUID.test(existing)) return existing;
    const fresh = crypto.randomUUID();
    storage?.setItem(KEY, fresh);
    return fresh;
  } catch {
    memoryKey ??= crypto.randomUUID();
    return memoryKey;
  }
}

function safeLocalStorage(): Storage | null {
  try {
    return typeof window === 'undefined' ? null : window.localStorage;
  } catch {
    return null;
  }
}
