/** AI interview scripts: question tree shape and the rule-based compliance check. */

export type QuestionType = 'yes_no' | 'recorded' | 'info';

export interface ScriptQuestion {
  key: string;
  type: QuestionType;
  text: string;
  yes?: string;
  no?: string;
  cross?: string;
  dealbreaker?: boolean;
  note?: string;
}

export interface ComplianceIssue {
  id: string;
  level: 'bad' | 'warn';
  text: string;
  fix?: { rule?: string; questionKey?: string; patch?: Partial<ScriptQuestion> };
}

export const REQUIRED_RULES: { id: string; test: RegExp; text: string; rule: string }[] = [
  { id: 'ai', test: /\bAI\b|artificial intelligence|automated assistant/i, text: 'The opening must say it is an AI assistant.', rule: 'Say you are an AI assistant calling for the company' },
  { id: 'recorded', test: /record/i, text: 'The opening must say the call is recorded.', rule: 'Say the call is recorded' },
  { id: 'safe', test: /safe time|good time|driving/i, text: 'Ask if now is a safe time to talk (offer a callback if driving).', rule: 'Ask if now is a safe time to talk; offer a callback if they are driving' },
  { id: 'human', test: /human|person|recruiter/i, text: 'Offer a person if the candidate asks for one.', rule: 'Offer a human recruiter if the candidate asks' },
];

/** Protected topics the script must never ask about. */
const PROTECTED: { id: string; re: RegExp; label: string }[] = [
  { id: 'origin', re: /\b(where (are you|were you) (from|born)|nationality|national origin|ethnic|race)\b/i, label: 'national origin / race' },
  { id: 'citizen', re: /\b(citizen(ship)?|green card|immigra|visa status)\b/i, label: 'citizenship (only ask “authorized to work in the US”)' },
  { id: 'religion', re: /\b(religio|church|pray|sabbath)\b/i, label: 'religion' },
  { id: 'family', re: /\b(married|pregnan|children|kids|family plans|husband|wife)\b/i, label: 'family' },
  { id: 'health', re: /\b(health(?! insurance)|medical|medication|disabilit|illness|injur)/i, label: 'health or disability' },
  { id: 'arrest', re: /\b(have you (ever )?been (arrested|convicted)|arrest record|how many (tickets|arrests))\b/i, label: 'arrests / criminal history (ask only whether they are comfortable with the background check)' },
  { id: 'age_exact', re: /\b(how old are you|date of birth|what year were you born)\b/i, label: 'exact age (ask only “are you 21 or older?”)' },
];

export function complianceCheck(
  questions: ScriptQuestion[],
  rules: string[],
  setup: { payText?: string | null; minAge?: number | null; address?: string | null },
): ComplianceIssue[] {
  const issues: ComplianceIssue[] = [];
  const ruleText = rules.join('\n');
  for (const r of REQUIRED_RULES) {
    if (!r.test.test(ruleText)) issues.push({ id: `rule-${r.id}`, level: 'bad', text: r.text, fix: { rule: r.rule } });
  }
  if (!/never ask about/i.test(ruleText)) {
    issues.push({ id: 'rule-protected', level: 'warn', text: 'Add a rule listing topics the AI must never ask about.', fix: { rule: 'Never ask about origin, citizenship (beyond work authorization), religion, family, health, disability or arrests' } });
  }
  if (!questions.length) issues.push({ id: 'empty', level: 'bad', text: 'The script has no questions.' });
  const keys = new Set<string>();
  for (const q of questions) {
    if (keys.has(q.key)) issues.push({ id: `dup-${q.key}`, level: 'bad', text: `Two questions use the key “${q.key}”.` });
    keys.add(q.key);
    const all = `${q.text} ${q.cross ?? ''}`;
    if (!/^[a-z0-9_]+(\.(yes|no))*$/i.test(q.key)) issues.push({ id: `key-${q.key}`, level: 'bad', text: `Key “${q.key}” must be letters/digits, optionally followed by .yes or .no (like 17.yes).` });
    const cond = condition(q.key);
    if (cond && !questions.some((p) => p.key === cond.parent)) issues.push({ id: `parent-${q.key}`, level: 'bad', text: `“${q.key}” is a follow-up of “${cond.parent}”, but there is no question “${cond.parent}”.` });
    for (const p of PROTECTED) {
      if (p.re.test(all)) issues.push({ id: `prot-${q.key}-${p.id}`, level: 'bad', text: `“${q.text}” touches a protected topic: ${p.label}.` });
    }
    if (q.type === 'yes_no' && (!q.yes?.trim() || !q.no?.trim()) && !cond) {
      issues.push({ id: `def-${q.key}`, level: 'warn', text: `“${q.text}” needs a definition of what counts as Yes and as No.`, fix: { questionKey: q.key, patch: { yes: q.yes || 'Clearly says yes', no: q.no || 'Clearly says no' } } });
    }
    if (q.dealbreaker && q.type !== 'yes_no') {
      issues.push({ id: `deal-${q.key}`, level: 'warn', text: `“${q.text}” is a dealbreaker but not a yes/no question.` });
    }
    if (q.type === 'yes_no' && !q.cross?.trim() && !cond) {
      issues.push({ id: `cross-${q.key}`, level: 'warn', text: `“${q.text}” has no cross-question for unclear answers (unclear goes to a person).`, fix: { questionKey: q.key, patch: { cross: 'Sorry, could you say yes or no?' } } });
    }
    const age = /(\d{2})\s*(or older|\+)/i.exec(q.text);
    if (age && setup.minAge && Number(age[1]) !== setup.minAge) {
      issues.push({ id: `age-${q.key}`, level: 'bad', text: `“${q.text}” says ${age[1]} but the job role minimum age is ${setup.minAge}.` });
    }
    const pay = /\$\s?\d+(\.\d{2})?/.exec(q.text);
    if (pay && setup.payText && !setup.payText.includes(pay[0].replace(/\s/g, ''))) {
      issues.push({ id: `pay-${q.key}`, level: 'bad', text: `“${q.text}” mentions ${pay[0]} but the job role pay is “${setup.payText}”.` });
    }
  }
  if (questions.some((q) => q.dealbreaker) && !/polite|thank/i.test(ruleText)) {
    issues.push({ id: 'deal-end', level: 'warn', text: 'Dealbreaker answers should end the call politely.', fix: { rule: 'If a dealbreaker answer is No, thank the candidate politely and end the call' } });
  }
  return issues;
}

/**
 * Import questions from CSV/Excel. Two layouts work:
 *  1. Key, Type, Question, Yes means, No means, Cross-question, Dealbreaker
 *  2. id, path, question, type (yes/no | subjective), dealbreaker — paths like 3, 3.no, 18.yes.yes
 * In layout 2 a ".no"/".yes" row without a question mark is something the AI says; a dealbreaker
 * on such a row makes its parent question the dealbreaker.
 */
export function questionsFromGrid(grid: string[][]): ScriptQuestion[] {
  const [head, ...body] = grid;
  if (!head) return [];
  const idx = (name: RegExp) => head.findIndex((h) => name.test(String(h ?? '').trim()));
  const iPath = idx(/^path$/i);
  const iKey = iPath >= 0 ? iPath : idx(/^key$/i);
  const iType = idx(/^type$/i);
  const iText = idx(/^question$/i);
  const iYes = idx(/^yes/i);
  const iNo = idx(/^no( |$)/i);
  const iCross = idx(/^cross/i);
  const iDeal = idx(/^deal/i);
  const cell = (r: string[], i: number) => (i >= 0 ? String(r[i] ?? '').trim() : '');
  const out: ScriptQuestion[] = [];
  body.forEach((r, n) => {
    const text = cell(r, iText);
    if (!text) return;
    const rawType = cell(r, iType).toLowerCase();
    const rawKey = cell(r, iKey).replace(/\s+/g, '');
    const key = rawKey ? (/^\d/.test(rawKey) && iPath < 0 ? `q${rawKey}` : rawKey) : `q${n + 1}`;
    const isFollow = Boolean(condition(key));
    const deal = /^(y|yes|true|1)$/i.test(cell(r, iDeal));
    let type: QuestionType = rawType === 'recorded' || rawType === 'subjective' || rawType === 'open' ? 'recorded' : rawType === 'info' ? 'info' : 'yes_no';
    if (isFollow && type === 'yes_no' && !text.includes('?')) type = 'info';
    if (!isFollow && type === 'yes_no' && !/\?/.test(text) && /^(thank|okay|ok|just to inform|this was)/i.test(text)) type = 'info';
    out.push({
      key,
      type,
      text,
      yes: iYes >= 0 ? cell(r, iYes) : type === 'yes_no' && !isFollow ? 'Clearly says yes' : undefined,
      no: iNo >= 0 ? cell(r, iNo) : type === 'yes_no' && !isFollow ? 'Clearly says no' : undefined,
      cross: iCross >= 0 ? cell(r, iCross) : type === 'yes_no' && !isFollow ? 'Sorry, could you say yes or no?' : undefined,
      dealbreaker: type === 'yes_no' ? deal && !isFollow : false,
    });
    if (deal && isFollow) {
      const parent = out.find((q) => q.key === condition(key)?.parent);
      if (parent && parent.type === 'yes_no') parent.dealbreaker = true;
    }
  });
  return out;
}

/** "18.yes.yes" → parent "18.yes", answer "yes". Plain keys have no condition. */
export function condition(key: string): { parent: string; answer: 'yes' | 'no' } | null {
  const m = /^(.+)\.(yes|no)$/i.exec(key);
  return m ? { parent: m[1] as string, answer: (m[2] as string).toLowerCase() as 'yes' | 'no' } : null;
}

export interface JobFacts {
  client: string;
  role: string;
  pay?: string | null;
  address?: string | null;
  trainingLocation?: string | null;
  shift?: string | null;
  schedule?: string | null;
  minAge?: number | null;
}

/** Same placeholder filling as the server (supabase/functions/_shared/voice/script.ts). */
export function fillFacts(text: string, f: JobFacts & { firstName?: string }): string {
  const map: Record<string, string | null | undefined> = {
    company: f.client,
    client: f.client,
    dsp: f.client,
    role: f.role,
    pay: f.pay,
    'pay rate': f.pay,
    address: f.address,
    'station address': f.address,
    location: f.address,
    'training location': f.trainingLocation,
    shift: f.shift,
    schedule: f.schedule,
    'min age': f.minAge != null ? String(f.minAge) : null,
    'first name': f.firstName,
  };
  return text.replace(/\[([a-z ]{2,20})\]/gi, (all, name: string) => {
    const v = map[name.toLowerCase()];
    return v == null || v === '' ? all : v;
  });
}

/** Placeholders still empty for this job role (shown as a warning in the editor). */
export function missingFacts(questions: ScriptQuestion[], rules: string[], f: JobFacts): string[] {
  const text = [...questions.map((q) => q.text), ...rules].join('\n');
  const left = new Set<string>();
  for (const m of fillFacts(text, f).matchAll(/\[([a-z ]{2,20})\]/gi)) left.add(String(m[1]).toLowerCase());
  return [...left];
}

export const STANDARD_RULES = [
  'Say you are an AI assistant calling for [company] and that the call is recorded',
  'Ask if now is a safe time to talk; offer a callback if they are driving',
  'Offer a human recruiter if the candidate asks for a person',
  'Never ask about origin, citizenship (beyond work authorization), religion, family, health, disability or arrests',
  'If a dealbreaker answer is No, thank the candidate politely and end the call',
  'Ask for yes or no answers on eligibility questions',
];

/**
 * The standard delivery-driver script (from the team's question sheet). Only [placeholders]
 * change per client: company, address, pay, training location, shift, schedule, min age.
 */
export const STANDARD_SCRIPT: ScriptQuestion[] = [
  { key: '1', type: 'yes_no', text: 'I am calling on behalf of [company] to collect some information about the [role] role you applied for. Is that okay?', yes: 'Agrees to continue', no: 'Does not want to continue', cross: 'Sorry, is it okay to continue?' },
  { key: '1.yes', type: 'info', text: 'Thank you. I have a few mandatory eligibility questions; please answer them with yes or no.' },
  { key: '2', type: 'yes_no', text: 'We are located at [address]. Are you comfortable with this location?', yes: 'Comfortable with the location', no: 'Not comfortable with the location', cross: 'Sorry, is the location okay for you, yes or no?' },
  { key: '3', type: 'yes_no', text: 'This position requires you to be at least [min age] years old and have a valid driver licence. Can you confirm you meet both?', yes: 'Confirms both', no: 'Under the minimum age or no valid licence', cross: 'Sorry, are you [min age] or older with a valid licence, yes or no?', dealbreaker: true },
  { key: '3.no', type: 'info', text: 'Once you meet both requirements you are welcome to re-apply and we will contact you.' },
  { key: '4', type: 'yes_no', text: 'Are you legally authorized to work in the United States?', yes: 'Says yes', no: 'Says no', cross: 'Sorry, are you authorized to work in the US, yes or no?', dealbreaker: true },
  { key: '4.no', type: 'info', text: 'Based on that, you do not meet the eligibility requirements. We appreciate your interest and thank you for applying.' },
  { key: '5', type: 'yes_no', text: 'Are you aware of driving regulations, including local traffic laws and parking rules?', yes: 'Says yes', no: 'Says no', cross: 'Sorry, could you say yes or no?' },
  { key: '6', type: 'yes_no', text: 'The role involves lifting packages up to 50 pounds and delivering about 300 to 350 packages a day, with bending, stairs and getting in and out of the vehicle often. Are you able to do these tasks with or without reasonable accommodation?', yes: 'Able to do the tasks', no: 'Not able to', cross: 'Sorry, could you say yes or no?' },
  { key: '7', type: 'yes_no', text: 'The job means delivering in all weather: heavy rain, snow, heat or cold. Are you comfortable with that?', yes: 'Comfortable', no: 'Not comfortable', cross: 'Sorry, could you say yes or no?' },
  { key: '8', type: 'yes_no', text: 'Are you able to work flexible shifts, including weekends or changing schedules based on business needs?', yes: 'Able', no: 'Not able', cross: 'Sorry, could you say yes or no?' },
  { key: '9', type: 'yes_no', text: 'The job means driving to unfamiliar locations and different routes. Are you comfortable with that?', yes: 'Comfortable', no: 'Not comfortable', cross: 'Sorry, could you say yes or no?' },
  { key: '10', type: 'yes_no', text: 'Are you confident using a smartphone for GPS, scanning packages, clocking in and out, and messaging your supervisors?', yes: 'Confident', no: 'Not confident', cross: 'Sorry, could you say yes or no?' },
  { key: '11', type: 'yes_no', text: 'The shift is [shift]. Are you comfortable with these shift timings?', yes: 'Comfortable', no: 'Not comfortable', cross: 'Sorry, could you say yes or no?' },
  { key: '12', type: 'yes_no', text: 'This position requires a pre-employment drug screening and a background check covering the past seven years, including your motor vehicle report and driving history. Are you comfortable with these requirements?', yes: 'Comfortable', no: 'Not comfortable', cross: 'Sorry, could you say yes or no?' },
  { key: '13', type: 'yes_no', text: 'The pay for this position is [pay], paid weekly, with benefits that may include health insurance, a 401(k) plan, paid training and paid time off. Are you comfortable with this pay?', yes: 'Comfortable', no: 'Not comfortable', cross: 'Sorry, is the pay okay for you, yes or no?' },
  { key: '14', type: 'yes_no', text: 'The work schedule is [schedule]. Are you comfortable with this schedule?', yes: 'Comfortable', no: 'Not comfortable', cross: 'Sorry, could you say yes or no?' },
  { key: '15', type: 'yes_no', text: 'Paid training takes place at [training location]. Are you able to attend training there?', yes: 'Able to attend', no: 'Not able to attend', cross: 'Sorry, can you get to the training location, yes or no?' },
  { key: '16', type: 'recorded', text: 'How far do you live from [address], and would you use your own vehicle or public transport to get there?' },
  { key: '17', type: 'recorded', text: 'How many years of driving and delivery driver experience do you have?' },
  { key: '18', type: 'yes_no', text: 'Are you currently employed?', yes: 'Employed now', no: 'Not employed now', cross: 'Sorry, are you working right now, yes or no?' },
  { key: '18.yes', type: 'recorded', text: 'Why are you looking for a job change?' },
  { key: '19', type: 'yes_no', text: 'Have you worked with Amazon in the past?', yes: 'Has worked with Amazon', no: 'Has not', cross: 'Sorry, could you say yes or no?' },
  { key: '19.yes', type: 'yes_no', text: 'Have you worked at an Amazon delivery service partner before?' },
  { key: '19.yes.yes', type: 'recorded', text: 'Please share the name of your last delivery service partner, why you left, and whether you are comfortable sharing a reference contact from there.' },
  { key: '20', type: 'yes_no', text: 'Our vans have the Netradyne safety camera, which checks seatbelt use, stop signs, speeding and distracted driving. Are you comfortable driving a vehicle with this system?', yes: 'Comfortable', no: 'Not comfortable', cross: 'Sorry, could you say yes or no?' },
  { key: '21', type: 'yes_no', text: 'Do you know the term “rescue”?', yes: 'Knows it', no: 'Does not know it', cross: 'Sorry, could you say yes or no?' },
  { key: '21.no', type: 'yes_no', text: 'If you finish your packages early you may be asked to help a driver who is behind, and another driver may help you on a heavy day. It is a team effort. Would you be comfortable doing that if dispatch asks?' },
  { key: '22', type: 'recorded', text: 'How would you respond to a customer who is upset about a late delivery?' },
  { key: '23', type: 'recorded', text: 'That is everything from my side. Do you have any questions about this job?' },
];
