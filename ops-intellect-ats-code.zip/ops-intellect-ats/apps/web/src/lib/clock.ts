/**
 * The computer's clock can be minutes off (we saw a PC 9 minutes behind), which made times
 * show as "in 8 min" for things that just happened. Every server answer carries the real
 * time in its Date header; we keep the difference and use it for "x min ago".
 */
let offsetMs = 0;

export function learnServerTime(dateHeader: string | null, sentAt: number, receivedAt: number): void {
  if (!dateHeader) return;
  const server = Date.parse(dateHeader);
  if (Number.isNaN(server)) return;
  // The header has 1-second precision; compare with the middle of the request.
  const local = (sentAt + receivedAt) / 2;
  const diff = server + 500 - local;
  // Ignore tiny differences; only correct clocks that are clearly off.
  offsetMs = Math.abs(diff) > 5_000 ? diff : 0;
}

export function serverNow(): number {
  return Date.now() + offsetMs;
}
