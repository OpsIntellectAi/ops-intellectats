import { serverNow } from './clock';
/** What the candidate list shows per row: AI call status, last message and next step. Pure, tested. */
import { buildQueues, QUEUES, type QueueKey } from './queues';
import { shortlistCheck } from './rules';
import { dateTimeIn, relative } from './time';
import type { AppRow } from './types';

export type Tone = 'ok' | 'warn' | 'bad' | 'info' | 'neutral' | 'purple';

export interface CellView {
  label: string;
  sub: string;
  tone: Tone;
}

const OUTCOME: Record<string, { label: string; tone: Tone }> = {
  completed: { label: 'Completed', tone: 'ok' },
  in_progress: { label: 'Calling…', tone: 'info' },
  queued: { label: 'Starting…', tone: 'info' },
  voicemail: { label: 'Voicemail', tone: 'warn' },
  no_answer: { label: 'No answer', tone: 'warn' },
  busy: { label: 'Busy', tone: 'warn' },
  dropped: { label: 'Dropped', tone: 'warn' },
  failed: { label: 'Failed', tone: 'bad' },
};

export function aiCallView(r: AppRow, queuedAt: string | null, tz: string, now: number = serverNow()): CellView {
  const zone = r.time_zone || tz;
  if (r.booked_call_at && new Date(r.booked_call_at).getTime() > now - 15 * 60_000 && (!r.last_call_at || r.last_call_at < r.booked_call_at)) {
    return { label: 'Scheduled', sub: dateTimeIn(r.booked_call_at, zone), tone: 'info' };
  }
  if (queuedAt) return { label: 'Queued', sub: `AI call ${dateTimeIn(queuedAt, zone)}`, tone: 'info' };
  if (r.last_call_at && r.last_call_outcome) {
    const o = OUTCOME[r.last_call_outcome] ?? { label: r.last_call_outcome, tone: 'neutral' as Tone };
    return { label: o.label, sub: `${r.last_call_via === 'csr' ? 'Phone · ' : ''}${relative(r.last_call_at, now)}`, tone: o.tone };
  }
  if (r.said_yes_at && r.stage === 'interview') return { label: 'Said yes', sub: `${relative(r.said_yes_at, now)} · call now`, tone: 'purple' };
  if (r.out_count > 0 && r.stage === 'interview') {
    // Only call it "sent" when the last text really left (or the candidate has replied).
    const lastOut = r.last_direction === 'outbound' ? (r.last_status ?? '') : '';
    if (lastOut && !REACHED.has(lastOut)) {
      const d = DELIVERY[lastOut] ?? { label: lastOut, tone: 'neutral' as Tone };
      return { label: 'Text not sent', sub: d.label, tone: d.tone === 'neutral' ? 'neutral' : d.tone };
    }
    return { label: 'Link sent', sub: 'Link sent, not booked', tone: 'neutral' };
  }
  return { label: 'Not called', sub: r.stage === 'interview' ? 'No text yet' : '', tone: 'neutral' };
}

/** Statuses where the text actually went out (test_sent = staging stand-in for sent). */
const REACHED = new Set(['delivered', 'sent', 'test_sent']);

const DELIVERY: Record<string, { label: string; tone: Tone }> = {
  delivered: { label: 'Delivered', tone: 'ok' },
  sent: { label: 'Sent', tone: 'ok' },
  queued: { label: 'Waiting to send', tone: 'neutral' },
  sending: { label: 'Sending', tone: 'neutral' },
  test_sent: { label: 'Test (not sent)', tone: 'neutral' },
  failed: { label: 'Failed', tone: 'bad' },
  undelivered: { label: 'Not delivered', tone: 'bad' },
  blocked_not_allowlisted: { label: 'Blocked · not a test phone', tone: 'warn' },
  blocked_a2p: { label: 'Blocked · A2P', tone: 'warn' },
  blocked_not_live: { label: 'Blocked · not live', tone: 'warn' },
  cancelled: { label: 'Cancelled', tone: 'neutral' },
};

export function lastMessageView(r: AppRow, now: number = serverNow()): CellView {
  if (!r.last_body || !r.last_at) return { label: 'Never messaged', sub: '', tone: 'neutral' };
  if (r.last_direction === 'inbound') {
    return { label: r.last_body, sub: `Unread reply · ${relative(r.last_at, now)}`, tone: 'info' };
  }
  const d = DELIVERY[r.last_status ?? ''] ?? { label: r.last_status ?? 'Sent', tone: 'neutral' as Tone };
  return { label: `You: ${r.last_body}`, sub: `${r.last_is_automatic ? 'Auto · ' : ''}${d.label} · ${relative(r.last_at, now)}`, tone: d.tone };
}

const STEP_TEXT: Record<QueueKey, string> = {
  said_yes: 'Said yes · AI call now',
  shared_email: 'Send DSP invite',
  replies_waiting: 'Reply to message',
  answers_to_review: 'Answer needs review',
  calls_to_review: 'Review interview',
  calls_to_retry: 'Retry the call',
  shortlisted_no_next: 'Ask for email',
  onboarding_stuck: 'Check onboarding',
  missed_booked: 'Missed booked call · call now',
  never_messaged: 'Send first text',
};

export function nextStep(r: AppRow, now: number = serverNow()): { text: string; key: QueueKey | null } {
  for (const q of QUEUES) if (q.test(r, now)) return { text: STEP_TEXT[q.key], key: q.key };
  if (r.opted_out_at) return { text: 'Opted out · no contact', key: null };
  switch (r.stage) {
    case 'interview':
      if (shortlistCheck(r).ready) return { text: 'Shortlist', key: null };
      if (r.booked_call_at) return { text: 'Wait for the booked call', key: null };
      return { text: 'Wait for a reply', key: null };
    case 'shortlisted':
      return { text: 'Move to pre-onboarding', key: null };
    case 'pre_onboarding':
      return { text: 'Send DSP invite', key: null };
    case 'onboarding':
      return { text: `${r.steps_done}/${r.steps_total} steps done`, key: null };
    case 'hired':
      return { text: 'Hired', key: null };
    case 'not_interested':
      return { text: r.not_interested_until ? `No contact until ${r.not_interested_until}` : 'Not interested', key: null };
    default:
      return { text: r.rejection_reason ? `Rejected: ${r.rejection_reason}` : 'Rejected', key: null };
  }
}

/** Counts for the contact chips (Everyone, Never messaged, No reply 3+ tries, Replied, Opted out). */
export type ContactChip = 'all' | 'never' | 'no_reply_tries' | 'replied' | 'opted_out';
export function contactChip(r: AppRow, c: ContactChip): boolean {
  if (c === 'all') return true;
  if (c === 'opted_out') return Boolean(r.opted_out_at);
  if (r.opted_out_at) return false;
  if (c === 'never') return r.out_count === 0;
  if (c === 'replied') return r.in_count > 0;
  return r.in_count === 0 && r.out_count >= 3;
}

export function queueCounts(rows: AppRow[], now: number = serverNow()) {
  return buildQueues(rows, now);
}
