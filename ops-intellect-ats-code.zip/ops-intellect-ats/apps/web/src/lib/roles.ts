/**
 * Role names and descriptions for the screen. UI HINTS ONLY: the database (RLS) and
 * Edge Functions decide what each person can really do.
 */
export type AppRole =
  | 'csr'
  | 'supervisor'
  | 'admin'
  | 'super_admin'
  | 'ops'
  | 'station_manager'
  | 'dsp_manager'
  | 'viewer';

export type Permission =
  | 'view'
  | 'candidates.act'
  | 'messages.send'
  | 'onboarding.update'
  | 'calls.review'
  | 'reports.view'
  | 'assistant.use'
  | 'candidates.assign'
  | 'audit.view'
  | 'audit.view_all'
  | 'templates.edit'
  | 'settings.edit'
  | 'reports.manage'
  | 'users.manage'
  | 'platform.admin';

export const ROLE_LABEL: Record<AppRole, string> = {
  csr: 'CSR',
  supervisor: 'Supervisor',
  admin: 'Admin',
  super_admin: 'Super Admin',
  ops: 'Ops Team',
  station_manager: 'Station Manager',
  dsp_manager: 'DSP Manager',
  viewer: 'Viewer',
};

export const ROLE_SCOPE: Record<AppRole, string> = {
  csr: 'Only candidates assigned to you, in the clients you are given',
  supervisor: 'Your own candidates and your CSRs’ candidates',
  admin: 'Every candidate in the clients you are given',
  super_admin: 'Everything, every client',
  ops: 'Every candidate in your clients; onboarding work only',
  station_manager: 'Only the stations assigned to you',
  dsp_manager: 'Your own company, all its stations, read-only',
  viewer: 'Read-only for the clients you are given',
};

export const MFA_ROLES: readonly AppRole[] = ['admin', 'super_admin'];

export function needsMfa(role: AppRole): boolean {
  return MFA_ROLES.includes(role);
}

/** Shape returned by public.my_access(). */
export interface MyAccess {
  user_id: string;
  full_name: string;
  email: string;
  role: AppRole;
  status: 'pending' | 'active' | 'disabled';
  session_ok: boolean;
  mfa_required: boolean;
  mfa_ok: boolean;
  effective_role: AppRole | null;
  permissions: Permission[];
}

export type Gate = 'ok' | 'mfa' | 'pending' | 'disabled' | 'expired' | 'no_access';

/** Decide which screen a signed-in person should see. */
export function accessGate(a: MyAccess | null): Gate {
  if (!a) return 'no_access';
  if (a.status === 'pending') return 'pending';
  if (a.status === 'disabled') return 'disabled';
  if (!a.session_ok) return 'expired';
  if (a.mfa_required && !a.mfa_ok) return 'mfa';
  if (!a.effective_role) return 'no_access';
  return 'ok';
}

export function can(a: MyAccess | null, p: Permission): boolean {
  return Boolean(a?.permissions.includes(p));
}
