import type { QueryClient } from '@tanstack/react-query';
import { pageForPath, pageLoaders } from '@/app/pages';
import { fetchMyAccess } from '@/features/auth/session';
import { fetchClientDetail, fetchRows, fetchTeam, pickStationRole, rowsKey } from '@/features/shell/context';
import { supabase } from './supabase';

function stored(key: string): string {
  try {
    return localStorage.getItem(key) ?? '';
  } catch {
    return '';
  }
}

/** "/c/<uuid>/…" → the client id, else null. */
export function clientIdFromPath(pathname: string): string | null {
  const m = /^\/c\/([0-9a-f-]{36})(?:\/|$)/i.exec(pathname);
  return m?.[1] ?? null;
}

/**
 * Runs once when the app opens. Without it every step waited for the one before:
 * sign-in check → access → page code → client → candidates, each a round trip to the
 * server (~250 ms from India). Here they all start together; the screens then find the
 * answers already loaded (same query keys) instead of asking again.
 * Nothing here can show data the person may not see: the database filters every request.
 */
export async function warmUp(qc: QueryClient, pathname: string): Promise<void> {
  const page = pageForPath(pathname);
  if (page) void pageLoaders[page]().catch(() => undefined);
  preloadOtherPages();

  const { data } = await supabase.auth.getSession();
  if (!data.session) return;

  void qc.prefetchQuery({ queryKey: ['my_access'], queryFn: fetchMyAccess, staleTime: 60_000 });

  const clientId = clientIdFromPath(pathname);
  if (!clientId) return;
  void qc.prefetchQuery({ queryKey: ['team', clientId], queryFn: () => fetchTeam(clientId) });

  // The job role open last time is remembered on this computer: ask for its candidates
  // now, together with the client, instead of after it.
  const lastRole = stored(`oi.role.${clientId}`);
  if (lastRole) void qc.prefetchQuery({ queryKey: rowsKey(clientId, lastRole), queryFn: () => fetchRows(clientId, lastRole) });

  const client = await qc.fetchQuery({ queryKey: ['client', clientId], queryFn: () => fetchClientDetail(clientId) }).catch(() => null);
  const { role } = pickStationRole(client, stored(`oi.station.${clientId}`), lastRole);
  if (client && role && role.id !== lastRole) void qc.prefetchQuery({ queryKey: rowsKey(client.id, role.id), queryFn: () => fetchRows(client.id, role.id) });
}

/** Once the first screen is up, fetch the code of the other pages quietly, so moving
 *  between pages never waits on a download. */
function preloadOtherPages(): void {
  if (typeof window === 'undefined') return;
  const run = () => {
    for (const load of Object.values(pageLoaders)) void load().catch(() => undefined);
  };
  const idle = (window as Window & { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => number }).requestIdleCallback;
  window.setTimeout(() => (idle ? idle(run, { timeout: 3000 }) : run()), 2500);
}
