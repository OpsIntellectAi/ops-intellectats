import { createClient } from '@supabase/supabase-js';
import { env } from './env';
import { getDeviceKey } from './device';
import { isExpiredJwt } from './jwt';
import { learnServerTime } from './clock';

/**
 * A request sent with an expired sign-in token (laptop asleep, tab in the background) gets
 * "JWT expired". We refresh the session once and send the same request again, so people
 * never see that error.
 */
let refreshing: Promise<string | null> | null = null;
async function freshToken(): Promise<string | null> {
  refreshing ??= supabase.auth
    .refreshSession()
    .then(({ data }) => data.session?.access_token ?? null)
    .catch(() => null)
    .finally(() => {
      window.setTimeout(() => (refreshing = null), 1000);
    });
  return refreshing;
}


const retryingFetch: typeof fetch = async (input, init) => {
  const sent = Date.now();
  const res = await fetch(input, init);
  learnServerTime(res.headers.get('date'), sent, Date.now());
  const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
  if ((res.status !== 401 && res.status !== 403) || url.includes('/auth/v1/')) return res;
  const text = await res.clone().text().catch(() => '');
  if (!isExpiredJwt(res.status, text)) return res;
  const token = await freshToken();
  if (!token) return res;
  const headers = new Headers(init?.headers ?? (input instanceof Request ? input.headers : undefined));
  headers.set('Authorization', `Bearer ${token}`);
  return fetch(input, { ...init, headers });
};

/**
 * Browser client with the PUBLIC anon key only. Every read is filtered by Row Level
 * Security in the database; anything that costs money or touches another service
 * (Twilio, AI, email) goes through an Edge Function instead.
 * The x-device-id header lets the activity log record which computer did what.
 */
/**
 * Sign-in token work is serialised inside this tab only. The browser-wide lock that
 * supabase-js uses by default can stall every request for 10 seconds when another tab
 * (or a page being closed) still holds it.
 */
let lockChain: Promise<unknown> = Promise.resolve();
function tabLock<R>(_name: string, _timeout: number, fn: () => Promise<R>): Promise<R> {
  const run = lockChain.then(fn, fn);
  lockChain = run.catch(() => undefined);
  return run;
}

export const supabase = createClient(env.VITE_SUPABASE_URL, env.VITE_SUPABASE_ANON_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, flowType: 'pkce', lock: tabLock },
  global: { headers: { 'x-device-id': getDeviceKey() }, fetch: retryingFetch },
});

// Timers stop while a laptop sleeps; check the token as soon as the tab is used again.
if (typeof document !== 'undefined') {
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      void supabase.auth.startAutoRefresh();
      void supabase.auth.getSession();
    } else {
      void supabase.auth.stopAutoRefresh();
    }
  });
}
