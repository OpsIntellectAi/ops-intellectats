/** CSV helpers. Exports are built in the browser from data the person can already see. */

export function toCsv(rows: Record<string, string | number | boolean | null | undefined>[], columns?: string[]): string {
  const cols = columns ?? Array.from(new Set(rows.flatMap((r) => Object.keys(r))));
  const esc = (v: string | number | boolean | null | undefined): string => {
    if (v === null || v === undefined) return '';
    let s = String(v);
    // Stop spreadsheet formula injection (=, +, -, @ at the start of a cell).
    if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
    return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [cols.map(esc).join(','), ...rows.map((r) => cols.map((c) => esc(r[c])).join(','))].join('\r\n');
}

export function downloadText(filename: string, text: string, type = 'text/csv;charset=utf-8'): void {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** RFC 4180 parser: quoted fields, escaped quotes, CRLF/LF line ends. */
export function detectDelimiter(text: string): ',' | ';' | '\t' {
  const first = text.replace(/^\uFEFF/, '').split(/\r?\n/, 1)[0] ?? '';
  const count = (ch: string) => first.split(ch).length - 1;
  const tabs = count('\t');
  const semis = count(';');
  const commas = count(',');
  if (tabs > commas && tabs >= semis) return '\t';
  if (semis > commas) return ';';
  return ',';
}

export function parseCsv(text: string, delimiter: ',' | ';' | '\t' = detectDelimiter(text)): string[][] {
  const out: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;
  const src = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < src.length; i += 1) {
    const ch = src[i] as string;
    if (quoted) {
      if (ch === '"') {
        if (src[i + 1] === '"') {
          field += '"';
          i += 1;
        } else quoted = false;
      } else field += ch;
    } else if (ch === '"' && field === '') quoted = true;
    else if (ch === delimiter) {
      row.push(field);
      field = '';
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && src[i + 1] === '\n') i += 1;
      row.push(field);
      out.push(row);
      row = [];
      field = '';
    } else field += ch;
  }
  if (field !== '' || row.length > 0) {
    row.push(field);
    out.push(row);
  }
  return out.filter((r) => r.some((c) => c.trim() !== ''));
}

export interface UploadRow {
  full_name: string;
  phone: string;
  email?: string;
  city?: string;
  zip?: string;
  job_role?: string;
  source?: string;
}

/** Which column a header means. Loose on purpose: "Candidate Name", "Mobile No.", "Cell #" all work. */
export function headerKey(raw: string): keyof UploadRow | 'first_name' | 'last_name' | null {
  const h = raw.trim().toLowerCase().replace(/[^a-z ]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (!h) return null;
  if (/^(first|given)( name)?$|^fname$/.test(h)) return 'first_name';
  if (/^(last|family|sur)( ?name)?$|^lname$/.test(h)) return 'last_name';
  if (/e ?mail/.test(h)) return 'email';
  if (/phone|mobile|cell|contact( no| number)?$|^number$|^tel|whatsapp/.test(h)) return 'phone';
  if (/zip|postal|pin ?code/.test(h)) return 'zip';
  if (/^city$|town|^location$/.test(h)) return 'city';
  if (/role|position|job( title)?$/.test(h)) return 'job_role';
  if (/source|channel|platform|^from$/.test(h)) return 'source';
  if (/name|candidate|applicant|driver/.test(h)) return 'full_name';
  return null;
}

/**
 * Turn a grid into upload rows. The first row with a name and a phone column is the header.
 * With no header, a column whose cells look like phone numbers is used as the phone and the
 * first text column as the name.
 */
export function gridToRows(grid: string[][]): { rows: UploadRow[]; missing: string[]; ignored: string[] } {
  const clean = grid.filter((r) => r.some((c) => String(c ?? '').trim() !== ''));
  if (!clean.length) return { rows: [], missing: ['Full Name', 'Phone'], ignored: [] };
  const headerIdx = clean.slice(0, 10).findIndex((r) => {
    const keys = r.map((c) => headerKey(String(c ?? '')));
    return keys.includes('phone') && (keys.includes('full_name') || keys.includes('first_name'));
  });
  if (headerIdx === -1) return guessColumns(clean);
  const head = clean[headerIdx] as string[];
  const keys = head.map((h) => headerKey(String(h ?? '')));
  // If two columns look like the name, use the first one.
  const firstIndex = (k: string) => keys.indexOf(k as never);
  const ignored = head.filter((_, i) => keys[i] === null || firstIndex(keys[i] as string) !== i).map(String);
  const rows = clean.slice(headerIdx + 1).map((cells) => {
    const get = (k: string) => {
      const i = firstIndex(k);
      return i >= 0 ? String(cells[i] ?? '').trim() : '';
    };
    const full = get('full_name') || [get('first_name'), get('last_name')].filter(Boolean).join(' ');
    const r: UploadRow = { full_name: full.replace(/\s+/g, ' '), phone: get('phone') };
    for (const k of ['email', 'city', 'zip', 'job_role', 'source'] as const) {
      const v = get(k);
      if (v) r[k] = v;
    }
    return r;
  });
  return { rows, missing: [], ignored };
}

function guessColumns(grid: string[][]): { rows: UploadRow[]; missing: string[]; ignored: string[] } {
  const width = Math.max(...grid.map((r) => r.length));
  const sample = grid.slice(0, 20);
  const looksPhone = (v: string) => /^\D*1?\D*\d{3}\D*\d{3}\D*\d{4}\D*$/.test(v.trim());
  const looksName = (v: string) => /^[A-Za-z][A-Za-z .'-]{1,80}$/.test(v.trim());
  let phoneCol = -1;
  let nameCol = -1;
  for (let i = 0; i < width; i += 1) {
    const vals = sample.map((r) => String(r[i] ?? ''));
    if (phoneCol < 0 && vals.filter(looksPhone).length >= Math.ceil(vals.length / 2)) phoneCol = i;
    else if (nameCol < 0 && vals.filter(looksName).length >= Math.ceil(vals.length / 2)) nameCol = i;
  }
  if (phoneCol < 0 || nameCol < 0) return { rows: [], missing: [...(nameCol < 0 ? ['Full Name'] : []), ...(phoneCol < 0 ? ['Phone'] : [])], ignored: [] };
  return {
    rows: grid.map((r) => ({ full_name: String(r[nameCol] ?? '').trim(), phone: String(r[phoneCol] ?? '').trim() })),
    missing: [],
    ignored: [],
  };
}

export const UPLOAD_TEMPLATE =
  'Full Name,Phone,Email,City,ZIP,Job Role,Source\r\n' +
  'Jane Example,(202) 555-0142,jane@example.com,Riverton,07000,Delivery Driver,Indeed\r\n' +
  'Sam Sample,202.555.0143,,Riverton,,,Facebook\r\n' +
  'Alex Demo,+1 202 555 0144,,,,,Walk-in\r\n';
