import { supabase } from './supabase';

/** Turn database and function errors into a sentence a recruiter can act on. */
export function friendlyError(err: unknown): string {
  const e = err as { message?: string; code?: string } | null;
  const msg = e?.message ?? '';
  if (e?.code === '42501' || /row-level security|permission denied/i.test(msg)) {
    return /cannot|only|not allowed/i.test(msg) && !/row-level/i.test(msg) ? msg : 'Your access level cannot do this.';
  }
  if (e?.code === '23505') return 'This already exists.';
  if (e?.code === '23514' || e?.code === 'P0001') return msg.replace(/^.*?ERROR:\s*/, '') || 'That change breaks a rule.';
  if (/Failed to fetch|NetworkError/i.test(msg)) return 'No connection. Check your internet and try again.';
  return msg || 'Something went wrong. Please try again.';
}

export async function rpc<T>(fn: string, args: Record<string, unknown> = {}): Promise<T> {
  const { data, error } = await supabase.rpc(fn, args);
  if (error) throw new Error(friendlyError(error));
  return data as T;
}

/** Call an Edge Function. Error bodies look like { error: { code, message } }. */
export async function callFunction<T>(name: string, body: Record<string, unknown>): Promise<T> {
  const { data, error } = await supabase.functions.invoke(name, { body });
  if (error) {
    const ctx = (error as { context?: Response }).context;
    let message = 'Something went wrong. Please try again.';
    if (ctx && typeof ctx.json === 'function') {
      const b = (await ctx.json().catch(() => null)) as { error?: { message?: string } } | null;
      if (b?.error?.message) message = b.error.message;
    }
    throw new Error(message);
  }
  return data as T;
}

export async function must<T>(p: PromiseLike<{ data: T | null; error: unknown }>, what = 'load this'): Promise<T> {
  const { data, error } = await p;
  if (error) throw new Error(`Could not ${what}. ${friendlyError(error)}`);
  return data as T;
}
