import { z } from 'zod';

/**
 * The ONLY values the browser may know. Anything starting with VITE_ is public:
 * never put a Twilio, AI, email, voice, encryption or service-role key here.
 */
const Env = z.object({
  VITE_SUPABASE_URL: z.string().url(),
  VITE_SUPABASE_ANON_KEY: z.string().min(20),
  VITE_SENTRY_DSN: z.string().url().optional().or(z.literal('')),
  VITE_APP_ENV: z.enum(['local', 'staging', 'production']).default('local'),
});

const parsed = Env.safeParse(import.meta.env);
if (!parsed.success) {
  throw new Error('Missing or invalid VITE_ environment variables. Copy .env.example to apps/web/.env.local.');
}

export const env = parsed.data;
