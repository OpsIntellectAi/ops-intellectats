import { describe, expect, it } from 'vitest';
import { detectDelimiter, gridToRows, headerKey, parseCsv } from './csv';
import { featureOn, FEATURES } from './features';
import { normalizePhone, phoneProblem } from './phone';
import { aiCallView, contactChip, lastMessageView, nextStep } from './rowview';
import { complianceCheck, condition, fillFacts, missingFacts, questionsFromGrid, STANDARD_RULES, STANDARD_SCRIPT } from './script';
import { isExpiredJwt } from './jwt';
import { callStats, filterCalls } from '@/features/calls/stats';
import type { AppRow, CallRow } from './types';

const NOW = new Date('2026-11-10T15:00:00Z').getTime();
const H = 3_600_000;
const iso = (msAgo: number) => new Date(NOW - msAgo).toISOString();
function row(p: Partial<AppRow> = {}): AppRow {
  return {
    id: 'a1', client_id: 'c1', candidate_id: 'k1', station_id: 's1', job_role_id: 'r1', stage: 'interview', owner_id: 'u1', source: 'Indeed',
    applied_at: iso(48 * H), stage_changed_at: iso(48 * H), not_interested_reason: null, not_interested_until: null, rejection_reason: null, booked_call_at: null,
    full_name: 'Jordan Miles', phone_e164: '+12025550101', email: null, city: null, zip: null, time_zone: null, opted_out_at: null, is_landline: false, lives_in_nyc: false,
    last_out_at: null, last_in_at: null, out_count: 0, in_count: 0, last_body: null, last_topics: null,
    ai_calls: 0, completed_ai_calls: 0, last_call_at: null, last_call_outcome: null, unreviewed_calls: 0, answers_to_review: 0,
    steps_total: 0, steps_done: 0, required_left: 0, last_step_change: null, said_yes_at: null, no_response_at: null, manual_call_needed: false, reschedule_requested_at: null, cadence_step: 0,
    last_direction: null, last_status: null, last_is_automatic: null, last_at: null, last_call_via: null, last_call_summary: null,
    ...p,
  };
}

describe('#3 phone numbers in any pattern', () => {
  it.each([
    ['7073330140', '+17073330140'],
    ['(707) 333-0140', '+17073330140'],
    ['707.333.0140', '+17073330140'],
    ['707 333 0140', '+17073330140'],
    ['707-333-0140', '+17073330140'],
    ['+1 707 333 0140', '+17073330140'],
    ['1-707-333-0140', '+17073330140'],
    [' 707/333/0140 ', '+17073330140'],
  ])('%s → %s', (input, out) => expect(normalizePhone(input)).toBe(out));
  it('rejects wrong lengths with a clear message', () => {
    expect(normalizePhone('70733301')).toBeNull();
    expect(phoneProblem('70733301')).toBe('Phone needs 10 digits (you typed 8)');
    expect(phoneProblem('')).toBe('Enter the mobile number');
    expect(phoneProblem('27073330140')).toContain('11');
  });
});

describe('#3 bulk upload accepts many file layouts', () => {
  it('understands loose header names', () => {
    expect(headerKey('Candidate Name')).toBe('full_name');
    expect(headerKey('Mobile No.')).toBe('phone');
    expect(headerKey('Cell #')).toBe('phone');
    expect(headerKey('Phone Number')).toBe('phone');
    expect(headerKey('E-mail')).toBe('email');
    expect(headerKey('First Name')).toBe('first_name');
    expect(headerKey('Last Name')).toBe('last_name');
    expect(headerKey('Zip Code')).toBe('zip');
  });
  it('joins first and last name', () => {
    const r = gridToRows([['First Name', 'Last Name', 'Mobile'], ['Ana', 'Ruiz', '707 333 0140']]);
    expect(r.rows[0]).toMatchObject({ full_name: 'Ana Ruiz', phone: '707 333 0140' });
  });
  it('finds the header even under a title row', () => {
    const r = gridToRows([['Applicants export Nov 10'], ['Name', 'Phone', 'Source'], ['Ana Ruiz', '(707) 333-0140', 'Indeed']]);
    expect(r.rows).toHaveLength(1);
    expect(r.rows[0]).toMatchObject({ full_name: 'Ana Ruiz', source: 'Indeed' });
  });
  it('works with no header at all (guesses the phone and name columns)', () => {
    const r = gridToRows([['Ana Ruiz', '707.333.0140'], ['Bo Lee', '7073330141']]);
    expect(r.missing).toEqual([]);
    expect(r.rows.map((x) => x.full_name)).toEqual(['Ana Ruiz', 'Bo Lee']);
  });
  it('reads semicolon and tab separated files', () => {
    expect(detectDelimiter('Name;Phone\nA;1')).toBe(';');
    expect(detectDelimiter('Name\tPhone\nA\t1')).toBe('\t');
    expect(parseCsv('Name;Phone\r\nAna Ruiz;707 333 0140')).toEqual([['Name', 'Phone'], ['Ana Ruiz', '707 333 0140']]);
  });
  it('says what is missing', () => {
    expect(gridToRows([['Email'], ['x@y.z']]).missing.length).toBeGreaterThan(0);
  });
});

describe('#2 one script for every client', () => {
  const facts = { client: 'Rider Logistics', role: 'Driver', pay: '$22.25 per hour', address: '1000 Richard Petty Way, Lebanon TN', trainingLocation: 'Nashville office', shift: '10 AM to 8:30 PM', schedule: '4 days incl. 1 weekend day', minAge: 21 };
  it('fills the DSP facts', () => {
    expect(fillFacts('[company] · [address] · [pay] · [training location] · [shift] · [schedule] · [min age]', facts)).toBe(
      'Rider Logistics · 1000 Richard Petty Way, Lebanon TN · $22.25 per hour · Nashville office · 10 AM to 8:30 PM · 4 days incl. 1 weekend day · 21',
    );
  });
  it('lists facts that are still empty', () => {
    expect(missingFacts(STANDARD_SCRIPT, STANDARD_RULES, { ...facts, trainingLocation: null })).toEqual(['training location']);
  });
  it('the standard script passes the compliance check (no must-fix items)', () => {
    const bad = complianceCheck(STANDARD_SCRIPT, STANDARD_RULES, { payText: facts.pay, minAge: 21, address: facts.address }).filter((i) => i.level === 'bad');
    expect(bad).toEqual([]);
  });
  it('“health insurance” and the background-check question are not flagged', () => {
    const issues = complianceCheck(
      [{ key: '13', type: 'yes_no', text: 'Benefits include health insurance. OK?', yes: 'y', no: 'n', cross: 'c' }, { key: '12', type: 'yes_no', text: 'A background check covers criminal record. Comfortable?', yes: 'y', no: 'n', cross: 'c' }],
      STANDARD_RULES,
      {},
    );
    expect(issues.filter((i) => i.level === 'bad')).toEqual([]);
    const asked = complianceCheck([{ key: 'x', type: 'yes_no', text: 'Have you ever been arrested?', yes: 'y', no: 'n', cross: 'c' }], STANDARD_RULES, {});
    expect(asked.some((i) => i.level === 'bad')).toBe(true);
  });
  it('follow-up keys', () => {
    expect(condition('18.yes.yes')).toEqual({ parent: '18.yes', answer: 'yes' });
    expect(condition('q3')).toBeNull();
  });
  it('imports the team sheet layout (id, path, question, type, dealbreaker)', () => {
    const grid = [
      ['id', 'path', 'question', 'type', 'dealbreaker'],
      ['995', '3', 'You must be at least 21 with a valid licence. Can you confirm?', 'yes/no', 'FALSE'],
      ['996', '3.no', 'Once you turn 21 you can re-apply and we will contact you.', 'yes/no', 'TRUE'],
      ['1012', '17', 'Are you currently employed?', 'yes/no', 'FALSE'],
      ['1013', '17.yes', 'Why are you looking for a job change?', 'subjective', 'FALSE'],
    ];
    const qs = questionsFromGrid(grid);
    expect(qs.map((q) => [q.key, q.type])).toEqual([['3', 'yes_no'], ['3.no', 'info'], ['17', 'yes_no'], ['17.yes', 'recorded']]);
    expect(qs[0]?.dealbreaker).toBe(true);
    expect(complianceCheck(qs, STANDARD_RULES, {}).filter((i) => i.level === 'bad')).toEqual([]);
  });
});

describe('#7 #11 candidate list cells', () => {
  it('last message: unread reply vs your delivered text', () => {
    const r1 = row({ last_body: 'Hi, can I move my call?', last_direction: 'inbound', last_at: iso(0.01 * H), in_count: 1, out_count: 1, last_in_at: iso(0.01 * H), last_out_at: iso(H) });
    expect(lastMessageView(r1, NOW)).toMatchObject({ label: 'Hi, can I move my call?', tone: 'info' });
    expect(lastMessageView(r1, NOW).sub.startsWith('Unread reply')).toBe(true);
    const r2 = row({ last_body: 'Hi Hector', last_direction: 'outbound', last_status: 'delivered', last_at: iso(20 * H), out_count: 1 });
    expect(lastMessageView(r2, NOW).label).toBe('You: Hi Hector');
    expect(lastMessageView(r2, NOW).sub.startsWith('Delivered')).toBe(true);
    expect(lastMessageView(row(), NOW).label).toBe('Never messaged');
  });
  it('AI call status', () => {
    expect(aiCallView(row({ booked_call_at: new Date(NOW + 2 * H).toISOString() }), null, 'America/New_York', NOW).label).toBe('Scheduled');
    expect(aiCallView(row({ last_call_at: iso(H), last_call_outcome: 'completed', last_call_via: 'ai' }), null, 'America/New_York', NOW).label).toBe('Completed');
    expect(aiCallView(row(), new Date(NOW + H).toISOString(), 'America/New_York', NOW).label).toBe('Queued');
    expect(aiCallView(row({ said_yes_at: iso(H) }), null, 'America/New_York', NOW).label).toBe('Said yes');
    expect(aiCallView(row({ out_count: 1, last_direction: 'outbound', last_status: 'delivered' }), null, 'America/New_York', NOW).label).toBe('Link sent');
    expect(aiCallView(row({ out_count: 1, last_direction: 'outbound', last_status: 'test_sent' }), null, 'America/New_York', NOW).label).toBe('Link sent');
    expect(aiCallView(row({ out_count: 1, last_direction: 'inbound', last_status: null }), null, 'America/New_York', NOW).label).toBe('Link sent');
    const blocked = aiCallView(row({ out_count: 1, last_direction: 'outbound', last_status: 'blocked_not_allowlisted' }), null, 'America/New_York', NOW);
    expect(blocked.label).toBe('Text not sent');
    expect(blocked.sub).toBe('Blocked · not a test phone');
    expect(aiCallView(row({ out_count: 1, last_direction: 'outbound', last_status: 'queued' }), null, 'America/New_York', NOW).sub).toBe('Waiting to send');
    expect(aiCallView(row({ out_count: 1 }), null, 'America/New_York', NOW).label).toBe('Link sent');
  });
  it('next step', () => {
    expect(nextStep(row({ out_count: 0 }), NOW).text).toBe('Send first text');
    expect(nextStep(row({ unreviewed_calls: 1, completed_ai_calls: 1, out_count: 1 }), NOW).text).toBe('Review interview');
    expect(nextStep(row({ out_count: 1, in_count: 1, last_out_at: iso(3 * H), last_in_at: iso(H), last_topics: ['reschedule'] }), NOW).text).toBe('Reply to message');
    expect(nextStep(row({ out_count: 1, completed_ai_calls: 1 }), NOW).text).toBe('Shortlist');
  });
  it('contact chips', () => {
    expect(contactChip(row({ out_count: 3, in_count: 0 }), 'no_reply_tries')).toBe(true);
    expect(contactChip(row({ out_count: 2 }), 'no_reply_tries')).toBe(false);
    expect(contactChip(row({ opted_out_at: iso(H), out_count: 0 }), 'never')).toBe(false);
    expect(contactChip(row({ in_count: 1 }), 'replied')).toBe(true);
  });
});

describe('#12 calls by day numbers', () => {
  const c = (p: Partial<CallRow>): CallRow => ({ id: Math.random().toString(), client_id: 'c', application_id: 'a', provider: 'vapi', direction: 'outbound', via: 'ai', outcome: 'completed', duration_seconds: 360, recording_path: null, script_version_id: null, attempt_number: 1, placed_by: null, started_at: iso(H), ended_at: null, created_at: iso(H), job_role_id: 'r', station_id: 's', owner_id: null, stage: 'interview', full_name: 'X', phone_e164: '+1', answers_to_review: 0, review_verdict: null, review_reason: null, summary: null, ...p });
  it('totals, directions, voicemail and average length of completed calls', () => {
    const list = [c({}), c({ duration_seconds: 420 }), c({ direction: 'inbound', via: 'csr', duration_seconds: 300 }), c({ outcome: 'voicemail', duration_seconds: 0 })];
    const s = callStats(list);
    expect([s.total, s.outgoing, s.incoming, s.completed, s.voicemail, s.avgSeconds]).toEqual([4, 3, 1, 3, 1, 360]);
    expect(filterCalls(list, 'all', 'csr')).toHaveLength(1);
    expect(filterCalls(list, 'outbound', 'ai')).toHaveLength(3);
  });
});

describe('#14 toggles', () => {
  it('missing means ON; only false turns off', () => {
    expect(featureOn({}, 'ai_calls')).toBe(true);
    expect(featureOn(undefined, 'ai_calls')).toBe(true);
    expect(featureOn({ ai_calls: false }, 'ai_calls')).toBe(false);
    expect(FEATURES.length).toBe(15);
    expect(new Set(FEATURES.map((f) => f.key)).size).toBe(15);
  });
});

describe('#3 signed-in session never shows "JWT expired"', () => {
  it('spots an expired token response', () => {
    expect(isExpiredJwt(401, '{"code":"PGRST301","message":"JWT expired"}')).toBe(true);
    expect(isExpiredJwt(401, '{"message":"Invalid JWT"}')).toBe(true);
    expect(isExpiredJwt(403, '{"message":"permission denied"}')).toBe(false);
    expect(isExpiredJwt(200, 'JWT expired')).toBe(false);
  });
});

describe('#2 the team question sheet (Driver-ai-questions.xlsx) imports cleanly', async () => {
  const grid = (await import('./fixtures/driver-questions.json')).default as string[][];
  const qs = questionsFromGrid(grid);
  it('keeps every row and its path', () => {
    expect(qs).toHaveLength(grid.length - 1);
    expect(qs.map((q) => q.key)).toContain('18.yes.yes');
  });
  it('turns ".no" statements into things the AI says, and marks dealbreakers on their parent', () => {
    expect(qs.find((q) => q.key === '3.no')?.type).toBe('info');
    expect(qs.find((q) => q.key === '3')?.dealbreaker).toBe(true);
    expect(qs.find((q) => q.key === '4')?.dealbreaker).toBe(true);
    expect(qs.find((q) => q.key === '15')?.type).toBe('recorded');
  });
  it('passes the compliance check with the standard rules', () => {
    const bad = complianceCheck(qs, STANDARD_RULES, { payText: '$22.25 per hour', minAge: 21 }).filter((i) => i.level === 'bad');
    expect(bad.map((b) => b.text)).toEqual([]);
  });
});

describe('times stay right when the computer clock is off', async () => {
  const { learnServerTime, serverNow } = await import('./clock');
  it('uses the server time when the PC is 9 minutes behind', () => {
    const local = Date.now();
    learnServerTime(new Date(local + 9 * 60_000).toUTCString(), local, local);
    expect(Math.round((serverNow() - Date.now()) / 60_000)).toBe(9);
    learnServerTime(new Date(local).toUTCString(), local, local);
    expect(Math.abs(serverNow() - Date.now())).toBeLessThan(1000);
  });
});
