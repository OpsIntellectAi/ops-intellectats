/** Super Admin feature toggles per client. A missing key means ON. Checked again on the server. */
export type FeatureKey =
  | 'auto_texts' | 'follow_ups' | 'booking_reminders' | 'ai_calls' | 'bulk_ai_calls' | 'phone_calls'
  | 'bulk_texts' | 'ai_overview' | 'ai_assistant' | 'alerts' | 'weekly_report' | 'self_service'
  | 'message_popups' | 'csv_export' | 'bulk_upload';

export const FEATURES: { key: FeatureKey; group: string; label: string; help: string }[] = [
  { key: 'auto_texts', group: 'Texts', label: 'Automatic texts', help: 'First text after applying, and texts when a stage or onboarding step changes.' },
  { key: 'follow_ups', group: 'Texts', label: 'No-reply follow-ups', help: 'Day 2 and Day 5 follow-up texts when the candidate has not replied.' },
  { key: 'booking_reminders', group: 'Texts', label: 'Booking reminders', help: 'Reminder texts before a booked AI call.' },
  { key: 'bulk_texts', group: 'Texts', label: 'Bulk texts', help: 'Text many selected candidates at once.' },
  { key: 'ai_calls', group: 'Calls', label: 'AI calls', help: 'AI phone interviews (button, booked calls and retries).' },
  { key: 'bulk_ai_calls', group: 'Calls', label: 'Bulk AI calls', help: 'Select many candidates and queue AI calls with one click.' },
  { key: 'phone_calls', group: 'Calls', label: 'Phone calls by the team', help: 'Twilio rings the recruiter, then the candidate.' },
  { key: 'ai_overview', group: 'AI', label: 'AI overview and insights', help: 'Overview of a text conversation and the AI insights page.' },
  { key: 'ai_assistant', group: 'AI', label: 'Ask the assistant', help: 'The assistant button at the bottom of every page.' },
  { key: 'alerts', group: 'Reports', label: 'Alerts', help: 'Alert texts and emails, and the alert box on My day.' },
  { key: 'weekly_report', group: 'Reports', label: 'Weekly client report', help: 'Monday email to the client contact.' },
  { key: 'self_service', group: 'Candidates', label: 'Candidate self-service page', help: 'The link candidates use to book their AI call and upload their licence.' },
  { key: 'message_popups', group: 'Candidates', label: 'New-message pop-ups', help: 'A pop-up with quick reply when a candidate texts back.' },
  { key: 'bulk_upload', group: 'Candidates', label: 'Bulk upload', help: 'Upload candidates from a CSV or Excel file.' },
  { key: 'csv_export', group: 'Candidates', label: 'CSV download', help: 'Download lists of candidates as CSV.' },
];

export function featureOn(features: Record<string, boolean> | null | undefined, key: FeatureKey): boolean {
  return features?.[key] !== false;
}
