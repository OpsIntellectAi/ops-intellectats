import { serverNow } from './clock';
const HOUR = 3_600_000;
const DAY = 24 * HOUR;

export function hoursSince(iso: string | null | undefined, now: number = Date.now()): number | null {
  if (!iso) return null;
  return (now - new Date(iso).getTime()) / HOUR;
}

export function daysSince(iso: string | null | undefined, now: number = Date.now()): number | null {
  if (!iso) return null;
  return (now - new Date(iso).getTime()) / DAY;
}

/** "just now", "5 min ago", "3 h ago", "2 days ago", "in 2 h". */
export function relative(iso: string | null | undefined, now: number = serverNow()): string {
  if (!iso) return '—';
  const diff = now - new Date(iso).getTime();
  const future = diff < 0;
  const abs = Math.abs(diff);
  let text: string;
  if (abs < 60_000) return future ? 'in a moment' : 'just now';
  if (abs < HOUR) text = `${Math.round(abs / 60_000)} min`;
  else if (abs < DAY) text = `${Math.round(abs / HOUR)} h`;
  else {
    const d = Math.round(abs / DAY);
    text = `${d} ${d === 1 ? 'day' : 'days'}`;
  }
  return future ? `in ${text}` : `${text} ago`;
}

/** Date + time in a given IANA zone, e.g. "Nov 10, 3:05 PM". */
export function dateTimeIn(iso: string | null | undefined, timeZone: string = 'America/New_York'): string {
  if (!iso) return '—';
  return new Intl.DateTimeFormat('en-US', { timeZone, month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(new Date(iso));
}

export function dateOnly(iso: string | null | undefined, timeZone: string = 'America/New_York'): string {
  if (!iso) return '—';
  return new Intl.DateTimeFormat('en-US', { timeZone, month: 'short', day: 'numeric', year: 'numeric' }).format(new Date(iso));
}

/** Local clock for a candidate, e.g. "9:14 AM CT". */
export function localClock(timeZone: string | null | undefined, now: Date = new Date()): string {
  const tz = timeZone || 'America/New_York';
  try {
    return new Intl.DateTimeFormat('en-US', { timeZone: tz, hour: 'numeric', minute: '2-digit', timeZoneName: 'short' }).format(now);
  } catch {
    return '';
  }
}

/** YYYY-MM-DD of an instant in a zone (for grouping by day). */
export function dayKey(iso: string, timeZone: string = 'America/New_York'): string {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(iso));
  return parts;
}

export function seconds(n: number | null | undefined): string {
  if (n == null) return '—';
  const m = Math.floor(n / 60);
  const s = n % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function addDays(date: Date, days: number): Date {
  return new Date(date.getTime() + days * DAY);
}
