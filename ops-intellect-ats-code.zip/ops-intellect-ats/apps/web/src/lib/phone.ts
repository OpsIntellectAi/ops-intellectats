/**
 * Phone numbers are accepted in any pattern: spaces, dashes, dots, brackets, "+1".
 * Only the digits count: 10 digits, or 11 starting with 1.
 */
export function phoneDigits(input: string): string {
  return input.replace(/\D/g, '');
}

export function normalizePhone(input: string): string | null {
  const d = phoneDigits(input);
  if (/^\d{10}$/.test(d)) return `+1${d}`;
  if (/^1\d{10}$/.test(d)) return `+${d}`;
  return null;
}

export function phoneProblem(input: string): string | null {
  const d = phoneDigits(input);
  if (!d) return 'Enter the mobile number';
  if (normalizePhone(input)) return null;
  return `Phone needs 10 digits (you typed ${d.length})`;
}
