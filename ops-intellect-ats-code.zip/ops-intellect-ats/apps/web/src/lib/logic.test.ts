import { describe, expect, it } from 'vitest';
import { gridToRows, parseCsv, toCsv } from './csv';
import { funnel, targetPace } from './dashboard';
import { buildQueues, contactMatch, nextActions, noReplyDays, teamBoard } from './queues';
import { findEmail, fillTemplate, hireCheck, shortlistCheck, visibleTemplates } from './rules';
import { complianceCheck, questionsFromGrid, type ScriptQuestion } from './script';
import type { AppRow, StepDef, StepRow, Template } from './types';

const NOW = new Date('2026-11-10T15:00:00Z').getTime();
const H = 3_600_000;
const iso = (msAgo: number) => new Date(NOW - msAgo).toISOString();

function row(p: Partial<AppRow> = {}): AppRow {
  return {
    id: 'a1', client_id: 'c1', candidate_id: 'k1', station_id: 's1', job_role_id: 'r1', stage: 'interview', owner_id: 'u1', source: 'Indeed',
    applied_at: iso(48 * H), stage_changed_at: iso(48 * H), not_interested_reason: null, not_interested_until: null, rejection_reason: null, booked_call_at: null,
    full_name: 'Jordan Miles', phone_e164: '+12025550101', email: null, city: null, zip: null, time_zone: null, opted_out_at: null, is_landline: false, lives_in_nyc: false,
    last_out_at: null, last_in_at: null, out_count: 0, in_count: 0, last_body: null, last_topics: null,
    ai_calls: 0, completed_ai_calls: 0, last_call_at: null, last_call_outcome: null, unreviewed_calls: 0, answers_to_review: 0,
    steps_total: 0, steps_done: 0, required_left: 0, last_step_change: null, said_yes_at: null, no_response_at: null, manual_call_needed: false, reschedule_requested_at: null, cadence_step: 0,
    last_direction: null, last_status: null, last_is_automatic: null, last_at: null, last_call_via: null, last_call_summary: null,
    ...p,
  };
}

describe('work queues', () => {
  it('puts a YES reply in "said yes", not in "replies waiting"', () => {
    const r = row({ out_count: 1, in_count: 1, last_out_at: iso(3 * H), last_in_at: iso(1 * H), last_topics: ['said_yes'] });
    const q = buildQueues([r], NOW);
    expect(q.said_yes).toHaveLength(1);
    expect(q.replies_waiting).toHaveLength(0);
  });
  it('a reply that was already answered is not waiting', () => {
    const r = row({ out_count: 2, in_count: 1, last_in_at: iso(3 * H), last_out_at: iso(1 * H) });
    expect(buildQueues([r], NOW).replies_waiting).toHaveLength(0);
  });
  it('opted-out people never show up in contact queues', () => {
    const r = row({ opted_out_at: iso(H), in_count: 1, last_in_at: iso(H), last_topics: ['said_yes'] });
    const q = buildQueues([r], NOW);
    expect(q.said_yes).toHaveLength(0);
    expect(q.never_messaged).toHaveLength(0);
  });
  it('onboarding with no step change for 24 h is stuck', () => {
    expect(buildQueues([row({ stage: 'onboarding', last_step_change: iso(30 * H) })], NOW).onboarding_stuck).toHaveLength(1);
    expect(buildQueues([row({ stage: 'onboarding', last_step_change: iso(2 * H) })], NOW).onboarding_stuck).toHaveLength(0);
  });
  it('a booked call 30 min in the past without a call is missed', () => {
    expect(buildQueues([row({ booked_call_at: iso(0.5 * H) })], NOW).missed_booked).toHaveLength(1);
    expect(buildQueues([row({ booked_call_at: new Date(NOW + H).toISOString() })], NOW).missed_booked).toHaveLength(0);
  });
  it('My day gives at most 10 actions, only for the CSR, each person once', () => {
    const rows = Array.from({ length: 15 }, (_, i) => row({ id: `a${i}`, owner_id: i < 12 ? 'me' : 'other', answers_to_review: 1, unreviewed_calls: 1 }));
    const list = nextActions(rows, 'me', 10, NOW);
    expect(list).toHaveLength(10);
    expect(new Set(list.map((x) => x.row.id)).size).toBe(10);
    expect(list.every((x) => x.row.owner_id === 'me')).toBe(true);
  });
  it('team board counts per owner', () => {
    const b = teamBoard([row({ owner_id: 'x' }), row({ id: 'a2', owner_id: 'x', stage: 'hired', stage_changed_at: iso(24 * H) })], NOW);
    expect(b[0]).toMatchObject({ ownerId: 'x', open: 1, hired7d: 1 });
  });
  it('contact filters and no-reply days', () => {
    const silent = row({ out_count: 2, last_out_at: iso(4 * 24 * H) });
    expect(contactMatch(silent, 'no_reply_3', NOW)).toBe(true);
    expect(contactMatch(silent, 'never', NOW)).toBe(false);
    expect(noReplyDays(silent, NOW)).toBe(4);
    expect(noReplyDays(row(), NOW)).toBeNull();
  });
});

describe('stage rules', () => {
  it('shortlist needs a completed interview and nothing to review', () => {
    expect(shortlistCheck({ stage: 'interview', completed_ai_calls: 0, answers_to_review: 0 }).ready).toBe(false);
    expect(shortlistCheck({ stage: 'interview', completed_ai_calls: 1, answers_to_review: 1 }).reason).toMatch(/review/);
    expect(shortlistCheck({ stage: 'interview', completed_ai_calls: 1, answers_to_review: 0 }).ready).toBe(true);
  });
  it('mark hired only when every required step is done or waived', () => {
    const defs: StepDef[] = [
      { id: 'd1', key: 'licence', name: 'Licence', phase: 'P', owner_label: 'CSR', statuses: ['Not started', 'Verified', 'Waived'], done_statuses: ['Verified'], bad_statuses: [], guidance: {}, required: true, sort_order: 1 },
      { id: 'd2', key: 'wotc', name: 'WOTC', phase: 'P', owner_label: 'Ops', statuses: ['Not started', 'Completed'], done_statuses: ['Completed'], bad_statuses: [], guidance: {}, required: false, sort_order: 2 },
      { id: 'd3', key: 'i9', name: 'I-9', phase: 'P', owner_label: 'Ops', statuses: ['Not started', 'Verified', 'Waived'], done_statuses: ['Verified'], bad_statuses: [], guidance: {}, required: true, sort_order: 3 },
    ];
    const step = (def: string, status: string): StepRow => ({ id: def, application_id: 'a', step_def_id: def, status, note: null, waived_reason: null, changed_by: null, changed_at: '' });
    expect(hireCheck(defs, [step('d1', 'Verified'), step('d3', 'Not started')]).missing).toEqual(['I-9']);
    expect(hireCheck(defs, [step('d1', 'Verified'), step('d3', 'Waived')]).ready).toBe(true);
  });
  it('scheduling-link templates hide after Interview or a passed background check', () => {
    const t: Template[] = [
      { id: '1', name: 'Link', body: '', stages: ['interview', 'shortlisted'], is_scheduling_link: true },
      { id: '2', name: 'Email', body: '', stages: ['interview', 'shortlisted'], is_scheduling_link: false },
    ];
    expect(visibleTemplates(t, 'interview', false).map((x) => x.id)).toEqual(['1', '2']);
    expect(visibleTemplates(t, 'shortlisted', false).map((x) => x.id)).toEqual(['2']);
    expect(visibleTemplates(t, 'interview', true).map((x) => x.id)).toEqual(['2']);
  });
  it('fills placeholders and finds emails in replies', () => {
    expect(fillTemplate('Hi [first name], [role] at [client]', { firstName: 'Ana', role: 'Driver', client: 'Northline' })).toBe('Hi Ana, Driver at Northline');
    expect(findEmail('sure it is Ana.Diaz+1@Example.com thanks')).toBe('ana.diaz+1@example.com');
    expect(findEmail('no email here')).toBeNull();
  });
});

describe('csv', () => {
  it('parses quoted fields and CRLF', () => {
    expect(parseCsv('Full Name,Phone\r\n"Diaz, Ana","(202) 555-0101"\r\n\r\nBo "B" Lee,2025550102\n')).toEqual([
      ['Full Name', 'Phone'],
      ['Diaz, Ana', '(202) 555-0101'],
      ['Bo "B" Lee', '2025550102'],
    ]);
  });
  it('maps headers and reports missing required columns', () => {
    expect(gridToRows([['Name', 'Mobile', 'Job Role'], ['A B', '1', 'Walker']]).rows[0]).toMatchObject({ full_name: 'A B', phone: '1', job_role: 'Walker' });
    expect(gridToRows([['Email'], ['x@y.z']]).missing).toContain('Phone');
  });
  it('blocks spreadsheet formula injection in exports', () => {
    expect(toCsv([{ a: '=HYPERLINK("x")' }])).toBe('a\r\n"\'=HYPERLINK(""x"")"');
  });
});

describe('dashboard', () => {
  it('funnel counts people who reached each stage', () => {
    const f = funnel([row({ stage: 'interview' }), row({ stage: 'onboarding' }), row({ stage: 'hired' })]);
    expect(f.map((m) => m.value)).toEqual([3, 2, 2, 2, 1]);
  });
  it('target pace', () => {
    const p = targetPace({ hires: 10, from_date: '2026-11-01', by_date: '2026-11-20' }, 2, new Date('2026-11-10T12:00:00Z').getTime());
    expect(p.expected).toBeGreaterThan(4);
    expect(p.behindBy).toBeGreaterThan(2);
  });
});

describe('script compliance', () => {
  const good: ScriptQuestion[] = [{ key: 'q1', type: 'yes_no', text: 'Are you 21 or older?', yes: 'Yes', no: 'No', cross: 'Yes or no?', dealbreaker: true }];
  const rules = [
    'Say you are an AI assistant calling for the company',
    'Say the call is recorded',
    'Ask if now is a safe time to talk',
    'Offer a human recruiter if asked',
    'Never ask about origin, religion, family, health',
    'End politely on a dealbreaker',
  ];
  it('a complete script passes', () => {
    expect(complianceCheck(good, rules, { minAge: 21 })).toEqual([]);
  });
  it('flags missing disclosures with a fix', () => {
    const issues = complianceCheck(good, [], { minAge: 21 });
    expect(issues.filter((i) => i.level === 'bad').map((i) => i.id)).toEqual(expect.arrayContaining(['rule-ai', 'rule-recorded', 'rule-safe']));
    expect(issues.find((i) => i.id === 'rule-ai')?.fix?.rule).toMatch(/AI assistant/);
  });
  it('flags protected topics and mismatched age/pay', () => {
    const bad: ScriptQuestion[] = [
      { key: 'q1', type: 'yes_no', text: 'Are you a US citizen?', yes: 'y', no: 'n', cross: 'c' },
      { key: 'q2', type: 'yes_no', text: 'Are you 18 or older?', yes: 'y', no: 'n', cross: 'c' },
      { key: 'q3', type: 'info', text: 'The pay is $25.00 per hour' },
    ];
    const ids = complianceCheck(bad, rules, { minAge: 21, payText: '$20.00 / hr' }).map((i) => i.id);
    expect(ids).toEqual(expect.arrayContaining(['prot-q1-citizen', 'age-q2', 'pay-q3']));
  });
  it('imports questions from a grid', () => {
    const qs = questionsFromGrid([['Key', 'Type', 'Question', 'Yes means', 'No means', 'Cross-question', 'Dealbreaker'], ['q1', 'yes_no', 'Valid licence?', 'has one', 'none', 'Yes or no?', 'yes'], ['', 'recorded', 'When can you start?', '', '', '', '']]);
    expect(qs).toHaveLength(2);
    expect(qs[0]).toMatchObject({ key: 'q1', dealbreaker: true });
    expect(qs[1]).toMatchObject({ key: 'q2', type: 'recorded' });
  });
});
