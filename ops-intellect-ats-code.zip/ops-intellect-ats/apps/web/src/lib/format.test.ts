import { describe, expect, it } from 'vitest';
import { easternClock, filterClients, formatPhone, initials } from './format';
import { accessGate, can, needsMfa, type MyAccess } from './roles';
import { getDeviceKey } from './device';

describe('format', () => {
  it('formats US numbers and leaves others alone', () => {
    expect(formatPhone('+12025550123')).toBe('(202) 555-0123');
    expect(formatPhone('+442071234567')).toBe('+442071234567');
  });

  it('makes initials', () => {
    expect(initials('Maya Sterling')).toBe('MS');
    expect(initials('Cher')).toBe('C');
    expect(initials('  ')).toBe('?');
  });

  it('shows Eastern time', () => {
    expect(easternClock(new Date('2026-11-10T17:05:00Z'))).toBe('Tue, Nov 10, 12:05 PM ET');
  });

  it('searches clients by name, station code or station name', () => {
    const list = [
      { id: '1', name: 'Northline Delivery', stations: [{ code: 'NL1', name: 'Riverton Hub' }] },
      { id: '2', name: 'Bluepeak Logistics', stations: [{ code: 'BP1', name: 'Eastgate Hub' }] },
    ];
    expect(filterClients(list, 'north').map((c) => c.id)).toEqual(['1']);
    expect(filterClients(list, 'bp1').map((c) => c.id)).toEqual(['2']);
    expect(filterClients(list, 'eastgate').map((c) => c.id)).toEqual(['2']);
    expect(filterClients(list, '').length).toBe(2);
    expect(filterClients(list, 'zzz').length).toBe(0);
  });
});

const base: MyAccess = {
  user_id: 'u', full_name: 'Test', email: 't@example.com', role: 'csr', status: 'active',
  session_ok: true, mfa_required: false, mfa_ok: true, effective_role: 'csr', permissions: ['view'],
};

describe('access gate', () => {
  it('sends each person to the right screen', () => {
    expect(accessGate(base)).toBe('ok');
    expect(accessGate(null)).toBe('no_access');
    expect(accessGate({ ...base, status: 'pending', effective_role: null })).toBe('pending');
    expect(accessGate({ ...base, status: 'disabled', effective_role: null })).toBe('disabled');
    expect(accessGate({ ...base, session_ok: false, effective_role: null })).toBe('expired');
    expect(accessGate({ ...base, role: 'admin', mfa_required: true, mfa_ok: false, effective_role: null })).toBe('mfa');
  });

  it('MFA is required for Admin and Super Admin only', () => {
    expect(needsMfa('admin')).toBe(true);
    expect(needsMfa('super_admin')).toBe(true);
    expect(needsMfa('supervisor')).toBe(false);
  });

  it('permission hints follow the server list', () => {
    expect(can(base, 'view')).toBe(true);
    expect(can(base, 'platform.admin')).toBe(false);
    expect(can(null, 'view')).toBe(false);
  });
});

describe('device key', () => {
  it('creates one id and keeps it', () => {
    const store = new Map<string, string>();
    const s = { getItem: (k: string) => store.get(k) ?? null, setItem: (k: string, v: string) => void store.set(k, v) };
    const a = getDeviceKey(s);
    expect(a).toMatch(/^[0-9a-f-]{36}$/);
    expect(getDeviceKey(s)).toBe(a);
  });

  it('replaces a tampered value', () => {
    const s = { getItem: () => 'not-a-uuid', setItem: () => undefined };
    expect(getDeviceKey(s)).toMatch(/^[0-9a-f-]{36}$/);
  });
});
