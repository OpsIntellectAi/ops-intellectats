/**
 * The work queues on Today and My day, computed from rows the person can already see.
 * Pure functions so they are unit-tested.
 */
import type { AppRow } from './types';
import { daysSince, hoursSince } from './time';

export type QueueKey =
  | 'said_yes'
  | 'shared_email'
  | 'replies_waiting'
  | 'answers_to_review'
  | 'calls_to_review'
  | 'calls_to_retry'
  | 'shortlisted_no_next'
  | 'onboarding_stuck'
  | 'missed_booked'
  | 'never_messaged';

export interface QueueDef {
  key: QueueKey;
  label: string;
  hint: string;
  action: string;
  test: (r: AppRow, now: number) => boolean;
}

const active = (r: AppRow) => !r.opted_out_at && r.stage !== 'rejected' && r.stage !== 'not_interested' && r.stage !== 'hired';
const repliedLast = (r: AppRow) => Boolean(r.last_in_at && (!r.last_out_at || r.last_in_at > r.last_out_at));

export const QUEUES: QueueDef[] = [
  {
    key: 'said_yes',
    label: 'Said yes to an AI call',
    hint: 'Replied YES to “Free for an AI call?”',
    action: 'Start AI call',
    test: (r) => active(r) && r.stage === 'interview' && repliedLast(r) && Boolean(r.last_topics?.includes('said_yes')),
  },
  {
    key: 'shared_email',
    label: 'Shared their email',
    hint: 'Ready for the DSP portal invite',
    action: 'Send DSP invite',
    test: (r) => active(r) && (r.stage === 'shortlisted' || r.stage === 'pre_onboarding') && Boolean(r.last_topics?.includes('shared_email') || r.email),
  },
  {
    key: 'replies_waiting',
    label: 'Replies waiting',
    hint: 'They texted last; nobody answered yet',
    action: 'Reply',
    test: (r) => active(r) && repliedLast(r) && !r.last_topics?.includes('said_yes') && !r.last_topics?.includes('shared_email'),
  },
  {
    key: 'answers_to_review',
    label: 'Answers to review',
    hint: 'The AI was not sure; a person decides',
    action: 'Review answer',
    test: (r) => r.answers_to_review > 0,
  },
  {
    key: 'calls_to_review',
    label: 'AI calls to review',
    hint: 'Every finished AI call is checked within 24 h',
    action: 'Review call',
    test: (r) => r.unreviewed_calls > 0,
  },
  {
    key: 'calls_to_retry',
    label: 'Calls to retry',
    hint: 'No answer, busy, dropped or voicemail',
    action: 'Retry call',
    test: (r) => active(r) && r.stage === 'interview' && ['no_answer', 'busy', 'dropped', 'failed', 'voicemail'].includes(r.last_call_outcome ?? ''),
  },
  {
    key: 'shortlisted_no_next',
    label: 'Shortlisted, no next step',
    hint: 'Shortlisted over 24 h ago with no email yet',
    action: 'Ask for email',
    test: (r, now) => active(r) && r.stage === 'shortlisted' && !r.email && (hoursSince(r.stage_changed_at, now) ?? 0) > 24,
  },
  {
    key: 'onboarding_stuck',
    label: 'Onboarding stuck over 24 h',
    hint: 'No onboarding step changed in a day',
    action: 'Open steps',
    test: (r, now) => r.stage === 'onboarding' && (hoursSince(r.last_step_change ?? r.stage_changed_at, now) ?? 0) > 24,
  },
  {
    key: 'missed_booked',
    label: 'Missed booked calls',
    hint: 'Booked time passed with no completed call',
    action: 'Call now',
    test: (r, now) =>
      active(r) && Boolean(r.booked_call_at) && new Date(r.booked_call_at as string).getTime() < now - 15 * 60_000 &&
      (!r.last_call_at || r.last_call_at < (r.booked_call_at as string)),
  },
  {
    key: 'never_messaged',
    label: 'Never messaged',
    hint: 'No text sent yet',
    action: 'Send first text',
    test: (r) => active(r) && r.stage === 'interview' && r.out_count === 0,
  },
];

export function buildQueues(rows: AppRow[], now: number = Date.now()): Record<QueueKey, AppRow[]> {
  const out = Object.fromEntries(QUEUES.map((q) => [q.key, [] as AppRow[]])) as Record<QueueKey, AppRow[]>;
  for (const r of rows) for (const q of QUEUES) if (q.test(r, now)) out[q.key].push(r);
  return out;
}

export interface NextAction {
  row: AppRow;
  queue: QueueDef;
}

/** CSR "My day": the next 10 actions, most urgent queue first, oldest first inside a queue. */
export function nextActions(rows: AppRow[], ownerId: string | null, limit = 10, now: number = Date.now()): NextAction[] {
  const mine = ownerId ? rows.filter((r) => r.owner_id === ownerId) : rows;
  const q = buildQueues(mine, now);
  const out: NextAction[] = [];
  const seen = new Set<string>();
  for (const def of QUEUES) {
    const list = [...q[def.key]].sort((a, b) => (a.last_in_at ?? a.stage_changed_at).localeCompare(b.last_in_at ?? b.stage_changed_at));
    for (const row of list) {
      if (seen.has(row.id)) continue;
      seen.add(row.id);
      out.push({ row, queue: def });
      if (out.length >= limit) return out;
    }
  }
  return out;
}

export interface BoardLine {
  ownerId: string | null;
  open: number;
  overdue: number;
  notReviewed: number;
  callsToday: number;
  hired7d: number;
}

/** Supervisor+ team board: one line per owner. */
export function teamBoard(rows: AppRow[], now: number = Date.now()): BoardLine[] {
  const by = new Map<string | null, BoardLine>();
  const today = new Date(now).toISOString().slice(0, 10);
  for (const r of rows) {
    const line = by.get(r.owner_id) ?? { ownerId: r.owner_id, open: 0, overdue: 0, notReviewed: 0, callsToday: 0, hired7d: 0 };
    const isOpen = r.stage !== 'hired' && r.stage !== 'rejected' && r.stage !== 'not_interested';
    if (isOpen) line.open += 1;
    if (isOpen && repliedLast(r) && (hoursSince(r.last_in_at, now) ?? 0) > 4) line.overdue += 1;
    line.notReviewed += r.unreviewed_calls + r.answers_to_review;
    if (r.last_call_at && r.last_call_at.slice(0, 10) === today) line.callsToday += 1;
    if (r.stage === 'hired' && (daysSince(r.stage_changed_at, now) ?? 99) <= 7) line.hired7d += 1;
    by.set(r.owner_id, line);
  }
  return [...by.values()].sort((a, b) => b.open - a.open);
}

export type ContactFilter = 'all' | 'never' | 'no_reply_3' | 'replied' | 'opted_out';

export function contactMatch(r: AppRow, f: ContactFilter, now: number = Date.now()): boolean {
  switch (f) {
    case 'all':
      return true;
    case 'never':
      return r.out_count === 0;
    case 'no_reply_3':
      return r.out_count > 0 && !repliedLast(r) && (daysSince(r.last_out_at, now) ?? 0) >= 3;
    case 'replied':
      return r.in_count > 0;
    case 'opted_out':
      return Boolean(r.opted_out_at);
  }
}

/** Days with no reply: since the last outbound text when they have not answered it. */
export function noReplyDays(r: AppRow, now: number = Date.now()): number | null {
  if (r.out_count === 0 || repliedLast(r)) return null;
  const d = daysSince(r.last_out_at, now);
  return d === null ? null : Math.floor(d);
}
