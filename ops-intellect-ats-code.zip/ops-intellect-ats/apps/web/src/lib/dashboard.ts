/** Dashboard numbers, computed from rows the person can see. Every number keeps its list of people. */
import { STAGE_LABEL, type Stage } from './format';
import type { AppRow, CallRow } from './types';
import { dayKey } from './time';

export interface Metric {
  label: string;
  value: number;
  rows: AppRow[];
}

export function inPeriod(iso: string | null, from: number, to: number): boolean {
  if (!iso) return false;
  const t = new Date(iso).getTime();
  return t >= from && t < to;
}

const REACHED: Record<Stage, Stage[]> = {
  interview: ['interview', 'shortlisted', 'pre_onboarding', 'onboarding', 'hired', 'rejected', 'not_interested'],
  shortlisted: ['shortlisted', 'pre_onboarding', 'onboarding', 'hired'],
  pre_onboarding: ['pre_onboarding', 'onboarding', 'hired'],
  onboarding: ['onboarding', 'hired'],
  hired: ['hired'],
  not_interested: ['not_interested'],
  rejected: ['rejected'],
};

/** Hiring funnel: how many applicants (applied in the period) reached each stage. */
export function funnel(rows: AppRow[]): Metric[] {
  const steps: Stage[] = ['interview', 'shortlisted', 'pre_onboarding', 'onboarding', 'hired'];
  return steps.map((s) => {
    const list = rows.filter((r) => REACHED[s].includes(r.stage) || (s === 'interview'));
    return { label: s === 'interview' ? 'Applied' : STAGE_LABEL[s], value: list.length, rows: list };
  });
}

export function kpis(rows: AppRow[], from: number, to: number): Metric[] {
  const applied = rows.filter((r) => inPeriod(r.applied_at, from, to));
  const interviewed = rows.filter((r) => r.completed_ai_calls > 0 && inPeriod(r.last_call_at, from, to));
  const shortlisted = rows.filter((r) => ['shortlisted', 'pre_onboarding', 'onboarding', 'hired'].includes(r.stage) && inPeriod(r.stage_changed_at, from, to));
  const hired = rows.filter((r) => r.stage === 'hired' && inPeriod(r.stage_changed_at, from, to));
  const onboarding = rows.filter((r) => r.stage === 'onboarding');
  const replied = rows.filter((r) => inPeriod(r.last_in_at, from, to));
  return [
    { label: 'New applicants', value: applied.length, rows: applied },
    { label: 'AI interviews done', value: interviewed.length, rows: interviewed },
    { label: 'Shortlisted', value: shortlisted.length, rows: shortlisted },
    { label: 'In onboarding now', value: onboarding.length, rows: onboarding },
    { label: 'Hired', value: hired.length, rows: hired },
    { label: 'Replied', value: replied.length, rows: replied },
  ];
}

export function contactHealth(rows: AppRow[], now: number = Date.now()): Metric[] {
  const never = rows.filter((r) => r.out_count === 0 && !r.opted_out_at);
  const replied = rows.filter((r) => r.in_count > 0 && !r.opted_out_at);
  const silent = rows.filter((r) => r.out_count > 0 && r.in_count === 0 && !r.opted_out_at && r.last_out_at && now - new Date(r.last_out_at).getTime() > 3 * 86_400_000);
  const opted = rows.filter((r) => r.opted_out_at);
  return [
    { label: 'Never messaged', value: never.length, rows: never },
    { label: 'Replied', value: replied.length, rows: replied },
    { label: 'No reply 3+ days', value: silent.length, rows: silent },
    { label: 'Opted out', value: opted.length, rows: opted },
  ];
}

export function bySource(rows: AppRow[]): Metric[] {
  const m = new Map<string, AppRow[]>();
  for (const r of rows) m.set(r.source, [...(m.get(r.source) ?? []), r]);
  return [...m.entries()].map(([label, list]) => ({ label, value: list.length, rows: list })).sort((a, b) => b.value - a.value);
}

/** Average days candidates have been sitting in their current stage. */
export function daysInStage(rows: AppRow[], now: number = Date.now()): { stage: Stage; avg: number; rows: AppRow[] }[] {
  const stages: Stage[] = ['interview', 'shortlisted', 'pre_onboarding', 'onboarding'];
  return stages.map((s) => {
    const list = rows.filter((r) => r.stage === s);
    const avg = list.length ? list.reduce((a, r) => a + (now - new Date(r.stage_changed_at).getTime()) / 86_400_000, 0) / list.length : 0;
    return { stage: s, avg: Math.round(avg * 10) / 10, rows: list };
  });
}

export function callsPerDay(calls: CallRow[], days: number, timeZone: string, now: number = Date.now()): { day: string; ai: number; csr: number }[] {
  const out: { day: string; ai: number; csr: number }[] = [];
  for (let i = days - 1; i >= 0; i -= 1) {
    out.push({ day: dayKey(new Date(now - i * 86_400_000).toISOString(), timeZone), ai: 0, csr: 0 });
  }
  const idx = new Map(out.map((d, i) => [d.day, i]));
  for (const c of calls) {
    const k = dayKey(c.started_at ?? c.created_at, timeZone);
    const i = idx.get(k);
    if (i === undefined) continue;
    const slot = out[i];
    if (!slot) continue;
    if (c.via === 'ai') slot.ai += 1;
    else slot.csr += 1;
  }
  return out;
}

export function callOutcomes(calls: CallRow[]): { label: string; value: number }[] {
  const m = new Map<string, number>();
  for (const c of calls) m.set(c.outcome, (m.get(c.outcome) ?? 0) + 1);
  return [...m.entries()].map(([label, value]) => ({ label: label.replace('_', ' '), value })).sort((a, b) => b.value - a.value);
}

/** On-pace line for a hiring target: hires expected by today if hiring evenly. */
export function targetPace(target: { hires: number; from_date: string; by_date: string }, hiredSoFar: number, now: number = Date.now()): { expected: number; behindBy: number; pct: number } {
  const from = new Date(`${target.from_date}T00:00:00Z`).getTime();
  const to = new Date(`${target.by_date}T23:59:59Z`).getTime();
  const share = Math.min(1, Math.max(0, (now - from) / (to - from)));
  const expected = Math.round(target.hires * share * 10) / 10;
  return { expected, behindBy: Math.max(0, Math.round((expected - hiredSoFar) * 10) / 10), pct: Math.min(100, Math.round((hiredSoFar / target.hires) * 100)) };
}
