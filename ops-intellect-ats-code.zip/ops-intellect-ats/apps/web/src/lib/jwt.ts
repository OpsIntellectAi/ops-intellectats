/** A response that means "your sign-in token expired" (PostgREST / Edge Functions). */
export function isExpiredJwt(status: number, body: string): boolean {
  return (status === 401 || status === 403) && /jwt expired|invalid jwt|token is expired|PGRST301|PGRST303/i.test(body);
}
