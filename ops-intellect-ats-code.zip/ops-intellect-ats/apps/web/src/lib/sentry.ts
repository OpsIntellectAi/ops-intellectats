import * as Sentry from '@sentry/react';
import { env } from './env';

/** Error monitoring. No candidate data is sent: we drop request bodies and user emails. */
export function initSentry(): void {
  if (!env.VITE_SENTRY_DSN) return;
  Sentry.init({
    dsn: env.VITE_SENTRY_DSN,
    environment: env.VITE_APP_ENV,
    sendDefaultPii: false,
    tracesSampleRate: 0.1,
    beforeSend(event) {
      if (event.request) {
        delete event.request.data;
        delete event.request.cookies;
      }
      if (event.user) event.user = { id: event.user.id };
      return event;
    },
  });
}
