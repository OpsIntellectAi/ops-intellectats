/**
 * Business rules shown in the screens (the database and Edge Functions enforce the
 * same rules; these copies decide what to enable and what to explain).
 */
import type { Stage } from './format';
import type { AppRow, StepDef, StepRow, Template } from './types';

/** Fill [first name], [role], [client], [link], [time] placeholders. */
export function fillTemplate(body: string, v: { firstName?: string; role?: string; client?: string; link?: string; time?: string }): string {
  return body
    .replace(/\[first name\]/gi, v.firstName ?? 'there')
    .replace(/\[role\]/gi, v.role ?? 'this')
    .replace(/\[client\]/gi, v.client ?? 'us')
    .replace(/\[link\]/gi, v.link ?? '[link]')
    .replace(/\[time\]/gi, v.time ?? '[time]');
}

/**
 * Templates show only for the stages chosen. Scheduling-link templates hide once the
 * candidate is past Interview or their background check has passed.
 */
export function visibleTemplates(all: Template[], stage: Stage, backgroundPassed: boolean): Template[] {
  return all.filter((t) => {
    if (!t.stages.includes(stage)) return false;
    if (t.is_scheduling_link && (stage !== 'interview' || backgroundPassed)) return false;
    return true;
  });
}

export type StepTone = 'ok' | 'bad' | 'warn' | 'neutral';

export function stepTone(def: StepDef, status: string): StepTone {
  if (def.done_statuses.includes(status) || status === 'Waived') return 'ok';
  if (def.bad_statuses.includes(status)) return 'bad';
  if (status === 'Not started') return 'neutral';
  return 'warn';
}

export interface HireCheck {
  ready: boolean;
  missing: string[];
}

/** "Mark hired" is enabled only when every required step is done or waived. */
export function hireCheck(defs: StepDef[], steps: StepRow[]): HireCheck {
  const byDef = new Map(steps.map((s) => [s.step_def_id, s]));
  const missing = defs
    .filter((d) => d.required)
    .filter((d) => {
      const s = byDef.get(d.id);
      return !s || !(d.done_statuses.includes(s.status) || s.status === 'Waived');
    })
    .sort((a, b) => a.sort_order - b.sort_order)
    .map((d) => d.name);
  return { ready: missing.length === 0, missing };
}

export interface ShortlistCheck {
  ready: boolean;
  reason: string | null;
}

/** Shortlist needs a completed AI interview and nothing waiting for review. */
export function shortlistCheck(r: Pick<AppRow, 'stage' | 'completed_ai_calls' | 'answers_to_review'>): ShortlistCheck {
  if (r.stage !== 'interview') return { ready: false, reason: 'Only candidates in Interview can be shortlisted.' };
  if (r.completed_ai_calls === 0) return { ready: false, reason: 'Needs a completed AI interview first.' };
  if (r.answers_to_review > 0) return { ready: false, reason: 'An answer still needs review.' };
  return { ready: true, reason: null };
}

export const NOT_INTERESTED_WAIT: { label: string; days: number | null }[] = [
  { label: '2 weeks', days: 14 },
  { label: '30 days', days: 30 },
  { label: '60 days', days: 60 },
  { label: 'Never', days: null },
];

export const STAGE_ORDER: Stage[] = ['interview', 'shortlisted', 'pre_onboarding', 'onboarding', 'hired'];

/** Detect an email address in a text reply. */
export function findEmail(text: string): string | null {
  const m = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i.exec(text);
  return m ? m[0].toLowerCase() : null;
}
