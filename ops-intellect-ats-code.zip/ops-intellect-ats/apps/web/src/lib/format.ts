/** "+12025550123" → "(202) 555-0123". Leaves anything else as it is. */
export function formatPhone(e164: string): string {
  const m = /^\+1(\d{3})(\d{3})(\d{4})$/.exec(e164);
  return m ? `(${m[1]}) ${m[2]}-${m[3]}` : e164;
}

/** Initials for an avatar: "Maya Sterling" → "MS". */
export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  const first = parts[0]?.[0] ?? '';
  const last = parts.length > 1 ? (parts[parts.length - 1]?.[0] ?? '') : '';
  return (first + last).toUpperCase() || '?';
}

/** The team works an EST shift from India, so the header shows US Eastern time. */
export function easternClock(d: Date = new Date()): string {
  return new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/New_York',
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(d) + ' ET';
}

export interface ClientSummary {
  id: string;
  name: string;
  stations: { code: string; name: string }[];
}

/** Client picker search: name, station code or station name; case-insensitive. */
export function filterClients(list: ClientSummary[], query: string): ClientSummary[] {
  const q = query.trim().toLowerCase();
  if (!q) return list;
  return list.filter(
    (c) =>
      c.name.toLowerCase().includes(q) ||
      c.stations.some((s) => s.code.toLowerCase().includes(q) || s.name.toLowerCase().includes(q)),
  );
}

export const STAGE_LABEL = {
  interview: 'Interview',
  shortlisted: 'Shortlisted',
  pre_onboarding: 'Pre-onboarding',
  onboarding: 'Onboarding',
  hired: 'Hired',
  not_interested: 'Not interested',
  rejected: 'Rejected',
} as const;

export type Stage = keyof typeof STAGE_LABEL;
