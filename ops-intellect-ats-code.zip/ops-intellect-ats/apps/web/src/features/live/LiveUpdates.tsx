import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui';
import { useToast } from '@/components/kit';
import { callFunction } from '@/lib/api';
import { initials } from '@/lib/format';
import { supabase } from '@/lib/supabase';
import { dateTimeIn, relative } from '@/lib/time';
import type { AppRow } from '@/lib/types';
import { useRows, useWorkspace } from '@/features/shell/context';
import { useSendText } from '@/features/messages/data';

interface Incoming {
  id: string;
  applicationId: string;
  body: string;
  at: string;
}

/**
 * Keeps every screen live: new texts, delivery updates and call results arrive through
 * Supabase Realtime (Row Level Security still decides who sees what). A new reply from a
 * candidate also opens a small pop-up with quick reply, AI call and Open chat.
 */
export function LiveUpdates() {
  const w = useWorkspace();
  const qc = useQueryClient();
  const [popups, setPopups] = useState<Incoming[]>([]);
  const popupsOn = w.on('message_popups');
  const timer = useRef<number | null>(null);
  const toast = useToast();
  const send = useSendText();
  const quickReply = (applicationId: string, text: string, first: string) => {
    toast(`Sending to ${first}…`);
    send.mutate(
      { ids: [applicationId], body: text, confirmBulk: false },
      {
        onSuccess: (r) =>
          toast(
            r.queued ? (r.sentNow ? 'Reply sent.' : 'Reply saved: it goes out at 8 AM their time (quiet hours) or when Twilio is set up.') : `Not sent: ${r.skipped[0]?.reason ?? 'skipped'}`,
            r.queued ? 'ok' : 'bad',
          ),
        onError: (e) => toast(e instanceof Error ? e.message : 'Could not send.', 'bad'),
      },
    );
  };

  useEffect(() => {
    const refreshRows = () => {
      // Many events can arrive together (bulk sends): refresh the lists once.
      if (timer.current) window.clearTimeout(timer.current);
      timer.current = window.setTimeout(() => {
        void qc.invalidateQueries({ queryKey: ['rows'] });
        void qc.invalidateQueries({ queryKey: ['calls'] });
      }, 600);
    };
    const channel = supabase
      .channel(`live-${w.client.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages', filter: `client_id=eq.${w.client.id}` }, (p) => {
        const row = (p.new ?? {}) as { id?: string; application_id?: string; direction?: string; body?: string; created_at?: string };
        if (row.application_id) void qc.invalidateQueries({ queryKey: ['msgs', row.application_id] });
        refreshRows();
        if (p.eventType === 'INSERT' && row.direction === 'inbound' && row.id && row.application_id) {
          const item = { id: row.id, applicationId: row.application_id, body: row.body ?? '', at: row.created_at ?? new Date().toISOString() };
          setPopups((l) => [item, ...l.filter((x) => x.applicationId !== item.applicationId)].slice(0, 3));
        }
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'calls', filter: `client_id=eq.${w.client.id}` }, (p) => {
        const row = (p.new ?? {}) as { id?: string; application_id?: string };
        if (row.application_id) void qc.invalidateQueries({ queryKey: ['app', row.application_id] });
        if (row.id) void qc.invalidateQueries({ queryKey: ['call', row.id] });
        refreshRows();
      })
      .subscribe();
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
      void supabase.removeChannel(channel);
    };
  }, [qc, w.client.id]);

  if (!popupsOn || !popups.length) return null;
  return (
    <div className="fixed bottom-20 right-4 z-40 flex w-[360px] max-w-[calc(100vw-2rem)] flex-col gap-3" aria-live="polite">
      {popups.map((p) => (
        <MessagePopup key={p.id} item={p} onSend={quickReply} onClose={() => setPopups((l) => l.filter((x) => x.id !== p.id))} />
      ))}
    </div>
  );
}

export function popupOverview(r: AppRow | undefined, tz: string): string {
  if (!r) return '';
  const parts: string[] = [];
  if (r.booked_call_at) parts.push(`Booked an AI call for ${dateTimeIn(r.booked_call_at, r.time_zone || tz)}.`);
  else if (r.last_call_at && r.last_call_outcome) parts.push(`Last call ${relative(r.last_call_at)}: ${r.last_call_outcome.replace('_', ' ')}.`);
  else if (r.said_yes_at) parts.push('Said YES to an AI call.');
  else if (r.out_count) parts.push(`${r.out_count} text${r.out_count === 1 ? '' : 's'} sent.`);
  if (r.reschedule_requested_at) parts.push('Wants a new call time.');
  return parts.join(' ');
}

function MessagePopup({ item, onClose, onSend }: { item: Incoming; onClose: () => void; onSend: (id: string, text: string, first: string) => void }) {
  const w = useWorkspace();
  const toast = useToast();
  const rowsQ = useRows();
  const row = rowsQ.data?.find((r) => r.id === item.applicationId);
  const [reply, setReply] = useState('');
  const ai = useMutation({
    mutationFn: () => callFunction<{ test: boolean }>('start-ai-call', { applicationId: item.applicationId }),
    onSuccess: (r) => {
      toast(r.test ? 'Test mode: a practice AI call was logged (no real call).' : 'AI call started.');
      onClose();
    },
    onError: (e) => toast(e instanceof Error ? e.message : 'Could not start the call.', 'bad'),
  });
  useEffect(() => {
    const t = window.setTimeout(onClose, 120_000);
    return () => window.clearTimeout(t);
  }, [onClose]);
  const name = row?.full_name ?? 'Candidate';
  return (
    <div role="dialog" aria-label={`New message from ${name}`} className="overflow-hidden rounded-2xl border border-line bg-white shadow-2xl">
      <div className="h-1 bg-info" />
      <div className="flex flex-col gap-3 p-4">
        <div className="flex items-start gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-soft text-sm font-bold text-brand">{initials(name)}</span>
          <div className="flex min-w-0 flex-1 flex-col">
            <span className="text-xs font-semibold text-info">New message · {relative(item.at)}</span>
            <span className="truncate text-[15px] font-bold">{name}</span>
            <span className="text-xs text-muted">{w.client.name} · {w.role?.name ?? ''}</span>
          </div>
          <button type="button" aria-label="Close" className="flex h-8 w-8 items-center justify-center rounded-lg text-muted hover:bg-black/5" onClick={onClose}>✕</button>
        </div>
        <div className="rounded-xl bg-canvas px-3 py-2 text-sm">{item.body}</div>
        {row ? <p className="text-xs text-muted"><b className="text-[#5B3F99]">Overview</b> · {popupOverview(row, w.tz)} Last reply: “{item.body.slice(0, 80)}”</p> : null}
        {w.can('messages.send') ? (
          <textarea
            aria-label="Quick reply"
            value={reply}
            maxLength={640}
            onChange={(e) => setReply(e.target.value)}
            placeholder="Quick reply…"
            className="min-h-[60px] rounded-xl border border-line px-3 py-2 text-sm outline-none focus:border-brand"
          />
        ) : null}
        <div className="flex flex-wrap items-center gap-2">
          {w.can('candidates.act') && w.on('ai_calls') ? (
            <Button className="min-h-[36px]" disabled={ai.isPending} onClick={() => ai.mutate()}>{ai.isPending ? 'Calling…' : 'AI call'}</Button>
          ) : null}
          <Button variant="ghost" className="min-h-[36px] text-brand" onClick={() => { w.openApp(item.applicationId); onClose(); }}>Open chat</Button>
          {w.can('messages.send') ? (
            <Button
              variant="primary"
              className="ml-auto min-h-[36px]"
              disabled={reply.trim().length < 2}
              onClick={() => {
                // Close at once; the text shows in the chat straight away and a toast confirms.
                onSend(item.applicationId, reply.trim(), name.split(' ')[0] ?? '');
                onClose();
              }}
            >
              Send
            </Button>
          ) : null}
        </div>
      </div>
    </div>
  );
}
