import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { Bar, Checkbox, PageHeader, SectionTitle, Select, Stat, useToast } from '@/components/kit';
import { Banner, Button, Card, Field, Spinner } from '@/components/ui';
import { friendlyError, must, rpc } from '@/lib/api';
import { supabase } from '@/lib/supabase';
import { dateTimeIn } from '@/lib/time';
import { useWorkspace } from '@/features/shell/context';

interface Rule { id: string; rule_key: string; label: string; threshold: number; channel: 'text' | 'email' | 'text_email'; enabled: boolean }
interface LogRow { id: string; message: string; sent_to: string; channel: string; is_test: boolean; created_at: string }
interface Target { id: string; job_role_id: string; hires: number; from_date: string; by_date: string }
interface Review { call_id: string; verdict: 'looks_right' | 'flagged'; reason: string | null; question_key: string | null; reviewer_id: string; created_at: string }

/** Keeps only plain formatting tags from the server-built report preview. */
export function safeHtml(html: string): string {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  doc.querySelectorAll('script,style,iframe,object,embed,link,meta,form,img').forEach((n) => n.remove());
  doc.querySelectorAll('*').forEach((el) => {
    for (const a of [...el.attributes]) if (!['align', 'cellpadding', 'style'].includes(a.name)) el.removeAttribute(a.name);
  });
  return doc.body.innerHTML;
}

export function ReportsPage() {
  const w = useWorkspace();
  return (
    <div className="flex flex-col gap-4">
      <PageHeader eyebrow={w.client.name} title="Reports & alerts" />
      <Alerts />
      <Targets />
      <WeeklyReport />
      <ReviewQuality />
    </div>
  );
}

function Alerts() {
  const w = useWorkspace();
  const toast = useToast();
  const qc = useQueryClient();
  const manage = w.can('reports.manage');
  const rules = useQuery({
    queryKey: ['alert-rules', w.client.id],
    queryFn: async () => (await must(supabase.from('alert_rules').select('id, rule_key, label, threshold, channel, enabled').eq('client_id', w.client.id).order('rule_key'), 'load alert rules')) as Rule[],
  });
  const log = useQuery({
    queryKey: ['alert-log', w.client.id],
    queryFn: async () => (await must(supabase.from('alert_log').select('id, message, sent_to, channel, is_test, created_at').eq('client_id', w.client.id).order('created_at', { ascending: false }).limit(40), 'load the alert log')) as LogRow[],
  });
  const save = useMutation({
    mutationFn: async (r: Rule) => {
      const { error } = await supabase.from('alert_rules').update({ threshold: r.threshold, channel: r.channel, enabled: r.enabled }).eq('id', r.id).select('id');
      if (error) throw new Error(friendlyError(error));
    },
    onSuccess: () => { toast('Alert saved.'); void qc.invalidateQueries({ queryKey: ['alert-rules'] }); },
    onError: (e) => toast(e instanceof Error ? e.message : 'Could not save.', 'bad'),
  });
  const test = useMutation({
    mutationFn: (id: string) => rpc<string>('test_alert', { p_rule: id }),
    onSuccess: (m) => { toast(m); void qc.invalidateQueries({ queryKey: ['alert-log'] }); },
    onError: (e) => toast(e instanceof Error ? e.message : 'Could not test.', 'bad'),
  });
  return (
    <Card className="flex flex-col gap-3 p-5">
      <SectionTitle>Alerts on the numbers</SectionTitle>
      <span className="text-sm text-muted">Checked every 15 minutes. Sent to this client's Supervisors by text and/or email, at most once every 6 hours per alert.</span>
      {rules.isLoading ? <Spinner /> : null}
      {(rules.data ?? []).map((r) => <RuleRow key={r.id} rule={r} editable={manage} onSave={(x) => save.mutate(x)} onTest={() => test.mutate(r.id)} />)}
      <SectionTitle>Alert log</SectionTitle>
      {(log.data ?? []).length ? (
        <div className="flex flex-col divide-y divide-line text-sm">
          {(log.data ?? []).map((l) => (
            <div key={l.id} className="flex flex-wrap justify-between gap-2 py-2">
              <span>{l.is_test ? '🧪 ' : ''}{l.message}</span>
              <span className="text-xs text-muted">{l.channel.replace('_', ' + ')} → {l.sent_to} · {dateTimeIn(l.created_at, 'America/New_York')} ET</span>
            </div>
          ))}
        </div>
      ) : <span className="text-sm text-muted">No alerts yet.</span>}
    </Card>
  );
}

function RuleRow({ rule, editable, onSave, onTest }: { rule: Rule; editable: boolean; onSave: (r: Rule) => void; onTest: () => void }) {
  const [r, setR] = useState(rule);
  const changed = r.threshold !== rule.threshold || r.channel !== rule.channel || r.enabled !== rule.enabled;
  return (
    <div className="flex flex-wrap items-end gap-3 rounded-lg bg-canvas p-3">
      <div className="min-w-[220px] flex-1 text-sm font-medium">{rule.label}</div>
      <Field label="Threshold" type="number" min={0} className="w-24" value={r.threshold} disabled={!editable} onChange={(e) => setR({ ...r, threshold: Number(e.target.value) })} />
      <Select label="Send by" value={r.channel} disabled={!editable} onChange={(e) => setR({ ...r, channel: e.target.value as Rule['channel'] })}>
        <option value="text">Text</option>
        <option value="email">Email</option>
        <option value="text_email">Text + email</option>
      </Select>
      <Checkbox label="On" checked={r.enabled} disabled={!editable} onChange={(v) => setR({ ...r, enabled: v })} />
      {editable ? <Button className="min-h-[40px]" disabled={!changed} onClick={() => onSave(r)}>Save</Button> : null}
      {editable ? <Button variant="ghost" className="min-h-[40px]" onClick={onTest}>Test send</Button> : null}
    </div>
  );
}

function Targets() {
  const w = useWorkspace();
  const toast = useToast();
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ['targets', w.client.id],
    queryFn: async () => (await must(supabase.from('hiring_targets').select('id, job_role_id, hires, from_date, by_date').eq('client_id', w.client.id), 'load targets')) as Target[],
  });
  const t = (q.data ?? []).find((x) => x.job_role_id === w.role?.id);
  const hired = useQuery({
    queryKey: ['target-hired', w.client.id, w.role?.id, t?.from_date],
    enabled: Boolean(t),
    queryFn: async () => {
      const { count } = await supabase.from('applications').select('id', { count: 'exact', head: true })
        .eq('client_id', w.client.id).eq('job_role_id', w.role?.id ?? '').eq('stage', 'hired').gte('stage_changed_at', t?.from_date ?? '');
      return count ?? 0;
    },
  });
  const [form, setForm] = useState({ hires: 10, from: new Date().toISOString().slice(0, 10), by: new Date(Date.now() + 30 * 86_400_000).toISOString().slice(0, 10) });
  const save = useMutation({
    mutationFn: async () => {
      const row = { client_id: w.client.id, job_role_id: w.role?.id, hires: form.hires, from_date: form.from, by_date: form.by };
      const { error } = await supabase.from('hiring_targets').upsert(row, { onConflict: 'client_id,job_role_id' }).select('id');
      if (error) throw new Error(friendlyError(error));
    },
    onSuccess: () => { toast('Target saved.'); void qc.invalidateQueries({ queryKey: ['targets'] }); },
    onError: (e) => toast(e instanceof Error ? e.message : 'Could not save.', 'bad'),
  });
  if (!w.role) return null;
  const pace = t ? Math.round(t.hires * Math.min(1, Math.max(0, (Date.now() - new Date(t.from_date).getTime()) / (new Date(t.by_date).getTime() - new Date(t.from_date).getTime() || 1)))) : 0;
  return (
    <Card className="flex flex-col gap-3 p-5">
      <SectionTitle>Hiring target · {w.role.name}</SectionTitle>
      {t ? (
        <div className="flex flex-col gap-2">
          <span className="text-sm">{hired.data ?? 0} hired of {t.hires} by {t.by_date} · on pace: {pace} {((hired.data ?? 0) < pace - 1) ? <b className="text-warn">(behind)</b> : null}</span>
          <Bar value={hired.data ?? 0} max={t.hires} />
        </div>
      ) : <span className="text-sm text-muted">No target for this job role.</span>}
      {w.can('reports.manage') ? (
        <div className="flex flex-wrap items-end gap-3">
          <Field label="Hires" type="number" min={1} className="w-24" value={form.hires} onChange={(e) => setForm({ ...form, hires: Number(e.target.value) })} />
          <Field label="From" type="date" value={form.from} onChange={(e) => setForm({ ...form, from: e.target.value })} />
          <Field label="By" type="date" value={form.by} onChange={(e) => setForm({ ...form, by: e.target.value })} />
          <Button className="min-h-[40px]" disabled={form.hires < 1 || form.by <= form.from || save.isPending} onClick={() => save.mutate()}>{t ? 'Update target' : 'Set target'}</Button>
        </div>
      ) : null}
    </Card>
  );
}

function WeeklyReport() {
  const w = useWorkspace();
  const [show, setShow] = useState(false);
  const q = useQuery({
    queryKey: ['weekly-preview', w.client.id],
    enabled: show,
    queryFn: () => rpc<{ to: string | null; subject: string; html: string }>('weekly_report_preview', { p_client: w.client.id }),
  });
  return (
    <Card className="flex flex-col gap-3 p-5">
      <SectionTitle right={<Button className="min-h-[40px]" onClick={() => setShow((s) => !s)}>{show ? 'Hide preview' : 'Preview this week'}</Button>}>
        Weekly client report
      </SectionTitle>
      <span className="text-sm text-muted">Emailed every Monday at 8:00 AM ET to the client contact. KPIs, pipeline, target, top drop-off question and next week's plan. No candidate names.</span>
      {show && q.isLoading ? <Spinner /> : null}
      {show && q.data ? (
        <div className="flex flex-col gap-2 rounded-lg border border-line p-4">
          <span className="text-xs text-muted">To: {q.data.to ?? <b className="text-bad">no contact email in Client setup</b>} · Subject: {q.data.subject}</span>
          <div className="text-sm [&_h2]:text-xl [&_h3]:mt-2 [&_h3]:font-bold" dangerouslySetInnerHTML={{ __html: safeHtml(q.data.html) }} />
        </div>
      ) : null}
      {show && q.error ? <Banner tone="bad">{q.error instanceof Error ? q.error.message : 'Could not load.'}</Banner> : null}
    </Card>
  );
}

function ReviewQuality() {
  const w = useWorkspace();
  const q = useQuery({
    queryKey: ['reviews', w.client.id],
    queryFn: async () => (await must(supabase.from('call_reviews').select('call_id, verdict, reason, question_key, reviewer_id, created_at').eq('client_id', w.client.id).order('created_at', { ascending: false }).limit(2000), 'load reviews')) as Review[],
  });
  const s = useMemo(() => {
    const list = q.data ?? [];
    const flagged = list.filter((r) => r.verdict === 'flagged');
    const count = (xs: (string | null)[]) => [...xs.reduce((m, x) => (x ? m.set(x, (m.get(x) ?? 0) + 1) : m), new Map<string, number>())].sort((a, b) => b[1] - a[1]);
    const byReviewer = [...list.reduce((m, r) => {
      const e = m.get(r.reviewer_id) ?? { n: 0, f: 0 };
      e.n++; if (r.verdict === 'flagged') e.f++;
      return m.set(r.reviewer_id, e);
    }, new Map<string, { n: number; f: number }>())];
    return { total: list.length, flagged: flagged.length, reasons: count(flagged.map((r) => r.reason)), questions: count(flagged.map((r) => r.question_key)), byReviewer };
  }, [q.data]);
  const name = (id: string) => w.team.find((t) => t.user_id === id)?.full_name ?? 'Someone';
  return (
    <Card className="flex flex-col gap-3 p-5">
      <SectionTitle>Review quality</SectionTitle>
      <div className="flex flex-wrap gap-3">
        <Stat label="AI calls reviewed" value={s.total} />
        <Stat label="Flagged as a problem" value={s.flagged} tone={s.flagged ? 'warn' : 'neutral'} sub={s.total ? `${Math.round((100 * s.flagged) / s.total)}%` : undefined} />
      </div>
      {s.reasons.length ? <span className="text-sm">Top flag reasons: {s.reasons.slice(0, 4).map(([k, n]) => `${k} (${n})`).join(' · ')}</span> : null}
      {s.questions[0] ? (
        <Banner tone="warn">Fix the script: question <b>{s.questions[0][0]}</b> is flagged most often ({s.questions[0][1]}×). Open Client setup → AI script and make it clearer.</Banner>
      ) : null}
      {s.byReviewer.length ? (
        <div className="flex flex-col gap-1 text-sm">
          {s.byReviewer.map(([id, v]) => <span key={id}>{name(id)}: {v.n} reviewed, {v.f} flagged</span>)}
        </div>
      ) : <span className="text-sm text-muted">No reviews yet.</span>}
    </Card>
  );
}
