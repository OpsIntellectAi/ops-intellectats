import { useEffect, useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { Banner, Button, Card, CenterPage, Field, Logo, Spinner } from '@/components/ui';
import { supabase } from '@/lib/supabase';
import { useSession } from './session';

/** Same rules as Supabase Auth: 12+ characters with lower, upper, digit and symbol. */
export function passwordProblem(p: string): string | null {
  if (p.length < 12) return 'Use at least 12 characters.';
  if (!/[a-z]/.test(p) || !/[A-Z]/.test(p)) return 'Use upper- and lower-case letters.';
  if (!/\d/.test(p)) return 'Add a number.';
  if (!/[^A-Za-z0-9]/.test(p)) return 'Add a symbol.';
  return null;
}

function SetPassword() {
  const navigate = useNavigate();
  const [p1, setP1] = useState('');
  const [p2, setP2] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const problem = passwordProblem(p1);
  const submit = async () => {
    setBusy(true);
    setErr(null);
    const { error } = await supabase.auth.updateUser({ password: p1 });
    setBusy(false);
    if (error) setErr(error.message);
    else navigate('/', { replace: true });
  };
  return (
    <CenterPage>
      <Card className="flex w-full max-w-[420px] flex-col gap-4 p-8">
        <Logo />
        <h1 className="font-serif text-3xl">Choose your password</h1>
        <p className="text-sm text-muted">Welcome to Ops Intellect. Pick a password you do not use anywhere else.</p>
        <Field label="New password" type="password" autoComplete="new-password" value={p1} onChange={(e) => setP1(e.target.value)} error={p1 && problem ? problem : undefined} />
        <Field label="Type it again" type="password" autoComplete="new-password" value={p2} onChange={(e) => setP2(e.target.value)} error={p2 && p1 !== p2 ? 'The two passwords are different.' : undefined} />
        {err ? <Banner tone="bad">{err}</Banner> : null}
        <Button variant="primary" disabled={Boolean(problem) || p1 !== p2 || busy} onClick={() => void submit()}>Save password</Button>
      </Card>
    </CenterPage>
  );
}

/** Google sends people back here; supabase-js swaps the one-time code for a session. */
export function AuthCallbackPage() {
  const { session, loading } = useSession();
  const [slow, setSlow] = useState(false);

  useEffect(() => {
    const t = window.setTimeout(() => setSlow(true), 8000);
    return () => window.clearTimeout(t);
  }, []);

  const params = new URLSearchParams(window.location.search);
  if (session && params.get('invited') === '1') return <SetPassword />;
  if (session) return <Navigate to="/" replace />;
  const failed = params.get('error_description');

  return (
    <CenterPage>
      <Card className="flex w-full max-w-[420px] flex-col gap-4 p-8">
        {failed ? (
          <Banner tone="bad">
            {/Signups not allowed/i.test(failed)
              ? 'This Google account has no Ops Intellect access. Ask your Admin to invite you.'
              : 'Google sign-in did not finish. Please try again.'}
          </Banner>
        ) : loading || !slow ? (
          <Spinner label="Signing you in…" />
        ) : (
          <Banner tone="warn">This is taking longer than usual. Go back and try again.</Banner>
        )}
        <a className="text-sm font-semibold text-brand underline" href="/sign-in">
          Back to sign in
        </a>
      </Card>
    </CenterPage>
  );
}
