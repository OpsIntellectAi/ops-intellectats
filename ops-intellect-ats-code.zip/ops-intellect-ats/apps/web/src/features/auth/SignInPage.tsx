import { zodResolver } from '@hookform/resolvers/zod';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Navigate, useNavigate } from 'react-router-dom';
import { z } from 'zod';
import { Banner, Button, Card, CenterPage, Field, Logo } from '@/components/ui';
import { supabase } from '@/lib/supabase';
import { useSession } from './session';

const Schema = z.object({
  email: z.string().trim().toLowerCase().email('Enter a valid email'),
  password: z.string().min(1, 'Enter your password'),
});
type Values = z.infer<typeof Schema>;

export function SignInPage() {
  const { session, blockedMessage } = useSession();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const { register, handleSubmit, formState } = useForm<Values>({ resolver: zodResolver(Schema) });

  if (session) return <Navigate to="/" replace />;

  const onEmail = handleSubmit(async (v) => {
    setBusy(true);
    setError(null);
    const { error: e } = await supabase.auth.signInWithPassword({ email: v.email, password: v.password });
    setBusy(false);
    if (e) {
      setError(e.status === 429 ? 'Too many attempts. Wait a few minutes and try again.' : 'Email or password is not right.');
      return;
    }
    navigate('/', { replace: true });
  });

  const onGoogle = async () => {
    setError(null);
    const { error: e } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${window.location.origin}/auth/callback` },
    });
    if (e) setError('Google sign-in is not available right now.');
  };

  return (
    <CenterPage>
      <Card className="flex w-full max-w-[420px] flex-col gap-5 p-8">
        <Logo />
        <div className="flex flex-col gap-1">
          <h1 className="font-serif text-4xl leading-tight">Sign in</h1>
          <p className="text-sm text-muted">Each person signs in with their own account. You only see the clients you were given.</p>
        </div>
        {blockedMessage ? <Banner tone="bad">{blockedMessage}</Banner> : null}
        {error ? <Banner tone="bad">{error}</Banner> : null}
        <Button onClick={onGoogle} className="w-full">
          <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
            <path fill="#4285F4" d="M45 24.5c0-1.6-.1-2.8-.4-4H24v7.6h11.9c-.5 3-2.3 5.6-5.1 7.3l7.9 6.1C43.2 37.4 45 31.4 45 24.5z" />
            <path fill="#34A853" d="M24 46c6.2 0 11.4-2 15.2-5.6l-7.9-6.1c-2.1 1.4-4.8 2.3-7.3 2.3-5.9 0-10.9-4-12.7-9.4l-8.1 6.3C7 40.8 14.8 46 24 46z" />
            <path fill="#FBBC05" d="M11.3 27.2c-.5-1.4-.7-2.8-.7-4.2s.3-2.9.7-4.2l-8.1-6.3C1.8 15.4 1 19.1 1 23s.8 7.6 2.2 10.5l8.1-6.3z" />
            <path fill="#EA4335" d="M24 9.4c3.4 0 6.4 1.2 8.8 3.4l6.6-6.6C35.4 2.5 30.2 0 24 0 14.8 0 7 5.2 3.2 12.5l8.1 6.3C13.1 13.4 18.1 9.4 24 9.4z" />
          </svg>
          Continue with Google
        </Button>
        <div className="flex items-center gap-3 text-xs text-muted">
          <span className="h-px flex-1 bg-line" />
          or with email
          <span className="h-px flex-1 bg-line" />
        </div>
        <form onSubmit={onEmail} className="flex flex-col gap-3" noValidate>
          <Field label="Work email" type="email" autoComplete="username" {...register('email')} error={formState.errors.email?.message} />
          <Field label="Password" type="password" autoComplete="current-password" {...register('password')} error={formState.errors.password?.message} />
          <Button type="submit" variant="primary" disabled={busy} className="w-full">
            {busy ? 'Signing in…' : 'Sign in'}
          </Button>
        </form>
        <p className="text-center text-xs text-muted">No account? Ask your Admin to invite you. There is no self sign-up.</p>
      </Card>
    </CenterPage>
  );
}
