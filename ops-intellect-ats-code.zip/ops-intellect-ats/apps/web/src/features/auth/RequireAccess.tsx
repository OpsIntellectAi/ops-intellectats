import { useEffect, type ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { Banner, Button, Card, CenterPage, Logo, Spinner } from '@/components/ui';
import { accessGate, type MyAccess } from '@/lib/roles';
import { supabase } from '@/lib/supabase';
import { useMyAccess, useSession } from './session';

const MESSAGES = {
  pending: 'Your account is waiting for a Super Admin to give you access. You will see your clients here once that is done.',
  disabled: 'Your account is turned off. Ask your Admin.',
  expired: 'You have been signed in for 12 hours. For safety, please sign in again.',
  no_access: 'You do not have access yet. Ask your Admin.',
} as const;

/** Signed in + active + (MFA when needed) + session younger than 12 hours. */
export function RequireAccess({ children }: { children: (access: MyAccess) => ReactNode }) {
  const { session, loading } = useSession();
  const accessQ = useMyAccess(Boolean(session));
  const gate = accessQ.data !== undefined ? accessGate(accessQ.data) : null;

  useEffect(() => {
    if (gate === 'expired') void supabase.auth.signOut();
  }, [gate]);

  if (loading) return <CenterPage><Spinner /></CenterPage>;
  if (!session) return <Navigate to="/sign-in" replace />;
  if (accessQ.isLoading || gate === null) {
    if (accessQ.isError) return <StatusCard message="Could not load your access. Check your connection and refresh." />;
    return <CenterPage><Spinner /></CenterPage>;
  }
  if (gate === 'mfa') return <Navigate to="/mfa" replace />;
  if (gate !== 'ok' || !accessQ.data) return <StatusCard message={MESSAGES[gate === 'ok' ? 'no_access' : gate]} />;
  return <>{children(accessQ.data)}</>;
}

function StatusCard({ message }: { message: string }) {
  return (
    <CenterPage>
      <Card className="flex w-full max-w-[440px] flex-col gap-4 p-8">
        <Logo />
        <Banner tone="info">{message}</Banner>
        <Button onClick={() => void supabase.auth.signOut()}>Sign out</Button>
      </Card>
    </CenterPage>
  );
}
