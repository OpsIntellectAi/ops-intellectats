import type { Session } from '@supabase/supabase-js';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { getDeviceKey } from '@/lib/device';
import type { MyAccess } from '@/lib/roles';
import { supabase } from '@/lib/supabase';

interface SessionState {
  session: Session | null;
  loading: boolean;
  blockedMessage: string | null;
}

const Ctx = createContext<SessionState>({ session: null, loading: true, blockedMessage: null });

/**
 * Tracks the Supabase session and, once per sign-in, tells the server which computer
 * this is (record-sign-in). A blocked computer is signed out straight away.
 */
export function SessionProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<SessionState>({ session: null, loading: true, blockedMessage: null });
  const qc = useQueryClient();

  useEffect(() => {
    let active = true;
    void supabase.auth.getSession().then(({ data }) => {
      if (active) setState((s) => ({ ...s, session: data.session, loading: false }));
    });
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      setState((s) => ({ ...s, session, loading: false }));
      // The page load itself (INITIAL_SESSION) and a routine token refresh do not change
      // access; re-asking then cancelled the first request and cost a round trip.
      if (event !== 'INITIAL_SESSION' && event !== 'TOKEN_REFRESHED') void qc.invalidateQueries({ queryKey: ['my_access'] });
      if (event === 'SIGNED_IN' && session) {
        void recordSignIn(session.user.id).then((blocked) => {
          if (blocked) {
            setState((s) => ({ ...s, blockedMessage: blocked }));
            void supabase.auth.signOut();
          }
        });
      }
      if (event === 'SIGNED_OUT') qc.clear();
    });
    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, [qc]);

  return <Ctx.Provider value={state}>{children}</Ctx.Provider>;
}

export function useSession(): SessionState {
  return useContext(Ctx);
}

/** Returns a message when this computer is blocked, otherwise null. */
async function recordSignIn(userId: string): Promise<string | null> {
  const flag = `oi.recorded.${userId}`;
  try {
    if (sessionStorage.getItem(flag)) return null;
  } catch {
    /* private mode: just record again */
  }
  const deviceKey = getDeviceKey();
  const { error } = await supabase.functions.invoke('record-sign-in', {
    body: { deviceKey },
    headers: { 'x-device-id': deviceKey },
  });
  if (error) {
    const ctx = (error as { context?: Response }).context;
    if (ctx && ctx.status === 403) {
      const body = (await ctx.json().catch(() => null)) as { error?: { code?: string; message?: string } } | null;
      if (body?.error?.code === 'device_blocked') return body.error.message ?? 'This computer is blocked.';
    }
    return null; // Recording failed for another reason; the server still enforces access.
  }
  try {
    sessionStorage.setItem(flag, '1');
  } catch {
    /* ignore */
  }
  return null;
}

/** The caller's level and permissions, straight from the database. */
export async function fetchMyAccess(): Promise<MyAccess | null> {
  const { data, error } = await supabase.rpc('my_access');
  if (error) throw new Error('Could not load your access level.');
  return (data as MyAccess | null) ?? null;
}

export function useMyAccess(enabled: boolean) {
  return useQuery({ queryKey: ['my_access'], enabled, staleTime: 60_000, queryFn: fetchMyAccess });
}
