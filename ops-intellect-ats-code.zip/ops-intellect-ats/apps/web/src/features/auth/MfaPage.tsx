import { useQueryClient } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { Banner, Button, Card, CenterPage, Field, Logo, Spinner } from '@/components/ui';
import { supabase } from '@/lib/supabase';
import { useSession } from './session';

type Mode =
  | { kind: 'loading' }
  | { kind: 'enroll'; factorId: string; qr: string; secret: string }
  | { kind: 'verify'; factorId: string };

/**
 * Two-step verification with an authenticator app (Google Authenticator, Microsoft
 * Authenticator, 1Password…). Required for Admin and Super Admin: the database gives them
 * no data until this session has passed it (aal2).
 */
export function MfaPage() {
  const { session } = useSession();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [mode, setMode] = useState<Mode>({ kind: 'loading' });
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!session) return;
    let cancelled = false;
    (async () => {
      const { data: aal } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
      if (aal?.currentLevel === 'aal2') {
        navigate('/', { replace: true });
        return;
      }
      const { data: factors, error: fErr } = await supabase.auth.mfa.listFactors();
      if (fErr) {
        if (!cancelled) setError('Could not load two-step verification. Refresh the page.');
        return;
      }
      const verified = factors.totp.find((f) => f.status === 'verified');
      if (verified) {
        if (!cancelled) setMode({ kind: 'verify', factorId: verified.id });
        return;
      }
      // Clear half-finished set-ups before starting a new one.
      for (const f of factors.all.filter((x) => x.status === 'unverified')) {
        await supabase.auth.mfa.unenroll({ factorId: f.id });
      }
      const { data: enr, error: eErr } = await supabase.auth.mfa.enroll({ factorType: 'totp', friendlyName: `Ops Intellect ${new Date().toISOString().slice(0, 10)}` });
      if (cancelled) return;
      if (eErr || !enr || enr.type !== 'totp') {
        setError('Could not start two-step verification set-up.');
        return;
      }
      setMode({ kind: 'enroll', factorId: enr.id, qr: enr.totp.qr_code, secret: enr.totp.secret });
    })();
    return () => {
      cancelled = true;
    };
  }, [session, navigate]);

  if (!session) return <Navigate to="/sign-in" replace />;

  const submit = async () => {
    if (mode.kind === 'loading') return;
    if (!/^\d{6}$/.test(code)) {
      setError('Enter the 6-digit code from your authenticator app.');
      return;
    }
    setBusy(true);
    setError(null);
    const { error: vErr } = await supabase.auth.mfa.challengeAndVerify({ factorId: mode.factorId, code });
    setBusy(false);
    if (vErr) {
      setError('That code did not work. Check the time on your phone and try the newest code.');
      return;
    }
    await qc.invalidateQueries({ queryKey: ['my_access'] });
    navigate('/', { replace: true });
  };

  return (
    <CenterPage>
      <Card className="flex w-full max-w-[460px] flex-col gap-5 p-8">
        <Logo />
        <div className="flex flex-col gap-1">
          <h1 className="font-serif text-4xl leading-tight">Two-step verification</h1>
          <p className="text-sm text-muted">Admin and Super Admin accounts need a code from an authenticator app every time they sign in.</p>
        </div>
        {error ? <Banner tone="bad">{error}</Banner> : null}
        {mode.kind === 'loading' ? <Spinner /> : null}
        {mode.kind === 'enroll' ? (
          <div className="flex flex-col items-center gap-3">
            <p className="self-start text-sm">1. Scan this with your authenticator app.</p>
            <img src={mode.qr} alt="QR code for your authenticator app" className="h-48 w-48 rounded-xl border border-line bg-white p-2" />
            <p className="self-start text-xs text-muted">
              Can’t scan? Type this key: <code className="break-all font-mono text-ink">{mode.secret}</code>
            </p>
            <p className="self-start text-sm">2. Enter the 6-digit code it shows.</p>
          </div>
        ) : null}
        {mode.kind !== 'loading' ? (
          <form
            className="flex flex-col gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              void submit();
            }}
          >
            <Field
              label="6-digit code"
              name="code"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
            />
            <Button type="submit" variant="primary" disabled={busy}>
              {busy ? 'Checking…' : 'Verify'}
            </Button>
          </form>
        ) : null}
        <Button variant="ghost" onClick={() => void supabase.auth.signOut()}>
          Sign out
        </Button>
      </Card>
    </CenterPage>
  );
}
