import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { useToast } from '@/components/kit';
import { Button, Field } from '@/components/ui';
import { friendlyError, must } from '@/lib/api';
import { formatPhone } from '@/lib/format';
import { supabase } from '@/lib/supabase';
import { normalizePhone } from '@/lib/phone';

/** Staging only texts and calls these numbers (Super Admin). */
export function TestPhones() {
  const toast = useToast();
  const qc = useQueryClient();
  const [phone, setPhone] = useState('+1');
  const [label, setLabel] = useState('');
  const q = useQuery({
    queryKey: ['test-phones'],
    queryFn: async () => (await must(supabase.from('test_phones').select('phone_e164, label').order('created_at'), 'load test phones')) as { phone_e164: string; label: string }[],
  });
  const add = useMutation({
    mutationFn: async () => {
      const { data: me } = await supabase.auth.getUser();
      const { error } = await supabase.from('test_phones').insert({ phone_e164: normalizePhone(phone) ?? `+${phone.replace(/\D/g, '')}`, label: label.trim(), added_by: me.user?.id });
      if (error) throw new Error(friendlyError(error));
    },
    onSuccess: () => { setPhone('+1'); setLabel(''); void qc.invalidateQueries({ queryKey: ['test-phones'] }); toast('Test phone added.'); },
    onError: (e) => toast(e instanceof Error ? e.message : 'Could not add.', 'bad'),
  });
  const remove = useMutation({
    mutationFn: async (p: string) => {
      const { error } = await supabase.from('test_phones').delete().eq('phone_e164', p);
      if (error) throw new Error(friendlyError(error));
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ['test-phones'] }),
  });
  return (
    <div className="flex flex-col gap-2 border-t border-line pt-3">
      <span className="text-sm font-semibold">Test phones (staging texts and calls go only to these)</span>
      {(q.data ?? []).map((t) => (
        <div key={t.phone_e164} className="flex items-center justify-between gap-2 rounded-lg bg-canvas px-3 py-2 text-sm">
          <span>{formatPhone(t.phone_e164)} {t.label ? `· ${t.label}` : ''}</span>
          <Button variant="ghost" className="min-h-[32px] px-2 text-xs" onClick={() => remove.mutate(t.phone_e164)}>Remove</Button>
        </div>
      ))}
      <div className="flex flex-wrap items-end gap-2">
        <Field label="Phone (E.164)" value={phone} onChange={(e) => setPhone(e.target.value)} />
        <Field label="Whose phone" value={label} onChange={(e) => setLabel(e.target.value)} />
        <Button className="min-h-[40px]" disabled={!/^\+[1-9]\d{7,14}$/.test(phone.replace(/[^\d+]/g, '')) || add.isPending} onClick={() => add.mutate()}>Add</Button>
      </div>
    </div>
  );
}
