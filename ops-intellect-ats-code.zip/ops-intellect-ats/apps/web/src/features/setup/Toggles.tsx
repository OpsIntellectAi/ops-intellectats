import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { Banner, Button, Chip, Spinner } from '@/components/ui';
import { useToast } from '@/components/kit';
import { callFunction, friendlyError, must, rpc } from '@/lib/api';
import { FEATURES, type FeatureKey } from '@/lib/features';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/features/shell/context';
import { DEFAULT_NI_REASONS, DEFAULT_REJECT_REASONS } from '@/features/candidates/CandidatePanel';

/** Switch for one feature. role="switch" so screen readers say on/off. */
export function Switch({ on, disabled, label, onChange }: { on: boolean; disabled?: boolean; label: string; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!on)}
      className={`relative h-7 w-12 shrink-0 rounded-full transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${on ? 'bg-brand' : 'bg-[#CFCAC0]'}`}
    >
      <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all ${on ? 'left-6' : 'left-1'}`} />
    </button>
  );
}

export function TogglesAndReasons() {
  const w = useWorkspace();
  const toast = useToast();
  const qc = useQueryClient();
  const isSuper = w.can('platform.admin');
  const features = w.client.client_settings?.features ?? {};
  const set = useMutation({
    mutationFn: (v: { key: FeatureKey; on: boolean }) => rpc('set_feature', { p_client: w.client.id, p_key: v.key, p_on: v.on }),
    onSuccess: (_d, v) => {
      void qc.invalidateQueries({ queryKey: ['client', w.client.id] });
      toast(`${FEATURES.find((f) => f.key === v.key)?.label ?? v.key} turned ${v.on ? 'ON' : 'OFF'} for ${w.client.name}.`);
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  const groups = [...new Set(FEATURES.map((f) => f.group))];
  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col gap-3 rounded-card border border-line bg-white p-5">
        <div className="flex flex-col">
          <span className="text-[17px] font-bold">Feature toggles · {w.client.name}</span>
          <span className="text-xs text-muted">
            {isSuper ? 'Only a Super Admin sees these switches. Each change is saved at once and recorded in the activity log. The server enforces them too.' : 'View only: only a Super Admin changes feature toggles.'}
          </span>
        </div>
        {groups.map((g) => (
          <div key={g} className="flex flex-col gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-muted">{g}</span>
            {FEATURES.filter((f) => f.group === g).map((f) => {
              const on = features[f.key] !== false;
              return (
                <div key={f.key} className="flex items-center justify-between gap-3 rounded-xl border border-line px-4 py-3">
                  <div className="flex flex-col">
                    <span className="text-sm font-semibold">{f.label} {on ? <Chip tone="ok">On</Chip> : <Chip tone="bad">Off</Chip>}</span>
                    <span className="text-xs text-muted">{f.help}</span>
                  </div>
                  <Switch on={on} disabled={!isSuper || set.isPending} label={f.label} onChange={(v) => set.mutate({ key: f.key, on: v })} />
                </div>
              );
            })}
          </div>
        ))}
        <span className="text-xs text-muted">The emergency stop (left menu) still pauses all automation for every client at once.</span>
      </div>
      <ReasonEditor kind="reject_reasons" title="Reject reasons" defaults={DEFAULT_REJECT_REASONS} />
      <ReasonEditor kind="not_interested_reasons" title="Not-interested reasons" defaults={DEFAULT_NI_REASONS} />
    </div>
  );
}

function ReasonEditor({ kind, title, defaults }: { kind: 'reject_reasons' | 'not_interested_reasons'; title: string; defaults: string[] }) {
  const w = useWorkspace();
  const toast = useToast();
  const qc = useQueryClient();
  const isSuper = w.can('platform.admin');
  const [list, setList] = useState<string[]>(w.client.client_settings?.[kind]?.length ? w.client.client_settings[kind] : defaults);
  const [add, setAdd] = useState('');
  const save = useMutation({
    mutationFn: async (next: string[]) => {
      const res = await must(supabase.from('client_settings').update({ [kind]: next }).eq('client_id', w.client.id).select('client_id'), 'save the reasons');
      if (Array.isArray(res) && res.length === 0) throw new Error('Your access level cannot change this.');
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['client', w.client.id] });
      toast(`${title} saved.`);
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  const update = (next: string[]) => {
    setList(next);
    save.mutate(next);
  };
  return (
    <div className="flex flex-col gap-3 rounded-card border border-line bg-white p-5">
      <div className="flex flex-col">
        <span className="text-[17px] font-bold">{title}</span>
        <span className="text-xs text-muted">One click in the {title.startsWith('Reject') ? 'Reject' : 'Not interested'} window fills the reason. Max 30.</span>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {list.map((r) => (
          <span key={r} className="inline-flex items-center gap-1 rounded-full border border-line bg-canvas pl-3 text-xs font-semibold">
            {r}
            {isSuper ? <button type="button" aria-label={`Remove ${r}`} className="flex h-7 w-7 items-center justify-center rounded-full text-muted hover:bg-black/5" onClick={() => update(list.filter((x) => x !== r))}>×</button> : <span className="w-2" />}
          </span>
        ))}
      </div>
      {isSuper ? (
        <div className="flex flex-wrap gap-2">
          <input value={add} maxLength={120} onChange={(e) => setAdd(e.target.value)} placeholder="Add a reason" aria-label={`Add ${title.toLowerCase()}`} className="min-h-[40px] min-w-[260px] flex-1 rounded-lg border border-line px-3 text-sm" />
          <Button disabled={add.trim().length < 3 || list.length >= 30 || list.includes(add.trim()) || save.isPending} onClick={() => { update([...list, add.trim()]); setAdd(''); }}>Add</Button>
        </div>
      ) : null}
    </div>
  );
}

interface Status {
  twilio: boolean;
  voice: 'vapi' | 'test';
  ai: 'anthropic' | 'openai' | 'test';
  email: boolean;
  encryption: boolean;
}

/** Which outside services have keys. Explains why real texts and calls do not go out yet. */
export function ServiceStatus() {
  const q = useQuery({ queryKey: ['service-status'], queryFn: () => callFunction<Status>('call-actions', { action: 'service_status' }), staleTime: 60_000 });
  const row = (label: string, ok: boolean, okText: string, offText: string, fix: string) => (
    <div className="flex flex-col gap-0.5 rounded-xl border border-line px-4 py-3">
      <span className="flex items-center gap-2 text-sm font-semibold">{label} <Chip tone={ok ? 'ok' : 'warn'}>{ok ? okText : offText}</Chip></span>
      {!ok ? <span className="text-xs text-muted">{fix}</span> : null}
    </div>
  );
  return (
    <div className="flex flex-col gap-2 border-t border-line pt-3">
      <span className="text-[15px] font-bold">Outside services</span>
      {q.isLoading ? <Spinner /> : null}
      {q.isError ? <Banner tone="warn">Could not check: {(q.error as Error).message}</Banner> : null}
      {q.data ? (
        <div className="grid gap-2 md:grid-cols-2">
          {row('Texts and phone calls (Twilio)', q.data.twilio, 'Connected', 'Test mode · nothing is really sent', 'Add the three Twilio keys (account, token, from-number) in Supabase → Edge Functions → Secrets. See the key guide.')}
          {row('AI phone interviews (voice)', q.data.voice === 'vapi', 'Vapi connected', 'Test mode · practice calls only', 'Add the three Vapi keys in Supabase → Edge Functions → Secrets. See the key guide.')}
          {row('AI overview, insights, assistant', q.data.ai !== 'test', q.data.ai === 'anthropic' ? 'Anthropic connected' : 'OpenAI connected', 'Test mode · simple answers', 'Add your Anthropic or OpenAI key in Supabase → Edge Functions → Secrets. See the key guide.')}
          {row('Email (alerts, weekly report)', q.data.email, 'Connected', 'Not set up', 'Add the Resend key and the sender address in Supabase → Edge Functions → Secrets.')}
          {row('Licence / date-of-birth encryption', q.data.encryption, 'Set up', 'Not set up', 'Add the field encryption key (32 random bytes, base64) in Supabase → Edge Functions → Secrets.')}
        </div>
      ) : null}
      <span className="text-xs text-muted">The key guide (exact secret names) is docs/KEYS-AND-GO-LIVE.md in the code repository. Keys never go into this website.</span>
      <span className="text-xs text-muted">Even with Twilio connected, staging only texts and calls the test phones above. Phone calls ring your own phone first: set it with the country code (e.g. +91… or +1…), and turn on that country in Twilio → Voice → Geo permissions.</span>
    </div>
  );
}
