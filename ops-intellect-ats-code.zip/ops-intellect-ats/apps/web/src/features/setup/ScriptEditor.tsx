import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useMemo, useState } from 'react';
import { Banner, Button, Chip, Field, Spinner } from '@/components/ui';
import { Checkbox, Empty, Modal, Select, TextArea, useToast } from '@/components/kit';
import { friendlyError, must } from '@/lib/api';
import { parseCsv } from '@/lib/csv';
import { complianceCheck, condition, fillFacts, missingFacts, questionsFromGrid, STANDARD_RULES, STANDARD_SCRIPT, type JobFacts, type ScriptQuestion } from '@/lib/script';
import { supabase } from '@/lib/supabase';
import { dateTimeIn } from '@/lib/time';
import { useWorkspace } from '@/features/shell/context';
import { ScriptSuggestions } from './ScriptSuggestions';

interface Version {
  id: string;
  version: number;
  question_tree: ScriptQuestion[];
  global_rules: string[];
  note: string | null;
  published_at: string | null;
  published_by: string | null;
  created_at: string;
}

/** Question tree editor with yes/no definitions, cross-questions, dealbreakers, rules, compliance check, import, versions, publish. */
export function ScriptEditor() {
  const w = useWorkspace();
  const toast = useToast();
  const qc = useQueryClient();
  const editable = w.can('platform.admin');
  const [roleId, setRoleId] = useState(w.role?.id ?? w.client.job_roles[0]?.id ?? '');
  const role = w.client.job_roles.find((j) => j.id === roleId) ?? null;
  const station = w.client.stations.find((s) => s.id === role?.station_id) ?? null;

  const scriptQ = useQuery({
    queryKey: ['script', roleId],
    enabled: Boolean(roleId),
    queryFn: async () => {
      const s = (await must(supabase.from('scripts').select('id, name, current_version_id').eq('job_role_id', roleId).maybeSingle(), 'load the script')) as {
        id: string;
        name: string;
        current_version_id: string | null;
      } | null;
      if (!s) return { script: null, versions: [] as Version[] };
      const versions = (await must(supabase.from('script_versions').select('*').eq('script_id', s.id).order('version', { ascending: false }), 'load versions')) as Version[];
      return { script: s, versions };
    },
  });

  const current = scriptQ.data?.versions.find((v) => v.id === scriptQ.data?.script?.current_version_id) ?? null;
  const latest = scriptQ.data?.versions[0] ?? null;
  const base = latest ?? current;
  const [questions, setQuestions] = useState<ScriptQuestion[]>([]);
  const [rules, setRules] = useState<string[]>([]);
  const [note, setNote] = useState('');
  useEffect(() => {
    setQuestions(base?.question_tree ?? []);
    setRules(base?.global_rules ?? []);
  }, [base]);

  const issues = useMemo(() => complianceCheck(questions, rules, { payText: role?.pay_text, minAge: role?.min_age, address: station?.address }), [questions, rules, role, station]);
  const facts: JobFacts = {
    client: w.client.name,
    role: role?.name ?? '',
    pay: role?.pay_text,
    address: station?.address,
    trainingLocation: role?.training_location,
    shift: role?.shift_text,
    schedule: role?.schedule_text ?? role?.days_per_week,
    minAge: role?.min_age,
  };
  const missing = missingFacts(questions, rules, facts);
  const [preview, setPreview] = useState(false);
  const [confirmStd, setConfirmStd] = useState(false);
  const loadStandard = () => {
    setQuestions(STANDARD_SCRIPT.map((q) => ({ ...q })));
    setRules([...STANDARD_RULES]);
    setNote('Standard delivery driver script');
    setConfirmStd(false);
    toast('Standard script loaded into the draft. Check the job facts, then Publish.');
  };
  const blocking = issues.filter((i) => i.level === 'bad');

  const save = useMutation({
    mutationFn: async (publish: boolean) => {
      let scriptId = scriptQ.data?.script?.id;
      if (!scriptId) {
        const s = (await must(supabase.from('scripts').insert({ client_id: w.client.id, job_role_id: roleId, name: `${role?.name ?? 'Role'} interview` }).select('id').single(), 'create the script')) as { id: string };
        scriptId = s.id;
      }
      const draft = latest && !latest.published_at ? latest : null;
      let versionId: string;
      if (draft) {
        await must(supabase.from('script_versions').update({ question_tree: questions, global_rules: rules, note: note || draft.note, ...(publish ? { published_at: new Date().toISOString(), published_by: w.access.user_id } : {}) }).eq('id', draft.id).select('id'), 'save the draft');
        versionId = draft.id;
      } else {
        const v = (await must(
          supabase
            .from('script_versions')
            .insert({
              script_id: scriptId,
              client_id: w.client.id,
              version: (latest?.version ?? 0) + 1,
              question_tree: questions,
              global_rules: rules,
              note: note || null,
              ...(publish ? { published_at: new Date().toISOString(), published_by: w.access.user_id } : {}),
            })
            .select('id')
            .single(),
          'save the version',
        )) as { id: string };
        versionId = v.id;
      }
      if (publish) await must(supabase.from('scripts').update({ current_version_id: versionId }).eq('id', scriptId).select('id'), 'publish');
    },
    onSuccess: (_d, publish) => {
      void qc.invalidateQueries({ queryKey: ['script', roleId] });
      setNote('');
      toast(publish ? 'Published. New AI calls use this version; past calls stay pinned to theirs.' : 'Draft saved.');
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });

  const setQ = (i: number, patch: Partial<ScriptQuestion>) => setQuestions(questions.map((q, n) => (n === i ? { ...q, ...patch } : q)));
  const move = (i: number, d: -1 | 1) => {
    const n = [...questions];
    const [x] = n.splice(i, 1);
    if (x) n.splice(i + d, 0, x);
    setQuestions(n);
  };
  const fix = (id: string) => {
    const issue = issues.find((x) => x.id === id);
    if (!issue?.fix) return;
    if (issue.fix.rule) setRules([...rules, issue.fix.rule]);
    if (issue.fix.questionKey && issue.fix.patch) setQuestions(questions.map((q) => (q.key === issue.fix?.questionKey ? { ...q, ...issue.fix.patch } : q)));
  };
  const importFile = async (file: File | undefined) => {
    if (!file) return;
    let grid: string[][];
    if (/\.xlsx$/i.test(file.name)) {
      const { default: readXlsx } = await import('read-excel-file');
      grid = (await readXlsx(file)).map((r) => r.map((c) => (c == null ? '' : String(c))));
    } else grid = parseCsv(await file.text());
    const qs = questionsFromGrid(grid);
    if (!qs.length) toast('No questions found. Columns: path (or Key), question, type, dealbreaker — or Key, Type, Question, Yes means, No means, Cross-question, Dealbreaker.', 'bad');
    else {
      setQuestions(qs);
      toast(`${qs.length} questions imported into the draft.`);
    }
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-end gap-2 rounded-card border border-line bg-white p-4">
        <Select label="Job role" value={roleId} onChange={(e) => setRoleId(e.target.value)}>
          {w.client.job_roles.map((j) => (
            <option key={j.id} value={j.id}>{w.client.stations.find((s) => s.id === j.station_id)?.code} · {j.name}</option>
          ))}
        </Select>
        <span className="text-sm text-muted">
          Live version: {current ? `v${current.version} (${dateTimeIn(current.published_at, w.tz)})` : 'none'}
          {latest && !latest.published_at ? ` · draft v${latest.version}` : ''}
        </span>
        {!editable ? <Chip>View only: only a Super Admin edits scripts</Chip> : null}
      </div>
      {scriptQ.isLoading ? <Spinner /> : null}

      <div className="flex flex-col gap-3 rounded-card border border-line bg-white p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-[17px] font-bold">One script for every client</span>
          {editable ? <Button variant="primary" onClick={() => (questions.length ? setConfirmStd(true) : loadStandard())}>Use standard driver script</Button> : null}
        </div>
        <span className="text-sm text-muted">
          Write [company], [address], [pay], [training location], [shift], [schedule] and [min age] in the questions. On every call they are filled in from this client and job role, so the same script works for every DSP — change only the job facts in <b>Roles and pay</b>.
        </span>
        <div className="grid gap-2 text-sm md:grid-cols-2">
          {([
            ['[company]', facts.client],
            ['[role]', facts.role],
            ['[address]', facts.address],
            ['[pay]', facts.pay],
            ['[training location]', facts.trainingLocation],
            ['[shift]', facts.shift],
            ['[schedule]', facts.schedule],
            ['[min age]', facts.minAge != null ? String(facts.minAge) : null],
          ] as const).map(([k, v]) => (
            <div key={k} className="flex items-center justify-between gap-2 rounded-lg bg-canvas px-3 py-2">
              <span className="font-mono text-xs">{k}</span>
              <span className={v ? 'font-semibold' : 'text-bad'}>{v || 'not set'}</span>
            </div>
          ))}
        </div>
        {missing.length ? <Banner tone="warn">Not filled for this job role: {missing.map((m) => `[${m}]`).join(', ')}. Add them in Client setup → Roles and pay (Super Admin), or the AI will skip that detail.</Banner> : null}
        <Checkbox label="Show the questions as the AI will say them" checked={preview} onChange={setPreview} />
        {preview ? (
          <ol className="flex flex-col gap-1.5 rounded-xl bg-canvas p-3 text-sm">
            <li className="text-muted">Opening (always): “Hi [first name], this is an AI assistant calling for {facts.client} about the {facts.role} role you applied for. This call is recorded. Is now a safe time to talk for about 8 minutes?”</li>
            {questions.map((q) => {
              const c = condition(q.key);
              return (
                <li key={q.key} className={c ? 'border-l-2 border-line pl-6' : ''}>
                  <span className="font-mono text-xs text-muted">{q.key}</span>{' '}
                  {c ? <span className="text-xs font-semibold text-info">if {c.parent} = {c.answer.toUpperCase()} · </span> : null}
                  {q.type === 'info' ? <span className="text-xs font-semibold text-muted">says · </span> : q.type === 'recorded' ? <span className="text-xs font-semibold text-muted">open answer · </span> : null}
                  {fillFacts(q.text, facts)}
                  {q.dealbreaker ? <span className="ml-1 text-xs font-semibold text-bad">dealbreaker</span> : null}
                </li>
              );
            })}
          </ol>
        ) : null}
      </div>
      <Modal
        open={confirmStd}
        title="Replace the draft with the standard script?"
        onClose={() => setConfirmStd(false)}
        footer={<><Button onClick={() => setConfirmStd(false)}>Cancel</Button><Button variant="primary" onClick={loadStandard}>Replace draft</Button></>}
      >
        <p className="text-sm">The {questions.length} questions in the draft are replaced by the standard delivery driver script ({STANDARD_SCRIPT.length} steps). The live version does not change until you Publish.</p>
      </Modal>

      <div className="flex flex-col gap-3 rounded-card border border-line bg-white p-4">
        <span className="text-[17px] font-bold">Rules for the whole call</span>
        {rules.map((r, i) => (
          <div key={i} className="flex gap-2">
            <input aria-label={`Rule ${i + 1}`} value={r} disabled={!editable} onChange={(e) => setRules(rules.map((x, n) => (n === i ? e.target.value : x)))} className="min-h-[40px] flex-1 rounded-lg border border-line px-2 text-sm" />
            {editable ? <Button className="min-h-[40px]" variant="ghost" onClick={() => setRules(rules.filter((_, n) => n !== i))}>Remove</Button> : null}
          </div>
        ))}
        {editable ? <Button className="self-start" onClick={() => setRules([...rules, ''])}>+ Rule</Button> : null}
      </div>

      <div className="flex flex-col gap-3">
        <span className="text-[17px] font-bold">Questions <span className="text-sm font-normal text-muted">· keys like 17.yes or 18.yes.yes are follow-ups</span></span>
        {!questions.length ? <Empty>No questions yet.</Empty> : null}
        {questions.map((q, i) => (
          <div key={i} className={`flex flex-col gap-2 rounded-card border border-line bg-white p-4 ${condition(q.key) ? 'ml-8 border-l-4 border-l-info' : ''}`}>
            {condition(q.key) ? <span className="text-xs font-semibold text-info">Follow-up: only when the answer to {condition(q.key)?.parent} is {condition(q.key)?.answer.toUpperCase()}</span> : null}
            <div className="flex flex-wrap items-end gap-2">
              <Field label="Key" className="w-28" value={q.key} disabled={!editable} onChange={(e) => setQ(i, { key: e.target.value.replace(/[^a-z0-9_.]/gi, '').slice(0, 30) })} />
              <Select label="Type" value={q.type} disabled={!editable} onChange={(e) => setQ(i, { type: e.target.value as ScriptQuestion['type'] })}>
                <option value="yes_no">Yes / No</option>
                <option value="recorded">Record the answer</option>
                <option value="info">Tell them (no answer)</option>
              </Select>
              <div className="min-w-[260px] flex-1"><Field label="Question" value={q.text} disabled={!editable} onChange={(e) => setQ(i, { text: e.target.value })} /></div>
            </div>
            {q.type === 'yes_no' ? (
              <div className="grid gap-2 md:grid-cols-3">
                <Field label="Counts as Yes" value={q.yes ?? ''} disabled={!editable} onChange={(e) => setQ(i, { yes: e.target.value })} />
                <Field label="Counts as No" value={q.no ?? ''} disabled={!editable} onChange={(e) => setQ(i, { no: e.target.value })} />
                <Field label="Cross-question if unclear" value={q.cross ?? ''} disabled={!editable} onChange={(e) => setQ(i, { cross: e.target.value })} />
              </div>
            ) : null}
            <div className="flex flex-wrap items-center gap-3">
              {q.type === 'yes_no' ? <Checkbox label="Dealbreaker (No ends the call politely)" checked={Boolean(q.dealbreaker)} disabled={!editable} onChange={(v) => setQ(i, { dealbreaker: v })} /> : null}
              <input aria-label="Compliance note" placeholder="Compliance note (optional)" value={q.note ?? ''} disabled={!editable} onChange={(e) => setQ(i, { note: e.target.value })} className="min-h-[36px] flex-1 rounded-lg border border-line px-2 text-sm" />
              {editable ? (
                <>
                  <Button className="min-h-[36px] px-3" disabled={i === 0} onClick={() => move(i, -1)} aria-label="Move up">↑</Button>
                  <Button className="min-h-[36px] px-3" disabled={i === questions.length - 1} onClick={() => move(i, 1)} aria-label="Move down">↓</Button>
                  <Button className="min-h-[36px]" variant="ghost" onClick={() => setQuestions(questions.filter((_, n) => n !== i))}>Remove</Button>
                </>
              ) : null}
            </div>
          </div>
        ))}
        {editable ? (
          <div className="flex flex-wrap items-center gap-2">
            <Button onClick={() => setQuestions([...questions, { key: `q${questions.length + 1}`, type: 'yes_no', text: '', yes: '', no: '', cross: 'Sorry, could you say yes or no?' }])}>+ Question</Button>
            <label className="inline-flex min-h-[44px] cursor-pointer items-center rounded-xl border border-line bg-white px-4 text-sm font-semibold">
              Import Excel / CSV
              <input type="file" accept=".csv,.xlsx" className="sr-only" onChange={(e) => void importFile(e.target.files?.[0])} />
            </label>
          </div>
        ) : null}
      </div>

      <div className="flex flex-col gap-2 rounded-card border border-line bg-white p-4">
        <span className="text-[17px] font-bold">Compliance check</span>
        <span className="text-xs text-muted">Checks AI and recording disclosure, safe-time question, offer of a person, protected topics, yes/no definitions, cross-questions, dealbreakers, and pay/age against the job role. Not legal advice.</span>
        {issues.length === 0 ? <Banner tone="ok">No problems found.</Banner> : null}
        {issues.map((iss) => (
          <div key={iss.id} className="flex flex-wrap items-center justify-between gap-2 text-sm">
            <span className="flex items-center gap-2"><Chip tone={iss.level === 'bad' ? 'bad' : 'warn'}>{iss.level === 'bad' ? 'Must fix' : 'Check'}</Chip>{iss.text}</span>
            {editable && iss.fix ? <Button className="min-h-[32px] text-xs" onClick={() => fix(iss.id)}>Fix in draft</Button> : null}
          </div>
        ))}
        {editable ? <ScriptSuggestions questions={questions} rules={rules} /> : null}
      </div>

      {editable ? (
        <div className="flex flex-col gap-2 rounded-card border border-line bg-white p-4">
          <TextArea label="What changed (version note)" value={note} onChange={(e) => setNote(e.target.value)} maxLength={300} className="min-h-[60px]" />
          <div className="flex flex-wrap gap-2">
            <Button disabled={save.isPending} onClick={() => save.mutate(false)}>Save draft</Button>
            <Button variant="primary" disabled={save.isPending || blocking.length > 0 || !questions.length} onClick={() => save.mutate(true)}>Publish</Button>
            {blocking.length ? <span className="self-center text-xs text-bad">Fix the {blocking.length} “must fix” item{blocking.length > 1 ? 's' : ''} before publishing.</span> : null}
          </div>
        </div>
      ) : null}

      <div className="flex flex-col gap-2 rounded-card border border-line bg-white p-4">
        <span className="text-[17px] font-bold">Versions</span>
        {(scriptQ.data?.versions ?? []).map((v) => (
          <div key={v.id} className="flex flex-wrap items-center justify-between gap-2 text-sm">
            <span>
              v{v.version} · {v.published_at ? `published ${dateTimeIn(v.published_at, w.tz)}` : 'draft'} · {v.question_tree.length} questions {v.note ? `· ${v.note}` : ''}
            </span>
            {v.id === current?.id ? <Chip tone="ok">Live</Chip> : null}
          </div>
        ))}
      </div>
    </div>
  );
}
