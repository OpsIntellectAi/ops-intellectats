import type { ScriptQuestion } from '@/lib/script';

/** Optional AI wording suggestions arrive with the AI features. */
export function ScriptSuggestions(props: { questions: ScriptQuestion[]; rules: string[] }) {
  return props.questions.length < 0 ? null : null;
}
