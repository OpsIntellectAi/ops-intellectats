import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { TestPhones } from './TestPhones';
import { useEffect, useState } from 'react';
import { Banner, Button, Chip, Field, Spinner } from '@/components/ui';
import { Checkbox, Empty, Modal, PageHeader, Select, TextArea, useToast } from '@/components/kit';
import { friendlyError, must } from '@/lib/api';
import { STAGE_LABEL, type Stage } from '@/lib/format';
import { supabase } from '@/lib/supabase';
import type { StepDef, Template } from '@/lib/types';
import { useWorkspace, type ClientSettings } from '@/features/shell/context';
import { useStepDefs, useTemplates } from '@/features/candidates/data';
import { ScriptEditor } from './ScriptEditor';
import { ServiceStatus, TogglesAndReasons } from './Toggles';

const STEPS = ['Client info', 'Roles and pay', 'Scheduling links', 'Automatic messages', 'Onboarding steps', 'Dashboard view', 'AI script', 'Toggles and reasons', 'Test and go live'] as const;
type StepName = (typeof STEPS)[number];

function useSave(what: string) {
  const toast = useToast();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (fn: () => PromiseLike<{ data: unknown; error: unknown }>) => {
      const res = await must(fn(), `save the ${what}`);
      if (Array.isArray(res) && res.length === 0) throw new Error('Your access level cannot change this.');
      return res;
    },
    onSuccess: () => {
      void qc.invalidateQueries();
      toast(`${what[0]?.toUpperCase()}${what.slice(1)} saved.`);
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
}

export function SetupPage() {
  const w = useWorkspace();
  const [step, setStep] = useState<StepName>('Client info');
  return (
    <div className="flex flex-col gap-4">
      <PageHeader eyebrow={w.client.name} title="Client setup" right={<Chip tone={w.client.is_live ? 'ok' : 'warn'}>{w.client.is_live ? 'Live' : 'Not live yet'}</Chip>} />
      <ol className="flex flex-wrap gap-1.5">
        {STEPS.map((s, i) => (
          <li key={s}>
            <button
              type="button"
              onClick={() => setStep(s)}
              className={`rounded-full px-3 py-1.5 text-xs font-bold ${step === s ? 'bg-brand text-white' : 'bg-[#EFECE5] text-ink hover:bg-brand-soft'}`}
              aria-current={step === s ? 'step' : undefined}
            >
              {i + 1}. {s}
            </button>
          </li>
        ))}
      </ol>
      {step === 'Client info' ? <ClientInfo /> : null}
      {step === 'Roles and pay' ? <RolesAndPay /> : null}
      {step === 'Scheduling links' ? <SchedulingLinks /> : null}
      {step === 'Automatic messages' ? <AutomaticMessages /> : null}
      {step === 'Onboarding steps' ? <OnboardingDefs /> : null}
      {step === 'Dashboard view' ? <DashboardView /> : null}
      {step === 'AI script' ? <ScriptEditor /> : null}
      {step === 'Toggles and reasons' ? <TogglesAndReasons /> : null}
      {step === 'Test and go live' ? <GoLive /> : null}
      <div className="flex justify-between">
        <Button disabled={step === STEPS[0]} onClick={() => setStep(STEPS[Math.max(0, STEPS.indexOf(step) - 1)] ?? STEPS[0])}>← Back</Button>
        <Button disabled={step === STEPS[STEPS.length - 1]} onClick={() => setStep(STEPS[Math.min(STEPS.length - 1, STEPS.indexOf(step) + 1)] ?? STEPS[0])}>Next →</Button>
      </div>
    </div>
  );
}

function Card({ title, children, note }: { title: string; children: React.ReactNode; note?: string }) {
  return (
    <div className="flex flex-col gap-3 rounded-card border border-line bg-white p-5">
      <div className="flex flex-col">
        <span className="text-[17px] font-bold">{title}</span>
        {note ? <span className="text-xs text-muted">{note}</span> : null}
      </div>
      {children}
    </div>
  );
}

const LEGAL = 'Not legal advice: have your counsel review these settings.';

// 1 ---------------------------------------------------------------
function ClientInfo() {
  const w = useWorkspace();
  const s = w.client.client_settings;
  const [v, setV] = useState<Partial<ClientSettings>>(s ?? {});
  const [name, setName] = useState(w.client.name);
  const save = useSave('client info');
  const saveName = useSave('client name');
  useEffect(() => setV(s ?? {}), [s]);
  if (!s) return <Empty>No settings row for this client.</Empty>;
  const set = <K extends keyof ClientSettings>(k: K, val: ClientSettings[K]) => setV({ ...v, [k]: val });
  const quietOk = (v.quiet_end ?? '08:00') >= '08:00' && (v.quiet_start ?? '20:00') <= '21:00';
  return (
    <div className="flex flex-col gap-4">
      <Card title="Company">
        <div className="flex flex-wrap items-end gap-2">
          <div className="min-w-[240px] flex-1"><Field label="Client name" value={name} onChange={(e) => setName(e.target.value)} disabled={!w.can('platform.admin')} /></div>
          {w.can('platform.admin') ? <Button disabled={name === w.client.name || saveName.isPending} onClick={() => saveName.mutate(() => supabase.from('clients').update({ name: name.trim() }).eq('id', w.client.id).select('id'))}>Save name</Button> : null}
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          <Field label="Contact name" value={v.contact_name ?? ''} onChange={(e) => set('contact_name', e.target.value || null)} />
          <Field label="Contact email (weekly report)" type="email" value={v.contact_email ?? ''} onChange={(e) => set('contact_email', e.target.value || null)} />
          <Field label="Contact phone" value={v.contact_phone ?? ''} onChange={(e) => set('contact_phone', e.target.value || null)} />
        </div>
        <Select label="Client time zone" value={v.time_zone ?? 'America/New_York'} onChange={(e) => set('time_zone', e.target.value)}>
          {['America/New_York', 'America/Chicago', 'America/Denver', 'America/Phoenix', 'America/Los_Angeles', 'America/Anchorage', 'Pacific/Honolulu'].map((t) => (
            <option key={t}>{t}</option>
          ))}
        </Select>
      </Card>
      <Card title="Texting" note={LEGAL}>
        <div className="grid gap-3 md:grid-cols-3">
          <Field label="First text at (candidate local time)" type="time" value={(v.auto_text_time ?? '08:00').slice(0, 5)} onChange={(e) => set('auto_text_time', e.target.value)} />
          <Field label="No texts after" type="time" value={(v.quiet_start ?? '20:00').slice(0, 5)} onChange={(e) => set('quiet_start', e.target.value)} />
          <Field label="No texts before" type="time" value={(v.quiet_end ?? '08:00').slice(0, 5)} onChange={(e) => set('quiet_end', e.target.value)} />
        </div>
        {!quietOk ? <Banner tone="bad">The sending window can never be wider than 8:00 AM – 9:00 PM candidate local time.</Banner> : null}
        <div className="grid gap-3 md:grid-cols-2">
          <Field label="Twilio Messaging Service SID (MG…)" value={v.twilio_messaging_service_sid ?? ''} onChange={(e) => set('twilio_messaging_service_sid', e.target.value.trim() || null)} placeholder="MG + 32 characters" />
          <Select label="A2P 10DLC campaign status" value={v.a2p_campaign_status ?? 'not_started'} onChange={(e) => set('a2p_campaign_status', e.target.value)}>
            <option value="not_started">Not started</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
          </Select>
        </div>
        <span className="text-xs text-muted">Live texting for this client stays blocked until the A2P campaign is Approved.</span>
      </Card>
      <Card title="AI calls, retention and NYC" note={LEGAL}>
        <div className="grid gap-3 md:grid-cols-4">
          <Field label="AI attempts per day" type="number" min={1} max={5} value={v.max_ai_attempts_per_day ?? 2} onChange={(e) => set('max_ai_attempts_per_day', Number(e.target.value))} />
          <Field label="AI attempts in total" type="number" min={1} max={10} value={v.max_ai_attempts_total ?? 4} onChange={(e) => set('max_ai_attempts_total', Number(e.target.value))} />
          <Field label="Delete recordings after (days)" type="number" min={1} max={3650} value={v.recording_retention_days ?? 90} onChange={(e) => set('recording_retention_days', Number(e.target.value))} />
          <Field label="Delete rejected after (months)" type="number" min={1} max={120} value={v.rejected_retention_months ?? 12} onChange={(e) => set('rejected_retention_months', Number(e.target.value))} />
        </div>
        <Checkbox label="Auto-shortlist when every answer is Yes (default off: a person reviews every interview). Always off for NYC candidates unless NYC AEDT compliance is on." checked={Boolean(v.auto_shortlist)} onChange={(x) => set('auto_shortlist', x)} />
        <Checkbox label="NYC AEDT compliance (Local Law 144): bias audit done, AI-use notice sent 10 business days before AI evaluation" checked={Boolean(v.aedt_enabled)} onChange={(x) => set('aedt_enabled', x)} />
        {v.aedt_enabled ? <Field label="Bias audit date" type="date" value={v.aedt_bias_audit_date ?? ''} onChange={(e) => set('aedt_bias_audit_date', e.target.value || null)} /> : null}
      </Card>
      <Button
        variant="primary"
        className="self-start"
        disabled={!quietOk || save.isPending}
        onClick={() =>
          save.mutate(() =>
            supabase
              .from('client_settings')
              .update({
                contact_name: v.contact_name,
                contact_email: v.contact_email,
                contact_phone: v.contact_phone,
                time_zone: v.time_zone,
                auto_text_time: v.auto_text_time,
                quiet_start: v.quiet_start,
                quiet_end: v.quiet_end,
                twilio_messaging_service_sid: v.twilio_messaging_service_sid,
                a2p_campaign_status: v.a2p_campaign_status,
                max_ai_attempts_per_day: v.max_ai_attempts_per_day,
                max_ai_attempts_total: v.max_ai_attempts_total,
                recording_retention_days: v.recording_retention_days,
                rejected_retention_months: v.rejected_retention_months,
                auto_shortlist: v.auto_shortlist,
                aedt_enabled: v.aedt_enabled,
                aedt_bias_audit_date: v.aedt_bias_audit_date,
              })
              .eq('client_id', w.client.id)
              .select('client_id'),
          )
        }
      >
        Save client info
      </Button>
    </div>
  );
}

// 2 ---------------------------------------------------------------
function RolesAndPay() {
  const w = useWorkspace();
  const isSuper = w.can('platform.admin');
  const save = useSave('job role');
  const [addRole, setAddRole] = useState(false);
  const [addStation, setAddStation] = useState(false);
  const [r, setR] = useState({ name: '', pay_text: '', min_age: 21, days_per_week: '', station_id: w.station?.id ?? '' });
  const [st, setSt] = useState({ code: '', name: '', address: '' });
  return (
    <Card title="Stations, job roles and pay" note={isSuper ? undefined : 'View only: only a Super Admin changes roles and pay.'}>
      {w.client.stations.map((s) => (
        <div key={s.id} className="flex flex-col gap-2 rounded-xl border border-line p-3">
          <span className="text-sm font-bold">{s.code} · {s.name} <span className="font-normal text-muted">{s.address ?? ''}</span></span>
          {w.client.job_roles.filter((j) => j.station_id === s.id).map((j) => (
            <RoleRow key={j.id} role={j} editable={isSuper} onSave={(patch) => save.mutate(() => supabase.from('job_roles').update(patch).eq('id', j.id).select('id'))} />
          ))}
        </div>
      ))}
      {isSuper ? (
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => setAddRole(true)}>+ Add job role</Button>
          <Button onClick={() => setAddStation(true)}>+ Add station</Button>
        </div>
      ) : null}
      <Modal
        open={addRole}
        title="Add a job role"
        onClose={() => setAddRole(false)}
        footer={
          <>
            <Button onClick={() => setAddRole(false)}>Cancel</Button>
            <Button
              variant="primary"
              disabled={r.name.trim().length < 2 || !r.station_id}
              onClick={() =>
                save.mutate(async () => {
                  const res = await supabase.from('job_roles').insert({ client_id: w.client.id, station_id: r.station_id, name: r.name.trim(), pay_text: r.pay_text || null, min_age: r.min_age, days_per_week: r.days_per_week || null }).select('id').single();
                  if (!res.error && res.data) await supabase.from('scripts').insert({ client_id: w.client.id, job_role_id: res.data.id, name: `${r.name.trim()} interview` });
                  setAddRole(false);
                  return res;
                })
              }
            >
              Add role
            </Button>
          </>
        }
      >
        <Select label="Station" value={r.station_id} onChange={(e) => setR({ ...r, station_id: e.target.value })}>
          {w.client.stations.map((s) => (
            <option key={s.id} value={s.id}>{s.code}</option>
          ))}
        </Select>
        <Field label="Role name" value={r.name} onChange={(e) => setR({ ...r, name: e.target.value })} placeholder="Delivery Driver" />
        <Field label="Pay" value={r.pay_text} onChange={(e) => setR({ ...r, pay_text: e.target.value })} placeholder="$20.00 / hr" />
        <div className="grid grid-cols-2 gap-3">
          <Field label="Minimum age" type="number" min={16} max={30} value={r.min_age} onChange={(e) => setR({ ...r, min_age: Number(e.target.value) })} />
          <Field label="Days per week" value={r.days_per_week} onChange={(e) => setR({ ...r, days_per_week: e.target.value })} placeholder="4–5" />
        </div>
      </Modal>
      <Modal
        open={addStation}
        title="Add a station"
        onClose={() => setAddStation(false)}
        footer={
          <>
            <Button onClick={() => setAddStation(false)}>Cancel</Button>
            <Button
              variant="primary"
              disabled={!/^[A-Z0-9-]{2,12}$/.test(st.code) || st.name.trim().length < 2}
              onClick={() => {
                save.mutate(() => supabase.from('stations').insert({ client_id: w.client.id, code: st.code, name: st.name.trim(), address: st.address || null, time_zone: w.tz }).select('id'));
                setAddStation(false);
              }}
            >
              Add station
            </Button>
          </>
        }
      >
        <Field label="Station code (capitals, e.g. NL3)" value={st.code} onChange={(e) => setSt({ ...st, code: e.target.value.toUpperCase() })} />
        <Field label="Station name" value={st.name} onChange={(e) => setSt({ ...st, name: e.target.value })} />
        <Field label="Address" value={st.address} onChange={(e) => setSt({ ...st, address: e.target.value })} />
      </Modal>
    </Card>
  );
}

function RoleRow({ role, editable, onSave }: { role: import('@/features/shell/context').JobRole; editable: boolean; onSave: (p: Record<string, unknown>) => void }) {
  const init = {
    pay_text: role.pay_text ?? '',
    min_age: role.min_age ?? 21,
    days_per_week: role.days_per_week ?? '',
    training_location: role.training_location ?? '',
    shift_text: role.shift_text ?? '',
    schedule_text: role.schedule_text ?? '',
  };
  const [v, setV] = useState(init);
  const changed = (Object.keys(init) as (keyof typeof init)[]).some((k) => v[k] !== init[k]);
  return (
    <div className="flex flex-col gap-2 rounded-lg bg-canvas p-3">
      <span className="text-sm font-bold">{role.name} <span className="text-xs font-normal text-muted">· these fill [pay], [min age], [training location], [shift] and [schedule] in the AI script</span></span>
      <div className="grid gap-2 md:grid-cols-3">
        <Field label="Pay [pay]" value={v.pay_text} disabled={!editable} onChange={(e) => setV({ ...v, pay_text: e.target.value })} placeholder="$22.25 per hour" />
        <Field label="Min age [min age]" type="number" value={v.min_age} disabled={!editable} onChange={(e) => setV({ ...v, min_age: Number(e.target.value) })} />
        <Field label="Days/week" value={v.days_per_week} disabled={!editable} onChange={(e) => setV({ ...v, days_per_week: e.target.value })} placeholder="4–5" />
        <Field label="Training location [training location]" value={v.training_location} disabled={!editable} maxLength={200} onChange={(e) => setV({ ...v, training_location: e.target.value })} placeholder="Station office, 1000 Example Way" />
        <Field label="Shift [shift]" value={v.shift_text} disabled={!editable} maxLength={200} onChange={(e) => setV({ ...v, shift_text: e.target.value })} placeholder="10:00 AM to 8:30 PM (10 hours)" />
        <Field label="Schedule [schedule]" value={v.schedule_text} disabled={!editable} maxLength={200} onChange={(e) => setV({ ...v, schedule_text: e.target.value })} placeholder="Full time, 4 days incl. 1 weekend day" />
      </div>
      {editable && changed ? (
        <Button
          variant="primary"
          className="self-start"
          onClick={() =>
            onSave({
              pay_text: v.pay_text || null,
              min_age: v.min_age,
              days_per_week: v.days_per_week || null,
              training_location: v.training_location.trim() || null,
              shift_text: v.shift_text.trim() || null,
              schedule_text: v.schedule_text.trim() || null,
            })
          }
        >
          Save {role.name}
        </Button>
      ) : null}
    </div>
  );
}

// 3 ---------------------------------------------------------------
function SchedulingLinks() {
  const w = useWorkspace();
  const save = useSave('scheduling link');
  const isSuper = w.can('platform.admin');
  return (
    <Card title="Scheduling links" note="The link candidates use to book their AI interview. One per job role. Must start with https://">
      {w.client.job_roles.map((j) => (
        <LinkRow key={j.id} label={`${w.client.stations.find((s) => s.id === j.station_id)?.code ?? ''} · ${j.name}`} value={j.scheduling_link ?? ''} editable={isSuper} onSave={(v) => save.mutate(() => supabase.from('job_roles').update({ scheduling_link: v || null }).eq('id', j.id).select('id'))} />
      ))}
      {!isSuper ? <span className="text-xs text-muted">Only a Super Admin changes scheduling links.</span> : null}
    </Card>
  );
}

function LinkRow({ label, value, editable, onSave }: { label: string; value: string; editable: boolean; onSave: (v: string) => void }) {
  const [v, setV] = useState(value);
  const ok = v === '' || /^https:\/\/\S{4,300}$/.test(v);
  return (
    <div className="flex flex-wrap items-end gap-2">
      <div className="min-w-[260px] flex-1"><Field label={label} value={v} disabled={!editable} onChange={(e) => setV(e.target.value.trim())} error={ok ? undefined : 'Must start with https://'} /></div>
      {editable && v !== value ? <Button disabled={!ok} onClick={() => onSave(v)}>Save</Button> : null}
    </div>
  );
}

// 4 ---------------------------------------------------------------
interface StepMsg {
  id: string;
  trigger_key: string;
  label: string;
  body: string;
  enabled: boolean;
}
interface Reminder {
  id: string;
  minutes_before: number;
  body: string;
  enabled: boolean;
}

function AutomaticMessages() {
  const w = useWorkspace();
  const save = useSave('message');
  const stepQ = useQuery({ queryKey: ['stepmsgs', w.client.id], queryFn: async () => (await must(supabase.from('step_messages').select('id, trigger_key, label, body, enabled').eq('client_id', w.client.id).order('label'), 'load messages')) as StepMsg[] });
  const remQ = useQuery({ queryKey: ['reminders', w.client.id], queryFn: async () => (await must(supabase.from('call_reminders').select('id, minutes_before, body, enabled').eq('client_id', w.client.id).order('minutes_before', { ascending: false }), 'load reminders')) as Reminder[] });
  const templatesQ = useTemplates(w.client.id);
  const [tpl, setTpl] = useState<Partial<Template> | null>(null);
  const canSettings = w.can('settings.edit');
  const order = (k: string) => (k === 'first_text' ? 0 : k.startsWith('follow_up') ? 1 : k.startsWith('stage') ? 2 : 3);
  return (
    <div className="flex flex-col gap-4">
      <Card title="First text, follow-ups and a text at every step" note="Each automatic text has its own switch. Placeholders: [first name] [role] [client] [link] [time]. Follow-ups: day 2 and day 5; on day 7 with no reply the candidate is marked No response.">
        {stepQ.isLoading ? <Spinner /> : null}
        {[...(stepQ.data ?? [])].sort((a, b) => order(a.trigger_key) - order(b.trigger_key)).map((m) => (
          <MessageRow key={m.id} label={m.label} sub={m.trigger_key} body={m.body} enabled={m.enabled} editable={canSettings} onSave={(body, enabled) => save.mutate(() => supabase.from('step_messages').update({ body, enabled }).eq('id', m.id).select('id'))} />
        ))}
      </Card>
      <Card title="Reminders before a booked AI call" note="Reminders that would land in the past are skipped. Reply C reschedules.">
        {(remQ.data ?? []).map((r) => (
          <MessageRow key={r.id} label={r.minutes_before >= 60 ? `${r.minutes_before / 60} h before` : `${r.minutes_before} min before`} body={r.body} enabled={r.enabled} editable={canSettings} onSave={(body, enabled) => save.mutate(() => supabase.from('call_reminders').update({ body, enabled }).eq('id', r.id).select('id'))} />
        ))}
      </Card>
      <Card title="Message templates" note="One-tap templates shown in the candidate panel for the stages you choose. Scheduling-link templates hide once a candidate is past Interview or their background check passed.">
        {(templatesQ.data ?? []).map((t) => (
          <div key={t.id} className="flex flex-wrap items-start justify-between gap-2 rounded-xl border border-line p-3">
            <div className="flex min-w-0 flex-1 flex-col gap-1">
              <span className="text-sm font-semibold">{t.name} {t.is_scheduling_link ? <Chip tone="info">scheduling link</Chip> : null}</span>
              <span className="text-sm text-muted">{t.body}</span>
              <div className="flex flex-wrap gap-1">{t.stages.map((s) => <Chip key={s}>{STAGE_LABEL[s]}</Chip>)}</div>
            </div>
            {w.can('templates.edit') ? <Button className="min-h-[34px] text-xs" onClick={() => setTpl(t)}>Edit</Button> : null}
          </div>
        ))}
        {w.can('templates.edit') ? <Button className="self-start" onClick={() => setTpl({ name: '', body: '', stages: ['interview'], is_scheduling_link: false })}>+ New template</Button> : null}
      </Card>
      {tpl ? <TemplateModal tpl={tpl} onClose={() => setTpl(null)} /> : null}
    </div>
  );
}

function MessageRow({ label, sub, body, enabled, editable, onSave }: { label: string; sub?: string; body: string; enabled: boolean; editable: boolean; onSave: (body: string, enabled: boolean) => void }) {
  const [b, setB] = useState(body);
  const [e, setE] = useState(enabled);
  const changed = b !== body || e !== enabled;
  return (
    <div className="flex flex-col gap-2 rounded-xl border border-line p-3">
      <div className="flex items-center justify-between gap-2">
        <span className="text-sm font-semibold">{label} {sub ? <span className="text-xs font-normal text-muted">{sub}</span> : null}</span>
        <Checkbox label="On" checked={e} disabled={!editable} onChange={setE} />
      </div>
      <TextArea aria-label={label} value={b} disabled={!editable} onChange={(x) => setB(x.target.value)} maxLength={640} className="min-h-[64px]" />
      <span className="text-xs text-muted">{b.length} characters · {Math.ceil(b.length / 160)} SMS segment{Math.ceil(b.length / 160) > 1 ? 's' : ''}</span>
      {editable && changed ? <Button className="self-start" disabled={b.trim().length < 2} onClick={() => onSave(b, e)}>Save</Button> : null}
    </div>
  );
}

function TemplateModal({ tpl, onClose }: { tpl: Partial<Template>; onClose: () => void }) {
  const w = useWorkspace();
  const save = useSave('template');
  const [v, setV] = useState(tpl);
  const stages: Stage[] = ['interview', 'shortlisted', 'pre_onboarding', 'onboarding', 'hired'];
  const ok = (v.name ?? '').trim().length >= 2 && (v.body ?? '').trim().length >= 2 && (v.stages ?? []).length > 0;
  return (
    <Modal
      open
      title={tpl.id ? 'Edit template' : 'New template'}
      onClose={onClose}
      footer={
        <>
          {tpl.id ? <Button variant="danger" onClick={() => { save.mutate(() => supabase.from('message_templates').delete().eq('id', tpl.id ?? '').select('id')); onClose(); }}>Delete</Button> : null}
          <Button onClick={onClose}>Cancel</Button>
          <Button
            variant="primary"
            disabled={!ok || save.isPending}
            onClick={() => {
              const row = { name: (v.name ?? '').trim(), body: (v.body ?? '').trim(), stages: v.stages, is_scheduling_link: Boolean(v.is_scheduling_link) };
              save.mutate(() =>
                tpl.id
                  ? supabase.from('message_templates').update(row).eq('id', tpl.id).select('id')
                  : supabase.from('message_templates').insert({ ...row, client_id: w.client.id, created_by: w.access.user_id }).select('id'),
              );
              onClose();
            }}
          >
            Save template
          </Button>
        </>
      }
    >
      <Field label="Name" value={v.name ?? ''} onChange={(e) => setV({ ...v, name: e.target.value })} maxLength={60} placeholder="e.g. Create a Gmail" />
      <TextArea label="Text" value={v.body ?? ''} onChange={(e) => setV({ ...v, body: e.target.value })} maxLength={640} />
      <div className="flex flex-col gap-1">
        <span className="text-sm font-semibold">Show for stages</span>
        <div className="flex flex-wrap gap-3">
          {stages.map((s) => (
            <Checkbox key={s} label={STAGE_LABEL[s]} checked={(v.stages ?? []).includes(s)} onChange={(x) => setV({ ...v, stages: x ? [...(v.stages ?? []), s] : (v.stages ?? []).filter((y) => y !== s) })} />
          ))}
        </div>
      </div>
      <Checkbox label="This template contains the AI-call scheduling link (hidden after Interview / background check passed)" checked={Boolean(v.is_scheduling_link)} onChange={(x) => setV({ ...v, is_scheduling_link: x })} />
    </Modal>
  );
}

// 5 ---------------------------------------------------------------
function OnboardingDefs() {
  const w = useWorkspace();
  const defsQ = useStepDefs(w.client.id);
  const save = useSave('onboarding step');
  const isSuper = w.can('platform.admin');
  return (
    <Card title="Onboarding steps" note={isSuper ? 'Required steps must be done or waived before “Mark hired”. Steps can run in parallel.' : 'View only: only a Super Admin changes onboarding steps.'}>
      {(defsQ.data ?? []).map((d) => (
        <DefRow key={d.id} d={d} editable={isSuper} onSave={(p) => save.mutate(() => supabase.from('onboarding_step_defs').update(p).eq('id', d.id).select('id'))} />
      ))}
    </Card>
  );
}

function DefRow({ d, editable, onSave }: { d: StepDef; editable: boolean; onSave: (p: Partial<StepDef>) => void }) {
  const [name, setName] = useState(d.name);
  const [req, setReq] = useState(d.required);
  const [owner, setOwner] = useState(d.owner_label);
  const changed = name !== d.name || req !== d.required || owner !== d.owner_label;
  return (
    <div className="flex flex-wrap items-end gap-2 rounded-xl border border-line p-3">
      <span className="w-8 text-sm text-muted">{d.sort_order}.</span>
      <div className="min-w-[220px] flex-1"><Field label={d.phase} value={name} disabled={!editable} onChange={(e) => setName(e.target.value)} /></div>
      <Select label="Owner" value={owner} disabled={!editable} onChange={(e) => setOwner(e.target.value)}>
        {['CSR', 'Ops', 'Station', 'Client'].map((o) => (
          <option key={o}>{o}</option>
        ))}
      </Select>
      <Checkbox label="Required" checked={req} disabled={!editable} onChange={setReq} />
      <span className="text-xs text-muted">{d.statuses.join(' · ')}</span>
      {editable && changed ? <Button onClick={() => onSave({ name: name.trim(), required: req, owner_label: owner })}>Save</Button> : null}
    </div>
  );
}

// 6 ---------------------------------------------------------------
function DashboardView() {
  const w = useWorkspace();
  const save = useSave('dashboard view');
  const all = ['kpis', 'funnel', 'calls_per_day', 'contact_health', 'onboarding', 'sources', 'days_in_stage', 'call_outcomes'];
  const [sel, setSel] = useState<string[]>(w.client.client_settings?.dashboard_widgets ?? all);
  return (
    <Card title="Dashboard view" note="Which panels everyone in this client sees on the Dashboard.">
      {all.map((k) => (
        <Checkbox key={k} label={k.replace(/_/g, ' ')} checked={sel.includes(k)} onChange={(v) => setSel(v ? [...sel, k] : sel.filter((x) => x !== k))} />
      ))}
      <Button variant="primary" className="self-start" onClick={() => save.mutate(() => supabase.from('client_settings').update({ dashboard_widgets: sel }).eq('client_id', w.client.id).select('client_id'))}>Save</Button>
    </Card>
  );
}

// 8 ---------------------------------------------------------------
const CHECKS: { key: string; label: string }[] = [
  { key: 'info', label: 'Client info, contact and time zone are right' },
  { key: 'a2p', label: 'A2P 10DLC campaign approved and Messaging Service SID entered' },
  { key: 'roles', label: 'Job roles, pay and minimum age match the client’s offer' },
  { key: 'links', label: 'Scheduling link works for every job role' },
  { key: 'texts', label: 'Automatic texts read well and STOP/HELP replies were tested' },
  { key: 'script', label: 'AI script published with no compliance problems, and a test call was reviewed' },
  { key: 'onboarding', label: 'Onboarding steps and required flags agreed with the client' },
  { key: 'team', label: 'CSRs, Supervisor and client users have access' },
  { key: 'legal', label: 'Counsel reviewed consent wording, recording notice and NYC settings' },
];

function GoLive() {
  const w = useWorkspace();
  const save = useSave('checklist');
  const live = useSave('live status');
  const [checks, setChecks] = useState<Record<string, boolean>>(w.client.client_settings?.go_live_checklist ?? {});
  const [confirm, setConfirm] = useState(false);
  const done = CHECKS.every((c) => checks[c.key]);
  const a2pOk = w.client.client_settings?.a2p_campaign_status === 'approved';
  return (
    <Card title="Test and go live" note={LEGAL}>
      {CHECKS.map((c) => (
        <Checkbox key={c.key} label={c.label} checked={Boolean(checks[c.key])} onChange={(v) => setChecks({ ...checks, [c.key]: v })} />
      ))}
      <Button className="self-start" onClick={() => save.mutate(() => supabase.from('client_settings').update({ go_live_checklist: checks }).eq('client_id', w.client.id).select('client_id'))}>Save checklist</Button>
      {w.can('platform.admin') ? (
        <div className="flex flex-col gap-2 border-t border-line pt-3">
          {!a2pOk ? <Banner tone="warn">Live texting stays blocked until the A2P campaign is Approved (step 1).</Banner> : null}
          <Button variant={w.client.is_live ? 'danger' : 'primary'} className="self-start" disabled={!w.client.is_live && !done} onClick={() => setConfirm(true)}>
            {w.client.is_live ? 'Take client offline' : 'Go live'}
          </Button>
          {!done && !w.client.is_live ? <span className="text-xs text-muted">Tick every item first.</span> : null}
          <TestPhones />
        </div>
      ) : null}
      <ServiceStatus />
      <Modal
        open={confirm}
        title={w.client.is_live ? 'Take this client offline?' : `Go live with ${w.client.name}?`}
        onClose={() => setConfirm(false)}
        footer={
          <>
            <Button onClick={() => setConfirm(false)}>Cancel</Button>
            <Button variant="primary" onClick={() => { live.mutate(() => supabase.from('clients').update({ is_live: !w.client.is_live }).eq('id', w.client.id).select('id')); setConfirm(false); }}>
              Confirm
            </Button>
          </>
        }
      >
        <p className="text-sm">{w.client.is_live ? 'Automatic texts and AI calls stop for this client.' : 'Automatic texts and AI calls start for this client (within the sending window, and only if A2P is approved).'}</p>
      </Modal>
    </Card>
  );
}
