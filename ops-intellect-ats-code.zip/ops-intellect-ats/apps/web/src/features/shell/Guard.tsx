import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Banner } from '@/components/ui';
import type { Permission } from '@/lib/roles';
import { useWorkspace } from './context';

/** Screens a level cannot use show a clear message, even when opened by typing the address. */
export function Guard({ need, children }: { need: Permission; children: ReactNode }) {
  const w = useWorkspace();
  if (w.can(need)) return <>{children}</>;
  return (
    <div className="flex flex-col gap-3">
      <Banner tone="info">Your access level does not include this screen.</Banner>
      <Link to="../my-day" relative="path" className="text-sm font-semibold text-brand underline">Back to My day</Link>
    </div>
  );
}
