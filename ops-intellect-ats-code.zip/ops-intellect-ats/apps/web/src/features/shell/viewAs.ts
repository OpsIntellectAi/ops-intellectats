import { useSyncExternalStore } from 'react';
import type { AppRole } from '@/lib/roles';

/**
 * "View as" for Super Admins on staging: changes which screens and buttons show,
 * nothing else. The data is still the Super Admin's (the database decides that).
 */
const KEY = 'oi.viewas';
const listeners = new Set<() => void>();

function read(): AppRole | null {
  try {
    return (sessionStorage.getItem(KEY) as AppRole | null) || null;
  } catch {
    return null;
  }
}

export function setViewAs(role: AppRole | null): void {
  try {
    if (role) sessionStorage.setItem(KEY, role);
    else sessionStorage.removeItem(KEY);
  } catch {
    /* storage blocked: nothing to remember */
  }
  listeners.forEach((l) => l());
}

export function useViewAs(): AppRole | null {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    read,
    () => null,
  );
}
