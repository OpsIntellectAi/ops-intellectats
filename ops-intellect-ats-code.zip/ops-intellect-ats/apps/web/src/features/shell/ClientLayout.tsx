import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate, useParams } from 'react-router-dom';
import { Banner, Button, Card, CenterPage, Field, Logo, Spinner } from '@/components/ui';
import { Modal, Select, TextArea, useToast } from '@/components/kit';
import { friendlyError, must, rpc } from '@/lib/api';
import { easternClock, initials } from '@/lib/format';
import { buildQueues } from '@/lib/queues';
import { ROLE_LABEL, type MyAccess, type Permission } from '@/lib/roles';
import { supabase } from '@/lib/supabase';
import { CandidatePanel } from '@/features/candidates/CandidatePanel';
import { AssistantButton } from '@/features/assistant/AssistantPanel';
import { LiveUpdates } from '@/features/live/LiveUpdates';
import { permissionOf, pickStationRole, useClientDetail, useOpenApp, useRows, useTeam, useWorkspace, WorkspaceProvider, type Workspace } from './context';
import { setViewAs, useViewAs } from './viewAs';
import { env } from '@/lib/env';
import type { AppRole } from '@/lib/roles';
import { featureOn } from '@/lib/features';

interface NavItem {
  to: string;
  label: string;
  need: Permission;
  count?: (w: CountSource) => number;
}
interface CountSource {
  today: number;
  review: number;
  replies: number;
}

const NAV: NavItem[] = [
  { to: 'my-day', label: 'My day', need: 'view' },
  { to: 'today', label: 'Today', need: 'view', count: (c) => c.today },
  { to: 'candidates', label: 'Candidates', need: 'view' },
  { to: 'calls', label: 'Calls', need: 'view', count: (c) => c.review },
  { to: 'insights', label: 'AI insights', need: 'reports.view' },
  { to: 'messages', label: 'Messages', need: 'view', count: (c) => c.replies },
  { to: 'dashboard', label: 'Dashboard', need: 'view' },
  { to: 'reports', label: 'Reports & alerts', need: 'reports.view' },
  { to: 'admin', label: 'Users & activity', need: 'audit.view' },
  { to: 'setup', label: 'Client setup', need: 'settings.edit' },
];

function remember(key: string, value?: string): string {
  try {
    if (value !== undefined) localStorage.setItem(key, value);
    return localStorage.getItem(key) ?? '';
  } catch {
    return '';
  }
}

export function ClientLayout({ access }: { access: MyAccess }) {
  const { clientId = '' } = useParams();
  const clientQ = useClientDetail(clientId);
  const teamQ = useTeam(clientId);
  const { openId, openApp } = useOpenApp();
  const qc = useQueryClient();

  const [stationId, setStationId] = useState(() => remember(`oi.station.${clientId}`));
  const [roleId, setRoleId] = useState(() => remember(`oi.role.${clientId}`));

  const client = clientQ.data ?? null;
  const { station, roles, role } = useMemo(() => pickStationRole(client, stationId, roleId), [client, stationId, roleId]);
  // Remember what is open, so the next visit can load its candidates straight away.
  useEffect(() => {
    if (station) remember(`oi.station.${clientId}`, station.id);
    if (role) remember(`oi.role.${clientId}`, role.id);
  }, [clientId, station, role]);

  const viewAs = useViewAs();
  const previewing = viewAs && access.role === 'super_admin' && env.VITE_APP_ENV !== 'production' ? viewAs : null;
  const matrixQ = useQuery({
    queryKey: ['role_permissions'],
    enabled: Boolean(previewing),
    queryFn: async () => (await must(supabase.from('role_permissions').select('role, permission'), 'load permissions')) as { role: AppRole; permission: Permission }[],
  });
  const effectiveAccess: MyAccess = previewing
    ? { ...access, role: previewing, permissions: (matrixQ.data ?? []).filter((x) => x.role === previewing).map((x) => x.permission) }
    : access;

  const refresh = useCallback(() => {
    void qc.invalidateQueries({ queryKey: ['client', clientId] });
    void qc.invalidateQueries({ queryKey: ['rows'] });
  }, [qc, clientId]);

  if (clientQ.isLoading) return <CenterPage><Spinner /></CenterPage>;
  if (!client) {
    return (
      <CenterPage>
        <Card className="flex w-full max-w-[440px] flex-col gap-4 p-8">
          <Banner tone="bad">You do not have access to this client, or it does not exist.</Banner>
          <Link to="/" className="text-sm font-semibold text-brand underline">Back to your clients</Link>
        </Card>
      </CenterPage>
    );
  }

  const ws: Workspace = {
    access: effectiveAccess,
    client,
    station,
    role,
    roles,
    team: teamQ.data ?? [],
    tz: client.client_settings?.time_zone ?? station?.time_zone ?? 'America/New_York',
    can: permissionOf(effectiveAccess),
    on: (f) => featureOn(client.client_settings?.features, f),
    openApp,
    refresh,
  };

  return (
    <WorkspaceProvider value={ws}>
      <div className="flex min-h-screen flex-wrap bg-canvas">
        <Sidebar
          onStation={(id) => {
            setStationId(remember(`oi.station.${clientId}`, id));
            setRoleId(remember(`oi.role.${clientId}`, ''));
          }}
          onRole={(id) => setRoleId(remember(`oi.role.${clientId}`, id))}
        />
        <main className="flex min-w-0 flex-[999_1_600px] flex-col gap-5 p-7 max-md:p-4">
          {previewing ? (
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-info-soft px-4 py-2.5 text-sm font-medium text-info">
              Viewing as {ROLE_LABEL[previewing]} (staging preview: screens and buttons only; the data is still yours).
              <button type="button" className="font-bold underline" onClick={() => setViewAs(null)}>Stop</button>
            </div>
          ) : null}
          {!role ? (
            <Banner tone="info">This station has no job role yet.{ws.can('platform.admin') ? ' Add one in Client setup → Roles and pay.' : ' Ask a Super Admin to add one.'}</Banner>
          ) : null}
          <Outlet />
        </main>
      </div>
      {openId ? <CandidatePanel applicationId={openId} onClose={() => openApp(null)} /> : null}
      {ws.on('ai_assistant') ? <AssistantButton /> : null}
      <LiveUpdates />
    </WorkspaceProvider>
  );
}

function Sidebar({ onStation, onRole }: { onStation: (id: string) => void; onRole: (id: string) => void }) {
  const w = useWorkspace();
  const navigate = useNavigate();
  const rowsQ = useRows();
  const [mobileOpen, setMobileOpen] = useState(false);
  const loc = useLocation();
  useEffect(() => setMobileOpen(false), [loc.pathname]);

  const counts: CountSource = useMemo(() => {
    const q = buildQueues(rowsQ.data ?? []);
    return {
      today: Object.values(q).reduce((a, l) => a + l.length, 0) - q.never_messaged.length,
      review: q.calls_to_review.length + q.answers_to_review.length,
      replies: q.replies_waiting.length + q.said_yes.length,
    };
  }, [rowsQ.data]);

  return (
    <aside className="flex flex-[1_0_250px] flex-col gap-4 border-r border-line bg-[#FBFAF7] p-5 md:sticky md:top-0 md:h-screen md:overflow-y-auto max-md:flex-[1_1_100%] max-md:border-b max-md:border-r-0">
      <div className="flex items-center justify-between">
        <Logo />
        <button type="button" className="rounded-lg border border-line px-3 py-1.5 text-sm font-semibold md:hidden" onClick={() => setMobileOpen((v) => !v)} aria-expanded={mobileOpen}>
          Menu
        </button>
      </div>
      <Card className="flex flex-col gap-2 p-3.5">
        <span className="text-[11px] font-bold uppercase tracking-wider text-muted">Open client</span>
        <span className="text-[15px] font-bold">{w.client.name}</span>
        <Select label="Station" value={w.station?.id ?? ''} onChange={(e) => onStation(e.target.value)}>
          {w.client.stations.map((s) => (
            <option key={s.id} value={s.id}>{`${s.code} · ${s.name}`}</option>
          ))}
        </Select>
        <Select label="Job role · separate data" value={w.role?.id ?? ''} onChange={(e) => onRole(e.target.value)}>
          {w.roles.map((r) => (
            <option key={r.id} value={r.id}>{r.name}</option>
          ))}
        </Select>
        <Button variant="default" className="min-h-[36px] text-xs" onClick={() => navigate('/')}>
          Switch client
        </Button>
      </Card>
      <nav aria-label="Main" className={`flex flex-col gap-0.5 ${mobileOpen ? '' : 'max-md:hidden'}`}>
        {NAV.filter((n) => w.can(n.need)).map((n) => {
          const c = n.count ? n.count(counts) : 0;
          return (
            <NavLink
              key={n.to}
              to={n.to}
              className={({ isActive }) =>
                `flex min-h-[40px] items-center justify-between rounded-lg px-3 text-sm font-medium ${isActive ? 'bg-brand text-white' : 'text-ink hover:bg-black/5'}`
              }
            >
              {({ isActive }) => (
                <>
                  {n.label}
                  {c > 0 ? <span className={`rounded-full px-2 text-xs font-bold ${isActive ? 'bg-white/20' : 'bg-brand-soft text-brand'}`}>{c}</span> : null}
                </>
              )}
            </NavLink>
          );
        })}
      </nav>
      <div className={`mt-auto flex flex-col gap-3 ${mobileOpen ? '' : 'max-md:hidden'}`}>
        <EmergencyStop />
        <ReportIssue />
        <div className="flex items-center gap-3">
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-ink text-xs font-bold text-white">{initials(w.access.full_name || w.access.email)}</span>
          <div className="flex min-w-0 flex-col">
            <span className="truncate text-sm font-bold">{w.access.full_name || w.access.email}</span>
            <span className="text-xs text-muted">{ROLE_LABEL[w.access.role]} · {easternClock()}</span>
          </div>
        </div>
        <Button variant="ghost" onClick={() => void supabase.auth.signOut()}>Sign out</Button>
      </div>
    </aside>
  );
}

function EmergencyStop() {
  const w = useWorkspace();
  const toast = useToast();
  const qc = useQueryClient();
  const [confirm, setConfirm] = useState(false);
  const stopQ = useQuery({
    queryKey: ['flag', 'emergency_stop'],
    queryFn: async () => {
      const d = await must(supabase.from('feature_flags').select('enabled').eq('key', 'emergency_stop').maybeSingle(), 'load the emergency stop');
      return Boolean((d as { enabled?: boolean } | null)?.enabled);
    },
    refetchInterval: 60_000,
  });
  const on = Boolean(stopQ.data);
  const m = useMutation({
    mutationFn: (v: boolean) => rpc('set_emergency_stop', { p_on: v }),
    onSuccess: (_d, v) => {
      void qc.invalidateQueries({ queryKey: ['flag'] });
      toast(v ? 'Emergency stop is ON. Automated texts and calls are paused.' : 'Emergency stop is OFF. Automation resumes.');
      setConfirm(false);
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  if (!w.can('settings.edit')) return on ? <Banner tone="bad">Emergency stop is ON: automated texts and AI calls are paused.</Banner> : null;
  return (
    <>
      <button
        type="button"
        onClick={() => setConfirm(true)}
        className={`flex min-h-[40px] items-center justify-center gap-2 rounded-xl border px-3 text-sm font-bold ${on ? 'border-bad bg-bad text-white' : 'border-[#EBC6BF] bg-bad-soft text-bad'}`}
      >
        {on ? '■ Emergency stop is ON' : 'Emergency stop'}
      </button>
      <Modal
        open={confirm}
        title={on ? 'Turn the emergency stop off?' : 'Stop all automation?'}
        onClose={() => setConfirm(false)}
        footer={
          <>
            <Button onClick={() => setConfirm(false)}>Cancel</Button>
            <Button variant={on ? 'primary' : 'danger'} disabled={m.isPending} onClick={() => m.mutate(!on)}>
              {on ? 'Resume automation' : 'Stop everything'}
            </Button>
          </>
        }
      >
        <p className="text-sm leading-relaxed">
          {on
            ? 'Automated texts, reminders, AI calls and bulk sends start again for every client.'
            : 'This pauses every automated text, reminder, AI call and bulk send for EVERY client right away. Manual work (one-off texts and calls by a person) continues. It is recorded in the activity log.'}
        </p>
      </Modal>
    </>
  );
}

function ReportIssue() {
  const w = useWorkspace();
  const toast = useToast();
  const loc = useLocation();
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [priority, setPriority] = useState<'p0' | 'p1' | 'p2'>('p2');
  const m = useMutation({
    mutationFn: async () =>
      must(
        supabase.from('bug_reports').insert({
          client_id: w.client.id,
          reporter_id: w.access.user_id,
          priority,
          title: title.trim(),
          description: desc.trim(),
          page: loc.pathname,
        }),
        'send the report',
      ),
    onSuccess: () => {
      toast('Thanks — the issue was reported.');
      setOpen(false);
      setTitle('');
      setDesc('');
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  return (
    <>
      <Button variant="default" className="min-h-[36px] text-xs" onClick={() => setOpen(true)}>Report an issue</Button>
      <Modal
        open={open}
        title="Report an issue"
        onClose={() => setOpen(false)}
        footer={
          <>
            <Button onClick={() => setOpen(false)}>Cancel</Button>
            <Button variant="primary" disabled={title.trim().length < 3 || m.isPending} onClick={() => m.mutate()}>Send report</Button>
          </>
        }
      >
        <Field label="What went wrong?" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={140} />
        <TextArea label="Details (what you clicked, what you expected)" value={desc} onChange={(e) => setDesc(e.target.value)} maxLength={4000} />
        <Select label="How bad is it?" value={priority} onChange={(e) => setPriority(e.target.value as 'p0' | 'p1' | 'p2')}>
          <option value="p0">P0 · Everyone is blocked or data is wrong</option>
          <option value="p1">P1 · Something important does not work</option>
          <option value="p2">P2 · Small problem or annoyance</option>
        </Select>
        <span className="text-xs text-muted">Page: {loc.pathname}. Do not paste passwords or personal data here.</span>
      </Modal>
    </>
  );
}
