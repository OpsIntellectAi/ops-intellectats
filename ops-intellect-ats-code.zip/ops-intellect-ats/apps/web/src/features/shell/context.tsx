import { useQuery, useQueryClient } from '@tanstack/react-query';
import { createContext, useCallback, useContext, type ReactNode } from 'react';
import { useSearchParams } from 'react-router-dom';
import { must } from '@/lib/api';
import { can as canDo, type MyAccess, type Permission } from '@/lib/roles';
import { supabase } from '@/lib/supabase';
import type { AppRow, TeamMember } from '@/lib/types';
import type { FeatureKey } from '@/lib/features';

export interface Station {
  id: string;
  code: string;
  name: string;
  address: string | null;
  time_zone: string;
}
export interface JobRole {
  id: string;
  name: string;
  station_id: string;
  pay_text: string | null;
  min_age: number | null;
  days_per_week: string | null;
  scheduling_link: string | null;
  training_location: string | null;
  shift_text: string | null;
  schedule_text: string | null;
}
export interface ClientSettings {
  time_zone: string;
  contact_name: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  a2p_campaign_status: string;
  auto_text_time: string;
  quiet_start: string;
  quiet_end: string;
  recording_retention_days: number;
  rejected_retention_months: number;
  auto_shortlist: boolean;
  aedt_enabled: boolean;
  aedt_bias_audit_date: string | null;
  max_ai_attempts_per_day: number;
  max_ai_attempts_total: number;
  twilio_messaging_service_sid: string | null;
  dashboard_widgets: string[];
  go_live_checklist: Record<string, boolean>;
  features: Record<string, boolean>;
  reject_reasons: string[];
  not_interested_reasons: string[];
  best_call_start: string;
  best_call_end: string;
}
export interface ClientDetail {
  id: string;
  name: string;
  slug: string;
  is_live: boolean;
  stations: Station[];
  job_roles: JobRole[];
  client_settings: ClientSettings | null;
}

export interface Workspace {
  access: MyAccess;
  client: ClientDetail;
  station: Station | null;
  role: JobRole | null;
  roles: JobRole[];
  team: TeamMember[];
  tz: string;
  can: (p: Permission) => boolean;
  /** Super Admin feature toggles for this client. Missing = ON. */
  on: (f: FeatureKey) => boolean;
  openApp: (applicationId: string | null) => void;
  refresh: () => void;
}

const Ctx = createContext<Workspace | null>(null);

export function WorkspaceProvider({ value, children }: { value: Workspace; children: ReactNode }) {
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useWorkspace(): Workspace {
  const v = useContext(Ctx);
  if (!v) throw new Error('useWorkspace outside a client');
  return v;
}

/** Loaders shared by the hooks below and by the start-up warm-up (lib/warmup.ts). */
export async function fetchClientDetail(clientId: string): Promise<ClientDetail | null> {
  const data = await must(
    supabase
      .from('clients')
      .select('id, name, slug, is_live, stations(id, code, name, address, time_zone), job_roles(id, name, station_id, pay_text, min_age, days_per_week, scheduling_link, training_location, shift_text, schedule_text), client_settings(*)')
      .eq('id', clientId)
      .maybeSingle(),
    'load this client',
  );
  if (!data) return null;
  const d = data as unknown as ClientDetail & { client_settings: ClientSettings | ClientSettings[] | null };
  const settings = Array.isArray(d.client_settings) ? (d.client_settings[0] ?? null) : d.client_settings;
  return { ...d, client_settings: settings, stations: [...d.stations].sort((a, b) => a.code.localeCompare(b.code)) };
}

export async function fetchTeam(clientId: string): Promise<TeamMember[]> {
  return (await must(supabase.rpc('client_team', { p_client: clientId }), 'load the team')) as TeamMember[];
}

export async function fetchRows(clientId: string, roleId: string): Promise<AppRow[]> {
  return (await must(
    supabase.from('application_rows').select('*').eq('client_id', clientId).eq('job_role_id', roleId).order('applied_at', { ascending: false }).limit(5000),
    'load candidates',
  )) as AppRow[];
}

export const rowsKey = (clientId: string, roleId: string | null | undefined) => ['rows', clientId, roleId ?? 'none'] as const;

/** Which station and job role are open: the last one picked on this computer, else the first. */
export function pickStationRole(client: ClientDetail | null, stationId: string, roleId: string) {
  const station = client?.stations.find((s) => s.id === stationId) ?? client?.stations[0] ?? null;
  const roles = client?.job_roles.filter((r) => r.station_id === station?.id).sort((a, b) => a.name.localeCompare(b.name)) ?? [];
  const role = roles.find((r) => r.id === roleId) ?? roles[0] ?? null;
  return { station, roles, role };
}

export function useClientDetail(clientId: string) {
  return useQuery({ queryKey: ['client', clientId], queryFn: () => fetchClientDetail(clientId) });
}

export function useTeam(clientId: string) {
  return useQuery({ queryKey: ['team', clientId], queryFn: () => fetchTeam(clientId) });
}

/** Every application of the open job role, filtered by the database to what this person may see. */
export function useRows() {
  const { client, role } = useWorkspace();
  return useQuery({
    queryKey: rowsKey(client.id, role?.id),
    enabled: Boolean(role),
    queryFn: () => fetchRows(client.id, role?.id ?? ''),
  });
}

export function useInvalidate() {
  const qc = useQueryClient();
  return useCallback(() => {
    void qc.invalidateQueries({ queryKey: ['rows'] });
    void qc.invalidateQueries({ queryKey: ['app'] });
    void qc.invalidateQueries({ queryKey: ['calls'] });
    void qc.invalidateQueries({ queryKey: ['messages'] });
  }, [qc]);
}

export function useOpenApp() {
  const [params, setParams] = useSearchParams();
  const openId = params.get('app');
  const openApp = useCallback(
    (id: string | null) => {
      setParams(
        (p) => {
          const n = new URLSearchParams(p);
          if (id) n.set('app', id);
          else n.delete('app');
          return n;
        },
        { replace: false },
      );
    },
    [setParams],
  );
  return { openId, openApp };
}

export function permissionOf(access: MyAccess) {
  return (p: Permission) => canDo(access, p);
}

export function ownerName(team: TeamMember[], id: string | null): string {
  if (!id) return 'Unassigned';
  return team.find((t) => t.user_id === id)?.full_name ?? 'Someone else';
}
