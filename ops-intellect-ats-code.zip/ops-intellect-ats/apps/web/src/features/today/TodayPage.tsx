import { useMemo, useState } from 'react';
import { Banner, Button, Chip, Spinner } from '@/components/ui';
import { Empty, PageHeader, Stat } from '@/components/kit';
import { easternClock, formatPhone } from '@/lib/format';
import { buildQueues, QUEUES, type QueueKey } from '@/lib/queues';
import { relative } from '@/lib/time';
import { useRows, useWorkspace } from '@/features/shell/context';
import { CandidateTable } from '@/features/candidates/CandidatesPage';
import { useQueuedJobs } from '@/features/messages/queued';

export function TodayPage() {
  const w = useWorkspace();
  const rowsQ = useRows();
  const queues = useMemo(() => buildQueues(rowsQ.data ?? []), [rowsQ.data]);
  const [open, setOpen] = useState<QueueKey | null>(null);
  const queued = useQueuedJobs();
  const rows = rowsQ.data ?? [];
  const today = new Date().toISOString().slice(0, 10);
  const kpi = {
    newToday: rows.filter((r) => r.applied_at.slice(0, 10) === today).length,
    callsToday: rows.filter((r) => r.last_call_at?.slice(0, 10) === today).length,
    replies: queues.replies_waiting.length + queues.said_yes.length + queues.shared_email.length,
    review: queues.calls_to_review.length + queues.answers_to_review.length,
  };
  return (
    <div className="flex flex-col gap-5">
      <PageHeader eyebrow={`${w.client.name} · ${w.station?.code ?? ''} · ${w.role?.name ?? ''} · ${easternClock()}`} title="Today" />
      {rowsQ.isLoading ? <Spinner /> : null}
      <div className="grid grid-cols-[repeat(auto-fit,minmax(170px,1fr))] gap-3">
        <Stat label="New applicants today" value={kpi.newToday} />
        <Stat label="Called today" value={kpi.callsToday} />
        <Stat label="Replies to handle" value={kpi.replies} tone={kpi.replies ? 'warn' : 'neutral'} />
        <Stat label="To review" value={kpi.review} tone={kpi.review ? 'warn' : 'neutral'} sub="AI calls and unclear answers" />
        <Stat label="Automatic texts queued" value={queued.data ?? '—'} sub="Waiting for the sending window" />
      </div>
      <div className="grid grid-cols-[repeat(auto-fit,minmax(300px,1fr))] gap-3">
        {QUEUES.filter((q) => q.key !== 'never_messaged').map((q) => {
          const list = queues[q.key];
          return (
            <div key={q.key} className={`flex flex-col gap-2 rounded-card border bg-white p-4 ${list.length ? 'border-line' : 'border-line opacity-70'}`}>
              <div className="flex items-center justify-between gap-2">
                <span className="text-[15px] font-bold">{q.label}</span>
                <Chip tone={list.length ? 'warn' : 'neutral'}>{list.length}</Chip>
              </div>
              <span className="text-xs text-muted">{q.hint}</span>
              {list.slice(0, 3).map((r) => (
                <button key={r.id} type="button" onClick={() => w.openApp(r.id)} className="flex items-center justify-between rounded-lg bg-canvas px-3 py-2 text-left text-sm hover:bg-brand-soft">
                  <span className="font-semibold">{r.full_name}</span>
                  <span className="text-xs text-muted">{r.last_in_at ? relative(r.last_in_at) : formatPhone(r.phone_e164)}</span>
                </button>
              ))}
              {list.length > 3 ? (
                <Button variant="ghost" className="min-h-[32px] text-xs" onClick={() => setOpen(open === q.key ? null : q.key)}>
                  {open === q.key ? 'Hide list' : `See all ${list.length}`}
                </Button>
              ) : null}
            </div>
          );
        })}
      </div>
      {open ? (
        <div className="flex flex-col gap-2">
          <span className="text-[15px] font-bold">{QUEUES.find((q) => q.key === open)?.label}</span>
          <CandidateTable rows={queues[open]} compact />
        </div>
      ) : null}
      {!rowsQ.isLoading && rows.length === 0 ? <Empty>No candidates for this job role yet.</Empty> : null}
      {queues.never_messaged.length ? <Banner tone="info">{queues.never_messaged.length} candidates have never been texted. The first automatic text goes at the client’s set time in their local time.</Banner> : null}
    </div>
  );
}
