import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Banner, Button, Card, CenterPage, Field, Logo, Spinner } from '@/components/ui';
import { Modal, Select, useToast } from '@/components/kit';
import { friendlyError, rpc } from '@/lib/api';
import { easternClock, filterClients, initials, type ClientSummary } from '@/lib/format';
import { can, ROLE_LABEL, type MyAccess } from '@/lib/roles';
import { supabase } from '@/lib/supabase';

/**
 * Shows ONLY the clients this person was given (the database filters the list; the
 * screen cannot ask for others). One client is opened at a time.
 */
export function ClientPickerPage({ access }: { access: MyAccess }) {
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const [adding, setAdding] = useState(false);
  const clientsQ = useQuery({
    queryKey: ['clients'],
    queryFn: async (): Promise<ClientSummary[]> => {
      const { data, error } = await supabase
        .from('clients')
        .select('id, name, stations(code, name)')
        .order('name');
      if (error) throw new Error('Could not load your clients.');
      return (data ?? []).map((c) => ({ id: c.id, name: c.name, stations: c.stations ?? [] }));
    },
  });

  const all = useMemo(() => clientsQ.data ?? [], [clientsQ.data]);
  const shown = useMemo(() => filterClients(all, q), [all, q]);

  // Only one client? Open it straight away.
  useEffect(() => {
    if (all.length === 1 && all[0]) navigate(`/c/${all[0].id}`, { replace: true });
  }, [all, navigate]);

  return (
    <CenterPage>
      <Card className="flex w-full max-w-[560px] flex-col gap-5 p-8">
        <div className="flex items-start justify-between gap-3">
          <Logo />
          <span className="text-xs text-muted">{easternClock()}</span>
        </div>
        <div className="flex flex-col gap-1">
          <h1 className="font-serif text-4xl leading-tight">Choose a client</h1>
          <p className="text-sm text-muted">
            Signed in as <b className="text-ink">{access.full_name || access.email}</b> · {ROLE_LABEL[access.role]}. One client is open at a time.
          </p>
        </div>
        {clientsQ.isLoading ? <Spinner /> : null}
        {clientsQ.isError ? <Banner tone="bad">Could not load your clients. Refresh the page.</Banner> : null}
        {all.length > 3 ? (
          <div className="flex flex-col gap-1.5">
            <input
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search clients by name or station"
              aria-label="Search clients"
              className="min-h-[44px] rounded-xl border border-line px-3 text-[15px] outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"
            />
            <span className="text-xs text-muted">
              {q ? `Showing ${shown.length} of ${all.length} clients` : `You have access to ${all.length} clients`}
            </span>
          </div>
        ) : null}
        <div className="flex max-h-[52vh] flex-col gap-2.5 overflow-y-auto p-0.5">
          {shown.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => navigate(`/c/${c.id}`)}
              aria-label={`Open ${c.name}`}
              className="flex items-center gap-3.5 rounded-2xl border border-line bg-white p-4 text-left transition-colors hover:border-brand focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand"
            >
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-sm font-bold text-brand">
                {initials(c.name)}
              </span>
              <span className="flex min-w-0 flex-1 flex-col gap-0.5">
                <span className="text-[15px] font-bold">{c.name}</span>
                <span className="truncate text-[13px] text-muted">
                  {c.stations.map((s) => `${s.code} · ${s.name}`).join('  ·  ') || 'No stations yet'}
                </span>
              </span>
              <span className="text-sm font-semibold text-brand">Open</span>
            </button>
          ))}
          {!clientsQ.isLoading && all.length === 0 ? (
            <Banner tone="info">You have no client yet. A Super Admin gives client access.</Banner>
          ) : null}
          {all.length > 0 && shown.length === 0 ? <p className="text-sm text-muted">No client matches “{q}”.</p> : null}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {can(access, 'platform.admin') ? (
            <Button onClick={() => setAdding(true)}>+ Add a client</Button>
          ) : null}
          <Button variant="ghost" className="ml-auto" onClick={() => void supabase.auth.signOut()}>
            Sign out
          </Button>
        </div>
      </Card>
      {adding ? <AddClientModal onClose={() => setAdding(false)} onCreated={(id) => navigate(`/c/${id}/setup`)} /> : null}
    </CenterPage>
  );
}

const ZONES = ['America/New_York', 'America/Chicago', 'America/Denver', 'America/Phoenix', 'America/Los_Angeles', 'America/Anchorage', 'Pacific/Honolulu'];

/** Super Admin only (the server checks too). Creates the client, its first station and default settings. */
function AddClientModal({ onClose, onCreated }: { onClose: () => void; onCreated: (id: string) => void }) {
  const toast = useToast();
  const qc = useQueryClient();
  const [v, setV] = useState({ name: '', slug: '', tz: 'America/New_York', code: '', station: '', address: '' });
  const slug = v.slug || v.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60);
  const ok = v.name.trim().length >= 2 && /^[a-z0-9-]{2,60}$/.test(slug) && /^[A-Z0-9-]{2,12}$/.test(v.code) && v.station.trim().length >= 2;
  const m = useMutation({
    mutationFn: () => rpc<string>('create_client', { p_name: v.name.trim(), p_slug: slug, p_time_zone: v.tz, p_station_code: v.code, p_station_name: v.station.trim(), p_station_address: v.address || null }),
    onSuccess: (id) => {
      void qc.invalidateQueries({ queryKey: ['clients'] });
      toast('Client added. Finish the setup steps next.');
      onCreated(id);
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  return (
    <Modal
      open
      title="Add a client"
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" disabled={!ok || m.isPending} onClick={() => m.mutate()}>Add client</Button>
        </>
      }
    >
      <Field label="Company name" value={v.name} onChange={(e) => setV({ ...v, name: e.target.value })} />
      <Field label="Short name for links" value={slug} onChange={(e) => setV({ ...v, slug: e.target.value.toLowerCase() })} />
      <Select label="Time zone" value={v.tz} onChange={(e) => setV({ ...v, tz: e.target.value })}>
        {ZONES.map((z) => (
          <option key={z}>{z}</option>
        ))}
      </Select>
      <div className="grid grid-cols-[120px_1fr] gap-3">
        <Field label="Station code" value={v.code} onChange={(e) => setV({ ...v, code: e.target.value.toUpperCase() })} placeholder="NL1" />
        <Field label="Station name" value={v.station} onChange={(e) => setV({ ...v, station: e.target.value })} />
      </div>
      <Field label="Station address (optional)" value={v.address} onChange={(e) => setV({ ...v, address: e.target.value })} />
      <span className="text-xs text-muted">Default onboarding steps, automatic texts, reminders, templates and alert rules are created. Nobody else sees this client until you give them access.</span>
    </Modal>
  );
}
