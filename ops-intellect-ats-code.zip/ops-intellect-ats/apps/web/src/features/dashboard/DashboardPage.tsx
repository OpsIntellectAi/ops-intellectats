import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { Button, Spinner } from '@/components/ui';
import { Bar, Checkbox, Modal, PageHeader, Select, Stat, useToast } from '@/components/kit';
import { friendlyError, must, rpc } from '@/lib/api';
import { downloadText, toCsv } from '@/lib/csv';
import { bySource, callOutcomes, callsPerDay, contactHealth, daysInStage, funnel, inPeriod, kpis, type Metric } from '@/lib/dashboard';
import { formatPhone, STAGE_LABEL } from '@/lib/format';
import { supabase } from '@/lib/supabase';
import type { AppRow } from '@/lib/types';
import { ownerName, useRows, useWorkspace } from '@/features/shell/context';
import { CandidateTable } from '@/features/candidates/CandidatesPage';
import { useCalls } from '@/features/calls/CallsPage';

const WIDGETS: { key: string; label: string }[] = [
  { key: 'kpis', label: 'Key numbers' },
  { key: 'funnel', label: 'Hiring funnel' },
  { key: 'calls_per_day', label: 'Calls per day' },
  { key: 'contact_health', label: 'Contact health' },
  { key: 'onboarding', label: 'Onboarding steps' },
  { key: 'sources', label: 'Sources' },
  { key: 'days_in_stage', label: 'Days in each stage' },
  { key: 'call_outcomes', label: 'Call outcomes' },
];

export function DashboardPage() {
  const w = useWorkspace();
  const rowsQ = useRows();
  const callsQ = useCalls();
  const [days, setDays] = useState(30);
  const [drill, setDrill] = useState<Metric | null>(null);
  const [custom, setCustom] = useState(false);
  const now = Date.now();
  const from = now - days * 86_400_000;
  const rows = useMemo(() => rowsQ.data ?? [], [rowsQ.data]);
  const inWindow = useMemo(() => rows.filter((r) => inPeriod(r.applied_at, from, now + 1)), [rows, from, now]);
  const widgets = w.client.client_settings?.dashboard_widgets ?? WIDGETS.map((x) => x.key);
  const show = (k: string) => widgets.includes(k);
  const calls = (callsQ.data ?? []).filter((c) => inPeriod(c.started_at ?? c.created_at, from, now + 1));
  const perDay = callsPerDay(calls, Math.min(days, 14), w.tz);
  const perDayMax = Math.max(1, ...perDay.map((d) => d.ai + d.csr));
  const onb = rows.filter((r) => r.stage === 'onboarding');

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        eyebrow={`${w.client.name} · ${w.station?.code ?? ''} · ${w.role?.name ?? ''}`}
        title="Dashboard"
        right={
          <>
            <Select aria-label="Period" value={days} onChange={(e) => setDays(Number(e.target.value))}>
              <option value={7}>Last 7 days</option>
              <option value={30}>Last 30 days</option>
              <option value={90}>Last 90 days</option>
              <option value={3650}>All time</option>
            </Select>
            {w.can('settings.edit') ? <Button className="min-h-[40px]" onClick={() => setCustom(true)}>Customize</Button> : null}
          </>
        }
      />
      {rowsQ.isLoading ? <Spinner /> : null}
      {show('kpis') ? (
        <div className="grid grid-cols-[repeat(auto-fit,minmax(150px,1fr))] gap-3">
          {kpis(rows, from, now + 1).map((m) => (
            <Stat key={m.label} label={m.label} value={m.value} onClick={() => setDrill(m)} />
          ))}
        </div>
      ) : null}
      <div className="grid gap-4 lg:grid-cols-2">
        {show('funnel') ? (
          <Panel title="Hiring funnel" sub="People who applied in the period">
            {funnel(inWindow).map((m, i, all) => (
              <Row key={m.label} label={m.label} value={m.value} max={all[0]?.value ?? 1} onClick={() => setDrill(m)} extra={i > 0 && (all[i - 1]?.value ?? 0) > 0 ? `${Math.round((m.value / (all[i - 1]?.value ?? 1)) * 100)}%` : undefined} />
            ))}
          </Panel>
        ) : null}
        {show('contact_health') ? (
          <Panel title="Contact health">
            {contactHealth(rows).map((m) => (
              <Row key={m.label} label={m.label} value={m.value} max={rows.length} onClick={() => setDrill(m)} />
            ))}
          </Panel>
        ) : null}
        {show('calls_per_day') ? (
          <Panel title="Calls per day" sub="AI and phone calls">
            {perDay.map((d) => (
              <Row key={d.day} label={d.day.slice(5)} value={d.ai + d.csr} max={perDayMax} extra={`${d.ai} AI · ${d.csr} phone`} />
            ))}
          </Panel>
        ) : null}
        {show('call_outcomes') ? (
          <Panel title="Call outcomes">
            {callOutcomes(calls).map((o) => (
              <Row key={o.label} label={o.label} value={o.value} max={calls.length} />
            ))}
            {!calls.length ? <span className="text-sm text-muted">No calls in this period.</span> : null}
          </Panel>
        ) : null}
        {show('sources') ? (
          <Panel title="Sources">
            {bySource(inWindow).map((m) => (
              <Row key={m.label} label={m.label} value={m.value} max={inWindow.length} onClick={() => setDrill(m)} />
            ))}
          </Panel>
        ) : null}
        {show('days_in_stage') ? (
          <Panel title="Days in each stage" sub="Average for people in that stage now">
            {daysInStage(rows).map((d) => (
              <Row key={d.stage} label={STAGE_LABEL[d.stage]} value={d.avg} max={Math.max(1, ...daysInStage(rows).map((x) => x.avg))} extra={`${d.rows.length} people`} onClick={() => setDrill({ label: STAGE_LABEL[d.stage], value: d.rows.length, rows: d.rows })} />
            ))}
          </Panel>
        ) : null}
        {show('onboarding') ? (
          <Panel title="Onboarding" sub={`${onb.length} people in onboarding`}>
            {[
              { label: 'All required steps done', rows: onb.filter((r) => r.required_left === 0) },
              { label: '1–3 steps left', rows: onb.filter((r) => r.required_left > 0 && r.required_left <= 3) },
              { label: '4+ steps left', rows: onb.filter((r) => r.required_left > 3) },
            ].map((m) => (
              <Row key={m.label} label={m.label} value={m.rows.length} max={onb.length} onClick={() => setDrill({ label: m.label, value: m.rows.length, rows: m.rows })} />
            ))}
          </Panel>
        ) : null}
      </div>
      {drill ? <Drill metric={drill} onClose={() => setDrill(null)} /> : null}
      {custom ? <Customize current={widgets} onClose={() => setCustom(false)} /> : null}
    </div>
  );
}

function Panel({ title, sub, children }: { title: string; sub?: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-3 rounded-card border border-line bg-white p-4">
      <div className="flex flex-col">
        <span className="text-[15px] font-bold">{title}</span>
        {sub ? <span className="text-xs text-muted">{sub}</span> : null}
      </div>
      {children}
    </div>
  );
}

function Row({ label, value, max, onClick, extra }: { label: string; value: number; max: number; onClick?: () => void; extra?: string }) {
  const Tag = onClick ? 'button' : 'div';
  return (
    <Tag type={onClick ? 'button' : undefined} onClick={onClick} className={`flex flex-col gap-1 text-left ${onClick ? 'rounded-lg hover:bg-canvas' : ''}`}>
      <span className="flex justify-between gap-2 text-sm">
        <span>{label}</span>
        <span className="font-semibold">
          {value} {extra ? <span className="text-xs font-normal text-muted">· {extra}</span> : null}
        </span>
      </span>
      <Bar value={value} max={max} />
    </Tag>
  );
}

function Drill({ metric, onClose }: { metric: Metric; onClose: () => void }) {
  const w = useWorkspace();
  const download = (rows: AppRow[]) => {
    downloadText(
      `${w.client.slug}-${metric.label.replace(/\s+/g, '-').toLowerCase()}.csv`,
      toCsv(rows.map((r) => ({ name: r.full_name, phone: formatPhone(r.phone_e164), stage: STAGE_LABEL[r.stage], owner: ownerName(w.team, r.owner_id), source: r.source, applied: r.applied_at }))),
    );
    void rpc('log_action', { p_action: 'CSV exported', p_client: w.client.id, p_label: `Dashboard · ${metric.label}`, p_rows: rows.length });
  };
  return (
    <Modal open wide title={`${metric.label} · ${metric.rows.length}`} onClose={onClose} footer={<><Button onClick={() => download(metric.rows)}>Download CSV</Button><Button onClick={onClose}>Close</Button></>}>
      {metric.rows.length ? <CandidateTable rows={metric.rows} compact /> : <span className="text-sm text-muted">Nobody.</span>}
    </Modal>
  );
}

function Customize({ current, onClose }: { current: string[]; onClose: () => void }) {
  const w = useWorkspace();
  const toast = useToast();
  const qc = useQueryClient();
  const [sel, setSel] = useState<string[]>(current);
  const m = useMutation({
    mutationFn: async () => must(supabase.from('client_settings').update({ dashboard_widgets: sel }).eq('client_id', w.client.id).select('client_id'), 'save the dashboard'),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['client', w.client.id] });
      toast('Dashboard saved for everyone in this client.');
      onClose();
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  return (
    <Modal open title="Customize the dashboard" onClose={onClose} footer={<><Button onClick={onClose}>Cancel</Button><Button variant="primary" disabled={m.isPending} onClick={() => m.mutate()}>Save</Button></>}>
      {WIDGETS.map((x) => (
        <Checkbox key={x.key} label={x.label} checked={sel.includes(x.key)} onChange={(v) => setSel(v ? [...sel, x.key] : sel.filter((k) => k !== x.key))} />
      ))}
    </Modal>
  );
}
