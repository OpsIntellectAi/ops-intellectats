import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { callFunction, must } from '@/lib/api';
import { supabase } from '@/lib/supabase';
import type { Message } from '@/lib/types';

/** Only the texts of one conversation: one small query, refreshed live (and every 20 s as a fallback). */
export function useMessages(applicationId: string | null) {
  return useQuery({
    queryKey: ['msgs', applicationId],
    enabled: Boolean(applicationId),
    refetchInterval: 20_000,
    staleTime: 5_000,
    queryFn: async () =>
      (await must(
        supabase
          .from('messages')
          .select('id, application_id, direction, body, status, topics, is_automatic, sent_by, error_code, created_at')
          .eq('application_id', applicationId ?? '')
          .order('created_at'),
        'load messages',
      )) as Message[],
  });
}

export interface SendResult {
  queued: number;
  skipped: { id: string; reason: string }[];
  sentNow: number;
}

/**
 * Sends a text. The bubble shows straight away ("sending…"); the real row replaces it when the
 * server answers. Only the lists that changed are reloaded.
 */
export function useSendText() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (v: { ids: string[]; body: string; confirmBulk: boolean }) =>
      callFunction<SendResult>('send-sms', { applicationIds: v.ids, body: v.body, confirmBulk: v.confirmBulk }),
    onMutate: async (v) => {
      if (v.ids.length !== 1) return;
      const id = v.ids[0] as string;
      await qc.cancelQueries({ queryKey: ['msgs', id] });
      const temp: Message = {
        id: `temp-${Date.now()}`,
        application_id: id,
        direction: 'outbound',
        body: v.body,
        status: 'sending',
        topics: [],
        is_automatic: false,
        sent_by: null,
        error_code: null,
        created_at: new Date().toISOString(),
      };
      qc.setQueryData<Message[]>(['msgs', id], (old) => [...(old ?? []), temp]);
    },
    onSettled: (_d, _e, v) => {
      for (const id of v.ids.slice(0, 50)) void qc.invalidateQueries({ queryKey: ['msgs', id] });
      void qc.invalidateQueries({ queryKey: ['rows'] });
    },
  });
}
