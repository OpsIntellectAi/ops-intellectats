import { useState } from 'react';
import { Modal, TextArea, useToast } from '@/components/kit';
import { Button } from '@/components/ui';
import { visibleTemplates } from '@/lib/rules';
import type { Stage } from '@/lib/format';
import type { AppRow } from '@/lib/types';
import { useTemplates } from '@/features/candidates/data';
import { useWorkspace } from '@/features/shell/context';
import { useSendText, type SendResult } from './data';


const SKIP_REASON: Record<string, string> = {
  opted_out: 'opted out',
  landline: 'landline',
  no_sms_consent: 'no SMS consent',
  paused_not_interested: 'not interested for now',
};

/**
 * Text one or many candidates. Placeholders ([first name], [role], [client], [link]) are
 * filled on the server for each person. Texts wait for the candidate's sending window.
 */
export function Composer({ rows, onSent, backgroundPassed = false }: { rows: AppRow[]; onSent?: () => void; backgroundPassed?: boolean }) {
  const w = useWorkspace();
  const toast = useToast();
  const tq = useTemplates(w.client.id);
  const [body, setBody] = useState('');
  const [confirm, setConfirm] = useState(false);
  const stages = [...new Set(rows.map((r) => r.stage))] as Stage[];
  const only = stages.length === 1 ? stages[0] : undefined;
  const templates = only ? visibleTemplates(tq.data ?? [], only, backgroundPassed) : [];
  const sendable = rows.filter((r) => !r.opted_out_at && !r.is_landline);

  const send = useSendText();
  const onSent2 = (r: SendResult) => {
      if (r.queued === 1 && r.sentNow === 1 && !r.skipped.length) {
        setConfirm(false);
        onSent?.();
        return;
      }
      const skipped = r.skipped.length
        ? ` ${r.skipped.length} skipped (${[...new Set(r.skipped.map((s) => SKIP_REASON[s.reason] ?? s.reason))].join(', ')}).`
        : '';
      const waiting = r.queued - r.sentNow;
      toast(`${r.queued} text${r.queued === 1 ? '' : 's'} queued${waiting > 0 ? `, ${waiting} waiting for their sending window` : ''}.${skipped}`);
      setConfirm(false);
      onSent?.();
  };
  const m = {
    isPending: send.isPending,
    mutate: (confirmBulk: boolean) => {
      const text = body.trim();
      setBody('');
      send.mutate(
        { ids: sendable.map((r) => r.id), body: text, confirmBulk },
        {
          onSuccess: onSent2,
          onError: (e) => {
            setBody(text);
            toast(e instanceof Error ? e.message : 'Could not send.', 'bad');
          },
        },
      );
    },
  };

  if (!w.can('messages.send')) return null;
  if (rows.length > 1 && !w.on('bulk_texts')) return <span className="text-sm text-muted">Bulk texts are turned off for this client.</span>;
  if (!sendable.length) {
    return <span className="text-sm text-muted">No one here can be texted (opted out or landline).</span>;
  }
  const send2 = () => (sendable.length > 30 && !confirm ? setConfirm(true) : m.mutate(sendable.length > 30));

  return (
    <div className="flex flex-col gap-2">
      {templates.length ? (
        <div className="flex flex-wrap gap-1.5">
          {templates.map((t) => (
            <button key={t.id} type="button" onClick={() => setBody(t.body)} className="min-h-[32px] rounded-full border border-line bg-canvas px-3 text-xs font-semibold hover:border-brand">
              {t.name}
            </button>
          ))}
        </div>
      ) : null}
      <TextArea
        aria-label="Text message"
        value={body}
        maxLength={640}
        placeholder="Write a text… [first name], [role], [client] and [link] are filled in for each person."
        onChange={(e) => setBody(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && (e.ctrlKey || e.metaKey) && body.trim().length >= 2 && !m.isPending) send2();
        }}
        className="min-h-[72px]"
      />
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="text-xs text-muted">
          {body.length}/640 · Ctrl+Enter to send · never sent 8 PM–8 AM their time{rows.length !== sendable.length ? ` · ${rows.length - sendable.length} can't be texted` : ''}
        </span>
        <Button variant="primary" className="min-h-[40px]" disabled={body.trim().length < 2 || m.isPending} onClick={send2}>
          {m.isPending ? 'Sending…' : sendable.length > 1 ? `Text ${sendable.length} people` : 'Send text'}
        </Button>
      </div>
      <Modal
        open={confirm}
        title={`Text ${sendable.length} people?`}
        onClose={() => setConfirm(false)}
        footer={
          <>
            <Button onClick={() => setConfirm(false)}>Cancel</Button>
            <Button variant="primary" disabled={m.isPending} onClick={() => m.mutate(true)}>Yes, text {sendable.length}</Button>
          </>
        }
      >
        <p className="text-sm">Bulk texts over 30 people are flagged in the activity log. Each person gets their own copy with their name filled in.</p>
      </Modal>
    </div>
  );
}

/** Human words for a text's delivery status. */
export function statusLabel(s: string): string {
  const map: Record<string, string> = {
    queued: 'waiting to send',
    test_sent: 'test mode · not sent',
    blocked_not_allowlisted: 'not sent · staging texts only test phones',
    blocked_a2p: 'not sent · A2P campaign not approved',
    blocked_not_live: 'not sent · client not live yet',
    cancelled: 'cancelled',
    received: '',
    sending: 'sending…',
  };
  return map[s] ?? s;
}
