import { useState } from 'react';
import { Modal } from '@/components/kit';
import { Button } from '@/components/ui';
import type { AppRow } from '@/lib/types';
import { Composer } from './Composer';

/** "Text N" on the Candidates list. */
export function BulkMessageButton({ rows, onDone }: { rows: AppRow[]; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button className="min-h-[40px]" onClick={() => setOpen(true)}>Text {rows.length}</Button>
      <Modal open={open} wide title={`Text ${rows.length} selected`} onClose={() => setOpen(false)}>
        <Composer rows={rows} onSent={() => { setOpen(false); onDone(); }} />
      </Modal>
    </>
  );
}
