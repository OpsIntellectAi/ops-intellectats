import { useQuery } from '@tanstack/react-query';
import { useWorkspace } from '@/features/shell/context';
import { supabase } from '@/lib/supabase';

/** Number of automatic texts waiting in the queue for this client (server counts; RLS-safe RPC). */
export function useQueuedJobs() {
  const w = useWorkspace();
  return useQuery({
    queryKey: ['queued', w.client.id],
    queryFn: async () => {
      const { data, error } = await supabase.rpc('queued_job_count', { p_client: w.client.id });
      if (error) return null;
      return data as number;
    },
    refetchInterval: 60_000,
  });
}
