import { useMutation } from '@tanstack/react-query';
import { useEffect, useRef, useState } from 'react';
import { Empty } from '@/components/kit';
import { Button, Spinner } from '@/components/ui';
import { callFunction } from '@/lib/api';
import { dateTimeIn } from '@/lib/time';
import type { AppRow } from '@/lib/types';
import { useWorkspace } from '@/features/shell/context';
import { Composer, statusLabel } from './Composer';
import { useMessages } from './data';

const TOPIC: Record<string, string> = {
  said_yes: 'said yes',
  shared_email: 'shared email',
  background_check: 'background check',
  drug_test: 'drug test',
  offer_letter: 'offer letter',
  reschedule: 'wants a new time',
  opted_out: 'STOP',
};

/** Conversation with one candidate, an AI overview, and the text box. Live: new texts appear by themselves. */
export function ChatBox({ row, backgroundPassed = false, tall = false }: { row: AppRow; backgroundPassed?: boolean; tall?: boolean }) {
  const w = useWorkspace();
  const q = useMessages(row.id);
  const messages = q.data ?? [];
  const end = useRef<HTMLDivElement>(null);
  const [overview, setOverview] = useState<string | null>(null);
  useEffect(() => {
    setOverview(null);
  }, [row.id]);
  useEffect(() => {
    end.current?.scrollIntoView?.({ block: 'nearest' });
  }, [messages.length, row.id]);
  const ov = useMutation({
    mutationFn: () => callFunction<{ overview: string }>('ai-text', { action: 'overview', applicationId: row.id }),
    onSuccess: (r) => setOverview(r.overview),
    onError: (e) => setOverview(e instanceof Error ? e.message : 'Could not get an overview.'),
  });
  return (
    <div className="flex flex-col gap-2 rounded-card border border-line bg-white p-4">
      <div className="flex items-center justify-between gap-2">
        <span className="text-sm font-bold">Conversation <span className="font-normal text-muted">· {messages.length} text{messages.length === 1 ? '' : 's'}</span></span>
        {messages.length && w.on('ai_overview') ? (
          <Button variant="ghost" className="min-h-[32px] px-2 text-xs" disabled={ov.isPending} onClick={() => ov.mutate()}>
            {ov.isPending ? 'Reading…' : 'AI overview'}
          </Button>
        ) : null}
      </div>
      {overview ? <p className="rounded-lg bg-info-soft p-2 text-sm"><b>Overview · </b>{overview}</p> : null}
      {q.isLoading ? <Spinner /> : null}
      {!q.isLoading && messages.length === 0 ? <Empty>No texts yet.</Empty> : null}
      <div className={`flex flex-col gap-2 overflow-y-auto pr-1 ${tall ? 'min-h-[320px] max-h-[calc(100vh-380px)]' : 'max-h-[420px]'}`}>
        {messages.map((m) => (
          <div key={m.id} className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm ${m.direction === 'inbound' ? 'self-start bg-canvas' : 'self-end bg-brand-soft'} ${m.status === 'sending' ? 'opacity-60' : ''}`}>
            <span className="whitespace-pre-wrap">{m.body}</span>
            <div className="mt-1 text-[11px] text-muted">
              {dateTimeIn(m.created_at, row.time_zone || w.tz)}
              {m.direction === 'outbound' ? ` · ${m.is_automatic ? 'automatic' : 'sent'}${statusLabel(m.status) ? ` · ${statusLabel(m.status)}` : ''}` : ''}
              {m.direction === 'inbound' && m.topics?.length ? ` · ${m.topics.map((t) => TOPIC[t] ?? t).join(', ')}` : ''}
            </div>
          </div>
        ))}
        <div ref={end} />
      </div>
      {row.opted_out_at ? (
        <span className="text-sm text-bad">Opted out (STOP). No texts until they text START.</span>
      ) : (
        <Composer rows={[row]} backgroundPassed={backgroundPassed} />
      )}
    </div>
  );
}
