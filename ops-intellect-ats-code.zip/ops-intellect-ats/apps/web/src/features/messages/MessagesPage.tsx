import { useMemo, useState } from 'react';
import { Chip, Spinner } from '@/components/ui';
import { Empty, PageHeader } from '@/components/kit';
import { formatPhone, initials, STAGE_LABEL } from '@/lib/format';
import { noReplyDays } from '@/lib/queues';
import { aiCallView, lastMessageView, nextStep } from '@/lib/rowview';
import { relative } from '@/lib/time';
import type { AppRow } from '@/lib/types';
import { ownerName, useRows, useWorkspace } from '@/features/shell/context';
import { RowActions } from '@/features/candidates/RowActions';
import { StatusPill, useQueuedCalls } from '@/features/candidates/CandidatesPage';
import { ChatBox } from './ChatBox';

type Topic = 'all' | 'waiting' | 'said_yes' | 'shared_email' | 'background_check' | 'drug_test' | 'offer_letter' | 'no_reply' | 'opted_out';
const TOPICS: { key: Topic; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'waiting', label: 'Needs reply' },
  { key: 'said_yes', label: 'Said yes' },
  { key: 'shared_email', label: 'Shared email' },
  { key: 'background_check', label: 'Background check' },
  { key: 'drug_test', label: 'Drug test' },
  { key: 'offer_letter', label: 'Offer letter' },
  { key: 'no_reply', label: 'No reply' },
  { key: 'opted_out', label: 'Opted out' },
];

const waiting = (r: AppRow) => Boolean(r.last_in_at && (!r.last_out_at || r.last_in_at > r.last_out_at));

export function topicMatch(r: AppRow, t: Topic): boolean {
  if (t === 'all') return r.in_count > 0 || r.out_count > 0;
  if (t === 'waiting') return waiting(r) && !r.opted_out_at;
  if (t === 'no_reply') return (noReplyDays(r) ?? 0) >= 1;
  if (t === 'opted_out') return Boolean(r.opted_out_at);
  return Boolean(r.last_topics?.includes(t));
}

export function MessagesPage() {
  const w = useWorkspace();
  const rowsQ = useRows();
  const queuedQ = useQueuedCalls();
  const [topic, setTopic] = useState<Topic>('all');
  const [q, setQ] = useState('');
  const [sel, setSel] = useState<string | null>(null);
  const rows = useMemo(() => rowsQ.data ?? [], [rowsQ.data]);
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    const digits = s.replace(/\D/g, '');
    return rows
      .filter((r) => topicMatch(r, topic))
      .filter((r) => !s || r.full_name.toLowerCase().includes(s) || (digits.length >= 3 && r.phone_e164.includes(digits)) || (r.last_body ?? '').toLowerCase().includes(s))
      .sort((a, b) => (b.last_at ?? '').localeCompare(a.last_at ?? ''));
  }, [rows, topic, q]);
  const current = rows.find((r) => r.id === (sel ?? list[0]?.id)) ?? null;
  return (
    <div className="flex flex-col gap-4">
      <PageHeader eyebrow={`${w.client.name} · ${w.station?.code ?? ''} · ${w.role?.name ?? ''}`} title="Messages" />
      <div role="tablist" className="flex flex-wrap gap-1 rounded-xl bg-[#EFECE5] p-1">
        {TOPICS.map((t) => {
          const n = rows.filter((r) => topicMatch(r, t.key)).length;
          return (
            <button
              key={t.key}
              type="button"
              role="tab"
              aria-selected={topic === t.key}
              onClick={() => { setTopic(t.key); setSel(null); }}
              className={`flex min-h-[36px] items-center gap-1.5 rounded-lg px-3 text-sm font-semibold ${topic === t.key ? 'bg-white text-ink shadow-sm' : 'text-muted hover:text-ink'}`}
            >
              {t.label}
              <span className={`rounded-full px-1.5 text-xs ${t.key === 'waiting' && n ? 'bg-info text-white' : topic === t.key ? 'bg-brand-soft text-brand' : 'bg-white/70'}`}>{n}</span>
            </button>
          );
        })}
      </div>
      {rowsQ.isLoading ? <Spinner /> : null}
      <div className="grid gap-4 lg:grid-cols-[minmax(300px,380px)_1fr]">
        <div className="flex flex-col gap-2">
          <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, phone or text" aria-label="Search conversations" className="min-h-[42px] rounded-xl border border-line bg-white px-3 text-sm outline-none focus:border-brand" />
          <div className="flex max-h-[calc(100vh-260px)] min-h-[300px] flex-col gap-1.5 overflow-y-auto pr-1">
            {list.length === 0 && !rowsQ.isLoading ? <Empty>No conversations here.</Empty> : null}
            {list.map((r) => {
              const lm = lastMessageView(r);
              const isOpen = current?.id === r.id;
              return (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => setSel(r.id)}
                  className={`flex gap-3 rounded-xl border p-3 text-left ${isOpen ? 'border-brand bg-white shadow-sm' : 'border-line bg-white/70 hover:bg-white'}`}
                >
                  <span className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-soft text-sm font-bold text-brand">
                    {initials(r.full_name)}
                    {waiting(r) ? <span className="absolute -right-0.5 -top-0.5 h-3 w-3 rounded-full border-2 border-white bg-info" aria-label="Needs reply" /> : null}
                  </span>
                  <span className="flex min-w-0 flex-1 flex-col gap-0.5">
                    <span className="flex items-center justify-between gap-2">
                      <span className={`truncate text-sm ${waiting(r) ? 'font-bold' : 'font-semibold'}`}>{r.full_name}</span>
                      <span className="shrink-0 text-[11px] text-muted">{relative(r.last_at)}</span>
                    </span>
                    <span className={`truncate text-xs ${waiting(r) ? 'font-semibold text-ink' : 'text-muted'}`}>{lm.label}</span>
                    <span className="flex flex-wrap gap-1">
                      <span className="text-[11px] text-muted">{STAGE_LABEL[r.stage]}</span>
                      {r.opted_out_at ? <Chip tone="bad">STOP</Chip> : null}
                      {r.said_yes_at && r.stage === 'interview' ? <span className="rounded bg-[#EEE8F8] px-1.5 text-[11px] font-semibold text-[#5B3F99]">Said yes</span> : null}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
        {current ? <Conversation row={current} queuedAt={queuedQ.data?.get(current.id) ?? null} /> : <Empty>Pick a conversation.</Empty>}
      </div>
    </div>
  );
}

function Conversation({ row, queuedAt }: { row: AppRow; queuedAt: string | null }) {
  const w = useWorkspace();
  const ai = aiCallView(row, queuedAt, w.tz);
  return (
    <div className="flex min-w-0 flex-col gap-3">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-card border border-line bg-white p-4">
        <div className="flex min-w-0 items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-brand-soft font-bold text-brand">{initials(row.full_name)}</span>
          <div className="flex min-w-0 flex-col">
            <span className="text-[17px] font-bold">{row.full_name}</span>
            <span className="text-xs text-muted">{formatPhone(row.phone_e164)} · {STAGE_LABEL[row.stage]} · {ownerName(w.team, row.owner_id)} · next: {nextStep(row).text}</span>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <StatusPill tone={ai.tone}>AI call: {ai.label}</StatusPill>
          <RowActions row={row} />
          <button type="button" className="text-sm font-semibold text-brand underline" onClick={() => w.openApp(row.id)}>Open candidate</button>
        </div>
      </div>
      {row.last_call_summary ? <p className="rounded-xl bg-info-soft px-3 py-2 text-sm"><b>Last call overview · </b>{row.last_call_summary}</p> : null}
      <ChatBox row={row} tall />
    </div>
  );
}
