import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { Banner, Button, Chip, Field, Spinner } from '@/components/ui';
import { Checkbox, Empty, Modal, PageHeader, Select, Tabs, useToast } from '@/components/kit';
import { callFunction, friendlyError, must, rpc } from '@/lib/api';
import { downloadText, toCsv } from '@/lib/csv';
import { env } from '@/lib/env';
import { ROLE_LABEL, ROLE_SCOPE, type AppRole, type Permission } from '@/lib/roles';
import { supabase } from '@/lib/supabase';
import { dateTimeIn, relative } from '@/lib/time';
import { useWorkspace } from '@/features/shell/context';
import { setViewAs, useViewAs } from '@/features/shell/viewAs';

type Tab = 'users' | 'permissions' | 'activity' | 'devices' | 'features' | 'issues';
const ROLES: AppRole[] = ['csr', 'supervisor', 'admin', 'super_admin', 'ops', 'station_manager', 'dsp_manager', 'viewer'];

export function AdminPage() {
  const w = useWorkspace();
  const tabs: { key: Tab; label: string }[] = [
    ...(w.can('users.manage') ? [{ key: 'users' as const, label: 'Users & access' }] : []),
    { key: 'permissions', label: 'Permissions' },
    { key: 'activity', label: 'Activity log' },
    ...(w.can('audit.view_all') ? [{ key: 'devices' as const, label: 'Computers' }, { key: 'issues' as const, label: 'Reported issues' }] : []),
    ...(w.can('platform.admin') ? [{ key: 'features' as const, label: 'Feature switches' }] : []),
  ];
  const [tab, setTab] = useState<Tab>(tabs[0]?.key ?? 'permissions');
  return (
    <div className="flex flex-col gap-4">
      <PageHeader eyebrow={w.client.name} title="Users & activity" />
      <Tabs<Tab> value={tab} onChange={setTab} tabs={tabs} />
      {tab === 'users' ? <UsersTab /> : null}
      {tab === 'permissions' ? <PermissionsTab /> : null}
      {tab === 'activity' ? <ActivityTab /> : null}
      {tab === 'devices' ? <DevicesTab /> : null}
      {tab === 'features' ? <FeaturesTab /> : null}
      {tab === 'issues' ? <IssuesTab /> : null}
    </div>
  );
}

// ---------------- Users & access ----------------
interface Person {
  id: string;
  full_name: string;
  email: string;
  role: AppRole;
  status: 'pending' | 'active' | 'disabled';
  invited_by: string | null;
}
interface Access {
  id: string;
  user_id: string;
  client_id: string;
  station_ids: string[] | null;
}
interface ClientLite {
  id: string;
  name: string;
  stations: { id: string; code: string }[];
}

function UsersTab() {
  const w = useWorkspace();
  const toast = useToast();
  const qc = useQueryClient();
  const isSuper = w.can('platform.admin');
  const [invite, setInvite] = useState(false);
  const [edit, setEdit] = useState<Person | null>(null);
  const [q, setQ] = useState('');

  const peopleQ = useQuery({
    queryKey: ['people'],
    queryFn: async () => (await must(supabase.from('profiles').select('id, full_name, email, role, status, invited_by').order('full_name'), 'load users')) as Person[],
  });
  const accessQ = useQuery({
    queryKey: ['uca'],
    queryFn: async () => (await must(supabase.from('user_client_access').select('id, user_id, client_id, station_ids'), 'load access')) as Access[],
  });
  const clientsQ = useQuery({
    queryKey: ['clients-lite'],
    queryFn: async () => (await must(supabase.from('clients').select('id, name, stations(id, code)').order('name'), 'load clients')) as ClientLite[],
  });
  const teamsQ = useQuery({
    queryKey: ['teams'],
    queryFn: async () => (await must(supabase.from('teams').select('id, supervisor_id, csr_id'), 'load teams')) as { id: string; supervisor_id: string; csr_id: string }[],
  });

  const people = (peopleQ.data ?? []).filter((p) => !q || `${p.full_name} ${p.email}`.toLowerCase().includes(q.toLowerCase()));
  const clientName = (id: string) => clientsQ.data?.find((c) => c.id === id)?.name ?? 'Client';

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-end gap-2">
        <label className="flex min-w-[220px] flex-1 flex-col gap-1 text-xs font-semibold text-[#3D403D]">
          Search people
          <input value={q} onChange={(e) => setQ(e.target.value)} className="min-h-[40px] rounded-lg border border-line px-2 text-sm" />
        </label>
        <Button variant="primary" onClick={() => setInvite(true)}>+ Add a user</Button>
      </div>
      {!isSuper ? <Banner tone="info">You can add users and set levels below Admin. Only a Super Admin gives client access, so new people see no client until then.</Banner> : null}
      {peopleQ.isLoading ? <Spinner /> : null}
      <div className="overflow-x-auto rounded-card border border-line bg-white">
        <table className="w-full min-w-[760px] text-left text-sm">
          <thead className="border-b border-line bg-[#FBFAF7] text-xs font-semibold text-muted">
            <tr>
              <th className="px-3 py-2">Person</th>
              <th className="px-3 py-2">Level</th>
              <th className="px-3 py-2">Status</th>
              <th className="px-3 py-2">Clients</th>
              <th className="px-3 py-2">Supervisor</th>
              <th className="px-3 py-2" />
            </tr>
          </thead>
          <tbody>
            {people.map((p) => {
              const acc = (accessQ.data ?? []).filter((a) => a.user_id === p.id);
              const sup = (teamsQ.data ?? []).find((t) => t.csr_id === p.id);
              return (
                <tr key={p.id} className="border-b border-line last:border-0">
                  <td className="px-3 py-2">
                    <div className="font-semibold">{p.full_name || '—'}</div>
                    <div className="text-xs text-muted">{p.email}</div>
                  </td>
                  <td className="px-3 py-2">{ROLE_LABEL[p.role]}</td>
                  <td className="px-3 py-2"><Chip tone={p.status === 'active' ? 'ok' : p.status === 'pending' ? 'warn' : 'bad'}>{p.status}</Chip></td>
                  <td className="px-3 py-2">
                    <div className="flex flex-wrap gap-1">
                      {acc.length ? acc.map((a) => <Chip key={a.id}>{clientName(a.client_id)}{a.station_ids ? ` · ${a.station_ids.length} station${a.station_ids.length > 1 ? 's' : ''}` : ''}</Chip>) : <span className="text-xs text-muted">No client</span>}
                    </div>
                  </td>
                  <td className="px-3 py-2 text-xs">{sup ? (peopleQ.data ?? []).find((x) => x.id === sup.supervisor_id)?.full_name ?? '—' : '—'}</td>
                  <td className="px-3 py-2 text-right">
                    {p.id !== w.access.user_id && (isSuper || !['admin', 'super_admin'].includes(p.role)) ? (
                      <Button className="min-h-[34px] text-xs" onClick={() => setEdit(p)}>Manage</Button>
                    ) : null}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {invite ? <InviteModal onClose={() => setInvite(false)} onDone={() => void qc.invalidateQueries({ queryKey: ['people'] })} /> : null}
      {edit ? (
        <ManageUser
          person={edit}
          access={(accessQ.data ?? []).filter((a) => a.user_id === edit.id)}
          clients={clientsQ.data ?? []}
          people={peopleQ.data ?? []}
          teams={teamsQ.data ?? []}
          onClose={() => setEdit(null)}
          onSaved={(msg) => {
            toast(msg);
            void qc.invalidateQueries({ queryKey: ['people'] });
            void qc.invalidateQueries({ queryKey: ['uca'] });
            void qc.invalidateQueries({ queryKey: ['teams'] });
            void qc.invalidateQueries({ queryKey: ['team'] });
          }}
        />
      ) : null}
    </div>
  );
}

function InviteModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const w = useWorkspace();
  const toast = useToast();
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<AppRole>('csr');
  const [link, setLink] = useState<string | null>(null);
  const allowed = ROLES.filter((r) => w.can('platform.admin') || !['admin', 'super_admin'].includes(r));
  const m = useMutation({
    mutationFn: () => callFunction<{ link: string | null }>('manage-users', { action: 'invite', email, fullName: name, role, redirectOrigin: window.location.origin }),
    onSuccess: (res) => {
      setLink(res.link);
      onDone();
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  return (
    <Modal
      open
      title="Add a user"
      onClose={onClose}
      footer={
        link ? (
          <Button variant="primary" onClick={onClose}>Done</Button>
        ) : (
          <>
            <Button onClick={onClose}>Cancel</Button>
            <Button variant="primary" disabled={m.isPending || name.trim().length < 2 || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.trim())} onClick={() => m.mutate()}>Create invite</Button>
          </>
        )
      }
    >
      {link ? (
        <>
          <Banner tone="ok">Account created. Send this one-time link to {name} (it works once). They choose their password when they open it.</Banner>
          <textarea readOnly value={link} className="min-h-[90px] rounded-xl border border-line p-2 text-xs" aria-label="Invite link" />
          <Button onClick={() => void navigator.clipboard.writeText(link).then(() => toast('Link copied.'))}>Copy link</Button>
          <span className="text-xs text-muted">{w.can('platform.admin') ? 'Next: give them client access (Manage).' : 'A Super Admin must give them client access before they see any data.'}</span>
        </>
      ) : (
        <>
          <Field label="Full name" value={name} onChange={(e) => setName(e.target.value)} />
          <Field label="Work email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Select label="Level" value={role} onChange={(e) => setRole(e.target.value as AppRole)}>
            {allowed.map((r) => (
              <option key={r} value={r}>{ROLE_LABEL[r]}</option>
            ))}
          </Select>
          <span className="text-xs text-muted">{ROLE_SCOPE[role]}.{['admin', 'super_admin'].includes(role) ? ' They must set up two-step verification on first sign-in.' : ''}</span>
        </>
      )}
    </Modal>
  );
}

function ManageUser({
  person,
  access,
  clients,
  people,
  teams,
  onClose,
  onSaved,
}: {
  person: Person;
  access: Access[];
  clients: ClientLite[];
  people: Person[];
  teams: { id: string; supervisor_id: string; csr_id: string }[];
  onClose: () => void;
  onSaved: (msg: string) => void;
}) {
  const w = useWorkspace();
  const toast = useToast();
  const isSuper = w.can('platform.admin');
  const [role, setRole] = useState<AppRole>(person.role);
  const [status, setStatus] = useState(person.status);
  const [addClient, setAddClient] = useState('');
  const [stations, setStations] = useState<string[]>([]);
  const sup = teams.find((t) => t.csr_id === person.id);
  const [supervisor, setSupervisor] = useState(sup?.supervisor_id ?? '');
  const allowed = ROLES.filter((r) => isSuper || !['admin', 'super_admin'].includes(r));

  const saveLevel = useMutation({
    mutationFn: () => rpc('set_user_role', { p_user: person.id, p_role: role, p_status: status }),
    onSuccess: () => onSaved('Level saved.'),
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  const grant = useMutation({
    mutationFn: async () =>
      must(
        supabase.from('user_client_access').insert({
          user_id: person.id,
          client_id: addClient,
          station_ids: role === 'station_manager' || stations.length ? stations : null,
          granted_by: w.access.user_id,
        }),
        'give access',
      ),
    onSuccess: () => {
      setAddClient('');
      setStations([]);
      onSaved('Client access given.');
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  const revoke = useMutation({
    mutationFn: async (id: string) => must(supabase.from('user_client_access').delete().eq('id', id), 'remove access'),
    onSuccess: () => onSaved('Client access removed.'),
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  const saveTeam = useMutation({
    mutationFn: async () => {
      if (sup) await must(supabase.from('teams').delete().eq('id', sup.id), 'update the team');
      if (supervisor) await must(supabase.from('teams').insert({ supervisor_id: supervisor, csr_id: person.id }), 'update the team');
    },
    onSuccess: () => onSaved('Supervisor saved.'),
    onError: (e) => toast(friendlyError(e), 'bad'),
  });

  const chosen = clients.find((c) => c.id === addClient);
  const supervisors = people.filter((p) => p.role === 'supervisor' && p.status === 'active');

  return (
    <Modal open wide title={`Manage ${person.full_name || person.email}`} onClose={onClose} footer={<Button onClick={onClose}>Close</Button>}>
      <div className="flex flex-col gap-2 rounded-xl border border-line p-3">
        <span className="text-sm font-bold">Level and status</span>
        <div className="flex flex-wrap items-end gap-2">
          <Select label="Level" value={role} onChange={(e) => setRole(e.target.value as AppRole)}>
            {allowed.map((r) => (
              <option key={r} value={r}>{ROLE_LABEL[r]}</option>
            ))}
          </Select>
          <Select label="Status" value={status} onChange={(e) => setStatus(e.target.value as Person['status'])}>
            <option value="active">Active</option>
            <option value="pending">Pending</option>
            <option value="disabled">Turned off</option>
          </Select>
          <Button variant="primary" className="min-h-[40px]" disabled={saveLevel.isPending || (role === person.role && status === person.status)} onClick={() => saveLevel.mutate()}>Save level</Button>
        </div>
        <span className="text-xs text-muted">{ROLE_SCOPE[role]}</span>
      </div>

      <div className="flex flex-col gap-2 rounded-xl border border-line p-3">
        <span className="text-sm font-bold">Client access</span>
        <div className="flex flex-wrap gap-2">
          {access.map((a) => {
            const c = clients.find((x) => x.id === a.client_id);
            return (
              <span key={a.id} className="flex items-center gap-1 rounded-full bg-[#EFECE5] px-3 py-1 text-xs font-semibold">
                {c?.name ?? 'Client'}
                {a.station_ids ? ` · ${a.station_ids.map((s) => c?.stations.find((x) => x.id === s)?.code ?? '?').join(', ')}` : ' · all stations'}
                {isSuper ? (
                  <button type="button" aria-label="Remove access" className="ml-1 text-bad" onClick={() => revoke.mutate(a.id)}>✕</button>
                ) : null}
              </span>
            );
          })}
          {!access.length ? <span className="text-xs text-muted">No client yet.</span> : null}
        </div>
        {isSuper ? (
          <div className="flex flex-col gap-2">
            <Select label="Give access to a client" value={addClient} onChange={(e) => { setAddClient(e.target.value); setStations([]); }}>
              <option value="">Choose a client…</option>
              {clients.filter((c) => !access.some((a) => a.client_id === c.id)).map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </Select>
            {chosen ? (
              <div className="flex flex-col gap-1">
                <span className="text-xs font-semibold text-muted">{role === 'station_manager' ? 'Stations (required for a Station Manager)' : 'Stations (leave empty for all stations)'}</span>
                <div className="flex flex-wrap gap-3">
                  {chosen.stations.map((s) => (
                    <Checkbox key={s.id} label={s.code} checked={stations.includes(s.id)} onChange={(v) => setStations(v ? [...stations, s.id] : stations.filter((x) => x !== s.id))} />
                  ))}
                </div>
                <Button variant="primary" className="self-start" disabled={grant.isPending || (role === 'station_manager' && stations.length === 0)} onClick={() => grant.mutate()}>Give access</Button>
              </div>
            ) : null}
          </div>
        ) : (
          <span className="text-xs text-muted">Only a Super Admin gives or removes client access.</span>
        )}
      </div>

      {person.role === 'csr' ? (
        <div className="flex flex-col gap-2 rounded-xl border border-line p-3">
          <span className="text-sm font-bold">Supervisor</span>
          <div className="flex flex-wrap items-end gap-2">
            <Select label="Reports to" value={supervisor} onChange={(e) => setSupervisor(e.target.value)}>
              <option value="">Nobody</option>
              {supervisors.map((s) => (
                <option key={s.id} value={s.id}>{s.full_name}</option>
              ))}
            </Select>
            <Button className="min-h-[40px]" disabled={saveTeam.isPending || supervisor === (sup?.supervisor_id ?? '')} onClick={() => saveTeam.mutate()}>Save supervisor</Button>
          </div>
        </div>
      ) : null}
    </Modal>
  );
}

// ---------------- Permissions ----------------
const PERM_LABEL: { key: Permission; label: string }[] = [
  { key: 'view', label: 'See candidates, calls, messages, dashboard of their scope' },
  { key: 'candidates.act', label: 'AI call / phone candidates, move stages, add or upload applicants' },
  { key: 'messages.send', label: 'Text candidates (single, bulk, reminders)' },
  { key: 'onboarding.update', label: 'Update onboarding steps, mark DSP invite sent, move to Onboarding/Hired' },
  { key: 'calls.review', label: 'Review AI calls and unclear answers' },
  { key: 'reports.view', label: 'Team board, AI insights, reports (view)' },
  { key: 'assistant.use', label: 'AI recruitment assistant (own scope)' },
  { key: 'candidates.assign', label: 'Assign candidates to CSRs' },
  { key: 'audit.view', label: 'Activity log (Supervisor: own team)' },
  { key: 'audit.view_all', label: 'All users’ activity, devices, export log' },
  { key: 'templates.edit', label: 'Add/edit message templates' },
  { key: 'settings.edit', label: 'Customize dashboard, automatic messages, client info, emergency stop' },
  { key: 'reports.manage', label: 'Weekly client report, alert rules, hiring targets, AI training pack' },
  { key: 'users.manage', label: 'Add users and set levels below Admin' },
  { key: 'platform.admin', label: 'Admins, client setup, AI script, add client, feature switches, client access, block device' },
];

function PermissionsTab() {
  const w = useWorkspace();
  const viewAs = useViewAs();
  const matrixQ = useQuery({
    queryKey: ['role_permissions'],
    queryFn: async () => (await must(supabase.from('role_permissions').select('role, permission'), 'load permissions')) as { role: AppRole; permission: Permission }[],
  });
  const has = (r: AppRole, p: Permission) => Boolean(matrixQ.data?.some((x) => x.role === r && x.permission === p));
  const canViewAs = w.access.role === 'super_admin' && env.VITE_APP_ENV !== 'production';
  return (
    <div className="flex flex-col gap-4">
      {canViewAs ? (
        <div className="flex flex-wrap items-end gap-2 rounded-card border border-line bg-white p-3">
          <Select label="View as (staging only: screens and buttons, your data stays the same)" value={viewAs ?? ''} onChange={(e) => setViewAs((e.target.value || null) as AppRole | null)}>
            <option value="">Myself (Super Admin)</option>
            {ROLES.filter((r) => r !== 'super_admin').map((r) => (
              <option key={r} value={r}>{ROLE_LABEL[r]}</option>
            ))}
          </Select>
          <span className="text-xs text-muted">To test what the database lets each level see, sign in as that person.</span>
        </div>
      ) : null}
      <div className="grid grid-cols-[repeat(auto-fit,minmax(220px,1fr))] gap-3">
        {ROLES.map((r) => (
          <div key={r} className={`flex flex-col gap-1 rounded-card border bg-white p-4 ${w.access.role === r ? 'border-brand' : 'border-line'}`}>
            <span className="text-[15px] font-bold">{ROLE_LABEL[r]}</span>
            <span className="text-sm text-muted">{ROLE_SCOPE[r]}</span>
          </div>
        ))}
      </div>
      <div className="overflow-x-auto rounded-card border border-line bg-white">
        <table className="w-full min-w-[900px] text-left text-sm">
          <thead className="border-b border-line bg-[#FBFAF7] text-xs font-semibold text-muted">
            <tr>
              <th className="px-3 py-2">Permission</th>
              {ROLES.map((r) => (
                <th key={r} className="px-2 py-2 text-center">{ROLE_LABEL[r]}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {PERM_LABEL.map((p) => (
              <tr key={p.key} className="border-b border-line last:border-0">
                <td className="px-3 py-2">{p.label}</td>
                {ROLES.map((r) => (
                  <td key={r} className="px-2 py-2 text-center">{has(r, p.key) ? <span className="font-bold text-brand" aria-label="allowed">✓</span> : <span className="text-[#C9C5BC]" aria-label="not allowed">—</span>}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <span className="text-xs text-muted">This table is read from the database. The database and server enforce it; the screen only hides buttons.</span>
    </div>
  );
}

// ---------------- Activity log ----------------
interface AuditRow {
  id: number;
  occurred_at: string;
  actor_id: string | null;
  actor_role: AppRole | null;
  client_id: string | null;
  action: string;
  target_type: string | null;
  target_label: string | null;
  before_value: string | null;
  after_value: string | null;
  device_key: string | null;
  ip: string | null;
  flagged: boolean;
  flag_reason: string | null;
}

function ActivityTab() {
  const w = useWorkspace();
  const [flagged, setFlagged] = useState(false);
  const [search, setSearch] = useState('');
  const [limit, setLimit] = useState(200);
  const logQ = useQuery({
    queryKey: ['audit', w.client.id, flagged, limit],
    queryFn: async () => {
      let qb = supabase
        .from('audit_log')
        .select('id, occurred_at, actor_id, actor_role, client_id, action, target_type, target_label, before_value, after_value, device_key, ip, flagged, flag_reason')
        .or(`client_id.eq.${w.client.id},client_id.is.null`)
        .order('id', { ascending: false })
        .limit(limit);
      if (flagged) qb = qb.eq('flagged', true);
      return (await must(qb, 'load the activity log')) as AuditRow[];
    },
  });
  const peopleQ = useQuery({
    queryKey: ['people-lite'],
    queryFn: async () => (await must(supabase.from('profiles').select('id, full_name'), 'load people')) as { id: string; full_name: string }[],
  });
  const who = (id: string | null) => (id ? peopleQ.data?.find((p) => p.id === id)?.full_name ?? 'User' : 'System');
  const rows = useMemo(
    () => (logQ.data ?? []).filter((r) => !search || `${r.action} ${r.target_label ?? ''} ${who(r.actor_id)}`.toLowerCase().includes(search.toLowerCase())),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [logQ.data, search, peopleQ.data],
  );
  const exportCsv = () => {
    downloadText(
      `${w.client.slug}-activity-log.csv`,
      toCsv(rows.map((r) => ({ time: r.occurred_at, who: who(r.actor_id), level: r.actor_role ?? '', action: r.action, target: r.target_label ?? '', before: r.before_value ?? '', after: r.after_value ?? '', ip: r.ip ?? '', device: r.device_key ?? '', flagged: r.flagged ? r.flag_reason ?? 'yes' : '' }))),
    );
    void rpc('log_action', { p_action: 'Activity log exported', p_client: w.client.id, p_label: 'Activity log', p_rows: rows.length });
  };
  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-end gap-3">
        <label className="flex min-w-[220px] flex-1 flex-col gap-1 text-xs font-semibold text-[#3D403D]">
          Search (person, action, candidate)
          <input value={search} onChange={(e) => setSearch(e.target.value)} className="min-h-[40px] rounded-lg border border-line px-2 text-sm" />
        </label>
        <Checkbox label="Flagged only" checked={flagged} onChange={setFlagged} />
        {w.can('audit.view_all') ? <Button className="min-h-[40px]" onClick={exportCsv}>Export CSV</Button> : null}
      </div>
      <span className="text-xs text-muted">The activity log cannot be edited or deleted by anyone. {w.access.role === 'supervisor' ? 'You see your own team’s actions.' : ''}</span>
      {logQ.isLoading ? <Spinner /> : null}
      {!logQ.isLoading && !rows.length ? <Empty>No activity.</Empty> : null}
      <div className="flex flex-col gap-1">
        {rows.map((r) => (
          <div key={r.id} className={`flex flex-wrap items-start justify-between gap-2 rounded-xl border bg-white p-3 text-sm ${r.flagged ? 'border-[#EBC6BF]' : 'border-line'}`}>
            <div className="flex min-w-0 flex-col">
              <span>
                <b>{who(r.actor_id)}</b> {r.actor_role ? <span className="text-muted">({ROLE_LABEL[r.actor_role]})</span> : null} · {r.action}
                {r.target_label ? ` · ${r.target_label}` : ''}
              </span>
              {r.before_value || r.after_value ? (
                <span className="truncate text-xs text-muted">{(r.before_value ?? '—').slice(0, 120)} → {(r.after_value ?? '—').slice(0, 120)}</span>
              ) : null}
              <span className="text-xs text-muted">{dateTimeIn(r.occurred_at, w.tz)} {r.ip ? `· IP ${r.ip}` : ''} {r.device_key ? `· computer …${r.device_key.slice(-6)}` : ''}</span>
            </div>
            {r.flagged ? <Chip tone="bad">{r.flag_reason ?? 'Flagged'}</Chip> : null}
          </div>
        ))}
      </div>
      {(logQ.data?.length ?? 0) >= limit ? <Button onClick={() => setLimit(limit + 200)}>Load more</Button> : null}
    </div>
  );
}

// ---------------- Computers ----------------
interface Device {
  id: string;
  user_id: string;
  device_key: string;
  label: string;
  last_ip: string | null;
  first_seen_at: string;
  last_seen_at: string;
  trusted: boolean;
  blocked: boolean;
}

function DevicesTab() {
  const w = useWorkspace();
  const toast = useToast();
  const qc = useQueryClient();
  const devQ = useQuery({
    queryKey: ['devices'],
    queryFn: async () => (await must(supabase.from('devices').select('id, user_id, device_key, label, last_ip, first_seen_at, last_seen_at, trusted, blocked').order('last_seen_at', { ascending: false }), 'load computers')) as Device[],
  });
  const peopleQ = useQuery({
    queryKey: ['people-lite'],
    queryFn: async () => (await must(supabase.from('profiles').select('id, full_name'), 'load people')) as { id: string; full_name: string }[],
  });
  const m = useMutation({
    mutationFn: async ({ d, patch }: { d: Device; patch: Partial<Device> & { blocked_by?: string | null; blocked_at?: string | null } }) =>
      must(supabase.from('devices').update(patch).eq('id', d.id).select('id'), 'update the computer'),
    onSuccess: (rows) => {
      if (Array.isArray(rows) && !rows.length) toast('Only a Super Admin can block or trust computers.', 'bad');
      else toast('Saved.');
      void qc.invalidateQueries({ queryKey: ['devices'] });
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  const canChange = w.can('platform.admin');
  return (
    <div className="flex flex-col gap-2">
      {devQ.isLoading ? <Spinner /> : null}
      {!devQ.isLoading && !(devQ.data ?? []).length ? <Empty>No computers recorded yet. They appear after people sign in.</Empty> : null}
      {(devQ.data ?? []).map((d) => (
        <div key={d.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line bg-white p-3 text-sm">
          <div className="flex flex-col">
            <span className="font-semibold">{peopleQ.data?.find((p) => p.id === d.user_id)?.full_name ?? 'User'} · {d.label}</span>
            <span className="text-xs text-muted">
              Last seen {relative(d.last_seen_at)} · IP {d.last_ip ?? '—'} · first seen {dateTimeIn(d.first_seen_at, w.tz)} · …{d.device_key.slice(-6)}
            </span>
          </div>
          <div className="flex items-center gap-2">
            {d.trusted ? <Chip tone="ok">Trusted</Chip> : null}
            {d.blocked ? <Chip tone="bad">Blocked</Chip> : null}
            {canChange ? (
              <>
                <Button className="min-h-[34px] text-xs" onClick={() => m.mutate({ d, patch: { trusted: !d.trusted } })}>{d.trusted ? 'Untrust' : 'Trust'}</Button>
                <Button
                  variant={d.blocked ? 'default' : 'danger'}
                  className="min-h-[34px] text-xs"
                  onClick={() => m.mutate({ d, patch: { blocked: !d.blocked, blocked_by: d.blocked ? null : w.access.user_id, blocked_at: d.blocked ? null : new Date().toISOString() } })}
                >
                  {d.blocked ? 'Unblock' : 'Block'}
                </Button>
              </>
            ) : null}
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------------- Feature switches ----------------
function FeaturesTab() {
  const toast = useToast();
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ['flags'],
    queryFn: async () => (await must(supabase.from('feature_flags').select('key, label, description, enabled').neq('key', 'emergency_stop').order('label'), 'load switches')) as { key: string; label: string; description: string; enabled: boolean }[],
  });
  const m = useMutation({
    mutationFn: async ({ key, enabled }: { key: string; enabled: boolean }) => must(supabase.from('feature_flags').update({ enabled }).eq('key', key).select('key'), 'save the switch'),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['flags'] });
      toast('Saved for every client.');
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  return (
    <div className="flex flex-col gap-2">
      {(q.data ?? []).map((f) => (
        <div key={f.key} className="flex items-center justify-between gap-3 rounded-xl border border-line bg-white p-3">
          <div className="flex flex-col">
            <span className="text-sm font-semibold">{f.label}</span>
            <span className="text-xs text-muted">{f.description}</span>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={f.enabled}
            aria-label={f.label}
            onClick={() => m.mutate({ key: f.key, enabled: !f.enabled })}
            className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${f.enabled ? 'bg-brand' : 'bg-[#CFCAC0]'}`}
          >
            <span className={`absolute top-1 h-5 w-5 rounded-full bg-white transition-all ${f.enabled ? 'left-6' : 'left-1'}`} />
          </button>
        </div>
      ))}
    </div>
  );
}

// ---------------- Reported issues ----------------
function IssuesTab() {
  const w = useWorkspace();
  const q = useQuery({
    queryKey: ['bugs'],
    queryFn: async () =>
      (await must(supabase.from('bug_reports').select('id, priority, title, description, page, status, created_at, reporter_id').order('created_at', { ascending: false }).limit(200), 'load issues')) as {
        id: string;
        priority: 'p0' | 'p1' | 'p2';
        title: string;
        description: string;
        page: string | null;
        status: string;
        created_at: string;
      }[],
  });
  return (
    <div className="flex flex-col gap-2">
      {!(q.data ?? []).length ? <Empty>No issues reported.</Empty> : null}
      {(q.data ?? []).map((b) => (
        <div key={b.id} className="flex flex-col gap-1 rounded-xl border border-line bg-white p-3 text-sm">
          <span className="flex items-center gap-2 font-semibold">
            <Chip tone={b.priority === 'p0' ? 'bad' : b.priority === 'p1' ? 'warn' : 'neutral'}>{b.priority.toUpperCase()}</Chip>
            {b.title}
          </span>
          {b.description ? <span className="text-muted">{b.description}</span> : null}
          <span className="text-xs text-muted">{dateTimeIn(b.created_at, w.tz)} · {b.page ?? ''} · {b.status}</span>
        </div>
      ))}
    </div>
  );
}
