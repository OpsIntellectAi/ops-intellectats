import type { CallRow } from '@/lib/types';

/** Phase 2: retries arrive with messaging + calls. */
export function RetryCallButton({ call }: { call: CallRow }) {
  return <span className="text-xs text-muted">{call.attempt_number} attempt{call.attempt_number > 1 ? 's' : ''}</span>;
}
