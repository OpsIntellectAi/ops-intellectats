import type { CallRow } from '@/lib/types';

export type CallDirection = 'all' | 'outbound' | 'inbound';
export type CallVia = 'all' | 'ai' | 'csr';

export function filterCalls(list: CallRow[], dir: CallDirection, via: CallVia): CallRow[] {
  return list.filter((c) => (dir === 'all' || c.direction === dir) && (via === 'all' || c.via === via));
}

/** The six numbers at the top of Calls by day, plus who is behind each number ("See names"). */
export function callStats(list: CallRow[]) {
  const lists = {
    total: list,
    outgoing: list.filter((c) => c.direction === 'outbound'),
    incoming: list.filter((c) => c.direction === 'inbound'),
    completed: list.filter((c) => c.outcome === 'completed'),
    voicemail: list.filter((c) => c.outcome === 'voicemail'),
  };
  const lens = lists.completed.map((c) => c.duration_seconds ?? 0).filter((n) => n > 0);
  return {
    total: list.length,
    outgoing: lists.outgoing.length,
    incoming: lists.incoming.length,
    completed: lists.completed.length,
    voicemail: lists.voicemail.length,
    avgSeconds: lens.length ? Math.round(lens.reduce((a, b) => a + b, 0) / lens.length) : 0,
    lists,
  };
}
