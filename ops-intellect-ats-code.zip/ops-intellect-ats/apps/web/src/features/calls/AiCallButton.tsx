import { useMutation, useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { Modal, useToast } from '@/components/kit';
import { Button, Field } from '@/components/ui';
import { callFunction, rpc } from '@/lib/api';
import type { AppRow } from '@/lib/types';
import type { ConsentRow } from '@/features/candidates/data';
import { hasConsent } from '@/features/candidates/data';
import { useInvalidate } from '@/features/shell/context';

/**
 * "AI call" button. The server decides (consent, stage, attempts, NYC notice, opt-out);
 * the reason is shown on the button when it is off.
 */
export function AiCallButton({ row, consents }: { row: AppRow; consents: ConsentRow[] }) {
  const toast = useToast();
  const invalidate = useInvalidate();
  const local = row.opted_out_at
    ? 'Opted out'
    : !hasConsent(consents, 'ai_call')
      ? 'No AI-call consent on file'
      : row.stage !== 'interview'
        ? 'AI interviews are for the Interview stage'
        : null;
  const q = useQuery({
    queryKey: ['ai-call-reason', row.id, row.ai_calls],
    enabled: local === null,
    queryFn: () => rpc<string | null>('ai_call_reason', { p_application: row.id }),
  });
  const reason = local ?? (q.isLoading ? 'Checking…' : q.data ?? null);
  const m = useMutation({
    mutationFn: () => callFunction<{ callId: string; attempt: number; test: boolean }>('start-ai-call', { applicationId: row.id }),
    onSuccess: (r) => {
      toast(r.test ? 'Test mode: a practice AI call was logged (no real call).' : `AI call started (attempt ${r.attempt}).`);
      invalidate();
      void q.refetch();
    },
    onError: (e) => toast(e instanceof Error ? e.message : 'Could not start the call.', 'bad'),
  });
  if (reason) {
    return (
      <Button disabled title={reason}>
        AI call <span className="text-xs font-normal">({reason})</span>
      </Button>
    );
  }
  return (
    <Button variant="primary" disabled={m.isPending} onClick={() => m.mutate()}>
      {m.isPending ? 'Calling…' : row.said_yes_at ? 'AI call now (said yes)' : 'AI call'}
    </Button>
  );
}

/** Twilio rings the recruiter first, then the candidate. Both sides hear that it is recorded. */
export function PhoneCallButton({ row }: { row: AppRow }) {
  const toast = useToast();
  const invalidate = useInvalidate();
  const [askPhone, setAskPhone] = useState(false);
  const [phone, setPhone] = useState('+1');
  const call = useMutation({
    mutationFn: () => callFunction<{ test: boolean }>('call-actions', { action: 'csr_call', applicationId: row.id }),
    onSuccess: (r) => {
      toast(r.test ? 'Test mode: the call was logged (Twilio is not set up yet).' : 'Your phone will ring now. Answer it to be connected.');
      invalidate();
    },
    onError: (e) => {
      const msg = e instanceof Error ? e.message : '';
      if (/own phone number/i.test(msg)) setAskPhone(true);
      else toast(msg || 'Could not start the call.', 'bad');
    },
  });
  const save = useMutation({
    mutationFn: () => callFunction('call-actions', { action: 'set_my_phone', phone: phone.replace(/[^\d+]/g, '') }),
    onSuccess: () => {
      setAskPhone(false);
      call.mutate();
    },
    onError: (e) => toast(e instanceof Error ? e.message : 'Could not save.', 'bad'),
  });
  return (
    <>
      <Button disabled={call.isPending} onClick={() => call.mutate()}>{call.isPending ? 'Ringing…' : 'Phone call'}</Button>
      <Modal
        open={askPhone}
        title="Which phone should ring?"
        onClose={() => setAskPhone(false)}
        footer={<><Button onClick={() => setAskPhone(false)}>Cancel</Button><Button variant="primary" disabled={save.isPending} onClick={() => save.mutate()}>Save and call</Button></>}
      >
        <p className="text-sm">Twilio rings your phone first, then the candidate. Your number is never shown to them.</p>
        <Field label="Your mobile (US)" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+12025550123" />
      </Modal>
    </>
  );
}
