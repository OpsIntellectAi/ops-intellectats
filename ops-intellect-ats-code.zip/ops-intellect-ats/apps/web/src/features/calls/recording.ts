import { callFunction } from '@/lib/api';

/** Recordings live in a private bucket; the server hands out a link that expires in 10 minutes. */
export async function recordingUrl(callId: string): Promise<string> {
  const r = await callFunction<{ url: string }>('call-actions', { action: 'recording_url', callId });
  return r.url;
}
