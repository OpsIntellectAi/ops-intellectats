import { useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { Button } from '@/components/ui';
import { Modal, Select, TextArea, useToast } from '@/components/kit';
import { friendlyError, must } from '@/lib/api';
import { supabase } from '@/lib/supabase';
import type { CallRow } from '@/lib/types';
import { useInvalidate, useWorkspace } from '@/features/shell/context';
import { recordingUrl } from './recording';

export const FLAG_REASONS = ['Heard the answer wrong', 'Asked the wrong question', 'Skipped a question', 'Talked over the candidate', 'Missing disclosure', 'Bad audio', 'Other'];

/** "Looks right" / "Flag a problem" for a finished AI call. */
export function CallReviewButtons({ call }: { call: CallRow }) {
  const w = useWorkspace();
  const toast = useToast();
  const invalidate = useInvalidate();
  const [flag, setFlag] = useState(false);
  const [reason, setReason] = useState(FLAG_REASONS[0] ?? 'Other');
  const [question, setQuestion] = useState('');
  const [note, setNote] = useState('');
  const m = useMutation({
    mutationFn: async (v: { verdict: 'looks_right' | 'flagged' }) =>
      must(
        supabase.from('call_reviews').insert({
          call_id: call.id,
          client_id: call.client_id,
          verdict: v.verdict,
          reason: v.verdict === 'flagged' ? reason : null,
          question_key: v.verdict === 'flagged' && question ? question : null,
          note: note.trim() || null,
          reviewer_id: w.access.user_id,
        }),
        'save the review',
      ),
    onSuccess: () => {
      invalidate();
      toast('Review saved.');
      setFlag(false);
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  if (!w.can('calls.review') || call.via !== 'ai' || call.outcome !== 'completed') return null;
  if (call.review_verdict) return <span className="text-xs text-muted">Reviewed: {call.review_verdict === 'looks_right' ? 'looks right' : `flagged (${call.review_reason ?? ''})`}</span>;
  return (
    <div className="flex flex-wrap gap-2">
      <Button variant="primary" className="min-h-[36px]" disabled={m.isPending} onClick={() => m.mutate({ verdict: 'looks_right' })}>Call looks right</Button>
      <Button className="min-h-[36px]" onClick={() => setFlag(true)}>Flag a problem</Button>
      <Modal
        open={flag}
        title="Flag a problem with this AI call"
        onClose={() => setFlag(false)}
        footer={
          <>
            <Button onClick={() => setFlag(false)}>Cancel</Button>
            <Button variant="danger" disabled={m.isPending} onClick={() => m.mutate({ verdict: 'flagged' })}>Flag</Button>
          </>
        }
      >
        <Select label="What went wrong" value={reason} onChange={(e) => setReason(e.target.value)}>
          {FLAG_REASONS.map((r) => (
            <option key={r}>{r}</option>
          ))}
        </Select>
        <Select label="Which question (optional)" value={question} onChange={(e) => setQuestion(e.target.value)}>
          <option value="">—</option>
          {['q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7', 'q8'].map((q) => (
            <option key={q} value={q}>{q}</option>
          ))}
        </Select>
        <TextArea label="Note (optional)" value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} />
      </Modal>
    </div>
  );
}

/** Opens the recording at the moment an answer was given (signed link, 10 minutes). */
export function PlayAnswer({ call, at }: { call: CallRow; at: number | null }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  if (!call.recording_path) return <span className="text-xs text-muted">{at != null ? `at ${Math.floor(at / 60)}:${String(at % 60).padStart(2, '0')}` : ''} · no recording</span>;
  return (
    <Button
      className="min-h-[36px]"
      disabled={busy}
      onClick={() => {
        setBusy(true);
        void recordingUrl(call.id)
          .then((url) => window.open(`${url}#t=${at ?? 0}`, '_blank', 'noopener'))
          .catch((e: unknown) => toast(friendlyError(e), 'bad'))
          .finally(() => setBusy(false));
      }}
    >
      ▶ Play this answer
    </Button>
  );
}
