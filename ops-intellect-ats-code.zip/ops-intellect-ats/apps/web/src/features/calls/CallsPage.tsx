import { useQuery } from '@tanstack/react-query';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Banner, Button, Chip, Spinner } from '@/components/ui';
import { Empty, Modal, PageHeader, Tabs, useToast } from '@/components/kit';
import { friendlyError, must, rpc } from '@/lib/api';
import { downloadText, toCsv } from '@/lib/csv';
import { condition, fillFacts, type ScriptQuestion } from '@/lib/script';
import { supabase } from '@/lib/supabase';
import { dateTimeIn, dayKey, seconds } from '@/lib/time';
import type { Answer, CallRow } from '@/lib/types';
import { ownerName, useWorkspace } from '@/features/shell/context';
import { StatusPill } from '@/features/candidates/CandidatesPage';
import { CallReviewButtons } from './CallReview';
import { recordingUrl } from './recording';
import { callStats, filterCalls, type CallDirection, type CallVia } from './stats';

type Tab = 'day' | 'review' | 'library';

export function useCalls() {
  const w = useWorkspace();
  return useQuery({
    queryKey: ['calls', w.client.id, w.role?.id],
    enabled: Boolean(w.role),
    queryFn: async () =>
      (await must(
        supabase.from('call_rows').select('*').eq('client_id', w.client.id).eq('job_role_id', w.role?.id ?? '').order('created_at', { ascending: false }).limit(2000),
        'load calls',
      )) as CallRow[],
  });
}

const OUTCOME_TONE: Record<string, 'ok' | 'warn' | 'bad' | 'info' | 'neutral'> = {
  completed: 'ok',
  in_progress: 'info',
  queued: 'info',
  voicemail: 'warn',
  no_answer: 'warn',
  busy: 'warn',
  dropped: 'warn',
  failed: 'bad',
};

export function CallsPage() {
  const w = useWorkspace();
  const callsQ = useCalls();
  const today = dayKey(new Date().toISOString(), w.tz);
  const yesterday = dayKey(new Date(Date.now() - 86_400_000).toISOString(), w.tz);
  const [tab, setTab] = useState<Tab>('day');
  const [day, setDay] = useState(today);
  const [dir, setDir] = useState<CallDirection>('all');
  const [via, setVia] = useState<CallVia>('all');
  const [open, setOpen] = useState<CallRow | null>(null);
  const [names, setNames] = useState<{ title: string; list: CallRow[] } | null>(null);

  const calls = useMemo(() => callsQ.data ?? [], [callsQ.data]);
  const ofDay = useMemo(() => calls.filter((c) => dayKey(c.started_at ?? c.created_at, w.tz) === day), [calls, day, w.tz]);
  const needsReview = calls.filter((c) => (c.via === 'ai' && c.outcome === 'completed' && !c.review_verdict) || c.answers_to_review > 0);
  const library = calls.filter((c) => c.outcome === 'completed');
  const base = tab === 'day' ? ofDay : tab === 'review' ? needsReview : library;
  const list = filterCalls(base, dir, via);
  const st = callStats(filterCalls(ofDay, 'all', via));
  const unreviewedAi = calls.filter((c) => c.via === 'ai' && c.outcome === 'completed' && !c.review_verdict).length;

  const downloadLibrary = async (kind: 'answers' | 'transcripts') => {
    const ids = library.map((c) => c.id);
    if (!ids.length) return;
    if (kind === 'answers') {
      const answers = (await must(supabase.from('call_answers').select('*').in('call_id', ids), 'load answers')) as Answer[];
      const byCall = new Map(library.map((c) => [c.id, c]));
      downloadText(
        `${w.client.slug}-ai-answers.csv`,
        toCsv(answers.map((a) => ({ call_id: a.call_id, candidate: byCall.get(a.call_id)?.full_name ?? '', question: a.question_text, heard: a.heard_text, result: a.result, at_seconds: a.at_seconds, reviewed: a.reviewed_at ? 'yes' : 'no' }))),
      );
      void rpc('log_action', { p_action: 'CSV exported', p_client: w.client.id, p_label: 'AI call answers', p_rows: answers.length });
    } else {
      const rows = (await must(supabase.from('calls').select('id, transcript, summary').in('id', ids), 'load transcripts')) as { id: string; transcript: string | null; summary: string | null }[];
      const byCall = new Map(library.map((c) => [c.id, c]));
      const text = rows
        .map((r) => `=== ${byCall.get(r.id)?.full_name ?? ''} · ${dateTimeIn(byCall.get(r.id)?.started_at ?? null, w.tz)} ===\n${r.summary ? `Overview: ${r.summary}\n` : ''}${r.transcript ?? '(no transcript)'}\n`)
        .join('\n');
      downloadText(`${w.client.slug}-call-transcripts.txt`, text, 'text/plain;charset=utf-8');
      void rpc('log_action', { p_action: 'Transcript downloaded', p_client: w.client.id, p_label: 'Call transcripts', p_rows: rows.length });
    }
  };

  const seg = (active: boolean) => `min-h-[36px] rounded-lg px-3 text-sm font-semibold ${active ? 'bg-white text-ink shadow-sm' : 'text-muted hover:text-ink'}`;
  const dayLabel = day === today ? 'Today' : day === yesterday ? 'Yesterday' : day;

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        eyebrow={`${w.client.name} · ${w.role?.name ?? ''} · ${dayLabel}`}
        title="Calls"
        right={
          <div className="flex flex-wrap items-center gap-2">
            <Button variant={day === today ? 'primary' : 'default'} className={day === today ? '!bg-ink !border-ink' : ''} onClick={() => setDay(today)}>Today</Button>
            <Button variant={day === yesterday ? 'primary' : 'default'} className={day === yesterday ? '!bg-ink !border-ink' : ''} onClick={() => setDay(yesterday)}>Yesterday</Button>
            <input type="date" aria-label="Pick a day" value={day} max={today} onChange={(e) => e.target.value && setDay(e.target.value)} className="min-h-[44px] rounded-xl border border-line bg-white px-3 text-sm" />
          </div>
        }
      />
      {unreviewedAi > 0 && w.can('calls.review') ? (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-card border border-[#EED9BF] bg-warn-soft/60 px-5 py-4">
          <div className="flex flex-wrap items-baseline gap-x-3">
            <span className="text-[15px] font-bold">{unreviewedAi} AI call{unreviewedAi === 1 ? ' has' : 's have'} not been reviewed</span>
            <span className="text-sm text-muted">A person listens to every finished AI call and marks it right, or flags a problem.</span>
          </div>
          <Button variant="primary" onClick={() => setTab('review')}>Review now</Button>
        </div>
      ) : null}
      <Tabs<Tab>
        value={tab}
        onChange={setTab}
        tabs={[
          { key: 'day', label: 'Calls by day', count: ofDay.length },
          { key: 'review', label: 'Needs review', count: needsReview.length },
          { key: 'library', label: 'Call library', count: library.length },
        ]}
      />
      {callsQ.isLoading ? <Spinner /> : null}
      {tab === 'day' ? (
        <div className="grid grid-cols-[repeat(auto-fit,minmax(150px,1fr))] gap-3">
          {([
            ['Total calls', st.total, st.lists.total],
            ['Outgoing', st.outgoing, st.lists.outgoing],
            ['Incoming', st.incoming, st.lists.incoming],
            ['Completed', st.completed, st.lists.completed],
            ['Voicemail', st.voicemail, st.lists.voicemail],
            ['Avg length (completed)', st.avgSeconds ? seconds(st.avgSeconds) : '—', st.lists.completed],
          ] as const).map(([label, value, l]) => (
            <div key={label} className="flex flex-col gap-1 rounded-card border border-line bg-white p-4">
              <span className="text-xs font-semibold text-muted">{label}</span>
              <span className="font-serif text-[34px] leading-none">{value}</span>
              <button type="button" className="self-start text-xs font-semibold text-muted hover:text-brand" onClick={() => setNames({ title: `${label} · ${dayLabel}`, list: [...l] })}>See names →</button>
            </div>
          ))}
        </div>
      ) : null}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex gap-1 rounded-xl bg-[#EFECE5] p-1" role="radiogroup" aria-label="Direction">
          {(['all', 'outbound', 'inbound'] as const).map((d) => (
            <button key={d} type="button" role="radio" aria-checked={dir === d} className={seg(dir === d)} onClick={() => setDir(d)}>{d === 'all' ? 'All directions' : d === 'outbound' ? 'Outgoing' : 'Incoming'}</button>
          ))}
        </div>
        <div className="flex gap-1 rounded-xl bg-[#EFECE5] p-1" role="radiogroup" aria-label="Who called">
          {(['all', 'ai', 'csr'] as const).map((v) => (
            <button key={v} type="button" role="radio" aria-checked={via === v} className={seg(via === v)} onClick={() => setVia(v)}>{v === 'all' ? 'AI + Twilio' : v === 'ai' ? 'AI agent' : 'Twilio (CSR)'}</button>
          ))}
        </div>
        <span className="text-sm text-muted">Open any call to listen to the recording, read the script answers and download the transcript.</span>
        {tab === 'library' ? (
          <div className="ml-auto flex flex-wrap gap-2">
            <Button onClick={() => void downloadLibrary('transcripts')}>Download transcripts (.txt)</Button>
            <Button onClick={() => void downloadLibrary('answers')}>Download answers (.csv)</Button>
          </div>
        ) : null}
      </div>
      {tab === 'review' && needsReview.length === 0 ? <Banner tone="ok">Nothing waiting for review.</Banner> : null}
      {!callsQ.isLoading && list.length === 0 && !(tab === 'review' && needsReview.length === 0) ? <Empty>No calls {tab === 'day' ? `on ${dayLabel.toLowerCase()}` : 'here'}.</Empty> : null}
      {list.length ? <CallTable list={list} onOpen={setOpen} /> : null}
      {open ? <CallDetail call={open} onClose={() => setOpen(null)} /> : null}
      <Modal open={Boolean(names)} title={names?.title ?? ''} onClose={() => setNames(null)} footer={<Button onClick={() => setNames(null)}>Close</Button>}>
        {names && !names.list.length ? <Empty>No one.</Empty> : null}
        <div className="flex flex-col divide-y divide-line">
          {names?.list.map((c) => (
            <button key={c.id} type="button" className="flex items-center justify-between gap-2 py-2 text-left text-sm hover:text-brand" onClick={() => { setNames(null); setOpen(c); }}>
              <span className="font-semibold">{c.full_name}</span>
              <span className="text-muted">{dateTimeIn(c.started_at ?? c.created_at, w.tz)} · {c.outcome.replace('_', ' ')}</span>
            </button>
          ))}
        </div>
      </Modal>
    </div>
  );
}

function CallTable({ list, onOpen }: { list: CallRow[]; onOpen: (c: CallRow) => void }) {
  const w = useWorkspace();
  return (
    <div className="overflow-x-auto rounded-card border border-line bg-white">
      <table className="w-full min-w-[1000px] text-left text-sm">
        <thead className="border-b border-line bg-[#FBFAF7] text-[11px] font-bold uppercase tracking-wider text-muted">
          <tr>
            <th className="px-4 py-3">Time</th>
            <th className="px-4 py-3">Candidate</th>
            <th className="px-4 py-3">Direction</th>
            <th className="px-4 py-3">Outcome</th>
            <th className="px-4 py-3">Length</th>
            <th className="px-4 py-3">Overview</th>
            <th className="px-4 py-3 text-right">Recording &amp; script</th>
          </tr>
        </thead>
        <tbody>
          {list.map((c) => (
            <tr key={c.id} className="cursor-pointer border-b border-line last:border-0 hover:bg-canvas" onClick={() => onOpen(c)}>
              <td className="whitespace-nowrap px-4 py-3">{new Intl.DateTimeFormat('en-US', { timeZone: w.tz, hour: 'numeric', minute: '2-digit' }).format(new Date(c.started_at ?? c.created_at))}</td>
              <td className="px-4 py-3">
                <div className="flex flex-col items-start gap-0.5">
                  <span className="text-[15px] font-semibold">{c.full_name}</span>
                  <span className="text-xs text-muted">{c.via === 'ai' ? 'AI interview' : `CSR screening · ${ownerName(w.team, c.placed_by)}`}</span>
                  {c.answers_to_review ? <Chip tone="warn">{c.answers_to_review} unclear</Chip> : null}
                  {c.review_verdict ? (
                    <Chip tone={c.review_verdict === 'looks_right' ? 'ok' : 'bad'}>{c.review_verdict === 'looks_right' ? 'Looks right' : 'Flagged'}</Chip>
                  ) : c.via === 'ai' && c.outcome === 'completed' ? (
                    <span className="rounded-md bg-warn-soft px-2 py-0.5 text-[11px] font-semibold text-warn">Not reviewed</span>
                  ) : null}
                </div>
              </td>
              <td className="px-4 py-3">
                <div className="flex flex-col items-start gap-0.5">
                  <span className="rounded-full bg-info-soft px-3 py-1 text-xs font-semibold text-info">{c.direction === 'inbound' ? 'Incoming' : 'Outgoing'}</span>
                  <span className="text-xs text-muted">{c.via === 'ai' ? 'AI agent' : 'Twilio · CSR'}</span>
                </div>
              </td>
              <td className="px-4 py-3"><StatusPill tone={OUTCOME_TONE[c.outcome] ?? 'neutral'}>{c.outcome === 'no_answer' ? 'No answer' : c.outcome.charAt(0).toUpperCase() + c.outcome.slice(1).replace('_', ' ')}</StatusPill></td>
              <td className="px-4 py-3 font-serif text-[18px]">{c.outcome === 'completed' ? seconds(c.duration_seconds) : '—'}</td>
              <td className="max-w-[360px] px-4 py-3"><span className="line-clamp-2 text-sm">{c.summary ?? (c.via === 'csr' ? (c.outcome === 'completed' && !c.duration_seconds ? 'Test phone call (Twilio not set up yet).' : 'Phone call by the team (no AI overview).') : c.outcome === 'completed' ? 'No overview yet.' : '—')}</span></td>
              <td className="px-4 py-3 text-right">
                <Button className="min-h-[38px]" onClick={(e) => { e.stopPropagation(); onOpen(c); }}>Listen &amp; script</Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

interface CallExtra {
  transcript: string | null;
  summary: string | null;
  facts: Record<string, string | null> | null;
}

/** One call: recording player, overview, the script that was used with each answer, transcript, review. */
export function CallDetail({ call, onClose }: { call: CallRow; onClose: () => void }) {
  const w = useWorkspace();
  const toast = useToast();
  const audio = useRef<HTMLAudioElement>(null);
  const [src, setSrc] = useState<string | null>(null);
  const [audioErr, setAudioErr] = useState<string | null>(null);
  const q = useQuery({
    queryKey: ['call', call.id],
    queryFn: async () => {
      const [answers, extra, version] = await Promise.all([
        must(supabase.from('call_answers').select('*').eq('call_id', call.id).order('at_seconds'), 'load answers'),
        must(supabase.from('calls').select('transcript, summary, facts').eq('id', call.id).maybeSingle(), 'load the call'),
        call.script_version_id
          ? must(supabase.from('script_versions').select('version, question_tree').eq('id', call.script_version_id).maybeSingle(), 'load the script')
          : Promise.resolve(null),
      ]);
      return {
        answers: answers as Answer[],
        extra: extra as CallExtra | null,
        script: version as { version: number; question_tree: ScriptQuestion[] } | null,
      };
    },
  });
  useEffect(() => {
    if (!call.recording_path) return;
    let alive = true;
    recordingUrl(call.id)
      .then((u) => alive && setSrc(u))
      .catch((e: unknown) => alive && setAudioErr(friendlyError(e)));
    return () => {
      alive = false;
    };
  }, [call.id, call.recording_path]);
  const seek = (at: number | null) => {
    if (!audio.current || at == null) return;
    audio.current.currentTime = at;
    void audio.current.play().catch(() => toast('Press play on the recording first.', 'bad'));
  };
  const role = w.client.job_roles.find((j) => j.id === call.job_role_id);
  const station = w.client.stations.find((s) => s.id === call.station_id);
  const facts = { client: w.client.name, role: role?.name ?? '', pay: role?.pay_text, address: station?.address, trainingLocation: role?.training_location, shift: role?.shift_text, schedule: role?.schedule_text ?? role?.days_per_week, minAge: role?.min_age };
  const answerOf = (key: string) => q.data?.answers.find((a) => a.question_key === key);
  const extraAnswers = (q.data?.answers ?? []).filter((a) => !q.data?.script?.question_tree.some((s) => s.key === a.question_key));

  return (
    <Modal
      open
      wide
      title={`${call.via === 'ai' ? 'AI interview' : 'Phone call'} · ${call.full_name}`}
      onClose={onClose}
      footer={<><Button onClick={() => { onClose(); w.openApp(call.application_id); }}>Open candidate</Button><Button onClick={onClose}>Close</Button></>}
    >
      <span className="text-sm text-muted">
        {dateTimeIn(call.started_at ?? call.created_at, w.tz)} · {call.direction === 'inbound' ? 'Incoming' : 'Outgoing'} · {call.outcome.replace('_', ' ')} · {seconds(call.duration_seconds)} · attempt {call.attempt_number}
        {call.via === 'csr' ? ` · ${ownerName(w.team, call.placed_by)}` : ''}
      </span>

      <div className="flex flex-col gap-2 rounded-xl border border-line p-3">
        <span className="text-xs font-bold uppercase tracking-wider text-muted">Recording</span>
        {call.recording_path ? (
          src ? (
            <audio ref={audio} controls preload="metadata" src={src} className="w-full" aria-label="Call recording">
              <track kind="captions" />
            </audio>
          ) : audioErr ? <Banner tone="bad">{audioErr}</Banner> : <Spinner label="Loading the recording…" />
        ) : (
          <span className="text-sm text-muted">{call.outcome === 'completed' ? 'No recording for this call.' : 'No recording: the call did not connect.'}</span>
        )}
        {call.recording_path?.startsWith('samples/') ? <span className="text-xs text-muted">Test mode: this is a sample recording with a synthetic voice, not the real call.</span> : null}
        {src ? <span className="text-xs text-muted">The link expires in 10 minutes and the listen is recorded in the activity log.</span> : null}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <CallReviewButtons call={call} />
      </div>
      {q.isLoading ? <Spinner /> : null}

      <div className="flex flex-col gap-1 rounded-xl bg-canvas p-3">
        <span className="text-xs font-bold uppercase tracking-wider text-muted">Overview</span>
        <span className="text-sm">{q.data?.extra?.summary ?? (call.outcome === 'completed' ? 'No overview for this call.' : 'The call did not connect, so there is no overview.')}</span>
        {q.data?.extra?.facts ? (
          <div className="flex flex-wrap gap-2 pt-1">
            {Object.entries(q.data.extra.facts).filter(([, v]) => v).map(([k, v]) => (
              <Chip key={k}>{k.replace('_', ' ')}: {v}</Chip>
            ))}
          </div>
        ) : null}
      </div>

      {call.via === 'ai' ? (
        <div className="flex flex-col gap-2">
          <span className="text-sm font-bold">Script and answers {q.data?.script ? <span className="font-normal text-muted">· script v{q.data.script.version}</span> : null}</span>
          {!q.data?.script && !q.isLoading ? <span className="text-sm text-muted">No script version is linked to this call.</span> : null}
          {q.data?.script?.question_tree.map((s) => {
            const a = answerOf(s.key);
            const c = condition(s.key);
            return (
              <div key={s.key} className={`flex flex-wrap items-center justify-between gap-2 border-b border-line pb-2 text-sm last:border-0 ${c ? 'pl-6' : ''} ${!a ? 'opacity-60' : ''}`}>
                <span className="flex-1">
                  <span className="font-mono text-xs text-muted">{s.key}</span> {c ? <span className="text-xs text-info">(if {c.parent} = {c.answer})</span> : null} {fillFacts(s.text, facts)}
                  {a && a.result !== 'info' ? <><br /><span className="text-muted">Heard: “{a.heard_text || '—'}”</span></> : null}
                  {!a ? <><br /><span className="text-xs text-muted">{s.type === 'info' ? 'Said only if needed' : 'Not asked on this call'}</span></> : null}
                </span>
                {a ? <Chip tone={a.result === 'yes' ? 'ok' : a.result === 'no' ? 'bad' : a.result === 'needs_review' ? 'warn' : 'neutral'}>{a.result.replace('_', ' ')}</Chip> : null}
                {a?.at_seconds != null && src ? <Button className="min-h-[34px] px-3 text-xs" onClick={() => seek(a.at_seconds)}>▶ {Math.floor(a.at_seconds / 60)}:{String(a.at_seconds % 60).padStart(2, '0')}</Button> : null}
              </div>
            );
          })}
          {extraAnswers.map((a) => (
            <div key={a.id} className="flex flex-wrap items-center justify-between gap-2 border-b border-line pb-2 text-sm">
              <span className="flex-1">{a.question_text}<br /><span className="text-muted">Heard: “{a.heard_text ?? '—'}”</span></span>
              <Chip tone={a.result === 'yes' ? 'ok' : a.result === 'no' ? 'bad' : a.result === 'needs_review' ? 'warn' : 'neutral'}>{a.result.replace('_', ' ')}</Chip>
            </div>
          ))}
        </div>
      ) : null}

      {q.data?.extra?.transcript ? (
        <div className="flex flex-col gap-1">
          <span className="text-sm font-bold">Full transcript</span>
          <pre className="max-h-[300px] overflow-y-auto whitespace-pre-wrap rounded-xl bg-canvas p-3 font-sans text-sm">{q.data.extra.transcript}</pre>
          <Button
            className="self-start"
            onClick={() => {
              downloadText(`transcript-${call.full_name.replace(/\s+/g, '-').toLowerCase()}.txt`, `${q.data?.extra?.summary ? `Overview: ${q.data.extra.summary}\n\n` : ''}${q.data?.extra?.transcript ?? ''}`, 'text/plain;charset=utf-8');
              void rpc('log_action', { p_action: 'Transcript downloaded', p_client: w.client.id, p_label: call.full_name, p_rows: 1 });
            }}
          >
            Download transcript
          </Button>
        </div>
      ) : null}
    </Modal>
  );
}
