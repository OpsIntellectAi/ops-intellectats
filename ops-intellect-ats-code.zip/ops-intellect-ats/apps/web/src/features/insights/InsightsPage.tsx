import { useMutation, useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { Bar, PageHeader, SectionTitle, Select, Stat, useToast } from '@/components/kit';
import { Banner, Button, Card, Spinner } from '@/components/ui';
import { callFunction, rpc } from '@/lib/api';
import { downloadText, toCsv } from '@/lib/csv';
import { useWorkspace } from '@/features/shell/context';

interface Insights {
  funnel: Record<'applied' | 'ai_called' | 'interviewed' | 'shortlisted' | 'onboarding' | 'hired' | 'no_response' | 'opted_out' | 'not_interested' | 'rejected', number>;
  questions: { key: string; text: string; asked: number; no: number; unclear: number }[];
  by_hour: { hour: number; calls: number; answered: number }[];
  outcomes: Record<string, number>;
  stalls: { step: string; stuck: number }[];
  time_zone: string;
}

const STEPS: { k: keyof Insights['funnel']; label: string }[] = [
  { k: 'applied', label: 'Applied' },
  { k: 'ai_called', label: 'AI called' },
  { k: 'interviewed', label: 'Interview done' },
  { k: 'shortlisted', label: 'Shortlisted' },
  { k: 'onboarding', label: 'Onboarding' },
  { k: 'hired', label: 'Hired' },
];

const hourLabel = (h: number) => `${((h + 11) % 12) + 1} ${h < 12 ? 'AM' : 'PM'}`;

export function InsightsPage() {
  const w = useWorkspace();
  const toast = useToast();
  const [days, setDays] = useState(30);
  const q = useQuery({
    queryKey: ['insights', w.client.id, w.role?.id ?? null, days],
    queryFn: () => rpc<Insights>('insights_data', { p_client: w.client.id, p_job_role: w.role?.id ?? null, p_days: days }),
  });
  const findings = useMutation({
    mutationFn: () => callFunction<{ findings: string[] }>('ai-text', { action: 'insights', clientId: w.client.id, jobRoleId: w.role?.id ?? null, days }),
    onError: (e) => toast(e instanceof Error ? e.message : 'Could not get findings.', 'bad'),
  });
  const pack = useMutation({
    mutationFn: () => rpc<{ instructions: unknown[]; calls: { call_ref: string; script_version: number; outcome: string; duration_seconds: number | null; transcript: string; answers: { key: string; question: string; heard: string; result: string }[]; review: { verdict: string; reason: string | null } | null }[] }>('training_pack', { p_client: w.client.id, p_job_role: w.role?.id ?? null, p_days: 90 }),
    onSuccess: (p) => {
      const stamp = new Date().toISOString().slice(0, 10);
      downloadText(`ai-training-pack-${stamp}.json`, JSON.stringify(p, null, 2), 'application/json');
      downloadText(`ai-training-transcripts-${stamp}.txt`, p.calls.map((c) => `=== ${c.call_ref} · script v${c.script_version ?? '-'} · ${c.outcome}\n${c.transcript}`).join('\n\n'), 'text/plain;charset=utf-8');
      downloadText(`ai-training-answers-${stamp}.csv`, toCsv(p.calls.flatMap((c) => c.answers.map((a) => ({ call: c.call_ref, key: a.key, question: a.question, heard: a.heard, result: a.result, review: c.review?.verdict ?? '' })))));
      toast(`Training pack downloaded (${p.calls.length} calls, names removed).`);
    },
    onError: (e) => toast(e instanceof Error ? e.message : 'Could not build the pack.', 'bad'),
  });

  if (q.isLoading) return <Spinner />;
  if (q.error || !q.data) return <Banner tone="bad">{q.error instanceof Error ? q.error.message : 'Could not load insights.'}</Banner>;
  const d = q.data;
  const f = d.funnel;
  const max = Math.max(1, f.applied);
  let worst = { from: '', to: '', lost: 0 };
  STEPS.slice(1).forEach((s, i) => {
    const prev = STEPS[i];
    if (!prev) return;
    const lost = f[prev.k] - f[s.k];
    if (lost > worst.lost) worst = { from: prev.label, to: s.label, lost };
  });
  const bestHour = [...d.by_hour].filter((h) => h.calls >= 3).sort((a, b) => b.answered / b.calls - a.answered / a.calls)[0];

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        eyebrow={`${w.client.name} · ${w.role?.name ?? 'all roles'}`}
        title="AI insights"
        right={
          <Select label="Period" value={String(days)} onChange={(e) => setDays(Number(e.target.value))}>
            <option value="7">Last 7 days</option>
            <option value="30">Last 30 days</option>
            <option value="90">Last 90 days</option>
          </Select>
        }
      />
      <Card className="flex flex-col gap-3 p-5">
        <SectionTitle>Why only {f.hired} of {f.applied} got through</SectionTitle>
        {STEPS.map((s, i) => {
          const before = i > 0 ? f[STEPS[i - 1]?.k ?? 'applied'] : 0;
          return (
          <div key={s.k} className="grid grid-cols-[140px_1fr_90px] items-center gap-3 text-sm max-sm:grid-cols-[110px_1fr_70px]">
            <span>{s.label}</span>
            <Bar value={f[s.k]} max={max} />
            <span className="text-right font-semibold">
              {f[s.k]}
              {i > 0 && before > 0 ? <span className="ml-1 text-xs font-normal text-muted">({Math.round((100 * f[s.k]) / before)}%)</span> : null}
            </span>
          </div>
          );
        })}
        <p className="text-sm text-muted">
          Biggest drop: {worst.lost ? <b className="text-ink">{worst.from} → {worst.to} ({worst.lost} people)</b> : 'none yet'} · No response after 7 days: {f.no_response} · Opted out: {f.opted_out} · Not interested: {f.not_interested}
        </p>
      </Card>

      <div className="grid grid-cols-[repeat(auto-fit,minmax(320px,1fr))] gap-4">
        <Card className="flex flex-col gap-2 p-5">
          <SectionTitle>Questions where candidates drop</SectionTitle>
          {d.questions.length ? d.questions.slice(0, 8).map((x) => (
            <div key={x.key} className="flex flex-col gap-1 text-sm">
              <span>{x.text}</span>
              <span className="text-xs text-muted">{x.asked} asked · {x.no} No · {x.unclear} unclear</span>
              <Bar value={x.no + x.unclear} max={Math.max(1, x.asked)} tone="warn" />
            </div>
          )) : <span className="text-sm text-muted">No interview answers in this period.</span>}
        </Card>
        <Card className="flex flex-col gap-2 p-5">
          <SectionTitle>Answer rate by time of day ({d.time_zone.replace('America/', '').replace('_', ' ')})</SectionTitle>
          {d.by_hour.length ? d.by_hour.map((h) => (
            <div key={h.hour} className="grid grid-cols-[60px_1fr_70px] items-center gap-2 text-sm">
              <span>{hourLabel(h.hour)}</span>
              <Bar value={h.answered} max={Math.max(1, h.calls)} tone="info" />
              <span className="text-right text-xs">{h.answered}/{h.calls}</span>
            </div>
          )) : <span className="text-sm text-muted">No AI calls in this period.</span>}
          {bestHour ? <span className="text-sm">Best time to call: <b>{hourLabel(bestHour.hour)}</b></span> : null}
        </Card>
        <Card className="flex flex-col gap-2 p-5">
          <SectionTitle>Onboarding stalls (over 48 h)</SectionTitle>
          {d.stalls.length ? d.stalls.map((s) => <Stat key={s.step} label={s.step} value={s.stuck} tone="warn" />) : <span className="text-sm text-muted">Nothing stuck.</span>}
        </Card>
      </div>

      <Card className="flex flex-col gap-3 p-5">
        <SectionTitle right={<Button className="min-h-[40px]" disabled={findings.isPending} onClick={() => findings.mutate()}>{findings.isPending ? 'Reading the numbers…' : 'Explain in plain English'}</Button>}>
          Findings and next actions
        </SectionTitle>
        {findings.data ? (
          <ul className="flex list-disc flex-col gap-1 pl-5 text-sm">{findings.data.findings.map((x) => <li key={x}>{x}</li>)}</ul>
        ) : (
          <span className="text-sm text-muted">The AI only sees these numbers, never names. People make every hiring decision.</span>
        )}
      </Card>

      {w.can('reports.manage') ? (
        <Card className="flex flex-col gap-2 p-5">
          <SectionTitle>AI training pack</SectionTitle>
          <p className="text-sm text-muted">Completed AI calls from the last 90 days with transcripts, answers, reviews and every published version of the AI instructions. Names and phone numbers are removed. Downloads JSON, TXT and CSV, and is recorded in the activity log.</p>
          <Button className="self-start" disabled={pack.isPending} onClick={() => pack.mutate()}>{pack.isPending ? 'Building…' : 'Download training pack'}</Button>
        </Card>
      ) : null}
    </div>
  );
}
