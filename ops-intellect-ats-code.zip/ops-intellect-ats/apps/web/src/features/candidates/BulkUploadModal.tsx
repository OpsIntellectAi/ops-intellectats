import { useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { Banner, Button } from '@/components/ui';
import { Checkbox, Modal, useToast } from '@/components/kit';
import { friendlyError, rpc } from '@/lib/api';
import { downloadText, gridToRows, parseCsv, UPLOAD_TEMPLATE, type UploadRow } from '@/lib/csv';
import { useInvalidate, useWorkspace } from '@/features/shell/context';
import { normalizePhone } from '@/lib/phone';

interface Preview {
  ready: number;
  added: number;
  skipped: { row: number; name: string; reason: string }[];
  dry_run: boolean;
}

async function readFile(file: File): Promise<string[][]> {
  if (/\.xls$/i.test(file.name)) throw new Error('old-excel');
  if (/\.(xlsx|xlsm)$/i.test(file.name)) {
    const { default: readXlsx } = await import('read-excel-file');
    const rows = await readXlsx(file);
    return rows.map((r) => r.map((c) => (c === null || c === undefined ? '' : c instanceof Date ? c.toISOString().slice(0, 10) : String(c))));
  }
  return parseCsv(await file.text());
}

export function BulkUploadModal({ onClose }: { onClose: () => void }) {
  const w = useWorkspace();
  const toast = useToast();
  const invalidate = useInvalidate();
  const [rows, setRows] = useState<UploadRow[] | null>(null);
  const [fileErr, setFileErr] = useState<string | null>(null);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [sms, setSms] = useState(false);
  const [ai, setAi] = useState(false);
  const [rec, setRec] = useState(false);
  const [confirmBig, setConfirmBig] = useState(false);

  const run = useMutation({
    mutationFn: ({ dry, list }: { dry: boolean; list: UploadRow[] }) =>
      rpc<Preview>('import_applicants', {
        p_client: w.client.id,
        p_station: w.station?.id,
        p_job_role: w.role?.id,
        p_rows: list,
        p_dry_run: dry,
        p_consent_sms: sms,
        p_consent_ai: ai,
        p_consent_recording: rec,
      }),
    onSuccess: (res) => {
      setPreview(res);
      if (!res.dry_run) {
        invalidate();
        toast(`${res.added} applicant${res.added === 1 ? '' : 's'} added.`);
      }
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });

  const onFile = async (file: File | undefined) => {
    setPreview(null);
    setRows(null);
    setFileErr(null);
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) return setFileErr('The file is larger than 5 MB.');
    try {
      const grid = await readFile(file);
      const parsed = gridToRows(grid);
      if (parsed.missing.length) return setFileErr(`Could not find the ${parsed.missing.join(' and ')} column. Name the columns "Full Name" (or First Name + Last Name) and "Phone", or use the template.`);
      if (!parsed.rows.length) return setFileErr('The file has no rows under the headers.');
      if (parsed.rows.length > 2000) return setFileErr('Upload at most 2,000 rows at a time.');
      // Phones in any pattern: only the digits are sent.
      const list = parsed.rows.map((r) => ({ ...r, phone: normalizePhone(r.phone) ?? r.phone }));
      setRows(list);
      run.mutate({ dry: true, list });
    } catch (e) {
      setFileErr(
        e instanceof Error && e.message === 'old-excel'
          ? 'This is an old Excel file (.xls). In Excel choose File → Save As → Excel Workbook (.xlsx), then upload again.'
          : 'Could not read this file. Save it as .csv or .xlsx and try again.',
      );
    }
  };

  const done = preview && !preview.dry_run;
  return (
    <Modal
      open
      wide
      title={`Bulk upload · ${w.role?.name ?? ''} · ${w.station?.code ?? ''}`}
      onClose={onClose}
      footer={
        done ? (
          <Button variant="primary" onClick={onClose}>Done</Button>
        ) : (
          <>
            <Button onClick={onClose}>Cancel</Button>
            <Button
              variant="primary"
              disabled={!preview || preview.ready === 0 || run.isPending}
              onClick={() => (preview && preview.ready > 30 && !confirmBig ? setConfirmBig(true) : rows && run.mutate({ dry: false, list: rows }))}
            >
              {confirmBig ? `Yes, import ${preview?.ready ?? 0}` : `Import ${preview?.ready ?? 0}`}
            </Button>
          </>
        )
      }
    >
      <ol className="flex list-decimal flex-col gap-1 pl-5 text-sm">
        <li>
          Fill in the template (Full Name and Phone are required).{' '}
          <button type="button" className="font-semibold text-brand underline" onClick={() => downloadText('ops-intellect-upload-template.csv', UPLOAD_TEMPLATE)}>
            Download template
          </button>
        </li>
        <li>Choose the file (.csv or .xlsx). You see a preview before anything is imported.</li>
        <li>Phone numbers can be in any pattern (spaces, dashes, dots, brackets, +1). Only the 10 digits are checked.</li>
        <li>Rows for another job role, duplicates and rows without name or phone are skipped.</li>
      </ol>
      <input type="file" accept=".csv,.txt,.tsv,.xlsx,.xlsm,.xls,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={(e) => void onFile(e.target.files?.[0])} aria-label="Choose file" />
      {fileErr ? <Banner tone="bad">{fileErr}</Banner> : null}
      {rows ? (
        <div className="flex flex-col gap-2 rounded-xl bg-canvas p-3">
          <span className="text-xs font-bold uppercase tracking-wider text-muted">Consent for everyone in this file</span>
          <Checkbox label="They agreed to text messages (SMS)" checked={sms} onChange={setSms} />
          <Checkbox label="They agreed to an AI phone interview" checked={ai} onChange={setAi} />
          <Checkbox label="They agreed to call recording" checked={rec} onChange={setRec} />
        </div>
      ) : null}
      {preview ? (
        <div className="flex flex-col gap-2">
          <Banner tone={preview.dry_run ? 'info' : 'ok'}>
            {preview.dry_run
              ? `${preview.ready} ready to import · ${preview.skipped.length} will be skipped.`
              : `${preview.added} imported · ${preview.skipped.length} skipped.`}
          </Banner>
          {confirmBig && preview.dry_run ? <Banner tone="warn">Bulk actions over 30 candidates are flagged in the activity log. Click import again to confirm.</Banner> : null}
          {preview.skipped.length ? (
            <div className="max-h-[240px] overflow-y-auto rounded-xl border border-line">
              <table className="w-full text-left text-sm">
                <thead className="bg-[#FBFAF7] text-xs text-muted">
                  <tr>
                    <th className="px-3 py-1.5">Row</th>
                    <th className="px-3 py-1.5">Name</th>
                    <th className="px-3 py-1.5">Skipped because</th>
                  </tr>
                </thead>
                <tbody>
                  {preview.skipped.map((s) => (
                    <tr key={s.row} className="border-t border-line">
                      <td className="px-3 py-1.5">{s.row + 1}</td>
                      <td className="px-3 py-1.5">{s.name || '—'}</td>
                      <td className="px-3 py-1.5 text-muted">{s.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : null}
        </div>
      ) : null}
    </Modal>
  );
}
