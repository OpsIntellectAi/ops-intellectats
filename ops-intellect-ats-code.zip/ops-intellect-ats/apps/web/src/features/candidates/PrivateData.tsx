import { useMutation, useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { Modal, TextArea, useToast } from '@/components/kit';
import { Button, Field } from '@/components/ui';
import { callFunction } from '@/lib/api';
import { downloadText } from '@/lib/csv';
import { useInvalidate, useWorkspace } from '@/features/shell/context';

/** Driver's licence number and date of birth: encrypted on the server, only ever shown masked. */
export function SensitiveFields({ candidateId }: { candidateId: string }) {
  const w = useWorkspace();
  const toast = useToast();
  const [lic, setLic] = useState('');
  const [dob, setDob] = useState('');
  const masked = useQuery({
    queryKey: ['masked', candidateId],
    retry: false,
    queryFn: () => callFunction<{ licence: string | null; birthYear: string | null }>('sensitive-fields', { action: 'masked', candidateId }),
  });
  const save = useMutation({
    mutationFn: () => callFunction('sensitive-fields', { action: 'set', candidateId, ...(lic ? { licenceNumber: lic.trim() } : {}), ...(dob ? { dateOfBirth: dob } : {}) }),
    onSuccess: () => { toast('Saved encrypted.'); setLic(''); setDob(''); void masked.refetch(); },
    onError: (e) => toast(e instanceof Error ? e.message : 'Could not save.', 'bad'),
  });
  return (
    <div className="flex flex-col gap-2 rounded-lg bg-white p-3">
      <span className="text-sm font-semibold">Licence and date of birth (encrypted)</span>
      {masked.error ? (
        <span className="text-sm text-muted">{masked.error instanceof Error ? masked.error.message : 'Not available.'}</span>
      ) : (
        <span className="text-sm">Licence: {masked.data?.licence ?? '—'} · Born: {masked.data?.birthYear ?? '—'}</span>
      )}
      {w.can('candidates.act') && !masked.error ? (
        <div className="flex flex-wrap items-end gap-2">
          <Field label="Licence number" value={lic} onChange={(e) => setLic(e.target.value)} autoComplete="off" />
          <Field label="Date of birth" type="date" value={dob} onChange={(e) => setDob(e.target.value)} />
          <Button className="min-h-[40px]" disabled={(!lic && !dob) || save.isPending} onClick={() => save.mutate()}>Save</Button>
        </div>
      ) : null}
      <span className="text-xs text-muted">Never type a Social Security number here; we never store SSNs.</span>
    </div>
  );
}

/** Export or delete everything about a person when they ask (Admin and up). */
export function DataRequest({ candidateId, name, onDeleted }: { candidateId: string; name: string; onDeleted: () => void }) {
  const w = useWorkspace();
  const toast = useToast();
  const invalidate = useInvalidate();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState('');
  const [typed, setTyped] = useState('');
  const exp = useMutation({
    mutationFn: () => callFunction<{ data: unknown }>('data-request', { action: 'export', candidateId }),
    onSuccess: (r) => { downloadText(`data-export-${candidateId.slice(0, 8)}.json`, JSON.stringify(r.data, null, 2), 'application/json'); toast('Export downloaded and logged.'); },
    onError: (e) => toast(e instanceof Error ? e.message : 'Could not export.', 'bad'),
  });
  const del = useMutation({
    mutationFn: () => callFunction('data-request', { action: 'delete', candidateId, reason: reason.trim() }),
    onSuccess: () => { toast('Deleted. Recorded in the activity log.'); setOpen(false); invalidate(); onDeleted(); },
    onError: (e) => toast(e instanceof Error ? e.message : 'Could not delete.', 'bad'),
  });
  if (!w.can('users.manage')) return null;
  return (
    <div className="flex flex-col gap-2 rounded-lg border border-line p-3">
      <span className="text-sm font-semibold">Data request from this person</span>
      <div className="flex flex-wrap gap-2">
        <Button className="min-h-[40px]" disabled={exp.isPending} onClick={() => exp.mutate()}>Export their data (.json)</Button>
        <Button variant="danger" className="min-h-[40px]" onClick={() => setOpen(true)}>Delete on request…</Button>
      </div>
      <Modal
        open={open}
        title="Delete this person's data?"
        onClose={() => setOpen(false)}
        footer={<><Button onClick={() => setOpen(false)}>Cancel</Button><Button variant="danger" disabled={reason.trim().length < 4 || typed !== name || del.isPending} onClick={() => del.mutate()}>Delete for good</Button></>}
      >
        <p className="text-sm">This deletes {name}, every application, text, call, recording and licence photo for this client. It cannot be undone. The activity log keeps who did it and why, without their name.</p>
        <TextArea label="Reason (e.g. asked by email on 11 Nov)" value={reason} onChange={(e) => setReason(e.target.value)} maxLength={300} />
        <Field label={`Type their full name to confirm: ${name}`} value={typed} onChange={(e) => setTyped(e.target.value)} />
      </Modal>
    </div>
  );
}
