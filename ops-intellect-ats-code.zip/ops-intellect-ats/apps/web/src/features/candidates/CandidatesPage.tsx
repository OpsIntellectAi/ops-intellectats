import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { Banner, Button, Spinner } from '@/components/ui';
import { Checkbox, Empty, Modal, PageHeader, Select, Tabs, useToast } from '@/components/kit';
import { friendlyError, must, rpc } from '@/lib/api';
import { downloadText, toCsv } from '@/lib/csv';
import { formatPhone, initials, STAGE_LABEL, type Stage } from '@/lib/format';
import { noReplyDays } from '@/lib/queues';
import { aiCallView, contactChip, lastMessageView, nextStep, type ContactChip, type Tone } from '@/lib/rowview';
import { supabase } from '@/lib/supabase';
import { dayKey, daysSince } from '@/lib/time';
import type { AppRow } from '@/lib/types';
import { ownerName, useInvalidate, useRows, useWorkspace } from '@/features/shell/context';
import { AddApplicantModal } from './AddApplicantModal';
import { BulkUploadModal } from './BulkUploadModal';
import { RowActions } from './RowActions';
import { BulkMessageButton } from '@/features/messages/BulkMessage';

const TABS: Stage[] = ['interview', 'shortlisted', 'pre_onboarding', 'onboarding', 'hired', 'not_interested', 'rejected'];

export interface Filters {
  stage: Stage;
  contact: ContactChip;
  appliedDays: number | null;
  appliedOn: string | null;
  noReply: number | null;
  owner: string;
  q: string;
}
const DEFAULT: Filters = { stage: 'interview', contact: 'all', appliedDays: null, appliedOn: null, noReply: null, owner: '', q: '' };

const CONTACT: { key: ContactChip; label: string }[] = [
  { key: 'all', label: 'Everyone' },
  { key: 'never', label: 'Never messaged' },
  { key: 'no_reply_tries', label: 'No reply (3+ tries)' },
  { key: 'replied', label: 'Replied' },
  { key: 'opted_out', label: 'Opted out' },
];

interface SavedView {
  id: string;
  name: string;
  filters: Partial<Filters> & { contact?: string };
  shared: boolean;
  owner_id: string;
}

/** Older saved views used other names for the contact filter. */
export function viewFilters(v: SavedView['filters']): Filters {
  const legacy: Record<string, ContactChip> = { no_reply_3: 'no_reply_tries' };
  const contact = (legacy[v.contact ?? ''] ?? v.contact ?? 'all') as ContactChip;
  return { ...DEFAULT, ...v, contact };
}

export function applyFilters(rows: AppRow[], f: Filters, tz = 'America/New_York', now: number = Date.now(), skipStage = false, skipContact = false): AppRow[] {
  const q = f.q.trim().toLowerCase();
  const digits = q.replace(/\D/g, '');
  return rows.filter((r) => {
    if (!skipStage && r.stage !== f.stage) return false;
    if (!skipContact && !contactChip(r, f.contact)) return false;
    if (f.appliedDays !== null && (daysSince(r.applied_at, now) ?? 0) > f.appliedDays) return false;
    if (f.appliedOn && dayKey(r.applied_at, tz) !== f.appliedOn) return false;
    if (f.noReply !== null) {
      const n = noReplyDays(r, now);
      if (n === null || n < f.noReply) return false;
    }
    if (f.owner === 'none' && r.owner_id) return false;
    if (f.owner && f.owner !== 'none' && r.owner_id !== f.owner) return false;
    if (q && !r.full_name.toLowerCase().includes(q) && !(digits.length >= 3 && r.phone_e164.includes(digits)) && !(r.email ?? '').toLowerCase().includes(q)) return false;
    return true;
  });
}

interface BulkResult {
  queued: number;
  skipped: { id: string; name: string | null; reason: string }[];
}

export function useQueuedCalls() {
  const w = useWorkspace();
  return useQuery({
    queryKey: ['queued-calls', w.client.id],
    refetchInterval: 60_000,
    queryFn: async () => {
      const { data, error } = await supabase.rpc('queued_ai_calls', { p_client: w.client.id });
      if (error) return new Map<string, string>();
      return new Map(((data ?? []) as { application_id: string; run_at: string }[]).map((x) => [x.application_id, x.run_at]));
    },
  });
}

export function CandidatesPage() {
  const w = useWorkspace();
  const toast = useToast();
  const qc = useQueryClient();
  const invalidate = useInvalidate();
  const rowsQ = useRows();
  const queuedQ = useQueuedCalls();
  const [f, setF] = useState<Filters>(DEFAULT);
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [add, setAdd] = useState(false);
  const [upload, setUpload] = useState(false);
  const [assignTo, setAssignTo] = useState('');
  const [confirmBulk, setConfirmBulk] = useState(false);
  const [confirmCalls, setConfirmCalls] = useState(false);
  const [callResult, setCallResult] = useState<BulkResult | null>(null);
  const [saveName, setSaveName] = useState('');
  const [saveShared, setSaveShared] = useState(false);
  const [saveOpen, setSaveOpen] = useState(false);

  const all = useMemo(() => rowsQ.data ?? [], [rowsQ.data]);
  const now = Date.now();
  // Stage counts follow the other filters (search, CSR, contact…), like the tabs in the prototype.
  const counts = useMemo(() => {
    const base = applyFilters(all, f, w.tz, now, true);
    return Object.fromEntries(TABS.map((s) => [s, base.filter((r) => r.stage === s).length])) as Record<Stage, number>;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [all, f, w.tz]);
  const contactCounts = useMemo(() => {
    const base = applyFilters(all, f, w.tz, now, false, true);
    return Object.fromEntries(CONTACT.map((c) => [c.key, base.filter((r) => contactChip(r, c.key)).length])) as Record<ContactChip, number>;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [all, f, w.tz]);
  const shown = useMemo(() => applyFilters(all, f, w.tz), [all, f, w.tz]);
  const selected = shown.filter((r) => sel.has(r.id));

  const viewsQ = useQuery({
    queryKey: ['views', w.client.id],
    queryFn: async () => (await must(supabase.from('saved_views').select('id, name, filters, shared, owner_id').eq('client_id', w.client.id).order('name'), 'load saved views')) as SavedView[],
  });
  const saveView = useMutation({
    mutationFn: async () =>
      must(supabase.from('saved_views').insert({ client_id: w.client.id, owner_id: w.access.user_id, name: saveName.trim(), filters: f, shared: saveShared }), 'save the view'),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['views'] });
      setSaveOpen(false);
      setSaveName('');
      toast('View saved.');
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  const deleteView = useMutation({
    mutationFn: async (id: string) => must(supabase.from('saved_views').delete().eq('id', id), 'delete the view'),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['views'] });
      toast('View removed.');
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });

  const assign = useMutation({
    mutationFn: async () => {
      const ids = selected.map((r) => r.id);
      const owner = assignTo === 'none' ? null : assignTo;
      const res = await must(supabase.from('applications').update({ owner_id: owner }).in('id', ids).select('id'), 'assign');
      if (ids.length > 30) await rpc('log_action', { p_action: 'Bulk assign', p_client: w.client.id, p_label: `Assigned to ${ownerName(w.team, owner)}`, p_rows: ids.length });
      return (res as { id: string }[]).length;
    },
    onSuccess: (n) => {
      invalidate();
      setSel(new Set());
      setConfirmBulk(false);
      toast(`${n} candidate${n === 1 ? '' : 's'} assigned to ${ownerName(w.team, assignTo === 'none' ? null : assignTo)}.`);
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });

  const bulkCalls = useMutation({
    mutationFn: () => rpc<BulkResult>('queue_ai_calls', { p_applications: selected.map((r) => r.id) }),
    onSuccess: (r) => {
      setConfirmCalls(false);
      setCallResult(r);
      setSel(new Set());
      void qc.invalidateQueries({ queryKey: ['queued-calls'] });
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });

  const selectFirst = (n: number | 'all') => setSel(new Set((n === 'all' ? shown : shown.slice(0, n)).map((r) => r.id)));
  const exportCsv = () => {
    const list = selected.length ? selected : shown;
    downloadText(
      `${w.client.slug}-${w.role?.name.replace(/\s+/g, '-').toLowerCase() ?? 'role'}-${f.stage}.csv`,
      toCsv(
        list.map((r) => ({
          name: r.full_name,
          phone: formatPhone(r.phone_e164),
          email: r.email,
          city: r.city,
          stage: STAGE_LABEL[r.stage],
          owner: ownerName(w.team, r.owner_id),
          source: r.source,
          applied: r.applied_at,
          last_text_out: r.last_out_at,
          last_reply: r.last_in_at,
          next_step: nextStep(r).text,
        })),
      ),
    );
    void rpc('log_action', { p_action: 'CSV exported', p_client: w.client.id, p_label: `Candidates · ${STAGE_LABEL[f.stage]}`, p_rows: list.length });
  };

  const csrs = w.team.filter((t) => ['csr', 'supervisor', 'admin', 'super_admin'].includes(t.role));
  const views = viewsQ.data ?? [];
  const canBulkCall = w.can('candidates.act') && w.on('ai_calls') && w.on('bulk_ai_calls');

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        eyebrow={`${w.client.name} · ${w.station?.code ?? ''} · ${w.role?.name ?? ''}`}
        title={`${w.role?.name ?? ''} candidates`}
        right={
          <>
            <label className="relative flex items-center">
              <span className="sr-only">Search name, phone or email</span>
              <svg className="pointer-events-none absolute left-3 text-muted" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>
              <input
                type="search"
                value={f.q}
                onChange={(e) => setF({ ...f, q: e.target.value })}
                placeholder="Search name or phone"
                className="min-h-[44px] w-[260px] rounded-xl border border-line bg-white pl-9 pr-3 text-sm outline-none focus:border-brand max-md:w-full"
              />
            </label>
            {w.can('candidates.act') && w.on('bulk_upload') ? <Button onClick={() => setUpload(true)}>⤒ Bulk upload</Button> : null}
            {w.can('candidates.act') ? <Button variant="primary" onClick={() => setAdd(true)}>Add {w.role?.name ?? ''} applicant</Button> : null}
          </>
        }
      />
      {!w.can('candidates.act') ? <div className="rounded-xl bg-info-soft px-4 py-2.5 text-sm font-medium text-info">View only: you can look at candidates but not add or move them.</div> : null}

      <div className="flex flex-wrap items-center gap-2">
        <span className="text-sm font-semibold">Saved views</span>
        {views.map((v) => {
          const n = applyFilters(all, viewFilters(v.filters), w.tz).length;
          return (
            <span key={v.id} className="inline-flex items-center gap-1 rounded-full border border-line bg-white pl-3 text-sm">
              <button type="button" className="py-1.5 font-medium hover:text-brand" onClick={() => setF(viewFilters(v.filters))} title={v.shared ? 'Shared with the team' : 'Only you'}>
                {v.name} <span className="ml-1 text-xs text-muted">{n}</span>
              </button>
              {v.owner_id === w.access.user_id ? (
                <button type="button" aria-label={`Remove view ${v.name}`} className="flex h-7 w-7 items-center justify-center rounded-full text-muted hover:bg-black/5" onClick={() => deleteView.mutate(v.id)}>×</button>
              ) : <span className="w-2" />}
            </span>
          );
        })}
        <button type="button" className="text-sm font-semibold text-brand hover:underline" onClick={() => setSaveOpen(true)}>+ Save this view</button>
      </div>

      <Tabs<Stage> value={f.stage} onChange={(s) => { setF({ ...f, stage: s }); setSel(new Set()); }} tabs={TABS.map((s) => ({ key: s, label: STAGE_LABEL[s], count: counts[s] }))} />

      <div className="flex flex-wrap items-end gap-3 rounded-card border border-line bg-white p-3">
        <div className="flex flex-col gap-1">
          <span className="text-xs font-semibold text-[#3D403D]">Contact</span>
          <div role="radiogroup" aria-label="Contact" className="flex flex-wrap gap-1 rounded-xl bg-[#EFECE5] p-1">
            {CONTACT.map((c) => (
              <button
                key={c.key}
                type="button"
                role="radio"
                aria-checked={f.contact === c.key}
                onClick={() => setF({ ...f, contact: c.key })}
                className={`min-h-[34px] rounded-lg px-3 text-sm font-semibold ${f.contact === c.key ? 'bg-white text-ink shadow-sm' : 'text-muted hover:text-ink'}`}
              >
                {c.label} · {contactCounts[c.key]}
              </button>
            ))}
          </div>
        </div>
        <label className="flex flex-col gap-1 text-xs font-semibold text-[#3D403D]">
          Applied on
          <input type="date" value={f.appliedOn ?? ''} onChange={(e) => setF({ ...f, appliedOn: e.target.value || null })} className="min-h-[40px] rounded-lg border border-line px-2 text-sm" />
        </label>
        <Select label="Applied" value={f.appliedDays ?? ''} onChange={(e) => setF({ ...f, appliedDays: e.target.value ? Number(e.target.value) : null })}>
          <option value="">Any time</option>
          <option value="1">Last 24 h</option>
          <option value="7">Last 7 days</option>
          <option value="30">Last 30 days</option>
        </Select>
        <Select label="No reply for" value={f.noReply ?? ''} onChange={(e) => setF({ ...f, noReply: e.target.value ? Number(e.target.value) : null })}>
          <option value="">Any time</option>
          {[1, 2, 3, 5, 7].map((n) => (
            <option key={n} value={n}>{n}+ days</option>
          ))}
        </Select>
        {w.access.role !== 'csr' ? (
          <Select label="CSR" value={f.owner} onChange={(e) => setF({ ...f, owner: e.target.value })}>
            <option value="">All my team</option>
            <option value="none">Unassigned</option>
            {csrs.map((t) => (
              <option key={t.user_id} value={t.user_id}>{t.full_name}</option>
            ))}
          </Select>
        ) : null}
        <Button className="min-h-[40px]" variant="ghost" onClick={() => setF({ ...DEFAULT, stage: f.stage })}>Clear</Button>
      </div>

      <div className="flex flex-wrap items-center gap-2 rounded-card bg-[#EFECE5] p-3">
        <span className="text-sm font-semibold">Select</span>
        {[20, 40, 50].map((n) => (
          <Button key={n} className="min-h-[34px] rounded-full px-3 text-xs" onClick={() => selectFirst(n)}>First {n}</Button>
        ))}
        <Button className="min-h-[34px] rounded-full px-3 text-xs" onClick={() => selectFirst('all')}>All shown</Button>
        <span className="text-sm text-muted">{shown.length} shown · {selected.length} selected</span>
        {selected.length ? <Button className="min-h-[34px] px-3 text-xs" variant="ghost" onClick={() => setSel(new Set())}>Clear selection</Button> : null}
        <div className="ml-auto flex flex-wrap items-center gap-2">
          {selected.length && canBulkCall ? (
            <Button variant="primary" className="min-h-[40px]" onClick={() => setConfirmCalls(true)}>AI call {selected.length}</Button>
          ) : null}
          {selected.length && w.can('messages.send') && w.on('bulk_texts') ? <BulkMessageButton rows={selected} onDone={() => setSel(new Set())} /> : null}
          {selected.length && w.can('candidates.assign') ? (
            <>
              <Select aria-label="Assign to" value={assignTo} onChange={(e) => setAssignTo(e.target.value)}>
                <option value="">Assign to…</option>
                <option value="none">Unassigned</option>
                {csrs.map((t) => (
                  <option key={t.user_id} value={t.user_id}>{t.full_name}</option>
                ))}
              </Select>
              <Button className="min-h-[40px]" disabled={!assignTo || assign.isPending} onClick={() => (selected.length > 30 ? setConfirmBulk(true) : assign.mutate())}>
                Assign {selected.length}
              </Button>
            </>
          ) : null}
          {w.on('csv_export') ? <Button className="min-h-[40px]" onClick={exportCsv}>Download CSV</Button> : null}
        </div>
      </div>

      {rowsQ.isLoading ? <Spinner /> : null}
      {rowsQ.isError ? <Banner tone="bad">{(rowsQ.error as Error).message}</Banner> : null}
      {!rowsQ.isLoading && shown.length === 0 ? <Empty>No candidates match.</Empty> : null}
      {shown.length ? <CandidateTable rows={shown} sel={sel} setSel={setSel} queued={queuedQ.data} /> : null}

      <Modal open={confirmBulk} title={`Assign ${selected.length} candidates?`} onClose={() => setConfirmBulk(false)} footer={<><Button onClick={() => setConfirmBulk(false)}>Cancel</Button><Button variant="primary" disabled={assign.isPending} onClick={() => assign.mutate()}>Yes, assign {selected.length}</Button></>}>
        <p className="text-sm">Bulk actions over 30 candidates are recorded and flagged in the activity log.</p>
      </Modal>
      <Modal
        open={confirmCalls}
        title={`AI call ${selected.length} candidate${selected.length === 1 ? '' : 's'}?`}
        onClose={() => setConfirmCalls(false)}
        footer={<><Button onClick={() => setConfirmCalls(false)}>Cancel</Button><Button variant="primary" disabled={bulkCalls.isPending} onClick={() => bulkCalls.mutate()}>{bulkCalls.isPending ? 'Queuing…' : `Yes, queue ${selected.length} AI calls`}</Button></>}
      >
        <ul className="flex list-disc flex-col gap-1 pl-5 text-sm">
          <li>Calls go out one every 30 seconds, only between {w.client.client_settings?.best_call_start?.slice(0, 5) ?? '10:00'} and {w.client.client_settings?.best_call_end?.slice(0, 5) ?? '18:00'} in each candidate&apos;s own time. Outside that window they wait for the next morning.</li>
          <li>Anyone without AI-call consent, opted out, not in Interview, already called today or with all attempts used is skipped — you see who and why.</li>
          <li>The emergency stop pauses queued calls.{selected.length > 30 ? ' Over 30 people: this is flagged in the activity log.' : ''}</li>
        </ul>
      </Modal>
      <Modal open={Boolean(callResult)} title="AI calls queued" onClose={() => setCallResult(null)} footer={<Button variant="primary" onClick={() => setCallResult(null)}>Done</Button>}>
        <Banner tone={callResult?.queued ? 'ok' : 'warn'}>{callResult?.queued ?? 0} queued · {callResult?.skipped.length ?? 0} skipped</Banner>
        {callResult?.skipped.length ? (
          <div className="max-h-[260px] overflow-y-auto rounded-xl border border-line">
            <table className="w-full text-left text-sm">
              <thead className="bg-[#FBFAF7] text-xs text-muted"><tr><th className="px-3 py-1.5">Candidate</th><th className="px-3 py-1.5">Skipped because</th></tr></thead>
              <tbody>
                {callResult.skipped.map((s) => (
                  <tr key={s.id} className="border-t border-line"><td className="px-3 py-1.5">{s.name ?? '—'}</td><td className="px-3 py-1.5 text-muted">{s.reason}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
      </Modal>
      <Modal open={saveOpen} title="Save this view" onClose={() => setSaveOpen(false)} footer={<><Button onClick={() => setSaveOpen(false)}>Cancel</Button><Button variant="primary" disabled={saveName.trim().length < 2 || saveView.isPending} onClick={() => saveView.mutate()}>Save</Button></>}>
        <p className="text-sm text-muted">Saves the stage, contact, dates, CSR and search you have now as one click.</p>
        <label className="flex flex-col gap-1 text-sm font-semibold">
          Short name
          <input value={saveName} onChange={(e) => setSaveName(e.target.value)} maxLength={40} placeholder="e.g. Shortlisted · no reply 2+ days · mine" className="min-h-[44px] rounded-xl border border-line px-3 font-normal" />
        </label>
        <Checkbox label="Share with the team in this client" checked={saveShared} onChange={setSaveShared} />
      </Modal>
      {add ? <AddApplicantModal onClose={() => setAdd(false)} /> : null}
      {upload ? <BulkUploadModal onClose={() => setUpload(false)} /> : null}
    </div>
  );
}

const TONE: Record<Tone, string> = {
  ok: 'bg-brand-soft text-brand',
  warn: 'bg-warn-soft text-warn',
  bad: 'bg-bad-soft text-bad',
  info: 'bg-info-soft text-info',
  neutral: 'bg-[#EFECE5] text-[#3D403D]',
  purple: 'bg-[#EEE8F8] text-[#5B3F99]',
};
const SUB: Record<Tone, string> = {
  ok: 'text-brand',
  warn: 'text-warn',
  bad: 'text-bad',
  info: 'text-info',
  neutral: 'text-muted',
  purple: 'text-[#5B3F99]',
};

export function StatusPill({ tone, children }: { tone: Tone; children: React.ReactNode }) {
  return (
    <span className={`inline-flex h-7 items-center gap-1.5 rounded-full px-3 text-xs font-semibold ${TONE[tone]}`}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" aria-hidden="true" />
      {children}
    </span>
  );
}

export function CandidateTable({ rows, sel, setSel, compact = false, queued }: { rows: AppRow[]; sel?: Set<string>; setSel?: (s: Set<string>) => void; compact?: boolean; queued?: Map<string, string> }) {
  const w = useWorkspace();
  const toggle = (id: string) => {
    if (!sel || !setSel) return;
    const n = new Set(sel);
    if (n.has(id)) n.delete(id);
    else n.add(id);
    setSel(n);
  };
  const allOn = Boolean(sel && rows.length && rows.every((r) => sel.has(r.id)));
  return (
    <div className="overflow-x-auto rounded-card border border-line bg-white">
      <table className="w-full min-w-[1080px] text-left text-sm">
        <thead className="border-b border-line bg-[#FBFAF7] text-[11px] font-bold uppercase tracking-wider text-muted">
          <tr>
            {sel && setSel ? (
              <th className="w-10 px-3 py-3">
                <input type="checkbox" aria-label="Select all shown" className="h-4 w-4 accent-brand" checked={allOn} onChange={() => setSel(allOn ? new Set() : new Set(rows.map((r) => r.id)))} />
              </th>
            ) : null}
            <th className="px-3 py-3">Candidate</th>
            {!compact ? <th className="px-3 py-3">CSR</th> : null}
            <th className="px-3 py-3">AI call</th>
            <th className="px-3 py-3">Last message</th>
            <th className="px-3 py-3">Next step</th>
            {!compact ? <th className="px-3 py-3 text-right">Actions</th> : null}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => {
            const ai = aiCallView(r, queued?.get(r.id) ?? null, w.tz);
            const lm = lastMessageView(r);
            const ns = nextStep(r);
            const nr = noReplyDays(r);
            return (
              <tr key={r.id} className={`cursor-pointer border-b border-line last:border-0 hover:bg-canvas ${sel?.has(r.id) ? 'bg-brand-soft/40' : ''}`} onClick={() => w.openApp(r.id)}>
                {sel ? (
                  <td className="px-3 py-3" onClick={(e) => e.stopPropagation()}>
                    <input type="checkbox" aria-label={`Select ${r.full_name}`} className="h-4 w-4 accent-brand" checked={sel.has(r.id)} onChange={() => toggle(r.id)} />
                  </td>
                ) : null}
                <td className="px-3 py-3">
                  <div className="flex items-center gap-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-soft text-sm font-bold text-brand">{initials(r.full_name)}</span>
                    <div className="flex min-w-0 flex-col">
                      <span className="truncate text-[15px] font-semibold">{r.full_name}</span>
                      <span className="text-xs text-muted">{formatPhone(r.phone_e164)} · {r.source}</span>
                    </div>
                  </div>
                </td>
                {!compact ? <td className="px-3 py-3 font-semibold">{r.owner_id ? ownerName(w.team, r.owner_id) : <span className="font-normal text-muted">Unassigned</span>}</td> : null}
                <td className="px-3 py-3">
                  <div className="flex flex-col items-start gap-1">
                    <StatusPill tone={ai.tone}>{ai.label}</StatusPill>
                    {ai.sub ? <span className="text-xs text-muted">{ai.sub}</span> : null}
                  </div>
                </td>
                <td className="max-w-[300px] px-3 py-3">
                  <div className="flex flex-col items-start gap-0.5">
                    <span className={`w-full truncate ${lm.label === 'Never messaged' ? 'text-muted' : ''}`} title={lm.label}>{lm.label}</span>
                    {lm.sub ? <span className={`text-xs font-semibold ${SUB[lm.tone]}`}>{lm.sub}</span> : null}
                    <div className="flex flex-wrap gap-1">
                      {r.reschedule_requested_at && !r.booked_call_at ? <StatusPillSmall tone="info">Reschedule</StatusPillSmall> : null}
                      {r.said_yes_at && r.stage === 'interview' && r.last_direction === 'inbound' ? <StatusPillSmall tone="purple">Said yes to AI call</StatusPillSmall> : null}
                      {r.opted_out_at ? <StatusPillSmall tone="bad">Opted out</StatusPillSmall> : null}
                      {nr !== null && nr >= 3 && !r.opted_out_at ? <StatusPillSmall tone="warn">No reply {nr} d</StatusPillSmall> : null}
                    </div>
                  </div>
                </td>
                <td className="max-w-[200px] px-3 py-3 font-medium">{ns.text}</td>
                {!compact ? (
                  <td className="px-3 py-3">
                    <RowActions row={r} />
                  </td>
                ) : null}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function StatusPillSmall({ tone, children }: { tone: Tone; children: React.ReactNode }) {
  return <span className={`mt-0.5 inline-flex h-5 items-center rounded-md px-2 text-[11px] font-semibold ${TONE[tone]}`}>{children}</span>;
}
