import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Banner, Button, Field } from '@/components/ui';
import { Checkbox, Modal, Select, useToast } from '@/components/kit';
import { friendlyError, rpc } from '@/lib/api';
import { useInvalidate, useWorkspace } from '@/features/shell/context';
import { normalizePhone, phoneProblem } from '@/lib/phone';

const Schema = z.object({
  full_name: z.string().trim().min(2, 'Enter the full name').max(120),
  phone: z
    .string()
    .trim()
    .superRefine((v, ctx) => {
      const p = phoneProblem(v);
      if (p) ctx.addIssue({ code: z.ZodIssueCode.custom, message: p });
    }),
  email: z.string().trim().email('Enter a valid email').or(z.literal('')),
  city: z.string().trim().max(80),
  zip: z.string().trim().regex(/^(\d{5})?$/, 'ZIP is 5 digits'),
  source: z.string().trim().min(1).max(40),
});
type Values = z.infer<typeof Schema>;

interface Result {
  status: 'added' | 'duplicate';
  application_id: string | null;
  visible?: boolean;
  name?: string | null;
}

export function AddApplicantModal({ onClose }: { onClose: () => void }) {
  const w = useWorkspace();
  const toast = useToast();
  const invalidate = useInvalidate();
  const [owner, setOwner] = useState('');
  const [sms, setSms] = useState(true);
  const [ai, setAi] = useState(true);
  const [rec, setRec] = useState(true);
  const [dup, setDup] = useState<Result | null>(null);
  const { register, handleSubmit, formState } = useForm<Values>({
    resolver: zodResolver(Schema),
    defaultValues: { full_name: '', phone: '', email: '', city: '', zip: '', source: 'Indeed' },
  });

  const m = useMutation({
    mutationFn: (v: Values) =>
      rpc<Result>('add_applicant', {
        p_client: w.client.id,
        p_station: w.station?.id,
        p_job_role: w.role?.id,
        p_full_name: v.full_name,
        p_phone: normalizePhone(v.phone) ?? v.phone,
        p_email: v.email || null,
        p_city: v.city || null,
        p_zip: v.zip || null,
        p_source: v.source,
        p_owner: owner || null,
        p_consent_sms: sms,
        p_consent_ai: ai,
        p_consent_recording: rec,
      }),
    onSuccess: (res) => {
      if (res.status === 'duplicate') {
        setDup(res);
        return;
      }
      invalidate();
      toast('Applicant added.');
      onClose();
      if (res.application_id) w.openApp(res.application_id);
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });

  const owners = w.team.filter((t) => ['csr', 'supervisor', 'admin', 'super_admin'].includes(t.role));
  return (
    <Modal
      open
      title={`Add applicant · ${w.role?.name ?? ''} · ${w.station?.code ?? ''}`}
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" disabled={m.isPending} onClick={handleSubmit((v) => m.mutate(v))}>Add applicant</Button>
        </>
      }
    >
      {dup ? (
        <Banner tone="warn">
          This phone number is already a candidate in {w.client.name}
          {dup.visible && dup.name ? ` (${dup.name})` : ' (owned by another CSR)'}. They were not added again.{' '}
          {dup.visible && dup.application_id ? (
            <button type="button" className="font-semibold underline" onClick={() => { onClose(); w.openApp(dup.application_id); }}>
              Open the existing candidate
            </button>
          ) : null}
        </Banner>
      ) : null}
      <Field label="Full name" {...register('full_name')} error={formState.errors.full_name?.message} autoComplete="off" />
      <Field label="Mobile phone" {...register('phone')} error={formState.errors.phone?.message} inputMode="tel" placeholder="Any pattern: 7073330140, (707) 333-0140, 707.333.0140" />
      <Field label="Email (optional)" {...register('email')} error={formState.errors.email?.message} type="email" />
      <div className="grid grid-cols-2 gap-3">
        <Field label="City" {...register('city')} />
        <Field label="ZIP" {...register('zip')} error={formState.errors.zip?.message} inputMode="numeric" />
      </div>
      <Select label="Source" {...register('source')}>
        {['Indeed', 'Facebook', 'Craigslist', 'Referral', 'Walk-in', 'Website', 'Direct'].map((s) => (
          <option key={s}>{s}</option>
        ))}
      </Select>
      {w.access.role !== 'csr' ? (
        <Select label="Owner" value={owner} onChange={(e) => setOwner(e.target.value)}>
          <option value="">Unassigned</option>
          {owners.map((t) => (
            <option key={t.user_id} value={t.user_id}>{t.full_name}</option>
          ))}
        </Select>
      ) : (
        <span className="text-xs text-muted">You will own this candidate.</span>
      )}
      <div className="flex flex-col gap-2 rounded-xl bg-canvas p-3">
        <span className="text-xs font-bold uppercase tracking-wider text-muted">Consent the candidate gave (recorded with wording v1-2026-11)</span>
        <Checkbox label="Text messages (SMS)" checked={sms} onChange={setSms} />
        <Checkbox label="AI phone interview" checked={ai} onChange={setAi} />
        <Checkbox label="Call recording" checked={rec} onChange={setRec} />
        <span className="text-xs text-muted">Only tick what the candidate actually agreed to. No AI-call consent means the AI call button stays off.</span>
      </div>
    </Modal>
  );
}
