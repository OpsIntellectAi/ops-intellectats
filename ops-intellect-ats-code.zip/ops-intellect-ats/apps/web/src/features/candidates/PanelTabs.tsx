import { useMutation } from '@tanstack/react-query';
import { DataRequest, SensitiveFields } from './PrivateData';
import { useMemo, useState } from 'react';
import { Banner, Button, Chip } from '@/components/ui';
import { Empty, Modal, Select, TextArea, useToast } from '@/components/kit';
import { friendlyError, must, rpc } from '@/lib/api';
import { toCsv, downloadText } from '@/lib/csv';
import { formatPhone, STAGE_LABEL } from '@/lib/format';
import { stepTone } from '@/lib/rules';
import { supabase } from '@/lib/supabase';
import { dateTimeIn, relative, seconds } from '@/lib/time';
import type { Answer, StepDef, StepRow } from '@/lib/types';
import { ownerName, useInvalidate, useWorkspace } from '@/features/shell/context';
import { CallReviewButtons, PlayAnswer } from '@/features/calls/CallReview';
import { CallDetail } from '@/features/calls/CallsPage';
import type { AppDetail } from './data';

// ---------------- Timeline ----------------
export function TimelineTab({ d }: { d: AppDetail }) {
  const w = useWorkspace();
  const items = useMemo(() => {
    const list: { at: string; text: string; who?: string; tone: 'stage' | 'msg' | 'call' | 'step' }[] = [];
    for (const h of d.history) {
      list.push({
        at: h.changed_at,
        text: h.from_stage ? `Moved ${STAGE_LABEL[h.from_stage]} → ${STAGE_LABEL[h.to_stage]}` : `${h.note ?? 'Applied'}`,
        who: h.changed_by ? ownerName(w.team, h.changed_by) : 'System',
        tone: 'stage',
      });
    }
    for (const m of d.messages) {
      list.push({ at: m.created_at, text: `${m.direction === 'inbound' ? 'They texted' : m.is_automatic ? 'Automatic text' : 'Text sent'}: “${m.body.slice(0, 120)}${m.body.length > 120 ? '…' : ''}”`, tone: 'msg' });
    }
    for (const c of d.calls) {
      list.push({ at: c.started_at ?? c.created_at, text: `${c.via === 'ai' ? 'AI call' : 'Phone call'} · ${c.outcome.replace('_', ' ')} · ${seconds(c.duration_seconds)}`, tone: 'call' });
    }
    for (const s of d.steps) {
      if (s.status !== 'Not started') list.push({ at: s.changed_at, text: `Onboarding step → ${s.status}`, who: s.changed_by ? ownerName(w.team, s.changed_by) : undefined, tone: 'step' });
    }
    return list.sort((a, b) => b.at.localeCompare(a.at));
  }, [d, w.team]);
  if (!items.length) return <Empty>Nothing yet.</Empty>;
  const dot = { stage: 'bg-brand', msg: 'bg-info', call: 'bg-warn', step: 'bg-[#8a8d8a]' } as const;
  return (
    <ol className="flex flex-col gap-3">
      {items.map((it, i) => (
        <li key={i} className="flex gap-3">
          <span className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full ${dot[it.tone]}`} aria-hidden="true" />
          <div className="flex flex-col">
            <span className="text-sm">{it.text}</span>
            <span className="text-xs text-muted">
              {dateTimeIn(it.at, w.tz)} {it.who ? `· ${it.who}` : ''}
            </span>
          </div>
        </li>
      ))}
    </ol>
  );
}

// ---------------- Interview ----------------
export function InterviewTab({ d }: { d: AppDetail }) {
  const w = useWorkspace();
  const toast = useToast();
  const invalidate = useInvalidate();
  const lastAi = d.calls.find((c) => c.via === 'ai' && c.outcome === 'completed');
  const answers = lastAi ? d.answers.filter((a) => a.call_id === lastAi.id) : [];
  const review = useMutation({
    mutationFn: ({ a, result }: { a: Answer; result: 'yes' | 'no' }) => rpc('review_answer', { p_answer: a.id, p_result: result }),
    onSuccess: () => {
      invalidate();
      toast('Answer saved.');
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  if (!lastAi) return <Empty>No finished AI interview yet.</Empty>;
  return (
    <div className="flex flex-col gap-3">
      <span className="text-sm text-muted">
        AI interview {dateTimeIn(lastAi.started_at, w.tz)} · {seconds(lastAi.duration_seconds)} · script version pinned to this call
      </span>
      {answers.map((a) => {
        const waiting = a.result === 'needs_review' && !a.reviewed_at;
        return (
          <div key={a.id} className={`flex flex-col gap-2 rounded-xl border bg-white p-3 ${waiting ? 'border-[#EED9BF]' : 'border-line'}`}>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-sm font-semibold">{a.question_text}</span>
              <Chip tone={a.result === 'yes' ? 'ok' : a.result === 'no' ? 'bad' : a.result === 'needs_review' ? 'warn' : 'neutral'}>
                {a.result === 'needs_review' ? 'Needs review' : a.result[0]?.toUpperCase() + a.result.slice(1)}
                {a.reviewed_at ? ' · reviewed' : ''}
              </Chip>
            </div>
            <span className="text-sm text-muted">Heard: “{a.heard_text ?? '—'}”</span>
            <div className="flex flex-wrap items-center gap-2">
              <PlayAnswer call={lastAi} at={a.at_seconds} />
              {waiting && w.can('calls.review') ? (
                <>
                  <Button variant="primary" className="min-h-[36px]" disabled={review.isPending} onClick={() => review.mutate({ a, result: 'yes' })}>Accept as Yes</Button>
                  <Button className="min-h-[36px]" disabled={review.isPending} onClick={() => review.mutate({ a, result: 'no' })}>Mark No</Button>
                </>
              ) : null}
            </div>
          </div>
        );
      })}
      <CallReviewButtons call={lastAi} />
    </div>
  );
}

// ---------------- Calls ----------------
export function CallsTab({ d }: { d: AppDetail }) {
  const w = useWorkspace();
  const [open, setOpen] = useState<import('@/lib/types').CallRow | null>(null);
  if (!d.calls.length) return <Empty>No calls yet.</Empty>;
  return (
    <div className="flex flex-col gap-2">
      {open ? <CallDetail call={open} onClose={() => setOpen(null)} /> : null}
      {d.calls.map((c) => (
        <div key={c.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line bg-white p-3">
          <div className="flex flex-col">
            <span className="text-sm font-semibold">
              {c.via === 'ai' ? 'AI call' : 'Phone call'} · {c.outcome.replace('_', ' ')} · attempt {c.attempt_number}
            </span>
            <span className="text-xs text-muted">{dateTimeIn(c.started_at ?? c.created_at, w.tz)} · {seconds(c.duration_seconds)}</span>
            {c.summary ? <span className="mt-1 text-xs">{c.summary}</span> : null}
          </div>
          <div className="flex items-center gap-2">
            <Button className="min-h-[36px] px-3 text-xs" onClick={() => setOpen(c)}>Listen &amp; script</Button>
            {c.review_verdict ? <Chip tone={c.review_verdict === 'looks_right' ? 'ok' : 'bad'}>{c.review_verdict === 'looks_right' ? 'Looks right' : `Flagged: ${c.review_reason ?? ''}`}</Chip> : null}
            {c.via === 'ai' && c.outcome === 'completed' && !c.review_verdict ? <Chip tone="warn">Not reviewed</Chip> : null}
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------------- Onboarding ----------------
export function OnboardingTab({ d, defs }: { d: AppDetail; defs: StepDef[] }) {
  const w = useWorkspace();
  const toast = useToast();
  const invalidate = useInvalidate();
  const [waive, setWaive] = useState<{ step: StepRow; def: StepDef } | null>(null);
  const [why, setWhy] = useState('');
  const byDef = new Map(d.steps.map((s) => [s.step_def_id, s]));
  const canEdit = w.can('onboarding.update');

  const save = useMutation({
    mutationFn: async ({ step, patch }: { step: StepRow; patch: Partial<StepRow> }) =>
      must(supabase.from('onboarding_steps').update(patch).eq('id', step.id).select('id'), 'save this step'),
    onSuccess: (rows) => {
      if (Array.isArray(rows) && rows.length === 0) toast('Your access level cannot change onboarding steps.', 'bad');
      else toast('Step saved.');
      invalidate();
      setWaive(null);
      setWhy('');
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });

  if (!d.steps.length) return <Empty>Onboarding steps start when the candidate reaches Pre-onboarding.</Empty>;
  const phases = Array.from(new Set(defs.map((x) => x.phase)));
  return (
    <div className="flex flex-col gap-4">
      {!canEdit ? <div className="rounded-xl bg-info-soft px-4 py-2.5 text-sm font-medium text-info">View only.</div> : null}
      <span className="text-sm text-muted">Steps can run at the same time. Required steps must be done or waived (with a reason) before “Mark hired”.</span>
      {phases.map((ph) => (
        <div key={ph} className="flex flex-col gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-muted">{ph}</span>
          {defs
            .filter((x) => x.phase === ph)
            .map((def) => {
              const step = byDef.get(def.id);
              if (!step) return null;
              const tone = stepTone(def, step.status);
              const guidance = def.guidance[step.status];
              return (
                <div key={def.id} className="flex flex-col gap-2 rounded-xl border border-line bg-white p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-col">
                      <span className="text-sm font-semibold">
                        {def.name} {def.required ? '' : <span className="text-xs font-normal text-muted">(optional)</span>}
                      </span>
                      <span className="text-xs text-muted">
                        Owner: {def.owner_label} · {step.status === 'Not started' ? 'not started' : `${relative(step.changed_at)}${step.changed_by ? ` by ${ownerName(w.team, step.changed_by)}` : ''}`}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Chip tone={tone === 'neutral' ? 'neutral' : tone}>{step.status}</Chip>
                      {canEdit ? (
                        <Select
                          aria-label={`Status of ${def.name}`}
                          value={step.status}
                          onChange={(e) => {
                            const v = e.target.value;
                            if (v === 'Waived') setWaive({ step, def });
                            else save.mutate({ step, patch: { status: v, waived_reason: null } });
                          }}
                        >
                          {def.statuses.map((s) => (
                            <option key={s} value={s}>{s}</option>
                          ))}
                        </Select>
                      ) : null}
                    </div>
                  </div>
                  {guidance ? <Banner tone="warn">{guidance}</Banner> : null}
                  {step.waived_reason ? <span className="text-xs text-muted">Waived because: {step.waived_reason}</span> : null}
                  {canEdit ? <NoteField step={step} onSave={(note) => save.mutate({ step, patch: { note } })} /> : step.note ? <span className="text-xs">Note: {step.note}</span> : null}
                </div>
              );
            })}
        </div>
      ))}
      <Modal
        open={Boolean(waive)}
        title={`Waive “${waive?.def.name ?? ''}”`}
        onClose={() => setWaive(null)}
        footer={
          <>
            <Button onClick={() => setWaive(null)}>Cancel</Button>
            <Button variant="primary" disabled={why.trim().length < 4 || save.isPending} onClick={() => waive && save.mutate({ step: waive.step, patch: { status: 'Waived', waived_reason: why.trim() } })}>
              Waive step
            </Button>
          </>
        }
      >
        <TextArea label="Why is this step not needed? (required)" value={why} onChange={(e) => setWhy(e.target.value)} maxLength={300} />
      </Modal>
    </div>
  );
}

function NoteField({ step, onSave }: { step: StepRow; onSave: (note: string | null) => void }) {
  const [v, setV] = useState(step.note ?? '');
  const changed = v !== (step.note ?? '');
  return (
    <div className="flex gap-2">
      <input
        aria-label="Note"
        value={v}
        onChange={(e) => setV(e.target.value)}
        maxLength={500}
        placeholder="Add a note"
        className="min-h-[36px] flex-1 rounded-lg border border-line px-2 text-sm outline-none focus:border-brand"
      />
      {changed ? <Button className="min-h-[36px]" onClick={() => onSave(v.trim() || null)}>Save note</Button> : null}
    </div>
  );
}

// ---------------- Scheduling ----------------
export function SchedulingTab({ d }: { d: AppDetail }) {
  const w = useWorkspace();
  const toast = useToast();
  const invalidate = useInvalidate();
  const tz = d.row.time_zone || w.tz;
  const link = w.role?.scheduling_link ?? null;
  const [when, setWhen] = useState('');
  const book = useMutation({
    mutationFn: async (iso: string | null) => must(supabase.from('applications').update({ booked_call_at: iso }).eq('id', d.row.id).select('id'), 'book the call'),
    onSuccess: (_r, iso) => {
      invalidate();
      toast(iso ? 'AI call booked. Reminders will go out before it.' : 'Booking removed.');
      setWhen('');
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-col gap-1 rounded-xl border border-line bg-white p-3">
        <span className="text-sm font-semibold">Scheduling link</span>
        {link ? (
          <div className="flex flex-wrap items-center gap-2">
            <code className="rounded bg-canvas px-2 py-1 text-xs">{link}</code>
            <Button className="min-h-[36px]" onClick={() => void navigator.clipboard.writeText(link).then(() => toast('Link copied.'))}>Copy</Button>
          </div>
        ) : (
          <span className="text-sm text-muted">No scheduling link for this job role yet (Client setup → Scheduling links).</span>
        )}
      </div>
      <div className="flex flex-col gap-2 rounded-xl border border-line bg-white p-3">
        <span className="text-sm font-semibold">Book the AI call for them</span>
        <span className="text-xs text-muted">Pick the time in the candidate’s local time ({tz}).</span>
        {d.row.booked_call_at ? <span className="text-sm">Booked: <b>{dateTimeIn(d.row.booked_call_at, tz)}</b></span> : null}
        {w.can('candidates.act') ? (
          <div className="flex flex-wrap items-center gap-2">
            <input type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} aria-label="Call time" className="min-h-[40px] rounded-lg border border-line px-2 text-sm" />
            <Button variant="primary" className="min-h-[40px]" disabled={!when || book.isPending} onClick={() => book.mutate(localInputToIso(when, tz))}>
              Book
            </Button>
            {d.row.booked_call_at ? <Button className="min-h-[40px]" onClick={() => book.mutate(null)}>Remove booking</Button> : null}
          </div>
        ) : null}
      </div>
    </div>
  );
}

/** "2026-11-12T09:30" typed in zone tz → UTC ISO string. */
export function localInputToIso(local: string, tz: string): string {
  const [datePart, timePart] = local.split('T');
  const [y, mo, da] = (datePart ?? '').split('-').map(Number);
  const [h, mi] = (timePart ?? '').split(':').map(Number);
  const guess = Date.UTC(y ?? 1970, (mo ?? 1) - 1, da ?? 1, h ?? 0, mi ?? 0);
  const asTz = new Date(new Date(guess).toLocaleString('en-US', { timeZone: tz }));
  const asUtc = new Date(new Date(guess).toLocaleString('en-US', { timeZone: 'UTC' }));
  return new Date(guess - (asTz.getTime() - asUtc.getTime())).toISOString();
}

// ---------------- Candidate file ----------------
export function FileTab({ d }: { d: AppDetail }) {
  const w = useWorkspace();
  const r = d.row;
  const download = () => {
    const rows = [
      { field: 'Name', value: r.full_name },
      { field: 'Phone', value: formatPhone(r.phone_e164) },
      { field: 'Email', value: r.email ?? '' },
      { field: 'City', value: r.city ?? '' },
      { field: 'ZIP', value: r.zip ?? '' },
      { field: 'Client', value: w.client.name },
      { field: 'Station', value: w.station?.code ?? '' },
      { field: 'Job role', value: w.role?.name ?? '' },
      { field: 'Stage', value: STAGE_LABEL[r.stage] },
      { field: 'Owner', value: ownerName(w.team, r.owner_id) },
      { field: 'Source', value: r.source },
      { field: 'Applied', value: r.applied_at },
      ...d.consents.map((c) => ({ field: `Consent: ${c.consent_type}`, value: `${c.wording_version} · ${c.source} · ${c.given_at}${c.revoked_at ? ` · revoked ${c.revoked_at}` : ''}` })),
      ...d.history.map((h) => ({ field: 'Stage change', value: `${h.changed_at} · ${h.from_stage ?? 'new'} → ${h.to_stage}` })),
      ...d.messages.map((m) => ({ field: `Text ${m.direction}`, value: `${m.created_at} · ${m.body}` })),
      ...d.calls.map((c) => ({ field: 'Call', value: `${c.created_at} · ${c.via} · ${c.outcome} · ${c.duration_seconds ?? 0}s` })),
      ...d.answers.map((a) => ({ field: `Answer: ${a.question_text}`, value: `${a.result} · “${a.heard_text ?? ''}”` })),
    ];
    downloadText(`candidate-${r.full_name.replace(/\s+/g, '-').toLowerCase()}.csv`, toCsv(rows, ['field', 'value']));
    void rpc('log_action', { p_action: 'Candidate file downloaded', p_client: w.client.id, p_label: r.full_name, p_rows: rows.length });
  };
  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-[repeat(auto-fit,minmax(200px,1fr))] gap-2 text-sm">
        <Info k="Phone" v={formatPhone(r.phone_e164)} />
        <Info k="Email" v={r.email ?? '—'} />
        <Info k="City / ZIP" v={`${r.city ?? '—'} ${r.zip ?? ''}`} />
        <Info k="Source" v={r.source} />
        <Info k="Applied" v={dateTimeIn(r.applied_at, w.tz)} />
      </div>
      <div className="flex flex-col gap-1">
        <span className="text-sm font-semibold">Consents</span>
        {d.consents.length ? (
          d.consents.map((c) => (
            <span key={c.id} className="text-sm">
              <Chip tone={c.revoked_at ? 'bad' : 'ok'}>{c.consent_type.replace('_', ' ')}</Chip> {c.wording_version} · {c.source} · {dateTimeIn(c.given_at, w.tz)}
              {c.revoked_at ? ` · revoked ${dateTimeIn(c.revoked_at, w.tz)}` : ''}
            </span>
          ))
        ) : (
          <span className="text-sm text-muted">No consent recorded.</span>
        )}
      </div>
      <SensitiveFields candidateId={r.candidate_id} />
      <Button onClick={download}>Download candidate file (.csv)</Button>
      <span className="text-xs text-muted">Downloads are recorded in the activity log.</span>
      <DataRequest candidateId={r.candidate_id} name={r.full_name} onDeleted={() => w.openApp(null)} />
    </div>
  );
}

function Info({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex flex-col rounded-lg bg-white p-2.5">
      <span className="text-xs text-muted">{k}</span>
      <span className="font-medium">{v}</span>
    </div>
  );
}
