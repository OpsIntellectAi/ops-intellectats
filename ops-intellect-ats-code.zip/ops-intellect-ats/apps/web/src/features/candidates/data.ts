import { useQuery } from '@tanstack/react-query';
import { must } from '@/lib/api';
import { supabase } from '@/lib/supabase';
import type { Answer, AppRow, CallRow, Message, StepDef, StepRow, Template } from '@/lib/types';
import type { Stage } from '@/lib/format';

export interface HistoryRow {
  id: string;
  from_stage: Stage | null;
  to_stage: Stage;
  changed_by: string | null;
  note: string | null;
  changed_at: string;
}
export interface ConsentRow {
  id: string;
  consent_type: 'sms' | 'ai_call' | 'recording';
  wording_version: string;
  source: string;
  given_at: string;
  revoked_at: string | null;
}
export interface AppDetail {
  row: AppRow;
  history: HistoryRow[];
  messages: Message[];
  calls: CallRow[];
  answers: Answer[];
  steps: StepRow[];
  consents: ConsentRow[];
  elsewhere: number | null;
}

export function useAppDetail(applicationId: string) {
  return useQuery({
    queryKey: ['app', applicationId],
    queryFn: async (): Promise<AppDetail | null> => {
      const row = (await must(supabase.from('application_rows').select('*').eq('id', applicationId).maybeSingle(), 'load this candidate')) as AppRow | null;
      if (!row) return null;
      const [history, messages, calls, steps, consents] = await Promise.all([
        must(supabase.from('stage_history').select('id, from_stage, to_stage, changed_by, note, changed_at').eq('application_id', applicationId).order('changed_at'), 'load the timeline'),
        must(supabase.from('messages').select('id, application_id, direction, body, status, topics, is_automatic, sent_by, error_code, created_at').eq('application_id', applicationId).order('created_at'), 'load messages'),
        must(supabase.from('call_rows').select('*').eq('application_id', applicationId).order('created_at', { ascending: false }), 'load calls'),
        must(supabase.from('onboarding_steps').select('id, application_id, step_def_id, status, note, waived_reason, changed_by, changed_at').eq('application_id', applicationId), 'load onboarding'),
        must(supabase.from('consents').select('id, consent_type, wording_version, source, given_at, revoked_at').eq('candidate_id', row.candidate_id).order('given_at'), 'load consents'),
      ]);
      const callIds = (calls as CallRow[]).map((c) => c.id);
      const answers = callIds.length
        ? ((await must(supabase.from('call_answers').select('*').in('call_id', callIds).order('at_seconds'), 'load answers')) as Answer[])
        : [];
      const { data: elsewhere } = await supabase.rpc('applied_elsewhere', { p_candidate: row.candidate_id });
      return {
        row,
        history: history as HistoryRow[],
        messages: messages as Message[],
        calls: calls as CallRow[],
        answers,
        steps: steps as StepRow[],
        consents: consents as ConsentRow[],
        elsewhere: (elsewhere as number | null) ?? null,
      };
    },
  });
}

export function useStepDefs(clientId: string) {
  return useQuery({
    queryKey: ['stepdefs', clientId],
    queryFn: async () =>
      (await must(supabase.from('onboarding_step_defs').select('*').eq('client_id', clientId).order('sort_order'), 'load onboarding steps')) as StepDef[],
  });
}

export function useTemplates(clientId: string) {
  return useQuery({
    queryKey: ['templates', clientId],
    queryFn: async () =>
      (await must(supabase.from('message_templates').select('id, name, body, stages, is_scheduling_link').eq('client_id', clientId).order('name'), 'load templates')) as Template[],
  });
}

export function hasConsent(consents: ConsentRow[], type: ConsentRow['consent_type']): boolean {
  return consents.some((c) => c.consent_type === type && !c.revoked_at);
}
