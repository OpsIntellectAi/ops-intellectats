import { useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { Banner, Button, Field } from '@/components/ui';
import { Modal, useToast } from '@/components/kit';
import { friendlyError, must, rpc } from '@/lib/api';
import { formatPhone } from '@/lib/format';
import { supabase } from '@/lib/supabase';
import { useInvalidate, useWorkspace } from '@/features/shell/context';
import type { AppDetail } from './data';

/**
 * The DSP portal invite is sent BY HAND in the Amazon DSP portal (there is no API).
 * This modal gives the details to copy, opens the portal, and records "I sent it",
 * which marks the step Invited and moves the candidate to Onboarding.
 */
export function DspInviteModal({ d, onClose }: { d: AppDetail; onClose: () => void }) {
  const w = useWorkspace();
  const toast = useToast();
  const invalidate = useInvalidate();
  const r = d.row;
  const [email, setEmail] = useState(r.email ?? '');
  const [first, ...rest] = r.full_name.split(' ');
  const details = [
    `First name: ${first ?? ''}`,
    `Last name: ${rest.join(' ')}`,
    `Email: ${email}`,
    `Phone: ${formatPhone(r.phone_e164)}`,
    `Station: ${w.station?.code ?? ''}`,
    `Role: ${w.role?.name ?? ''}`,
  ].join('\n');

  const saveEmail = useMutation({
    mutationFn: async () => must(supabase.from('candidates').update({ email: email.trim().toLowerCase() }).eq('id', r.candidate_id).select('id'), 'save the email'),
    onSuccess: () => {
      invalidate();
      toast('Email saved.');
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  const sent = useMutation({
    mutationFn: () => rpc('mark_dsp_invite_sent', { p_application: r.id }),
    onSuccess: () => {
      invalidate();
      toast(`${first ?? 'Candidate'} marked Invited and moved to Onboarding.`);
      onClose();
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  const emailOk = /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.trim());

  return (
    <Modal
      open
      title="DSP portal invite (manual)"
      onClose={onClose}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" disabled={!emailOk || email.trim().toLowerCase() !== (r.email ?? '') || sent.isPending} onClick={() => sent.mutate()}>
            I sent it
          </Button>
        </>
      }
    >
      <ol className="flex list-decimal flex-col gap-1.5 pl-5 text-sm">
        <li>Check the email below (they must not have used it with Amazon before).</li>
        <li>Copy the details.</li>
        <li>Open the DSP portal and send the invite there.</li>
        <li>Come back and click “I sent it”.</li>
      </ol>
      <div className="flex items-end gap-2">
        <div className="flex-1">
          <Field label="Candidate email" value={email} onChange={(e) => setEmail(e.target.value)} type="email" />
        </div>
        {email.trim().toLowerCase() !== (r.email ?? '') ? (
          <Button disabled={!emailOk || saveEmail.isPending} onClick={() => saveEmail.mutate()}>Save email</Button>
        ) : null}
      </div>
      <pre className="whitespace-pre-wrap rounded-xl bg-canvas p-3 text-sm">{details}</pre>
      <div className="flex flex-wrap gap-2">
        <Button onClick={() => void navigator.clipboard.writeText(details).then(() => toast('Details copied.'))}>Copy details</Button>
        <a className="inline-flex min-h-[44px] items-center rounded-xl border border-line bg-white px-4 text-sm font-semibold" href="https://logistics.amazon.com" target="_blank" rel="noopener noreferrer">
          Open DSP portal ↗
        </a>
      </div>
      {!r.email ? <Banner tone="warn">Save the email first.</Banner> : null}
    </Modal>
  );
}
