import { useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { Banner, Button, Chip, Spinner } from '@/components/ui';
import { Drawer, Modal, Select, Tabs, TextArea, useToast } from '@/components/kit';
import { friendlyError, must } from '@/lib/api';
import { formatPhone, STAGE_LABEL, type Stage } from '@/lib/format';
import { hireCheck, NOT_INTERESTED_WAIT, shortlistCheck, STAGE_ORDER } from '@/lib/rules';
import { supabase } from '@/lib/supabase';
import { addDays, dateTimeIn, localClock, relative } from '@/lib/time';
import { ownerName, useInvalidate, useWorkspace } from '@/features/shell/context';
import { useAppDetail, useStepDefs, type AppDetail } from './data';
import { DspInviteModal } from './DspInviteModal';
import { CallsTab, FileTab, InterviewTab, OnboardingTab, SchedulingTab, TimelineTab } from './PanelTabs';
import { ChatBox } from '@/features/messages/ChatBox';
import { AiCallButton, PhoneCallButton } from '@/features/calls/AiCallButton';

type TabKey = 'timeline' | 'file' | 'calls' | 'interview' | 'onboarding' | 'scheduling';

export function CandidatePanel({ applicationId, onClose }: { applicationId: string; onClose: () => void }) {
  const q = useAppDetail(applicationId);
  return (
    <Drawer open onClose={onClose} title="Candidate">
      {q.isLoading ? <div className="p-6"><Spinner /></div> : null}
      {q.isError ? <div className="p-6"><Banner tone="bad">{(q.error as Error).message}</Banner></div> : null}
      {!q.isLoading && !q.data && !q.isError ? (
        <div className="flex flex-col gap-3 p-6">
          <Banner tone="info">This candidate is not in your scope (or no longer exists).</Banner>
          <Button onClick={onClose}>Close</Button>
        </div>
      ) : null}
      {q.data ? <PanelBody d={q.data} onClose={onClose} /> : null}
    </Drawer>
  );
}

function PanelBody({ d, onClose }: { d: AppDetail; onClose: () => void }) {
  const w = useWorkspace();
  const defsQ = useStepDefs(w.client.id);
  const [tab, setTab] = useState<TabKey>(d.row.stage === 'onboarding' || d.row.stage === 'pre_onboarding' ? 'onboarding' : d.answers.length ? 'interview' : 'timeline');
  const r = d.row;
  const firstName = r.full_name.split(' ')[0] ?? r.full_name;
  const tz = r.time_zone || w.tz;
  const reviewCount = r.answers_to_review + r.unreviewed_calls;

  return (
    <div className="flex flex-col gap-4 p-6 max-md:p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 flex-col gap-1">
          <h2 className="font-serif text-[34px] leading-tight">{r.full_name}</h2>
          <span className="text-sm text-muted">
            {formatPhone(r.phone_e164)} · {r.email ?? 'no email yet'} · {r.city ?? '—'} · their time {localClock(tz)}
          </span>
          <span className="text-sm text-muted">
            Applied {relative(r.applied_at)} via {r.source} · Owner: <b className="text-ink">{ownerName(w.team, r.owner_id)}</b>
          </span>
        </div>
        <Button variant="ghost" onClick={onClose} aria-label="Close panel">✕</Button>
      </div>

      <Stepper stage={r.stage} />

      <div className="flex flex-wrap gap-2">
        <Chip tone={r.stage === 'hired' ? 'ok' : r.stage === 'rejected' || r.stage === 'not_interested' ? 'bad' : 'info'}>{STAGE_LABEL[r.stage]}</Chip>
        {r.opted_out_at ? <Chip tone="bad">Opted out (STOP) · no texts or AI calls</Chip> : null}
        {r.is_landline ? <Chip tone="warn">Landline · no texts</Chip> : null}
        {r.lives_in_nyc ? <Chip tone="warn">Lives in NYC · AEDT rules</Chip> : null}
        {reviewCount > 0 ? <Chip tone="warn">{reviewCount} to review</Chip> : null}
        {d.elsewhere ? <Chip tone="info">Also applied to {d.elsewhere} other client{d.elsewhere > 1 ? 's' : ''}</Chip> : null}
        {r.not_interested_until ? <Chip>No contact until {r.not_interested_until}</Chip> : null}
        {r.said_yes_at && r.stage === 'interview' ? <Chip tone="ok">Said YES to an AI call</Chip> : null}
        {r.reschedule_requested_at && !r.booked_call_at ? <Chip tone="warn">Wants a new call time</Chip> : null}
        {r.no_response_at ? <Chip tone="warn">No response after 7 days</Chip> : null}
        {r.manual_call_needed ? <Chip tone="bad">Call them yourself (AI attempts used or asked for a person)</Chip> : null}
      </div>

      {r.booked_call_at ? (
        <Banner tone="info">
          AI call booked for {dateTimeIn(r.booked_call_at, tz)} (their time). Reminders go 2 h and 15 min before{' '}
          {new Date(r.booked_call_at).getTime() - 2 * 3_600_000 < Date.now() ? '(2 h reminder already past, skipped)' : ''}.
        </Banner>
      ) : null}

      <StageActions d={d} defsLoaded={defsQ.data ?? []} firstName={firstName} />

      <ChatBox
        row={r}
        backgroundPassed={d.steps.some((st) => {
          const def = (defsQ.data ?? []).find((x) => x.id === st.step_def_id);
          return def?.key === 'background' && def.done_statuses.includes(st.status);
        })}
      />

      <Tabs<TabKey>
        value={tab}
        onChange={setTab}
        tabs={[
          { key: 'timeline', label: 'Timeline' },
          { key: 'interview', label: 'Interview', count: d.answers.filter((a) => a.result === 'needs_review' && !a.reviewed_at).length || undefined },
          { key: 'calls', label: 'Calls', count: d.calls.length || undefined },
          { key: 'onboarding', label: 'Onboarding', count: r.steps_total ? r.steps_done : undefined },
          { key: 'scheduling', label: 'Scheduling' },
          { key: 'file', label: 'Candidate file' },
        ]}
      />
      {tab === 'timeline' ? <TimelineTab d={d} /> : null}
      {tab === 'interview' ? <InterviewTab d={d} /> : null}
      {tab === 'calls' ? <CallsTab d={d} /> : null}
      {tab === 'onboarding' ? <OnboardingTab d={d} defs={defsQ.data ?? []} /> : null}
      {tab === 'scheduling' ? <SchedulingTab d={d} /> : null}
      {tab === 'file' ? <FileTab d={d} /> : null}
    </div>
  );
}

function Stepper({ stage }: { stage: Stage }) {
  const idx = STAGE_ORDER.indexOf(stage);
  return (
    <ol className="flex flex-wrap items-center gap-1.5" aria-label="Progress">
      {STAGE_ORDER.map((s, i) => {
        const done = idx >= 0 && i < idx;
        const current = i === idx;
        return (
          <li key={s} className="flex items-center gap-1.5">
            <span
              className={`rounded-full px-3 py-1 text-xs font-bold ${current ? 'bg-brand text-white' : done ? 'bg-brand-soft text-brand' : 'bg-[#EFECE5] text-muted'}`}
              aria-current={current ? 'step' : undefined}
            >
              {done ? '✓ ' : ''}
              {STAGE_LABEL[s]}
            </span>
            {i < STAGE_ORDER.length - 1 ? <span className="text-muted" aria-hidden="true">›</span> : null}
          </li>
        );
      })}
    </ol>
  );
}

function StageActions({ d, defsLoaded, firstName }: { d: AppDetail; defsLoaded: import('@/lib/types').StepDef[]; firstName: string }) {
  const w = useWorkspace();
  const toast = useToast();
  const invalidate = useInvalidate();
  const r = d.row;
  const [ni, setNi] = useState(false);
  const [rej, setRej] = useState(false);
  const [dsp, setDsp] = useState(false);
  const [reason, setReason] = useState('');
  const [wait, setWait] = useState<number | null>(30);

  const update = useMutation({
    mutationFn: async (patch: Record<string, unknown>) => must(supabase.from('applications').update(patch).eq('id', r.id).select('id'), 'update this candidate'),
    onSuccess: (rows, patch) => {
      if (Array.isArray(rows) && rows.length === 0) {
        toast('Your access level cannot change this candidate.', 'bad');
        return;
      }
      invalidate();
      const s = patch.stage as Stage | undefined;
      toast(s ? `${firstName} moved to ${STAGE_LABEL[s]}.` : 'Saved.');
      setNi(false);
      setRej(false);
      setReason('');
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });

  const canAct = w.can('candidates.act');
  const canOnb = w.can('onboarding.update');
  const sl = shortlistCheck(r);
  const hc = hireCheck(defsLoaded, d.steps);
  const assignable = w.team.filter((t) => ['csr', 'supervisor', 'admin', 'super_admin'].includes(t.role));
  const rejReasons = w.client.client_settings?.reject_reasons?.length ? w.client.client_settings.reject_reasons : DEFAULT_REJECT_REASONS;
  const niReasons = w.client.client_settings?.not_interested_reasons?.length ? w.client.client_settings.not_interested_reasons : DEFAULT_NI_REASONS;

  if (!canAct && !canOnb && !w.can('candidates.assign')) {
    return <div className="rounded-xl bg-info-soft px-4 py-2.5 text-sm font-medium text-info">View only: your access level can look but not move candidates.</div>;
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      {canAct && w.on('ai_calls') ? <AiCallButton row={r} consents={d.consents} /> : null}
      {canAct && !r.opted_out_at && w.on('phone_calls') ? <PhoneCallButton row={r} /> : null}
      {r.stage === 'interview' && canAct ? (
        <Button variant="primary" disabled={!sl.ready || update.isPending} title={sl.reason ?? ''} onClick={() => update.mutate({ stage: 'shortlisted' })}>
          Shortlist
        </Button>
      ) : null}
      {r.stage === 'interview' && canAct && !sl.ready ? <span className="text-xs text-muted">{sl.reason}</span> : null}
      {r.stage === 'shortlisted' && canAct ? (
        <Button disabled={update.isPending} onClick={() => update.mutate({ stage: 'pre_onboarding' })}>Move to pre-onboarding</Button>
      ) : null}
      {(r.stage === 'shortlisted' || r.stage === 'pre_onboarding') && canOnb ? (
        <Button variant="primary" onClick={() => setDsp(true)}>DSP portal invite</Button>
      ) : null}
      {r.stage === 'onboarding' && canOnb ? (
        <Button variant="primary" disabled={!hc.ready || update.isPending} title={hc.ready ? '' : `Still to do: ${hc.missing.join(', ')}`} onClick={() => update.mutate({ stage: 'hired' })}>
          Mark hired
        </Button>
      ) : null}
      {r.stage === 'onboarding' && canOnb && !hc.ready ? <span className="text-xs text-muted">{hc.missing.length} required step{hc.missing.length > 1 ? 's' : ''} left</span> : null}
      {(r.stage === 'not_interested' || r.stage === 'rejected') && canAct ? (
        <Button onClick={() => update.mutate({ stage: 'interview', not_interested_reason: null, not_interested_until: null, rejection_reason: null })}>Reopen</Button>
      ) : null}
      {r.stage !== 'hired' && r.stage !== 'not_interested' && r.stage !== 'rejected' && canAct ? (
        <>
          <Button onClick={() => setNi(true)}>Not interested</Button>
          <Button variant="danger" onClick={() => setRej(true)}>Reject</Button>
        </>
      ) : null}
      {w.can('candidates.assign') ? (
        <Select
          aria-label="Owner"
          value={r.owner_id ?? ''}
          onChange={(e) => update.mutate({ owner_id: e.target.value || null })}
          className="ml-auto"
        >
          <option value="">Unassigned</option>
          {assignable.map((t) => (
            <option key={t.user_id} value={t.user_id}>{t.full_name}</option>
          ))}
        </Select>
      ) : null}

      <Modal
        open={ni}
        title={`${firstName} is not interested`}
        onClose={() => setNi(false)}
        footer={
          <>
            <Button onClick={() => setNi(false)}>Cancel</Button>
            <Button
              variant="primary"
              disabled={reason.trim().length < 3 || update.isPending}
              onClick={() =>
                update.mutate({
                  stage: 'not_interested',
                  not_interested_reason: reason.trim(),
                  not_interested_until: wait === null ? '9999-12-31' : addDays(new Date(), wait).toISOString().slice(0, 10),
                })
              }
            >
              Save
            </Button>
          </>
        }
      >
        <ReasonChips reasons={niReasons} value={reason} onPick={setReason} />
        <TextArea label="Reason (required)" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Pick a reason above or type your own" maxLength={300} />
        <Select label="Try again after" value={wait === null ? 'never' : String(wait)} onChange={(e) => setWait(e.target.value === 'never' ? null : Number(e.target.value))}>
          {NOT_INTERESTED_WAIT.map((o) => (
            <option key={o.label} value={o.days === null ? 'never' : String(o.days)}>{o.label}</option>
          ))}
        </Select>
        <span className="text-xs text-muted">No texts or calls go to them until then.</span>
      </Modal>
      <Modal
        open={rej}
        title={`Reject ${firstName}?`}
        onClose={() => setRej(false)}
        footer={
          <>
            <Button onClick={() => setRej(false)}>Cancel</Button>
            <Button variant="danger" disabled={reason.trim().length < 3 || update.isPending} onClick={() => update.mutate({ stage: 'rejected', rejection_reason: reason.trim() })}>
              Reject
            </Button>
          </>
        }
      >
        <Banner tone="warn">A person makes this decision. Never reject someone because an AI answer was unclear.</Banner>
        <ReasonChips reasons={rejReasons} value={reason} onPick={setReason} />
        <TextArea label="Reason (required)" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Pick a reason above or type your own" maxLength={300} />
      </Modal>
      {dsp ? <DspInviteModal d={d} onClose={() => setDsp(false)} /> : null}
    </div>
  );
}

export const DEFAULT_REJECT_REASONS = [
  'Under 21 or no valid driver licence',
  'Not authorized to work in the US',
  'Not comfortable with the pay',
  'Not comfortable with the schedule or weekends',
  'Lives too far / no way to commute',
  'Failed background check',
  'Failed drug test',
  'No-show for interview or training',
  'Duplicate application',
];
export const DEFAULT_NI_REASONS = ['Found another job', 'Pay too low', 'Schedule does not work', 'Location too far', 'Not ready to start yet', 'Did not reply after several tries', 'Wants a different role'];

/** One click fills the reason; the same reasons come up again and again. Super Admin edits the list in Client setup. */
function ReasonChips({ reasons, value, onPick }: { reasons: string[]; value: string; onPick: (r: string) => void }) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-xs font-bold uppercase tracking-wider text-muted">Common reasons</span>
      <div className="flex flex-wrap gap-1.5">
        {reasons.map((r) => (
          <button
            key={r}
            type="button"
            aria-pressed={value === r}
            onClick={() => onPick(r)}
            className={`min-h-[32px] rounded-full border px-3 text-xs font-semibold ${value === r ? 'border-brand bg-brand-soft text-brand' : 'border-line bg-canvas hover:border-brand'}`}
          >
            {r}
          </button>
        ))}
      </div>
    </div>
  );
}
