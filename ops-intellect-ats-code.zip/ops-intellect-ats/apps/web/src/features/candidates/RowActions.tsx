import { useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui';
import { useToast } from '@/components/kit';
import { callFunction, friendlyError, must } from '@/lib/api';
import { shortlistCheck } from '@/lib/rules';
import { supabase } from '@/lib/supabase';
import type { AppRow } from '@/lib/types';
import { useInvalidate, useWorkspace } from '@/features/shell/context';
import { useSendText } from '@/features/messages/data';
import { useTemplates } from './data';

export function RobotIcon() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="4" y="8" width="16" height="12" rx="3" /><path d="M12 4v4M9 13h.01M15 13h.01M9 17h6" />
    </svg>
  );
}
export function PhoneIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z" />
    </svg>
  );
}

const iconBtn = 'inline-flex h-10 w-10 items-center justify-center rounded-xl border border-line bg-white text-ink hover:border-brand disabled:cursor-not-allowed disabled:opacity-40';

/** Row buttons in the candidate list: AI call, phone call, Send link, Shortlist. */
export function RowActions({ row }: { row: AppRow }) {
  const w = useWorkspace();
  const toast = useToast();
  const invalidate = useInvalidate();
  const tq = useTemplates(w.client.id);
  const send = useSendText();
  const canAct = w.can('candidates.act');
  const ai = useMutation({
    mutationFn: () => callFunction<{ test: boolean; attempt: number }>('start-ai-call', { applicationId: row.id }),
    onSuccess: (r) => {
      toast(r.test ? `Test mode: practice AI call logged for ${row.full_name}.` : `AI call started for ${row.full_name}.`);
      invalidate();
    },
    onError: (e) => toast(e instanceof Error ? e.message : 'Could not start the AI call.', 'bad'),
  });
  const phone = useMutation({
    mutationFn: () => callFunction<{ test: boolean }>('call-actions', { action: 'csr_call', applicationId: row.id }),
    onSuccess: (r) => {
      toast(r.test ? 'Test mode: the call was logged (Twilio keys are not added yet).' : 'Your phone will ring now. Answer it to be connected.');
      invalidate();
    },
    onError: (e) => toast(e instanceof Error ? e.message : 'Could not start the call.', 'bad'),
  });
  const shortlist = useMutation({
    mutationFn: async () => must(supabase.from('applications').update({ stage: 'shortlisted' }).eq('id', row.id).select('id'), 'shortlist'),
    onSuccess: () => {
      toast(`${row.full_name.split(' ')[0]} shortlisted.`);
      invalidate();
    },
    onError: (e) => toast(friendlyError(e), 'bad'),
  });
  const linkTpl = (tq.data ?? []).find((t) => t.is_scheduling_link);
  const sl = shortlistCheck(row);
  const stop = (e: React.MouseEvent) => e.stopPropagation();
  if (!canAct) return null;
  return (
    <div className="flex items-center justify-end gap-1.5" onClick={stop}>
      {w.on('ai_calls') ? (
        <button type="button" className={iconBtn} title={row.stage !== 'interview' ? 'AI interviews are for the Interview stage' : row.opted_out_at ? 'Opted out' : 'AI call now'} aria-label={`AI call ${row.full_name}`} disabled={ai.isPending || row.stage !== 'interview' || Boolean(row.opted_out_at)} onClick={() => ai.mutate()}>
          {ai.isPending ? '…' : <RobotIcon />}
        </button>
      ) : null}
      {w.on('phone_calls') ? (
        <button type="button" className={iconBtn} title="Phone call (Twilio rings you first)" aria-label={`Phone call ${row.full_name}`} disabled={phone.isPending || Boolean(row.opted_out_at)} onClick={() => phone.mutate()}>
          {phone.isPending ? '…' : <PhoneIcon />}
        </button>
      ) : null}
      {row.stage === 'interview' && row.said_yes_at && !row.booked_call_at && linkTpl && w.can('messages.send') ? (
        <Button className="min-h-[40px] px-3" disabled={send.isPending} onClick={() => send.mutate({ ids: [row.id], body: linkTpl.body, confirmBulk: false }, { onSuccess: () => toast('Booking link sent.'), onError: (e) => toast(e instanceof Error ? e.message : 'Could not send.', 'bad') })}>
          Send link
        </Button>
      ) : null}
      {row.stage === 'interview' ? (
        <Button variant="primary" className="min-h-[40px] px-3" disabled={!sl.ready || shortlist.isPending} title={sl.reason ?? 'Move to Shortlisted'} onClick={() => shortlist.mutate()}>
          Shortlist
        </Button>
      ) : null}
    </div>
  );
}
