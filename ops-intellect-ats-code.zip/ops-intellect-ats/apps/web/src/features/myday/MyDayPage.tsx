import { useQuery } from '@tanstack/react-query';
import { useMemo } from 'react';
import { Button, Chip, Spinner } from '@/components/ui';
import { Bar, Empty, PageHeader, Stat } from '@/components/kit';
import { must } from '@/lib/api';
import { targetPace } from '@/lib/dashboard';
import { easternClock } from '@/lib/format';
import { buildQueues, nextActions, teamBoard } from '@/lib/queues';
import { supabase } from '@/lib/supabase';
import { relative } from '@/lib/time';
import { ownerName, useRows, useWorkspace } from '@/features/shell/context';
import { useNavigate } from 'react-router-dom';

export function MyDayPage() {
  const w = useWorkspace();
  const rowsQ = useRows();
  const rows = useMemo(() => rowsQ.data ?? [], [rowsQ.data]);
  const isCsr = w.access.role === 'csr';
  const mine = useMemo(() => nextActions(rows, isCsr ? w.access.user_id : null, 10), [rows, isCsr, w.access.user_id]);
  const board = useMemo(() => teamBoard(rows), [rows]);
  const q = useMemo(() => buildQueues(rows), [rows]);

  const targetQ = useQuery({
    queryKey: ['target', w.client.id, w.role?.id],
    enabled: Boolean(w.role) && w.can('reports.view'),
    queryFn: async () =>
      (await must(supabase.from('hiring_targets').select('hires, from_date, by_date').eq('client_id', w.client.id).eq('job_role_id', w.role?.id ?? '').maybeSingle(), 'load the target')) as {
        hires: number;
        from_date: string;
        by_date: string;
      } | null,
  });
  const hiredInWindow = targetQ.data ? rows.filter((r) => r.stage === 'hired' && r.stage_changed_at.slice(0, 10) >= (targetQ.data?.from_date ?? '')).length : 0;
  const pace = targetQ.data ? targetPace(targetQ.data, hiredInWindow) : null;

  const alerts: string[] = [];
  if (q.calls_to_review.length >= 5) alerts.push(`${q.calls_to_review.length} AI calls are waiting for review.`);
  if (q.shortlisted_no_next.length >= 3) alerts.push(`${q.shortlisted_no_next.length} shortlisted people have no next step for 24 h+.`);
  if (q.onboarding_stuck.length >= 3) alerts.push(`${q.onboarding_stuck.length} people are stuck in onboarding over 24 h.`);
  if (pace && pace.behindBy >= 2) alerts.push(`Hiring is ${pace.behindBy} behind the target pace.`);

  return (
    <div className="flex flex-col gap-5">
      <PageHeader eyebrow={`${w.client.name} · ${w.station?.code ?? ''} · ${w.role?.name ?? ''} · ${easternClock()}`} title={`Your day, ${(w.access.full_name || w.access.email).split(' ')[0]}`} />
      {w.on('alerts') ? <AlertBox fallback={alerts} /> : null}
      {rowsQ.isLoading ? <Spinner /> : null}

      {pace && targetQ.data ? (
        <div className="flex flex-col gap-2 rounded-card border border-line bg-white p-4">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <span className="text-[15px] font-bold">Hiring target · {w.role?.name}</span>
            <span className="text-sm text-muted">
              {hiredInWindow} of {targetQ.data.hires} hired · by {targetQ.data.by_date} · on pace: {pace.expected}
            </span>
          </div>
          <Bar value={hiredInWindow} max={targetQ.data.hires} tone={pace.behindBy >= 2 ? 'warn' : 'brand'} />
        </div>
      ) : null}

      {!isCsr ? (
        <div className="flex flex-col gap-2">
          <span className="text-[17px] font-bold">Team board</span>
          <div className="overflow-x-auto rounded-card border border-line bg-white">
            <table className="w-full min-w-[620px] text-left text-sm">
              <thead className="border-b border-line bg-[#FBFAF7] text-xs font-semibold text-muted">
                <tr>
                  <th className="px-3 py-2">Owner</th>
                  <th className="px-3 py-2">Open</th>
                  <th className="px-3 py-2">Overdue replies</th>
                  <th className="px-3 py-2">Not reviewed</th>
                  <th className="px-3 py-2">Calls today</th>
                  <th className="px-3 py-2">Hired 7 days</th>
                </tr>
              </thead>
              <tbody>
                {board.map((b) => (
                  <tr key={b.ownerId ?? 'none'} className="border-b border-line last:border-0">
                    <td className="px-3 py-2 font-semibold">{ownerName(w.team, b.ownerId)}</td>
                    <td className="px-3 py-2">{b.open}</td>
                    <td className="px-3 py-2">{b.overdue ? <Chip tone="warn">{b.overdue}</Chip> : 0}</td>
                    <td className="px-3 py-2">{b.notReviewed ? <Chip tone="warn">{b.notReviewed}</Chip> : 0}</td>
                    <td className="px-3 py-2">{b.callsToday}</td>
                    <td className="px-3 py-2">{b.hired7d}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-[repeat(auto-fit,minmax(160px,1fr))] gap-3">
          <Stat label="My open candidates" value={rows.filter((r) => r.owner_id === w.access.user_id && !['hired', 'rejected', 'not_interested'].includes(r.stage)).length} />
          <Stat label="Replies waiting" value={q.replies_waiting.length + q.said_yes.length} tone={q.replies_waiting.length ? 'warn' : 'neutral'} />
          <Stat label="To review" value={q.calls_to_review.length + q.answers_to_review.length} />
        </div>
      )}

      <div className="flex flex-col gap-2">
        <span className="text-[17px] font-bold">{isCsr ? 'Your next 10 actions' : 'Next actions'}</span>
        {mine.length === 0 && !rowsQ.isLoading ? <Empty>All caught up.</Empty> : null}
        {mine.map(({ row, queue }) => (
          <div key={row.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line bg-white p-3">
            <div className="flex flex-col">
              <span className="text-sm font-semibold">{row.full_name}</span>
              <span className="text-xs text-muted">
                {queue.label} · {row.last_in_at ? `replied ${relative(row.last_in_at)}` : `in stage ${relative(row.stage_changed_at)}`}
                {!isCsr ? ` · ${ownerName(w.team, row.owner_id)}` : ''}
              </span>
            </div>
            <Button variant="primary" className="min-h-[36px]" onClick={() => w.openApp(row.id)}>{queue.action}</Button>
          </div>
        ))}
      </div>
    </div>
  );
}

interface AlertRow {
  rule_id: string;
  rule_key: string;
  label: string;
  threshold: number;
  current_value: number;
  channel: string;
  recipients: string;
  last_sent_at: string | null;
}

const ALERT_LINK: Record<string, string> = {
  unreviewed_calls: '../calls',
  answer_rate: '../calls',
  shortlisted_no_reply: '../candidates',
  onboarding_stuck: '../candidates',
  behind_target: '../reports',
};

/** Alerts that are over their line right now (Reports & alerts sets the lines). */
function AlertBox({ fallback }: { fallback: string[] }) {
  const w = useWorkspace();
  const navigate = useNavigate();
  const q = useQuery({
    queryKey: ['alert-status', w.client.id],
    refetchInterval: 5 * 60_000,
    queryFn: async () => {
      const { data, error } = await supabase.rpc('alert_status', { p_client: w.client.id });
      if (error) return null;
      return data as AlertRow[];
    },
  });
  const list = q.data;
  if (q.isLoading) return null;
  if (!list) {
    return fallback.length ? (
      <div className="flex flex-col gap-1 rounded-card border border-[#EBC6BF] bg-bad-soft px-5 py-4">
        {fallback.map((a) => <span key={a} className="text-sm text-[#3D403D]">{a}</span>)}
      </div>
    ) : null;
  }
  if (!list.length) return null;
  const by = (c: string) => c.replace('_', ' + ').replace('both', 'text + email');
  return (
    <div role="alert" className="flex flex-col gap-2 rounded-card border border-[#EBC6BF] bg-bad-soft px-5 py-4">
      <span className="text-[15px] font-bold text-bad">{list.length} alert{list.length === 1 ? '' : 's'} for {w.client.name} · {w.role?.name ?? ''}</span>
      {list.map((a) => (
        <div key={a.rule_id} className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-sm text-[#3D403D]">
            {a.label} {a.rule_key === 'answer_rate' ? `${a.threshold}%` : a.threshold} · {a.current_value}{a.rule_key === 'answer_rate' ? '%' : ''} now · sent to {a.recipients} by {by(a.channel)}
            {a.last_sent_at ? <span className="text-muted"> · last sent {relative(a.last_sent_at)}</span> : null}
          </span>
          <Button className="min-h-[36px] px-3 text-xs" onClick={() => navigate(ALERT_LINK[a.rule_key] ?? '../reports', { relative: 'path' })}>See list</Button>
        </div>
      ))}
    </div>
  );
}
