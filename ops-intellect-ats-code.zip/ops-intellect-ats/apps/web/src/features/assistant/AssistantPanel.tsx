import { useMutation } from '@tanstack/react-query';
import { useEffect, useRef, useState } from 'react';
import { Drawer } from '@/components/kit';
import { Button } from '@/components/ui';
import { callFunction } from '@/lib/api';
import { useWorkspace } from '@/features/shell/context';

interface Turn { q: string; a: string | null; error?: boolean }

const EXAMPLES = ['How many shortlisted this week?', 'Who hasn\'t received their DSP invite?', 'What is our AI call answer rate?', 'Show the hiring funnel'];

/** AI recruitment assistant: answers only from data this person can already see. */
export function AssistantButton() {
  const w = useWorkspace();
  const [open, setOpen] = useState(false);
  if (!w.can('assistant.use')) return null;
  return (
    <>
      <Button variant="primary" className="fixed bottom-4 right-4 z-30 shadow-lg max-md:bottom-3 max-md:right-3" onClick={() => setOpen(true)}>
        ✦ Ask the assistant
      </Button>
      <Drawer open={open} onClose={() => setOpen(false)} title="Recruitment assistant">
        <div className="flex items-center justify-between border-b border-line bg-white px-4 py-3">
          <h2 className="font-serif text-2xl">Recruitment assistant</h2>
          <Button variant="ghost" onClick={() => setOpen(false)} aria-label="Close assistant">✕</Button>
        </div>
        <AssistantChat />
      </Drawer>
    </>
  );
}

function AssistantChat() {
  const w = useWorkspace();
  const [turns, setTurns] = useState<Turn[]>([]);
  const [q, setQ] = useState('');
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => {
    end.current?.scrollIntoView?.({ block: 'end' });
  }, [turns]);
  const ask = useMutation({
    mutationFn: (question: string) => callFunction<{ answer: string }>('assistant', { clientId: w.client.id, jobRoleId: w.role?.id ?? null, question }),
    onSuccess: (r) => setTurns((t) => t.map((x, i) => (i === t.length - 1 ? { ...x, a: r.answer } : x))),
    onError: (e) => setTurns((t) => t.map((x, i) => (i === t.length - 1 ? { ...x, a: e instanceof Error ? e.message : 'Could not answer.', error: true } : x))),
  });
  const send = (text: string) => {
    const s = text.trim();
    if (s.length < 3 || ask.isPending) return;
    setTurns((t) => [...t, { q: s, a: null }]);
    setQ('');
    ask.mutate(s);
  };
  return (
    <div className="flex h-full flex-col gap-3 p-4">
      <p className="text-xs text-muted">
        Answers use only {w.client.name} · {w.role?.name ?? 'all roles'} data that you can already see. Every question is logged. The assistant never decides who to hire.
      </p>
      <div className="flex flex-1 flex-col gap-3 overflow-y-auto">
        {turns.length === 0 ? (
          <div className="flex flex-wrap gap-2">
            {EXAMPLES.map((x) => <button key={x} type="button" onClick={() => send(x)} className="min-h-[36px] rounded-full border border-line bg-white px-3 text-sm hover:border-brand">{x}</button>)}
          </div>
        ) : null}
        {turns.map((t, i) => (
          <div key={i} className="flex flex-col gap-1.5">
            <div className="self-end rounded-2xl bg-brand-soft px-3 py-2 text-sm">{t.q}</div>
            <div className={`self-start whitespace-pre-wrap rounded-2xl px-3 py-2 text-sm ${t.error ? 'bg-bad-soft text-bad' : 'bg-canvas'}`}>{t.a ?? 'Thinking…'}</div>
          </div>
        ))}
        <div ref={end} />
      </div>
      <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); send(q); }}>
        <input aria-label="Ask a question" value={q} maxLength={500} onChange={(e) => setQ(e.target.value)} placeholder="Ask about your candidates…" className="min-h-[44px] flex-1 rounded-xl border border-line px-3 text-sm" />
        <Button variant="primary" type="submit" disabled={q.trim().length < 3 || ask.isPending}>Ask</Button>
      </form>
    </div>
  );
}
