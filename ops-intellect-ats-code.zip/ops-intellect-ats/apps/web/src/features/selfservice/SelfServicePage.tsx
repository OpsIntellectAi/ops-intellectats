import { useMutation, useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Banner, Button, Card, CenterPage, Logo, Spinner } from '@/components/ui';
import { supabase } from '@/lib/supabase';
import { dateTimeIn } from '@/lib/time';
import { localInputToIso } from '@/features/candidates/PanelTabs';

interface SelfData {
  firstName: string;
  role: string;
  client: string;
  address: string | null;
  stage: string;
  bookedAt: string | null;
  timeZone: string;
  window: { start: string; end: string };
  canBook: boolean;
  steps: { name: string; status: string; done: boolean }[];
}

async function call<T>(body: Record<string, unknown>): Promise<T> {
  const { data, error } = await supabase.functions.invoke('self-service', { body });
  if (error) {
    const ctx = (error as { context?: Response }).context;
    const b = ctx ? ((await ctx.json().catch(() => null)) as { error?: { message?: string } } | null) : null;
    throw new Error(b?.error?.message ?? 'Something went wrong. Please try again.');
  }
  return data as T;
}

/** Candidate page (phone-first): see/reschedule the AI call, upload a licence photo, see the checklist. */
export function SelfServicePage() {
  const { token = '' } = useParams();
  const valid = /^[0-9a-f]{36}$/.test(token);
  const q = useQuery({ queryKey: ['self', token], enabled: valid, retry: false, queryFn: () => call<SelfData>({ action: 'get', token }) });
  const [when, setWhen] = useState('');
  const [msg, setMsg] = useState<{ tone: 'ok' | 'bad' | 'info'; text: string } | null>(null);
  const book = useMutation({
    mutationFn: (at: string | null) => (at ? call({ action: 'book', token, at }) : call({ action: 'cancel', token })),
    onSuccess: () => { setMsg({ tone: 'ok', text: 'Saved. We will text you reminders before the call.' }); void q.refetch(); },
    onError: (e) => setMsg({ tone: 'bad', text: e instanceof Error ? e.message : 'Could not save.' }),
  });
  const person = useMutation({
    mutationFn: () => call({ action: 'ask_person', token }),
    onSuccess: () => setMsg({ tone: 'ok', text: 'Thanks. A recruiter will call you instead of the AI assistant.' }),
    onError: (e) => setMsg({ tone: 'bad', text: e instanceof Error ? e.message : 'Could not save.' }),
  });
  const upload = useMutation({
    mutationFn: async (file: File) => {
      if (file.size > 10 * 1024 * 1024) throw new Error('Please use a photo under 10 MB.');
      const ext = (file.name.split('.').pop() ?? 'jpg').toLowerCase();
      if (!['jpg', 'jpeg', 'png', 'heic', 'pdf'].includes(ext)) throw new Error('Please upload a JPG, PNG, HEIC or PDF.');
      const r = await call<{ signedUrl: string }>({ action: 'upload_url', token, ext });
      const res = await fetch(r.signedUrl, { method: 'PUT', body: file, headers: { 'content-type': file.type || 'application/octet-stream' } });
      if (!res.ok) throw new Error('Upload failed. Please try again.');
    },
    onSuccess: () => setMsg({ tone: 'ok', text: 'Licence photo received. Thank you!' }),
    onError: (e) => setMsg({ tone: 'bad', text: e instanceof Error ? e.message : 'Upload failed.' }),
  });

  if (!valid) return <Shell><Banner tone="bad">This link is not valid.</Banner></Shell>;
  if (q.isLoading) return <Shell><Spinner /></Shell>;
  if (q.error || !q.data) return <Shell><Banner tone="bad">{q.error instanceof Error ? q.error.message : 'This link is not active.'}</Banner></Shell>;
  const d = q.data;
  return (
    <Shell>
      <h1 className="font-serif text-[30px] leading-tight">Hi {d.firstName}</h1>
      <p className="text-sm text-muted">{d.role} · {d.client}{d.address ? ` · ${d.address}` : ''}</p>
      {msg ? <Banner tone={msg.tone}>{msg.text}</Banner> : null}

      {d.stage === 'interview' ? (
        <section className="flex flex-col gap-2">
          <h2 className="text-base font-bold">Your short AI interview</h2>
          {d.bookedAt ? <p className="text-sm">Booked for <b>{dateTimeIn(d.bookedAt, d.timeZone)}</b> (your time).</p> : <p className="text-sm">Pick a time between {d.window.start} and {d.window.end} your time.</p>}
          {d.canBook ? (
            <>
              <input aria-label="Call time" type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} className="min-h-[44px] rounded-xl border border-line px-3" />
              <div className="flex flex-wrap gap-2">
                <Button variant="primary" disabled={!when || book.isPending} onClick={() => book.mutate(localInputToIso(when, d.timeZone))}>{d.bookedAt ? 'Move my call' : 'Book my call'}</Button>
                {d.bookedAt ? <Button disabled={book.isPending} onClick={() => book.mutate(null)}>Cancel booking</Button> : null}
              </div>
            </>
          ) : (
            <p className="text-sm text-muted">Booking online is not available. Please reply to our text.</p>
          )}
          <p className="text-xs text-muted">The call is with an AI assistant and is recorded. A person reviews every interview and makes every decision.</p>
          <button type="button" className="self-start text-sm font-semibold text-brand underline" disabled={person.isPending} onClick={() => person.mutate()}>
            I'd like to talk to a person instead
          </button>
        </section>
      ) : null}

      <section className="flex flex-col gap-2">
        <h2 className="text-base font-bold">Driver's licence photo</h2>
        <label className="inline-flex min-h-[44px] cursor-pointer items-center justify-center rounded-xl border border-line bg-white px-4 text-sm font-semibold">
          {upload.isPending ? 'Uploading…' : 'Upload a photo'}
          <input type="file" accept="image/*,.pdf" className="sr-only" onChange={(e) => { const f = e.target.files?.[0]; if (f) upload.mutate(f); }} />
        </label>
        <p className="text-xs text-muted">Stored privately. Only the hiring team can open it.</p>
      </section>

      {d.steps.length ? (
        <section className="flex flex-col gap-1.5">
          <h2 className="text-base font-bold">Your onboarding checklist</h2>
          {d.steps.map((s) => (
            <div key={s.name} className="flex items-center justify-between gap-2 rounded-lg bg-canvas px-3 py-2 text-sm">
              <span>{s.done ? '✓ ' : ''}{s.name}</span>
              <span className={s.done ? 'font-semibold text-brand' : 'text-muted'}>{s.status}</span>
            </div>
          ))}
        </section>
      ) : null}
      <p className="text-xs text-muted">Reply STOP to our texts at any time to stop messages.</p>
    </Shell>
  );
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <CenterPage>
      <Card className="flex w-full max-w-[440px] flex-col gap-4 p-6 max-sm:p-4">
        <Logo />
        {children}
      </Card>
    </CenterPage>
  );
}
