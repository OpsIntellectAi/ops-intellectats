import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode } from 'react';
import { forwardRef } from 'react';

type Variant = 'primary' | 'default' | 'ghost' | 'danger';

const variantClass: Record<Variant, string> = {
  primary: 'bg-brand text-white hover:bg-brand-dark border border-brand',
  default: 'bg-white text-ink border border-line hover:border-[#CFCAC0]',
  ghost: 'bg-transparent text-ink border border-transparent hover:bg-black/5',
  danger: 'bg-bad-soft text-bad border border-[#EBC6BF] hover:bg-[#F4DDD8]',
};

export function Button({
  variant = 'default',
  className = '',
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return (
    <button
      type="button"
      {...rest}
      className={`inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand disabled:cursor-not-allowed disabled:opacity-50 ${variantClass[variant]} ${className}`}
    />
  );
}

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-card border border-line bg-white ${className}`}>{children}</div>;
}

type Tone = 'ok' | 'warn' | 'bad' | 'info' | 'neutral';
const toneClass: Record<Tone, string> = {
  ok: 'bg-brand-soft text-brand',
  warn: 'bg-warn-soft text-warn',
  bad: 'bg-bad-soft text-bad',
  info: 'bg-info-soft text-info',
  neutral: 'bg-[#EFECE5] text-[#3D403D]',
};

export function Chip({ tone = 'neutral', children }: { tone?: Tone; children: ReactNode }) {
  return (
    <span className={`inline-flex h-6 items-center rounded-full px-2.5 text-xs font-semibold ${toneClass[tone]}`}>
      {children}
    </span>
  );
}

export function Banner({ tone = 'info', children }: { tone?: Tone; children: ReactNode }) {
  return (
    <div role={tone === 'bad' ? 'alert' : 'status'} className={`rounded-xl px-4 py-3 text-sm font-medium leading-relaxed ${toneClass[tone]}`}>
      {children}
    </div>
  );
}

export const Field = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string }>(
  function Field({ label, error, id, className = '', ...rest }, ref) {
    const inputId = id ?? rest.name;
    return (
      <label htmlFor={inputId} className="flex flex-col gap-1.5 text-sm font-semibold text-[#3D403D]">
        {label}
        <input
          ref={ref}
          id={inputId}
          {...rest}
          aria-invalid={error ? 'true' : undefined}
          className={`min-h-[44px] rounded-xl border bg-white px-3 text-[15px] font-normal text-ink outline-none focus:border-brand focus:ring-2 focus:ring-brand/20 ${error ? 'border-bad' : 'border-line'} ${className}`}
        />
        {error ? <span className="text-xs font-semibold text-bad">{error}</span> : null}
      </label>
    );
  },
);

export function Logo() {
  return (
    <div className="flex items-center gap-2.5">
      <div className="flex h-8 w-8 items-center justify-center rounded-[9px] bg-brand" aria-hidden="true">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4 16l5-6 4 4 7-9" />
        </svg>
      </div>
      <div className="flex flex-col leading-tight">
        <span className="text-[15px] font-bold">Ops Intellect</span>
        <span className="text-xs text-muted">ATS</span>
      </div>
    </div>
  );
}

export function Spinner({ label = 'Loading…' }: { label?: string }) {
  return (
    <div className="flex items-center gap-3 text-sm text-muted" role="status">
      <span className="h-5 w-5 animate-spin rounded-full border-2 border-line border-t-brand" aria-hidden="true" />
      {label}
    </div>
  );
}

export function CenterPage({ children }: { children: ReactNode }) {
  return <main className="flex min-h-screen items-center justify-center bg-canvas p-4">{children}</main>;
}
