import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from 'react';

export function Select({
  label,
  className = '',
  children,
  ...rest
}: SelectHTMLAttributes<HTMLSelectElement> & { label?: string }) {
  const el = (
    <select
      {...rest}
      className={`min-h-[40px] rounded-lg border border-line bg-white px-2 text-sm text-ink outline-none focus:border-brand focus:ring-2 focus:ring-brand/20 disabled:opacity-60 ${className}`}
    >
      {children}
    </select>
  );
  if (!label) return el;
  return (
    <label className="flex flex-col gap-1 text-xs font-semibold text-[#3D403D]">
      {label}
      {el}
    </label>
  );
}

export function TextArea({ label, className = '', ...rest }: TextareaHTMLAttributes<HTMLTextAreaElement> & { label?: string }) {
  return (
    <label className="flex flex-col gap-1.5 text-sm font-semibold text-[#3D403D]">
      {label}
      <textarea
        {...rest}
        className={`min-h-[88px] rounded-xl border border-line bg-white px-3 py-2 text-[15px] font-normal text-ink outline-none focus:border-brand focus:ring-2 focus:ring-brand/20 ${className}`}
      />
    </label>
  );
}

export function Checkbox({ label, checked, onChange, disabled }: { label: ReactNode; checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <label className={`flex items-start gap-2 text-sm ${disabled ? 'opacity-60' : ''}`}>
      <input type="checkbox" className="mt-0.5 h-4 w-4 accent-brand" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <span>{label}</span>
    </label>
  );
}

/** Accessible modal: focus moves in, Escape closes, page behind does not scroll. */
export function Modal({
  open,
  title,
  onClose,
  children,
  footer,
  wide = false,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    ref.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div
        ref={ref}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={`flex max-h-[90vh] w-full flex-col rounded-card border border-line bg-white shadow-xl outline-none ${wide ? 'max-w-[860px]' : 'max-w-[520px]'}`}
      >
        <div className="flex items-center justify-between gap-3 border-b border-line px-5 py-4">
          <h2 className="text-[17px] font-bold">{title}</h2>
          <button type="button" onClick={onClose} aria-label="Close" className="flex h-9 w-9 items-center justify-center rounded-lg text-muted hover:bg-black/5">
            ✕
          </button>
        </div>
        <div className="flex flex-col gap-4 overflow-y-auto px-5 py-4">{children}</div>
        {footer ? <div className="flex flex-wrap justify-end gap-2 border-t border-line px-5 py-3">{footer}</div> : null}
      </div>
    </div>
  );
}

/** Right-side panel (candidate panel). Full screen on phones. */
export function Drawer({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-black/20" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <aside role="dialog" aria-modal="true" aria-label={title} className="flex h-full w-full max-w-[760px] flex-col overflow-y-auto bg-canvas shadow-2xl">
        {children}
      </aside>
    </div>
  );
}

export function Tabs<T extends string>({
  tabs,
  value,
  onChange,
}: {
  tabs: { key: T; label: string; count?: number }[];
  value: T;
  onChange: (k: T) => void;
}) {
  return (
    <div role="tablist" className="flex flex-wrap gap-1 rounded-xl bg-[#EFECE5] p-1">
      {tabs.map((t) => (
        <button
          key={t.key}
          type="button"
          role="tab"
          aria-selected={value === t.key}
          onClick={() => onChange(t.key)}
          className={`flex min-h-[36px] items-center gap-1.5 rounded-lg px-3 text-sm font-semibold ${value === t.key ? 'bg-white text-ink shadow-sm' : 'text-muted hover:text-ink'}`}
        >
          {t.label}
          {t.count !== undefined ? <span className={`rounded-full px-1.5 text-xs ${value === t.key ? 'bg-brand-soft text-brand' : 'bg-white/70'}`}>{t.count}</span> : null}
        </button>
      ))}
    </div>
  );
}

export function Stat({ label, value, sub, onClick, tone = 'neutral' }: { label: string; value: ReactNode; sub?: ReactNode; onClick?: () => void; tone?: 'neutral' | 'warn' | 'bad' | 'ok' }) {
  const ring = tone === 'bad' ? 'border-[#EBC6BF]' : tone === 'warn' ? 'border-[#EED9BF]' : tone === 'ok' ? 'border-[#C9DED8]' : 'border-line';
  const Tag = onClick ? 'button' : 'div';
  return (
    <Tag
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      className={`flex flex-col gap-1 rounded-card border ${ring} bg-white p-4 text-left ${onClick ? 'transition-colors hover:border-brand' : ''}`}
    >
      <span className="text-xs font-semibold text-muted">{label}</span>
      <span className="font-serif text-[34px] leading-none">{value}</span>
      {sub ? <span className="text-xs text-muted">{sub}</span> : null}
    </Tag>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="rounded-xl border border-dashed border-line bg-white/60 p-6 text-center text-sm text-muted">{children}</div>;
}

export function ViewOnly({ children }: { children?: ReactNode }) {
  return (
    <div role="status" className="rounded-xl bg-info-soft px-4 py-2.5 text-sm font-medium text-info">
      {children ?? 'View only: your access level can look but not change this.'}
    </div>
  );
}

export function SectionTitle({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-2">
      <h2 className="text-[17px] font-bold">{children}</h2>
      {right}
    </div>
  );
}

export function PageHeader({ eyebrow, title, right }: { eyebrow?: ReactNode; title: string; right?: ReactNode }) {
  return (
    <header className="flex flex-wrap items-end justify-between gap-3">
      <div className="flex flex-col gap-1">
        {eyebrow ? <span className="text-[13px] text-muted">{eyebrow}</span> : null}
        <h1 className="font-serif text-[38px] leading-tight max-md:text-[30px]">{title}</h1>
      </div>
      {right ? <div className="flex flex-wrap gap-2">{right}</div> : null}
    </header>
  );
}

// ---------- toasts ----------
interface ToastItem {
  id: number;
  text: string;
  tone: 'ok' | 'bad';
}
const ToastCtx = createContext<(text: string, tone?: 'ok' | 'bad') => void>(() => undefined);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const push = useCallback((text: string, tone: 'ok' | 'bad' = 'ok') => {
    const id = Date.now() + Math.random();
    setItems((l) => [...l, { id, text, tone }]);
    window.setTimeout(() => setItems((l) => l.filter((t) => t.id !== id)), tone === 'bad' ? 7000 : 3500);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div aria-live="polite" className="pointer-events-none fixed bottom-4 left-1/2 z-[60] flex -translate-x-1/2 flex-col gap-2">
        {items.map((t) => (
          <div key={t.id} className={`pointer-events-auto rounded-xl px-4 py-3 text-sm font-semibold shadow-lg ${t.tone === 'bad' ? 'bg-bad text-white' : 'bg-ink text-white'}`}>
            {t.text}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function useToast() {
  return useContext(ToastCtx);
}

/** Simple bar for charts without a chart library. */
export function Bar({ value, max, tone = 'brand' }: { value: number; max: number; tone?: 'brand' | 'warn' | 'info' }) {
  const pct = max > 0 ? Math.max(2, Math.round((value / max) * 100)) : 0;
  const color = tone === 'warn' ? 'bg-warn' : tone === 'info' ? 'bg-info' : 'bg-brand';
  return (
    <div className="h-2.5 w-full rounded-full bg-[#EFECE5]" aria-hidden="true">
      <div className={`h-2.5 rounded-full ${color}`} style={{ width: `${value > 0 ? pct : 0}%` }} />
    </div>
  );
}
