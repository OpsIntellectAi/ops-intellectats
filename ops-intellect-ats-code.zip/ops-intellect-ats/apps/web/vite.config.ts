import { fileURLToPath, URL } from 'node:url';
import react from '@vitejs/plugin-react';
import { sentryVitePlugin } from '@sentry/vite-plugin';
import type { PluginOption } from 'vite';
import { defineConfig } from 'vitest/config';

// Source maps are built only when they can be uploaded privately to Sentry, and are then
// deleted from dist/ so they are never served to the public.
const sentryUpload = Boolean(process.env.SENTRY_AUTH_TOKEN && process.env.SENTRY_ORG && process.env.SENTRY_PROJECT);

export default defineConfig(({ mode }) => {
  const plugins: PluginOption[] = [react()];
  if (sentryUpload) {
    plugins.push(
      sentryVitePlugin({
        org: process.env.SENTRY_ORG,
        project: process.env.SENTRY_PROJECT,
        authToken: process.env.SENTRY_AUTH_TOKEN,
        sourcemaps: { filesToDeleteAfterUpload: ['./dist/**/*.map'] },
        telemetry: false,
      }),
    );
  }
  return {
    plugins,
    resolve: { alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) } },
    // Only these three variables may ever reach the browser (see scripts/check-secrets.mjs).
    envPrefix: 'VITE_',
    build: {
      target: 'es2022',
      minify: 'esbuild',
      sourcemap: sentryUpload ? 'hidden' : false,
      chunkSizeWarningLimit: 900,
      // Libraries change rarely: separate files stay cached in the browser between releases.
      rollupOptions: {
        output: {
          manualChunks: {
            react: ['react', 'react-dom', 'react-router-dom'],
            supabase: ['@supabase/supabase-js'],
            query: ['@tanstack/react-query', 'zod'],
          },
        },
      },
    },
    esbuild: mode === 'production' ? { drop: ['console', 'debugger'], legalComments: 'none' } : {},
    server: {
      port: 5173,
      strictPort: true,
      // Local / Codespace only: the browser reaches local Supabase through /supabase.
      proxy: {
        '/supabase': {
          target: 'http://127.0.0.1:54321',
          changeOrigin: true,
          ws: true,
          rewrite: (path: string) => path.replace(/^\/supabase/, ''),
        },
      },
    },
    test: { environment: 'node', include: ['src/**/*.test.ts'] },
  };
});
